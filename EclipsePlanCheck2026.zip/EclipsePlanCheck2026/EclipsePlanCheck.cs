using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using EclipsePlanCheck;
using System.Drawing;
using EclipsePlanCheck.Helpers;
using System.Diagnostics;
using System.Threading;
using System.Windows.Threading;

// TODO: Replace the following version attributes by creating AssemblyInfo.cs. You can do this in the properties of the Visual Studio project.
[assembly: AssemblyVersion("1.1.16.0")]
[assembly: AssemblyFileVersion("1.1.16.0")]
//[assembly: AssemblyInformationalVersion("1.0")]

// TODO: Uncomment the following line if the script requires write access.
// [assembly: ESAPIScript(IsWriteable = true)]

namespace VMS.TPS
{
  public class Script
  {
    public Script()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    public void Execute(ScriptContext context /*, System.Windows.Window window, ScriptEnvironment environment*/)
    {
            //Keep track of elapsed time for alle elements:

            List<ElapsedTimeStatistic> elapsedTimeStatistics = new List<ElapsedTimeStatistic>();
            ElapsedTimeStatistic elapsedTimeStatistic = new ElapsedTimeStatistic { ElapsedTime = 0, TaskName = "" };

           //StopWatch elapsed time
            var stopWatchMain = new Stopwatch();
            stopWatchMain.Start();

            //---------------------------------------
            //---------------------------------------
            // 1 Sanity Check (CT exist, structure set exist, plan exist, fractionation exist, dose exist ? etc.). used to decide which checks to go through with and wich ones to skip
            //---------------------------------------
            //---------------------------------------

            //Set patient Context
            #region "Constructor 1 -Inputkontroll og errorhandling 2"

            ////StopWatch elapsed time
            //var stopWatchTemp = new Stopwatch();
            //stopWatchTemp.Start();

            PatientContext patientContext = PatientContextExtension.GetPatientContext(context);

            // Exit program if no patient
            if (patientContext.SanityLevel == Constants.SanityLevelNoPatient)
            {
                ErrorHandlingExtension.ErrorDog(patientContext.SanityDescription);
                return;
            }

            ////Elapsed time
            //stopWatchTemp.Stop();
            //elapsedTimeStatistic.TaskName = "PatientContext";
            //elapsedTimeStatistic.ElapsedTime = stopWatchTemp.ElapsedMilliseconds;
            //elapsedTimeStatistics.Add(elapsedTimeStatistic);
            #endregion
            //MessageBox.Show("SanityLevel: " + patientContext.SanityLevel + Environment.NewLine + "SanityDescription: " + patientContext.SanityDescription + Environment.NewLine + "Couch: " + patientContext.CouchId + Environment.NewLine);

            //---------------------------------------
            //---------------------------------------
            // 2 Run CheckScenario (A precheck of patient context. Loading templates and scoring them based on patient context. Enables user to chose correct template)
            //---------------------------------------
            //---------------------------------------

            //StopWatch elapsed time
            //stopWatchTemp.Restart();

            var checkScenario = new CheckScenario(patientContext);


            //Hent ut resultat:
            string templateName = checkScenario.CheckScenarioResult.TemplateName; //Set chosen template. (Endre til � sende selve "EclipseCheckTemplat", som inneholder mye mer informasjon?)
            CheckScenarioResult checkScenarioResultat = checkScenario.CheckScenarioResult; //The result from all templates. Useful if we want to access later.
            
            //Set useful  variables
            string machine = checkScenario.CheckScenarioResult.CheckScenarioMaskin;
            PlanTechnique teknikk = checkScenario.CheckScenarioResult.CheckScenarioTechnique;
            // Full liste av felt med info:
            List<Field> FeltListe = checkScenario.CheckScenarioResult.CheckScenarioFieldList;
            //Feltanalyse (lateralitet etc.)
            FieldsAnalysis f_analyse = checkScenario.CheckScenarioResult.CheckScenarioFieldAnalysis;

            //This can be modified when we instead load from CSV-file:
            //Generate documentation (in future hope to only do this when a button is clicked i the Form, but  for now this must be done in advance):
            string documentation = "";
            documentation = GeneralExtension.GenerateDocumentation(patientContext, checkScenarioResultat);
            //Add ChangeLog to documentation
            string changes = "";
            changes = GeneralExtension.GenerateChangeLog();
            documentation = changes + documentation; //"ChangeLog:" + Environment.NewLine + changes + Environment.NewLine + Environment.NewLine + "Documentation:" + Environment.NewLine + documentation;
            //Set documentation:
            checkScenarioResultat.Documentation = documentation;


            //---------------------------------------
            //---------------------------------------
            // 2 Send CheckScenario result (templates loaded) to View. CheckPoints have not yet been run yet. 
            //   A template is chosen by marking it and pressing "OK". See CheckScenarioView.xaml and CheckScenarioView.xaml.cs.
            //---------------------------------------
            //---------------------------------------

            CheckScenarioView checkScenarioView = new CheckScenarioView(checkScenario, patientContext); 
         
            //Place window
            checkScenarioView.Top = 5;
            checkScenarioView.Left = 50;
            checkScenarioView.Height = 800;
            //Expand window if warning about version:
            if (checkScenario.CheckScenarioResult.ScriptVersionHandling.NewerVersionWarning != "")
            {
                checkScenarioView.Width = 1350;
                checkScenarioView.Height = 1100;
            }
            stopWatchMain.Stop(); //While window is open and user is making decision


            //Return chosen templates:
            bool?result = checkScenarioView.ShowDialog(); //Show() ShowDialog(); //hvis du vil l�se skjermen
            if (checkScenarioView.Focusable) { checkScenarioView.Focus(); }
            

            //If you press "OK" you chose to continue program with this template
            if (result == true)
            {   //Modify template chosen:
                checkScenario = checkScenarioView.checkScenarioMod;
            }
            else { }//Program exits if "Cancel" is pressed.

        //---------------------------------------
        //---------------------------------------
        // 3    Based on template chosen, Run MainViewModel to actually run the main CheckPoints
        //---------------------------------------
        //---------------------------------------



            if (result == true)
            {
                //You want the viewModel to NOT contain any buisiness logic. Create the ViewModel with the values from the unfinished created checkpoints.
                //THEN run an asynchronious call to update viewModel, one CheckPoint at a time(?). 

                // The ESAPI worker needs to be created in the main thread
                var esapiWorker = new EsapiWorker(patientContext);

                // This new queue of tasks will prevent the script
                // from exiting until the new window is closed
                DispatcherFrame frame = new DispatcherFrame();

                RunOnNewStaThread(() =>
                {
                    // This method won't return until the window is closed
                    InitializeAndStartMainWindow(esapiWorker, patientContext, checkScenarioResultat); //Pass also stopwatch list somehow, so we have a full overview of time spent.

                    // End the queue so that the script can exit
                    frame.Continue = false;
                });

                // Start the new queue, waiting until the window is closed
                Dispatcher.PushFrame(frame);



            } //Program just exits if "Cancel" is pressed.

        }
        private void RunOnNewStaThread(Action a)
        {
            Thread thread = new Thread(() => a());
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }
        private void InitializeAndStartMainWindow(EsapiWorker esapiWorker, PatientContext patientContext, CheckScenarioResult checkScenarioResultat)
        {
            //StopWatch elapsed time
            var stopWatch = new Stopwatch();
            stopWatch.Start(); //Continue counting elapsed time

            //Create MainViewModel. //Should present it empty now. And THEN run checks afterwards, initiated from CodeBehind (MainView.xaml.cs). See "Window1_ContentRendered" and look for "RunFullUpdateCommand"
            var mainViewModel = new MainViewModel(esapiWorker, patientContext, checkScenarioResultat); //patientContext, checkScenarioResultat

            //Stop clock to see elapsed time //Now it only sees initialisation time, earlier the work was done in the viewmodel, but moved out now.
            stopWatch.Stop();
            mainViewModel.EclipseCheckResult.TimeElapsed = CheckPointExtension.stopWatchTimeElapsed(stopWatch);
            stopWatch.Reset();
            //MessageBox.Show("Before Window");
            var window1 = new Window1(mainViewModel, patientContext, checkScenarioResultat);  //Maybe we should send also send checkScenario here, so it is available in Code Behind       
            //MessageBox.Show("After Window");
            //place window
            window1.Top = 5;
            window1.Left = 50;

            //Update with Eclipseboluses and HUStructures here:
            //mainViewModel.EclipseCheckResult.PopulateStructureLists(patientContext, checkScenarioResultat);

            if (window1.Focusable) { window1.Focus(); }
            window1.ShowDialog(); //Show() ShowDialog(); //locks the screen
            
            //window1.Height = 1000;

        }

    }
}

