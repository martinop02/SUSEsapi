﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

using System.Windows.Input;
using System.Windows.Media.Media3D;
using EclipsePlanCheck.Helpers;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using EclipseImage = VMS.TPS.Common.Model.API.Image;

namespace EclipsePlanCheck
{

    public class PatientContext //Implementer i Sanity Check
    {
        public int SanityLevel { get; set; }
        public string SanityDescription { get; set; }
        public string CouchId { get; set; }
        public string BodyId { get; set; }
        public string UserName { get; set; }
        public string UserId { get; set; }

        public Patient ChosenPatient { get; set; }
        public Image ChosenImage { get; set; }
        public ExternalPlanSetup ChosenPlan { get; set; }
        public Course ChosenCourse { get; set; }
        public StructureSet ChosenStructureSet { get; set; }

        public Structure TargetVolume { get; set; }

        public bool TargetStructureExist { get; set; } //Could use if (plan == null) instead?
        public bool TargetStructureSegmented { get; set; }
        public bool HasBody { get; set; }
    }

    public class SanityCheck  //Do we have sufficient context to perform the check? (patient exist, image exist, structure set exist, course created, plan created, dose calculated, target structure chose etc.)
    {
        public string ErrorMessageText { get; set; }
        public bool SanityState { get; set; }

    }

    public class ElapsedTimeStatistic //Statistics on elapsed time in script.
    {
        public string TaskName { get; set; }
        public double ElapsedTime { get; set; }
    }

    public class PlanTechnique //Technique
    {
        public string TechniqueName { get; set; }
        public string NumberOfStaticFields { get; set; }
        public string NumberOfIMRTFields { get; set; }
        public string NumberOfFifFields { get; set; }
        public string NumberOfArcFields { get; set; }
        public string NumberOfSRSArcFields { get; set; }
        public string NumberOfTotBodyFields { get; set; }
        public string NumberOfElectronFields { get; set; }
    }

    public class Field
    {
        public string FieldID { get; set; }
        public string FieldEnergy { get; set; }
        public string FieldDoseRate { get; set; }
        public string FieldMachineID { get; set; }
        public string FieldMU { get; set; }
        public string FieldCollimatorAngle { get; set; }
        public string FieldGantryAngle { get; set; }
        public string FieldExtended { get; set; }
        public string FieldTechniqueName { get; set; }
        public string FieldWedge { get; set; }

        //Electrons:
        public string FieldApplicator { get; set; } //Electrons:
        public string FieldTray { get; set; } //Electrons:
        public string FieldTrayCustomCode { get; set; } //Electrons:

    }

    public struct Isosenter //
    {
        public string Iso_x { get; set; }
        public string Iso_y { get; set; }
        public string Iso_z { get; set; }

        public string FieldsHaveSameIsosenter { get; set; }

    }

    //Analysere 180 grader felt, gantryvekting, lateralitet, extended-status etc.:
    public struct FieldsAnalysis
    {
        public double GantryWeightScore { get; set; }
        public string GantryWeight { get; set; }
        public bool Exist_180_field { get; set; }
        public string Extended_180_field { get; set; }
        public string AngleWarning { get; set; }
        public string AngleComment { get; set; }
        //Annet nyttig i analyse av gantryvinkel og Extended:
        public Isosenter PlanIsosenter { get; set; }
        public string PlanLaterality { get; set; }

        public string PlanLaterality_cm { get; set; }
        public string PatientOrientation { get; set; }

        public string ExtractedValue { get; set; }
        public string ExtractedValueCSV { get; set; }
        public string Elaboration { get; set; }

        public string OptimalExtendedStatusFromGantryWeight { get; set; }
        public string OptimalExtendedStatusFromLaterality { get; set; }
        public string OptimalExtendedStatus { get; set; }
    }

    public class FieldEnergy
    {
        public string EnergyName { get; set; }
        public string DoseRate { get; set; }
        public string MachineType { get; set; }
    }


    //----------------------------------------------------------------
    //----Forklaring:
    //----------------------------------------------------------------
    //Sjekknavn = navn på sjekk
    //SjekkResultatVerdi  = Uthentet verdi fra Eclipse, hvor det er relevant.
    //SjekkTemplatVerdi = Forventet verdi fra templatet hvor det er relevant
    //SjekkStatus = Status på sjekken. Se Konstanter.Ok, Konstanter.Error, Konstanter.Warning etc. Kan også være Konstanter.Til_info hvis det er en type "Info".
    //SjekkNummer = Nummer på sjekken. Har major nummer x og minor nummer y: "x.y". Feks: 1.1   1.2   1.3    /    2.1   2.2   2.3    /     3.11     etc. Noen har i tillegg alternativer "a" og "b" etc.
    //SjekkKategori  = Kategorien til sjekken. Feks "Plansjekk", "Beregning.  Brukes foreløpig ikke til noe.
    //SjekkType = Type til sjekken. Enten "Sjekk" (Gul/rød/Grønn) eller "Info" (blå)
    //SjekkTaskNavn = Hvilken task denne sjekken skal utføres på. Sjekkene sorteres også på hvem som utfører sjekken (doseplan, fysiker etc.)
    //SjekkForklaring = Mer detaljert orklaring av hva sjekken gjør.Defineres i forkant av sjekken av templatet.
    //SjekkUtdypning = Ekstra informasjon som kan legges til når sjekken gjennomføres. Ikke så mye brukt per naa.
    //SjekkDebug = Ekstra informasjon til debuging av kode.
    //SjekkVerifikasjon = Er koden verifisert. Hvis ikke, advarsel?
    //ColorSet  = Fargen på statuscellen
    //----------------------------------------------------------------
    //----------------------------------------------------------------

    //Hver sjekk returnerer dette
    public class CheckPoint : INotifyPropertyChanged
    {
        //Fields
        //public string CheckName { get; set; } //Kommer i tabell

        private string _checkSwitchCode;
        public string CheckSwitchCode  //Used to identify correct method in switch statement
        {
            get => _checkSwitchCode;
            set
            {
                _checkSwitchCode = value;
                OnPropertyChanged(nameof(CheckSwitchCode));
            }
        }


        private string _checkName;
        public string CheckName  //Kommer i tabell //Now called CheckName, should be called CheckLabel?
        {
            get => _checkName;
            set
            {
                _checkName = value;
                OnPropertyChanged(nameof(CheckName));
            }
        }
        public string CheckType { get; set; } //
        public string CheckState { get; set; } //For instance Experimental, Validation, Validated.
        public string CheckValidationDate { get; set; } //Kommer i Tooltip
        public string CheckValidationComment { get; set; } //Kommer i Tooltip
        public string CheckLastModification { get; set; }
        public string CheckSortingNumber { get; set; } = "";//Used to sort the list, internal to each sublist (course, CT and structures etc.)

        public string CheckResultValueCSV = ""; //Default value //Suggest to have a separate resultvalue ("not display" value) to send to CSV. Cannot contain line breaks or advanced formatting.
        //public string CheckResultValueCSV //{ get; set; } 
        // {
        //    get => _checkResultValueCSV;
        //    set
        //    {
        //        _checkResultValueCSV = value;
        //        OnPropertyChanged(nameof(CheckResultValueCSV));
        //    }
        //}

        private string _checkResultValue;
        public string CheckResultValue  //Kommer i tabell
        {
            get => _checkResultValue;
            set
            {
                _checkResultValue = value;
                OnPropertyChanged(nameof(CheckResultValue));
            }
        } //Kommer i tabell. Dette er verdier hentet ut fra Aria, kan veare modifisert for presentasjon i tabell
        //public string CheckTemplateValue { get; set; } //Kommer i tabell
        private string _CheckTemplateValue;
        public string CheckTemplateValue  //Kommer i tabell
        {
            get => _CheckTemplateValue;
            set
            {
                _CheckTemplateValue = value;
                OnPropertyChanged(nameof(CheckTemplateValue));
            }
        }

        private string _CheckTemplateValueDisplay; //separate one, because we require to check against template raw value, but also want to modify it for display (adding line breaks etc.) Not used yet.
        public string CheckTemplateValueDisplay  //Kommer i tabell
        {
            get => _CheckTemplateValueDisplay;
            set
            {
                _CheckTemplateValueDisplay = value;
                OnPropertyChanged(nameof(CheckTemplateValueDisplay));
            }
        }

        public string CheckTemplateValueCSV { get; set; } = "";//IF we want to customize output to CSV-file. 

        private string _checkStatus;
        public string CheckStatus
        {
            get => _checkStatus;
            set
            {
                _checkStatus = value;
                OnPropertyChanged(nameof(CheckStatus));
            }
        } //Kommer i tabell

        private string _checkStatusDisplay;
        public string CheckStatusDisplay
        {
            get => _checkStatusDisplay;
            set
            {
                _checkStatusDisplay = value;
                OnPropertyChanged(nameof(CheckStatusDisplay));
            }
        } //Kommer i tabell

        public string CheckCategory { get; set; } //Vises ikke
        public string CheckListCategory { get; set; } //Sorterer i forskjellige lister
        public string CheckExplanation { get; set; }  //Kommer i Tooltip


        public string CheckNumber { get; set; } //Kommer i tabell
        public string CheckTaskName { get; set; } //Kommer i Tooltip

        private string _checkComment;
        public string CheckComment  //Kommer i tabell

        {
            get => _checkComment;
            set
            {
                if (_checkComment != value)
                {
                    _checkComment = value;
                    OnPropertyChanged(nameof(CheckComment));
                }
            }
        }
        //Kommer i Details, synlig hvis ikke tom eller null.
        public string CheckElaboration { get; set; } //Kommer i Tooltip
        public string CheckVerification { get; set; } //Kommer i Tooltip
        public string CheckVerificationDate { get; set; } //Kommer i Tooltip
        public string CheckDebug { get; set; }  //Kommer i tooltip, ev. egen liste av errors tilgjengelig ved knapp?
        public string CheckResultRawValue { get; set; } //Hvis man trenger umodifisert raaverdi av uthenting av resultat fra Aria

        //public string CheckSettings { get; set; }  //Denne burde bare fjernes  //Hvor strengt et krav skal tolkes (Streng / Medium). Brukes på Lateralitet feks, mamma pas skal alltid har rett lateralitet i alle benevninger. Lunge har ikke alltid lateralitet i PTV-ID.
                                                   
        public string CheckTrafficLight { get; set; } //Hvor alvorlig en feil er hvis det ikke stemmer (Warning, Warning2, Error)

        public string CheckInvisibleUnlessWarningOrError { get; set; } // InvisibleUnlessWarningOrError //InactivateCheckpoint

        public string CheckInactivated { get; set; } //This one can be set in advance to inactivate a check because it is not beeing used. Say a certain hospital is not interested in running this check.

        public string CheckDiscardedAtRuntime { get; set; } //A check can also be discarded for logical reasons "on the fly" by the code if the code finds the check is not relevant for situation (beyond the demand for required patient context). For instance: certain checks are only done for Halcyon machines, or when the is a IMRT-plan, or if there is a wedge present in plan etc.
        // public string CheckPurposefullyRejectedGodforsakenCastAwayAndUnceremoniouslyAbandonedAtRuntime // trying to find a sensible name that captures the meaning...

        public int CheckSanityLevelRequired { get; set; }

        private string _checkTimeElapsed;
        public string CheckTimeElapsed
        {
            get => _checkTimeElapsed;
            set
            {
                if (_checkTimeElapsed != value)
                {
                    _checkTimeElapsed = value;
                    OnPropertyChanged(nameof(CheckTimeElapsed));
                }
            }
        }  //How muchtime the code used on this checkpoint

        string _colorSet; //set a default too?
        public string ColorSet
        {
            get => _colorSet;
            set
            {
                if (_colorSet != value)
                {
                    _colorSet = value;
                    OnPropertyChanged(nameof(ColorSet));

                }
            }
        }//Bestemmer fargen på row

        public DvhValue DvhValue { get; set; } //Hvis sjekkpunktet er en dvh-verdi sendes det som egen klasse

        public Margins Margins { get; set; } //Hvis sjekkpunktet er en margin-verdi sendes det som egen klasse

        private bool _calculateLate = false; //Default should be false;
        public bool CalculateLate
        {
            get => _calculateLate;
            set
            {
                if (_calculateLate != value)
                {
                    _calculateLate = value;
                    OnPropertyChanged(nameof(CalculateLate));
                }
            }
        }
        private bool _calculateDelayed = false;
        public bool CalculateDelayed
        {
            get => _calculateDelayed;
            set
            {
                if (_calculateDelayed != value)
                {
                    _calculateDelayed = value;
                    OnPropertyChanged(nameof(CalculateDelayed));
                }
            }
        }
        // If true, the calculation is delayed until the "calculate/regn ut" button is pressed.
        // If false, calculation runs at startup of the script as normal. 
        // This is used to make the script run faster for checks that require heavier calculation, and are not always needed.

        //Test - progress value from 0 to 100.
        private int _progress = 0;
        public int Progress  //This is currently not in use. I thought of implementing a progress bar inside the datagrid for each checkpoint. Too complex for now.
        {
            get => _progress;
            set
            {
                if (_progress != value)
                {
                    _progress = value;
                    OnPropertyChanged(nameof(Progress));
                }
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));



    }

    public class RefPoint
    {//Endret fra norsk til engelsk - oppdater View!
        public String CheckResult { get; set; }
        public String StructureID { get; set; }
        public String RefPointID { get; set; }
        public String DailyDoseTolerance { get; set; }  //Double
        public String SessionDoseTolerance { get; set; } //Double
        public String TotalDoseTolerance { get; set; } //Double
        public String SessionDose { get; set; } //Double
        public String TotalDose { get; set; } //Double
        public String SessionDoseDifference { get; set; }
        public String TotalDoseDifference { get; set; }
        public String Explanation { get; set; }

        public String Type_RefPoint { get; set; }  //Primary el. Secondary

        public string ColorSet { get; set; }

    }

    //Support structures, overrides, bolus, couch.
    public class StructureCheck  
    { //Any changes must also be done in xaml-file!!
        public string StructureID { get; set; }
        public string StructureHU { get; set; }
        public string StructureType { get; set; } // struktur eller bolus.
        public string AttachedFields { get; set; } //Kun boluser
        public string NonAttachedFields { get; set; } //Kun boluser
        public string Explanation { get; set; } //MouseOver tooltip
        public string Status { get; set; }
        public string ColorSet { get; set; }

    }

    //public class MatchedStructures  //Find matched structures
    //{
    //    public string LargerStructureName { get; set; }
    //    public string SmallerStructureName { get; set; }
    //}


    public class MarginList
    {
        public List<Margins> ListOfMargins { get; set; }

        public StructureSet StructureSet { get; set; }

        public Structure StructureBody { get; set; }

        public string LargeStructureStartWith { get; set; }
        public string SmallStructureStartWith { get; set; }
        public List<TargetStructures> LargeTargetStructureList { get; set; }
        public List<TargetStructures> SmallTargetStructureList { get; set; }
        public string OriginalLargeTargetStructureListIds { get; set; }
        public string OriginalSmallTargetStructureListIds { get; set; }
        public string FinalLargeTargetStructureListIds { get; set; }
        public string FinalSmallTargetStructureListIds { get; set; }
        public int NumberOfSmallStructures { get; set; }
        public int NumberOfLargeStructures { get; set; }
        public List<string> ListOfGTVStructuresToRemoveFromGTVToCTVList { get; set; }
        public List<string> ListOfCTVStructuresToRemoveFromCTVToPTVList { get; set; }

        public string Output { get; set; } //should not be used, we want output to be set on each Margin pair in list.
        public string Debug { get; set; }
    }


    public class Margins
    {
        //public MatchedStructures MatchedStructures { get; set; }

        
        public string LargeStructureID { get; set; }
        public string SmallStructureID { get; set; }
        public string LargeStructureStartWith { get; set; }
        public string SmallStructureStartWith { get; set; }
        public string Origin_XYZ_LargeStructure { get; set; }
        public string Origin_XYZ_SmallStructure { get; set; }
        public string Origin_XYZ { get; set; } //Utdatert?

        //Used for directional margins
        public double Origin_LargeStructure_X { get; set; }
        public double Origin_LargeStructure_Y { get; set; }
        public double Origin_LargeStructure_Z { get; set; }
        public double Size_LargeStructure_X { get; set; }
        public double Size_LargeStructure_Y { get; set; }
        public double Size_LargeStructure_Z { get; set; }

        public double X_Pluss_Minimum_Coordinate { get; set; }
        public double X_Minus_Maximum_Coordinate { get; set; }
        public double Y_Pluss_Minimum_Coordinate { get; set; }
        public double Y_Minus_Maximum_Coordinate { get; set; }
        public double Z_Pluss_Minimum_Coordinate { get; set; }
        public double Z_Minus_Maximum_Coordinate { get; set; }


        public double X_origin_diff { get; set; }
        public double X_size_diff { get; set; }
        public double Y_origin_diff { get; set; }
        public double Y_size_diff { get; set; }
        public double Z_origin_diff { get; set; }
        public double Z_size_diff { get; set; }


        public double X_Pluss_Mean_Margin { get; set; }
        public double X_Minus_Mean_Margin { get; set; }
        public double Y_Pluss_Mean_Margin { get; set; }
        public double Y_Minus_Mean_Margin { get; set; }
        public double Z_Pluss_Mean_Margin { get; set; }
        public double Z_Minus_Mean_Margin { get; set; }

        public double X_Pluss_Mean_Count { get; set; }
        public double X_Minus_Mean_Count { get; set; }
        public double Y_Pluss_Mean_Count { get; set; }
        public double Y_Minus_Mean_Count { get; set; }
        public double Z_Pluss_Mean_Count { get; set; }
        public double Z_Minus_Mean_Count { get; set; }

        public double X_Pluss_Negativ_Margin_Count { get; set; }
        public double X_Minus_Negativ_Margin_Count { get; set; }
        public double Y_Pluss_Negativ_Margin_Count { get; set; }
        public double Y_Minus_Negativ_Margin_Count { get; set; }
        public double Z_Pluss_Negativ_Margin_Count { get; set; }
        public double Z_Minus_Negativ_Margin_Count { get; set; }


        public double X_Pluss_Margin { get; set; }
        public double X_Minus_Margin { get; set; }
        public double Y_Pluss_Margin { get; set; }
        public double Y_Minus_Margin { get; set; }
        public double Z_Pluss_Margin { get; set; }
        public double Z_Minus_Margin { get; set; }

        //Calculated margins
        public double MeanMargin { get; set; }
        public double MeanMarginNotCroppedToBody { get; set; }

        //Tolerances mean margins
        public double ExpectedMeanMargin { get; set; } //Lets say 5mm
        public double MeanMarginLowWarning { get; set; }  //lets say 4mm  //If not defined, use TolerancesMarginsPercentageWarning
        public double MeanMarginHighWarning { get; set; } //Lets say 6mm //If not defined, use TolerancesMarginsPercentageWarning
        public double MeanMarginLowError { get; set; } //Lets say 3mm //If not defined, use TolerancesMarginsPercentageError
        public double MeanMarginHighError { get; set; } //Lets say 7mm //If not defined, use TolerancesMarginsPercentageError

        //Tolerances directional (interpreted as +/- X %)
        public double X_Pluss_Margin_tolerance { get; set; }  //uses TolerancesMarginsPercentage for upper and lower tolerance if not explicitly defined
        public double X_Pluss_Margin_HighWarning { get; set; }  
        public double X_Pluss_Margin_LowWarning { get; set; }
        public double X_Pluss_Margin_HighError { get; set; }
        public double X_Pluss_Margin_LowError { get; set; }
        public double X_Minus_Margin_tolerance { get; set; }  //uses TolerancesMarginsPercentage for upper and lower tolerance if not explicitly defined
        public double X_Minus_Margin_HighWarning { get; set; }
        public double X_Minus_Margin_LowWarning { get; set; }
        public double X_Minus_Margin_HighError { get; set; }
        public double X_Minus_Margin_LowError { get; set; }
        public double Y_Pluss_Margin_tolerance { get; set; }  //uses TolerancesMarginsPercentage for upper and lower tolerance if not explicitly defined
        public double Y_Pluss_Margin_HighWarning { get; set; }
        public double Y_Pluss_Margin_LowWarning { get; set; }
        public double Y_Pluss_Margin_HighError { get; set; }
        public double Y_Pluss_Margin_LowError { get; set; }
        public double Y_Minus_Margin_tolerance { get; set; }  //uses TolerancesMarginsPercentage for upper and lower tolerance if not explicitly defined
        public double Y_Minus_Margin_HighWarning { get; set; }
        public double Y_Minus_Margin_LowWarning { get; set; }
        public double Y_Minus_Margin_HighError { get; set; }
        public double Y_Minus_Margin_LowError { get; set; }
        public double Z_Pluss_Margin_tolerance { get; set; }  //uses TolerancesMarginsPercentage for upper and lower tolerance if not explicitly defined
        public double Z_Pluss_Margin_HighWarning { get; set; }
        public double Z_Pluss_Margin_LowWarning { get; set; }
        public double Z_Pluss_Margin_HighError { get; set; }
        public double Z_Pluss_Margin_LowError { get; set; }
        public double Z_Minus_Margin_tolerance { get; set; }  ///uses TolerancesMarginsPercentage for upper and lower tolerance if not explicitly defined
        public double Z_Minus_Margin_HighWarning { get; set; }
        public double Z_Minus_Margin_LowWarning { get; set; }
        public double Z_Minus_Margin_HighError { get; set; }
        public double Z_Minus_Margin_LowError { get; set; }

        public string ValidPatientOrientation { get; set; } //Only apply directional tolerances for this patient orientation.
        public string OnlyPrintTolerance { get; set; } //Do not check tolerances, just print them

        //Booleans
        public string MeanExpectedToleranceExplicitlySet { get; set; } ///"True" if expected tolerences are set explicitly. 
        public string MeanUpperLowerToleranceExplicitlySet { get; set; } //"True" if upper and lower tolerances are set explicitly, "False" if tolerances are calculated using generic percentage.
        public string MeanExpectedDirectionlToleranceExplicitlySet { get; set; } //"True" if expected directional tolerences are set explicitly. 
        public string MeanUpperLowerDirectionlToleranceExplicitlySet { get; set; } //"True" if upper and lower tolerances are set explicitly, "False" if tolerances are calculated using generic percentage.

        //Statuses and debug
        public string Output { get; set; }
        public string Status { get; set; }

        public string WarningMarginsLow { get; set; } //Which directions is margin too low
        public string WarningMarginsHigh { get; set; } //Which direction is margin too high
        public string Warning { get; set; }
        public string Comment { get; set; }
        public string Debug { get; set; }
        public string IsSmallStructureWithinLargeStructure { get; set; }
        public string BasicCheckNegativMarginDetected { get; set; }
        public string AdvancedCheckNegativMarginDetected { get; set; }
        public string AreStructureOriginsClose { get; set; }
        public string ExistCroppingAgainstBody { get; set; }
        public string ExceptionSmallStructureIsSlightlyOutsideLargeStructureWhereNoCropping { get; set; }
        public string ExceptionMaxDistanceSmallStructureToLargeStructureWhereSmallStructureOutsideDicomCoordinates { get; set; }
        public double NumberOfPointsWhereStructureOutsideStructureButCloseToBody { get; set; }
        public double NumberOfPointsWhereStructureEqualToStructure { get; set; }
        public double NumberOfPointsWhereStructureOutsideStructureAndNoExcuses { get; set; }//maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside
        public double NumberOfPointsTotal { get; set; }
        public double NumberOfPointsOk { get; set; }
        public double MaxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside { get; set; }

        //Large Structure resolution debug
        public double MeanDistanceLargeStructureResolution { get; set; }
        public double ModeDistanceLargeStructureResolution { get; set; }
        public double LargestDistanceLargeStructureResolution { get; set; }
        public double NumberOfBadResolutionPoints { get; set; }
        public double NumberOfLargeStructurePoints { get; set; }
        public double PercentageBadResolutionPoints { get; set; }

        public List<Point3D> BadResolutionPoints { get; set; } //Points where measurement of margins and isStructureWithinStructure-debug should be avoided, because distances will be wrong.

        public double AverageDistanceOutsideLargeStructure { get; set; }
        public double PercentagePointsWhereStructureOutsideStructureAndNoExcuses { get; set; }

        //Disse er ikke i bruk enda, men tenker de er relevant, må konvertere fra "X_Minus", "X_Pluss" til relevant pasientorientering. Ikke implementert.
        //public double CranialMargin { get; set; }
        //public double KaudalMargin { get; set; }
        //public double PosteriorMargin { get; set; }
        //public double AnteriorMargin { get; set; }
        //public double LeftMargin { get; set; }
        //public double RightMargin { get; set; }

        //public double CranialMarginTolerance { get; set; }
        //public double KaudalMarginTolerance { get; set; }
        //public double PosteriorMarginTolerance { get; set; }
        //public double AnteriorMarginTolerance { get; set; }
        //public double LeftMarginTolerance { get; set; }
        //public double RightMarginTolerance { get; set; }

    }

    public class MarginsDirectionalTolerances
    {
        public double Directional_Mean_Margin { get; set; }
        public double Margin_tolerance { get; set; }  
        public double Margin_HighWarning { get; set; }
        public double Margin_LowWarning { get; set; }
        public double Margin_HighError { get; set; }
        public double Margin_LowError { get; set; }
      
    }


        //Brukes i parsing av target structures, used in matching structures to check for Margins

    public class TargetStructures
    {
        public string TargetStructureId { get; set; }
        public string TargetStructureCode { get; set; }
        public string TargetStructureDose { get; set; }
        public string TargetStructureHasDose { get; set; }
        public string TargetStructureDescription { get; set; }

    }

    public class OARStructures
    {

    }

    //Used in check for high resolution status of structures. Need to know certain things befor it can be determined if it should be High or Low resolution. Extracts following information from all structures
    public class StructureResolution
    {
        public Structure StructureItem { get; set; }
        public string DicomType { get; set; }
        public string IsTargetStructure { get; set; }
        public string IsOAR { get; set; }
        public string IsPTV { get; set; }
        public string IsPRV { get; set; }
        public string StructureId { get; set; }
        public string IsHighResolution { get; set; }
        public string IsEmpty { get; set; }
        public double Volume { get; set; }
        public double SmallestDistanceToTargetStructure { get; set; } 
        public string ExistInTemplateList { get; set; }
        public string ShouldBeHighResolution { get; set; }
    }

    public class MarginsMeasuringPoint
    {
        public double Distance { get; set; }
        public Point3D point3D { get; set; }
    }
    // End margins

    //Marker
    public class MarkerDetection
    {
        public VVector Start { get; set; } //Vvectors of scan start
        public VVector Stop { get; set; } //Vvectors of scan stop

        public VVector Start_Converted { get; set; } //Vvectors of scan start
        public VVector Stop_Converted { get; set; } //Vvectors of scan stop

        public double[,] VoxelPlane { get; set; } //Corrected
        public bool BodyEntryFound { get; set; }
        public int PixelIndex_BodyEntry_X { get; set; }
        public double MaxValueEntry { get; set; }
        public int IndexMaxValueEntry { get; set; }
        public bool MarkerFoundEntry { get; set; }

        public bool BodyExitFound { get; set; }
        public int PixelIndex_BodyExit_X { get; set; }
        public double MaxValueExit { get; set; }
        public int IndexMaxValueExit { get; set; }
        public bool MarkerFoundExit { get; set; }

        public int Z_slice { get; set; } //current Z_slice
        public double Z_VVector { get; set; }
        public int Y_PixelPosition { get; set; } //Current y-position

        public int InsideBodyBufferSize { get; set; }

        public int Z_slice_difference_from_UserOrigin_Entry { get; set; }
        public int Z_slice_difference_from_UserOrigin_Exit { get; set; }
        public int Y_position_difference_from_UserOrigin_Entry { get; set; }
        public int Y_position_difference_from_UserOrigin_Exit { get; set; }

        public double pixelIndex_BodyEntry_X_StartSearch { get; set; }
        public double pixelIndex_BodyEntry_X_StopSearch { get; set; }
        public double pixelIndex_BodyExit_X_StartSearch { get; set; }
        public double pixelIndex_BodyExit_X_StopSearch { get; set; }

        public string DebugMarker { get; set; }
    }
    public class MarkerDetectionData
    {
        //Classes
        public List<MarkerDetection> MarkerDetectionList { get; set; }
        public VVector Start { get; set; } //Vvectors of scan start
        public VVector Stop { get; set; } //Vvectors of scan stop

        public Structure Body { get; set; } //Needed to find where segment crosses body

        //General:
        //MarkerDetectionList
        public int MarkerDetectionListCount { get; set; }
        public int UserOriginY_Position_pixelnumber { get; set; } //Voxelnumber in scan where Y is. Required.
        public int UserOriginX_Position_pixelnumber { get; set; } //Voxelnumber. Not used
        public int UserOriginZ_slice { get; set; } //Slice number (from 0 to max slice number)
        
        public double Z_Resolution_mm { get; set; }
        public double Y_Resolution_mm { get; set; }
        public double X_Resolution_mm { get; set; }

        public double Z_Size_pixels { get; set; }
        public double Y_Size_pixels { get; set; }
        public double X_Size_pixels { get; set; }

        public double Z_UserOrigin { get; set; }
        public double Y_UserOrigin { get; set; }
        public double X_UserOrigin { get; set; }

        public double Z_UserOrigin_Converted { get; set; } //DicomToUser if available
        public double Y_UserOrigin_Converted { get; set; }
        public double X_UserOrigin_Converted { get; set; }

        public double Z_ImageOrigin { get; set; }
        public double Y_ImageOrigin { get; set; }
        public double X_ImageOrigin { get; set; }

        public double Z_ImageOrigin_Converted { get; set; } //DicomToUser if available
        public double Y_ImageOrigin_Converted { get; set; }
        public double X_ImageOrigin_Converted { get; set; }

        public double z_StartSearch_pixel { get; set; }
        public double z_StopSearch_pixel { get; set; }
        public double y_StartSearch_pixel { get; set; }
        public double y_StopSearch_pixel { get; set; }

        public double y_ReducedStartSearch_pixel { get; set; }
        public double y_ReducedStopSearch_pixel { get; set; }

        public double z_StartSearch_VVector { get; set; }
        public double z_StopSearch_VVector { get; set; }
        public double y_StartSearch_VVector { get; set; }
        public double y_StopSearch_VVector { get; set; }

        public double pixelIndex_BodyEntry_X_StartSearch_BestFit { get; set; }
        public double pixelIndex_BodyEntry_X_StopSearch_BestFit { get; set; }
        public double pixelIndex_BodyExit_X_StartSearch_BestFit { get; set; }
        public double pixelIndex_BodyExit_X_StopSearch_BestFit { get; set; }

        //Final statuses
        public double TotalMaxValueEntry { get; set; }
        public double TotalMaxValueExit { get; set; }
        public int TotalMaxZSliceEntry { get; set; }
        public int TotalMaxZSliceExit { get; set; }
        public int TotalMaxYPositionEntry { get; set; }
        public int TotalMaxYPositionExit { get; set; }
        public int TotalMaxEntryListPosition { get; set; }
        public int TotalMaxExitListPosition { get; set; }
        public VVector Total_Start_Converted_Entry { get; set; }
        public VVector Total_Stop_Converted_Entry { get; set; }
        public VVector Total_Start_Converted_Exit { get; set; }
        public VVector Total_Stop_Converted_Exit { get; set; }



        //Distance to markers Z and Y:
        public double TotalMaxYPositionEntry_DifferenceMm { get; set; } // mm = pixlerdiff_entry * Y_Res
        public double TotalMaxYPositionExit_DifferenceMm { get; set; } // mm = pixlerdiff_exit * Y_Res
        public double TotalMaxZSliceEntryDifferenceMm { get; set; } // mm = slizediff * Z_Res
        public double TotalMaxZSliceExitDifferenceMm { get; set; }// mm = slizediff * Z_Res

        public double TotalExitDifferenceMm { get; set; }
        public double TotalEntryDifferenceMm { get; set; }
        public bool TotalExitDifferenceMmWithinTolerance { get; set; }
        public bool TotalEntryDifferenceMmWithinTolerance { get; set; }

        public int Z_slice_difference_from_UserOrigin_Exit { get; set; }
        public int Z_slice_difference_from_UserOrigin_Entry { get; set; }

        //public int TotalMaxEntryListPosition { get; set; } // mm = slizediff * Z_Res
        //public int TotalMaxExitListPosition { get; set; }// mm = slizediff * Z_Res

        public bool TotalEntryMarkersDetected { get; set; }
        public bool TotalExitMarkersDetected { get; set; }

        //Debug of specific slices of interest
        public string Debug_TotalEntrySlice { get; set; }
        public string Debug_TotalExitSlice { get; set; }
        public string Debug_OriginSlice { get; set; }

        //Sendt to CheckPoint
        public string Status { get; set; } //To be sent to CheckPoint
        public string Comment { get; set; } //To be sent to CheckPoint
        public string Output { get; set; } //To be sent to CheckPoint
        public string Tolerance { get; set; }


    }


    public class Toleransetabell
    {
        public string Toleransetabeller { get; set; }
        public string NumberOfToleranceTables { get; set; }

    }

    public class Fractionation
    {
        public string DosePerFraction { get; set; } //fraksjonsdose
        public string NumberOfFractions { get; set; } //Antall fraksjoner
        public string TotalDose { get; set; } //totaldose

    }

    public class DvhValue
    {
        public string StructureID { get; set; } //Enkelt struktunavn eller array av potensielle strukturnavn. Feks. "Lens;Linse;Lens*" (takler wildcard). Velger første match i arrayen!
        public string pPrefix { get; set; } //prefix (V = Volume, D = Dose etc.)
        public string pEnhet { get; set; } //prefiks enhet (Skal Volume være i cc eller %, skal dose være i Gy eller %)
        public double? pValue { get; set; } //prefix value (Feks "D98%", er prefix "D", prefix value "98" og prefix enhet "%")
        public string rEnhet { get; set; } //resultat enhet (skal resultatet ut i %, Gy eller cc)
        //public string volPres { get; set; } //VolumePresentation : cc eller %. Settes i koden.
        //public string dosePres { get; set; } //DoseValuePresentation Gy eller %. Settes i koden.
        public double rValue { get; set; } //resultatet (numerisk verdi)

        public string Operator { get; set; }  // "<", ">", "=<", "=>", "==" etc. Se funksjonen som analyserer resultatet.
        public double? ToleranceAdv { get; set; }
        public double? ToleranceErr { get; set; }

    }

    public class PDCheck  // gjore om til "Public struct"?
    {
        public bool CheckNecessary { get; set; }
        public string CheckRationale { get; set; }
        public string CheckToleranceLimit { get; set; }
    }


    public class ScriptVersionHandling
    {
        //-----------------
        //ScriptVersions
        //-----------------
        public string ScriptName { get; set; }
        public string ScriptVersion { get; set; }
        public string ScriptNameAndVersion { get; set; }
        public string NewerVersionInfo { get; set; } //To tooltip
        public string NewerVersionWarning { get; set; } //Warning displayed
        public string LastChangeInfo { get; set; } //What is the last change
        public DateTime LastChangeDate { get; set; } //When was last change done
        public string LastChangeDateToDisplay { get; set; } //When was last change done

    }

    public class CheckScenarioResult // Ble opprettet for å kunne kjore presjekk.
    {
        //-----------------
        //ScriptVersions
        //-----------------
        public ScriptVersionHandling ScriptVersionHandling { get; set; }

        public string Documentation { get; set; }
        public string Hospital { get; set; }

        //public string ScriptVersion { get; set; }
        //public string NewerVersionInfo { get; set; } //To tooltip
        //public string NewerVersionWarning { get; set; } //Warning displayed

        //-----------------
        //Valgt templat, endelig resultat
        //-----------------
        public string TemplateName { get; set; }
        public int TemplateIndex { get; set; } //Prechosen because of score
        public int TemplateScore { get; set; }
        public EclipseCheckTemplate TemplateChosen { get; set; }
        public List<EclipseCheckTemplate> EclipseCheckTemplateList { get; set; }  //Full list of templates (also those not chosen).

        //-----------------
        // Technique-analysis
        //-----------------
        //Hvis det skal utfores sjekker basert paa teknikk/maskin etc.
        public PlanTechnique CheckScenarioTechnique { get; set; } 
        public string CheckScenarioMaskin { get; set; }  //TB, Ethos, Halcyon etc.
        public List<Field> CheckScenarioFieldList { get; set; } //Feltliste og analyse
        public FieldsAnalysis CheckScenarioFieldAnalysis { get; set; } //Henter ut analyse av felt (inneholder de kiler, type teknikk, MLC, har de bakfrafelt etc. etc. etc.)

        public string Debug { get; set; }

        //Type of Control
        public List<string> KontrollTask { get; set; } //Listen av tilgjengelige kontrolltasks valg maa sendes til View slik at man kan velge
        public string ValgtKontrollTask { get; set; } //Valgt kontrolltask

    }
    //Informasjon som brukes til aa identifisere rett templat. Hver templat inneholder info om diagnoser, forventede strukturer, ptver, ctver, plannavn etc.
    public class EclipseCheckTemplate 
    {
        //Valgt templat

        public string TemplateName { get; set; } 

        //Used in CheckScenario or in concrete CheckPoints:
        public string TemplateDiagnosis { get; set; }
        public string TemplateStrukturSetIDs { get; set; }
        public string TemplatePTVStructureIDs { get; set; }
        public string TemplateCTVStructureIDs { get; set; }
        public string TemplateOARStructureIDs { get; set; }
        public string TemplateOtherStructureIDs { get; set; }
        public string TemplateCourseIDs { get; set; }

        public string TemplatePlanIDs { get; set; }
        public string TemplateFractionations { get; set; }
        public string TemplateTechniqueName { get; set; }

        public string TemplateIntent { get; set; }
        public string TemplatePatientOrientation { get; set; }
        public string TemplateCTSliceThickness { get; set; }
        public string TemplateNormalization { get; set; }
        public string TemplateCalculationAlgorithm { get; set; }
        public string TemplateCalculationResolution { get; set; }
        public string TemplateToleranceTableTreat { get; set; }
        public string TemplateToleranceTableSetup { get; set; }

        public string TemplateNumberOfSetupFields { get; set; }
        public string TemplateEnergyChoice { get; set; } 
        public string TemplateBasePlanContribution { get; set; } // For instance "80;90" for 80% or 90%.
        public string TemplateCouchName { get; set; }  //CouchName
        public string TemplateCouchHU { get; set; }  //HU for couch
        public string TemplateMandatoryHighResolutionStructureIDs { get; set; } //Must have HighResolution. There is a separate technical test that checks and warns about large structures with high resolution. 
        public string TemplateMandatoryStructureIDs { get; set; } //Should exist and should be contoured.

        public string TemplateComment { get; set; }

        //Scoring and coloring the templates and debug - are calculated later
        public int TemplateScore { get; set; }
        public string ColorSet { get; set; }
        public string Debug { get; set; } //Notifies if any template values are overriden.
    }

    //Collision ViewModel
    public class CollisionCheckViewModel : INotifyPropertyChanged //: ViewModelBase
    {
        private bool _view;
        public bool View
        {
            get { return _view; }
            set
            {
                _view = value;
                OnPropertyChanged(nameof(View));
            }
        }
        //public string _fieldID { get; set; }
        private string _fieldID;
        public string FieldID
        {
            get { return _fieldID; }
            set
            {
                _fieldID = value;
                OnPropertyChanged(nameof(FieldID));
            }
        }
        //public string GantryToTable { get; set; }
        private string _gantryToTable;
        public string GantryToTable
        {
            get { return _gantryToTable; }
            set
            {
                _gantryToTable = value;
                OnPropertyChanged(nameof(GantryToTable));
            }
        }
        //public string GantryToBody { get; set; }
        private string _gantryToBody;
        public string GantryToBody
        {
            get { return _gantryToBody; }
            set
            {
                _gantryToBody = value;
                OnPropertyChanged(nameof(GantryToBody));
            }
        }
        //public string Status { get; set; }
        private string _status;
        public string Status
        {
            get { return _status; }
            set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
            }
        }

        //public string Status { get; set; }
        private string _debug;
        public string Debug
        {
            get { return _debug; }
            set
            {
                _debug = value;
                OnPropertyChanged(nameof(Debug));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }


    //Endelige resultatet som skal sendes til MainView. Sjekkene skal være av type SjekkPunkt. 
    //Losningen som brukes naa er at SjekkPunktene samles i lister som bindes til DataGrids i GUI.
    public class EclipseCheckModel : INotifyPropertyChanged
    {
        //Property changed in Model:
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));


        //Esapi worker
        private EsapiWorker _esapiWorker;
        public EsapiWorker EsapiWorker //{ get; set; } //Testing to make iNotify update on change
        {

            get { return _esapiWorker; }
            set
            {
                if (_esapiWorker != value)
                {
                    _esapiWorker = value;
                    OnPropertyChanged(nameof(EsapiWorker));
                }
            }
        }

        //Progressbar - meant it to be used on a "lower" level (hence "local"). For now it is the only and main progressbar. The "global" one is not used.
        private double _localProgressValue;
        public double LocalProgressValue  //Prgressvalue, between 0 and 100.
        {
            get => _localProgressValue;
            set
            {
                _localProgressValue = value;
                OnPropertyChanged(nameof(LocalProgressValue));
            }
        }

        private string _localProgressText; //progressbar text
        public string LocalProgressText
        {
            get => _localProgressText;
            set
            {
                _localProgressText = value;
                OnPropertyChanged(nameof(LocalProgressText));
            }
        }
        //
        private bool _localProgressOngoing; //progressbar is visiblie if progress is ongoing, otherwise invisible.
        public bool LocalProgressOngoing
        {
            get => _localProgressOngoing;
            set
            {
                _localProgressOngoing = value;
                OnPropertyChanged(nameof(LocalProgressOngoing));
            }
        }

        private string _hoveredItemText;
        public string HoveredItemText //Send to FocusWindow
        {
            get => _hoveredItemText;
            set
            {
                if (_hoveredItemText != value)
                {
                    _hoveredItemText = value;
                    OnPropertyChanged(nameof(HoveredItemText));
                }
            }
        }

        private string _hoveredItemTitle;
        public string HoveredItemTitle //Send to FocusWindow
        {
            get => _hoveredItemTitle;
            set
            {
                if (_hoveredItemTitle != value)
                {
                    _hoveredItemTitle = value;
                    OnPropertyChanged(nameof(HoveredItemTitle));
                }
            }
        }

        //Progressbar - meant on higher level (overall progress of script, say) - NOT USED
        private double _globalProgressValue;
        public double GlobalProgressValue
        {
            get => _globalProgressValue;
            set
            {
                _globalProgressValue = value;
                OnPropertyChanged(nameof(GlobalProgressValue));
            }
        }

        private string _globalProgressText;
        public string GlobalProgressText
        {
            get => _globalProgressText;
            set
            {
                _globalProgressText = value;
                OnPropertyChanged(nameof(GlobalProgressText));
            }
        }

        public string TemplateName { get; set; }

        public string ChosenControlTask { get; set; }


        private bool _showReferencePoints;
        public bool ShowReferencePoints
        {
            get { return _showReferencePoints; }
            set
            {
                if (_showReferencePoints != value)
                {
                    _showReferencePoints = value;
                    OnPropertyChanged(nameof(ShowReferencePoints));
                }
            }
        }


        //public string ScriptVersion { get; set; } //Including name
        //public string NewerVersionInfo { get; set; }
        public ScriptVersionHandling ScriptVersionHandling { get; set; }

        public string Documentation { get; set; }

        public string Hospital { get; set; }

        //public string MobiusPath { get; set; }

        public string TimeElapsed { get; set; }


        private List<MarginList> _listOfMarginLists;
        public List<MarginList> ListOfMarginLists
        {
            get { return _listOfMarginLists; }
            set
            {
                if (_listOfMarginLists != value)
                {
                    _listOfMarginLists = value;
                    OnPropertyChanged(nameof(ListOfMarginLists));
                }
            }
        }
        //what else can I call it!? 
        //We have say a "CTV-PTV" list that contains say "CTV_50 -> PTV_50" and "CTV_60 -> PTV_60".
        //But then you also have a "GTV-CTV" list ("GTV_50 -> CTV_50" and "GTV60 -> CTV_60"). Hence a ListOfLists....

        public string TimeElapsedDistribution { get; set; }

        //public List<CheckPoint> CheckPointListAll { get; set; }

        private List<CheckPoint> _checkPointListAll; 
        public List<CheckPoint> CheckPointListAll //The whole list of checkpoints before they are cleaned and sorted.
        {
            get { return _checkPointListAll; }
            set
            {
                if (_checkPointListAll != value)
                {
                    _checkPointListAll = value;
                    OnPropertyChanged(nameof(CheckPointListAll));
                }
            }
        }

        //public List<CheckPoint> CheckPointListCourse { get; set; }
        private List<CheckPoint> _checkPointListCourse; 
        public List<CheckPoint> CheckPointListCourse 
        {
            get { return _checkPointListCourse; }
            set
            {
                if (_checkPointListCourse != value)
                {
                    _checkPointListCourse = value;
                    OnPropertyChanged(nameof(CheckPointListCourse));
                }
            }
        }
        //public List<CheckPoint> CheckPointListStructures { get; set; }
        private List<CheckPoint> _checkPointListStructures;
        public List<CheckPoint> CheckPointListStructures
        {
            get { return _checkPointListStructures; }
            set
            {
                if (_checkPointListStructures != value)
                {
                    _checkPointListStructures = value;
                    OnPropertyChanged(nameof(CheckPointListStructures));
                }
            }
        }
        //public List<CheckPoint> CheckPointListPlan { get; set; }
        private List<CheckPoint> _checkPointListPlan;
        public List<CheckPoint> CheckPointListPlan
        {
            get { return _checkPointListPlan; }
            set
            {
                if (_checkPointListPlan != value)
                {
                    _checkPointListPlan = value;
                    OnPropertyChanged(nameof(CheckPointListPlan));
                }
            }
        }
        //public List<CheckPoint> CheckPointListTechnique { get; set; }
        private List<CheckPoint> _checkPointListTechnique;
        public List<CheckPoint> CheckPointListTechnique
        {
            get { return _checkPointListTechnique; }
            set
            {
                if (_checkPointListTechnique != value)
                {
                    _checkPointListTechnique = value;
                    OnPropertyChanged(nameof(CheckPointListTechnique));
                }
            }
        }
        //public List<CheckPoint> CheckPointListReferencePoints { get; set; }
        private List<CheckPoint> _checkPointListReferencePoints;
        public List<CheckPoint> CheckPointListReferencePoints
        {
            get { return _checkPointListReferencePoints; }
            set
            {
                if (_checkPointListReferencePoints != value)
                {
                    _checkPointListReferencePoints = value;
                    OnPropertyChanged(nameof(CheckPointListReferencePoints));
                }
            }
        }
        //public List<CheckPoint> CheckPointListReferenceDVH { get; set; }
        private List<CheckPoint> _checkPointListDVH;
        public List<CheckPoint> CheckPointListDVH
        {
            get { return _checkPointListDVH; }
            set
            {
                if (_checkPointListDVH != value)
                {
                    _checkPointListDVH = value;
                    OnPropertyChanged(nameof(CheckPointListDVH));
                }
            }
        }
        //public List<CheckPoint> CheckPointListSUS { get; set; }
        private List<CheckPoint> _checkPointListSUS;
        public List<CheckPoint> CheckPointListSUS
        {
            get { return _checkPointListSUS; }
            set
            {
                if (_checkPointListSUS != value)
                {
                    _checkPointListSUS = value;
                    OnPropertyChanged(nameof(CheckPointListSUS));
                }
            }
        }

        public string CheckPointListCourse_Title { get; set; } //No need to change these ones. So they are set Permanent. Unless we want to remove entire list if it is empty?
        public string CheckPointListStructures_Title { get; set; }
        public string CheckPointListPlan_Title { get; set; }
        public string CheckPointListTechnique_Title { get; set; }
        public string CheckPointListReferencePoints_Title { get; set; }
        public string CheckPointListReferenceDVH_Title { get; set; }
        public string CheckPointListOther_Title { get; set; }

        //Debug -> maybe consider making all debuginfo a seperate class, bound to a separate view. This class can then be set here: public DebugInfo DebugInfo  { get; set; }
        public string SanityLevel { get; set; }
        public string SanityDescription { get; set; }
        //public List<CheckPoint> CheckPointListInactivated { get; set; }
        private List<CheckPoint> _checkPointListInactivated; 
        public List<CheckPoint> CheckPointListInactivated 
        {
            get { return _checkPointListInactivated; }
            set
            {
                if (_checkPointListInactivated != value)
                {
                    _checkPointListInactivated = value;
                    OnPropertyChanged(nameof(CheckPointListInactivated));
                }
            }
        }

        private List<CheckPoint> _checkPointListDiscarded;
        public List<CheckPoint> CheckPointListDiscarded
        {
            get { return _checkPointListDiscarded; }
            set
            {
                if (_checkPointListDiscarded != value)
                {
                    _checkPointListDiscarded = value;
                    OnPropertyChanged(nameof(CheckPointListDiscarded));
                }
            }
        }


        //public List<CheckPoint> CheckPointListFailedSanityLevel { get; set; }
        private List<CheckPoint> _checkPointListFailedSanityLevel; 
        public List<CheckPoint> CheckPointListFailedSanityLevel
        {
            get { return _checkPointListFailedSanityLevel; }
            set
            {
                if (_checkPointListFailedSanityLevel != value)
                {
                    _checkPointListFailedSanityLevel = value;
                    OnPropertyChanged(nameof(CheckPointListFailedSanityLevel));
                }
            }
        }
        //public List<CheckPoint> CheckPointListWrongControlType { get; set; }
        private List<CheckPoint> _checkPointListWrongControlType;
        public List<CheckPoint> CheckPointListWrongControlType
        {
            get { return _checkPointListWrongControlType; }
            set
            {
                if (_checkPointListWrongControlType != value)
                {
                    _checkPointListWrongControlType = value;
                    OnPropertyChanged(nameof(CheckPointListWrongControlType));
                }
            }
        }

        //public string NumberOfInactivatedCheckPoints { get; set; }
        private string _numberOfInactivatedCheckPoints; 
        public string NumberOfInactivatedCheckPoints 
        {
            get { return _numberOfInactivatedCheckPoints; }
            set
            {
                if (_numberOfInactivatedCheckPoints != value)
                {
                    _numberOfInactivatedCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfInactivatedCheckPoints));
                }
            }
        }

        //public string NumberOfInactivatedCheckPoints { get; set; }
        private string _numberOfDiscardedCheckPoints;
        public string NumberOfDiscardedCheckPoints
        {
            get { return _numberOfDiscardedCheckPoints; }
            set
            {
                if (_numberOfDiscardedCheckPoints != value)
                {
                    _numberOfDiscardedCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfInactivatedCheckPoints));
                }
            }
        }

        //public string NumberOfFailedSanityCheckPoints { get; set; }
        private string _numberOfFailedSanityCheckPoints; 
        public string NumberOfFailedSanityCheckPoints 
        {
            get { return _numberOfFailedSanityCheckPoints; }
            set
            {
                if (_numberOfFailedSanityCheckPoints != value)
                {
                    _numberOfFailedSanityCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfFailedSanityCheckPoints));
                }
            }
        }
        //public string NumberOfUnknownStatusCheckPoints { get; set; }
        private string _numberOfUnknownStatusCheckPoints;
        public string NumberOfUnknownStatusCheckPoints
        {
            get { return _numberOfUnknownStatusCheckPoints; }
            set
            {
                if (_numberOfUnknownStatusCheckPoints != value)
                {
                    _numberOfUnknownStatusCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfUnknownStatusCheckPoints));
                }
            }
        }
        //public string NumberOfWrongControlTypeCheckPoints { get; set; }
        private string _numberOfWrongControlTypeCheckPoints;
        public string NumberOfWrongControlTypeCheckPoints
        {
            get { return _numberOfWrongControlTypeCheckPoints; }
            set
            {
                if (_numberOfWrongControlTypeCheckPoints != value)
                {
                    _numberOfWrongControlTypeCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfWrongControlTypeCheckPoints));
                }
            }
        }
        //public string NumberOfErrorStatusCheckPoints { get; set; }
        private string _numberOfErrorStatusCheckPoints;
        public string NumberOfErrorStatusCheckPoints
        {
            get { return _numberOfErrorStatusCheckPoints; }
            set
            {
                if (_numberOfErrorStatusCheckPoints != value)
                {
                    _numberOfErrorStatusCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfErrorStatusCheckPoints));
                }
            }
        }
        //public string NumberOfWarningStatusCheckPoints { get; set; }
        private string _numberOfWarningStatusCheckPoints;
        public string NumberOfWarningStatusCheckPoints
        {
            get { return _numberOfWarningStatusCheckPoints; }
            set
            {
                if (_numberOfWarningStatusCheckPoints != value)
                {
                    _numberOfWarningStatusCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfWarningStatusCheckPoints));
                }
            }
        }
        //public string NumberOfOkStatusCheckPoints { get; set; }
        private string _numberOfOkStatusCheckPoints;
        public string NumberOfOkStatusCheckPoints
        {
            get { return _numberOfOkStatusCheckPoints; }
            set
            {
                if (_numberOfOkStatusCheckPoints != value)
                {
                    _numberOfOkStatusCheckPoints = value;
                    OnPropertyChanged(nameof(NumberOfOkStatusCheckPoints));
                }
            }
        }

        public string Debug { get; set; }


        private List<RefPoint> _rfpList;
        public List<RefPoint> RfpList
        {
            get { return _rfpList; }
            set
            {
                if (_rfpList != value)
                {
                    _rfpList = value;
                    OnPropertyChanged(nameof(RfpList));
                }
            }
        }

        private List<StructureCheck> _strukturer; 
        public List<StructureCheck> Strukturer
        {

            get { return _strukturer; }
            set
            {
                if (_strukturer != value)
                {
                    _strukturer = value;
                    OnPropertyChanged(nameof(Strukturer));
                }
            }
        }

        private List<StructureCheck> _boluser;
        public List<StructureCheck> Boluser {

            get { return _boluser; }
            set
            {
                if (_boluser != value)
                {
                    _boluser = value;
                    OnPropertyChanged(nameof(Boluser));
                }
            }
        }

        //Test of Colliosion Check View
        private ObservableCollection<CollisionCheckViewModel> _collisionSummaries;
        public ObservableCollection<CollisionCheckViewModel> CollisionSummaries
        {
            get => _collisionSummaries;
            set
            {
                if (_collisionSummaries != value)
                {
                    _collisionSummaries = value;
                    OnPropertyChanged(nameof(CollisionSummaries));
                }
            }
        }

        private Model3DGroup _collimatorModel;
        public Model3DGroup CollimatorModel
        {
            get => _collimatorModel;
            set
            {
                if (_collimatorModel != value)
                {
                    _collimatorModel = value;
                    OnPropertyChanged(nameof(CollimatorModel));
                }
            }
        }

        private Model3DGroup _couchBodyModel;
        public Model3DGroup CouchBodyModel
        {
            get => _couchBodyModel;
            set
            {
                if (_couchBodyModel != value)
                {
                    _couchBodyModel = value;
                    OnPropertyChanged(nameof(CouchBodyModel));
                }
            }
        }

        private Point3D _isoctr;
        public Point3D Isoctr
        {
            get => _isoctr;
            set
            {
                if (_isoctr != value)
                {
                    _isoctr = value;
                    OnPropertyChanged(nameof(Isoctr));
                }
            }
        }

        private Point3D _cameraPosition;
        public Point3D CameraPosition //Make into an ObservableCollection that can change?
        {
            get => _cameraPosition;
            set
            {
                if (_cameraPosition != value)
                {
                    _cameraPosition = value;
                    OnPropertyChanged(nameof(CameraPosition));
                }
            }
        }

        private Vector3D _upDir;
        public Vector3D UpDir //Make into an ObservableCollection that can change?
        {
            get => _upDir;
            set
            {
                if (_upDir != value)
                {
                    _upDir = value;
                    OnPropertyChanged(nameof(UpDir));
                }
            }
        }

        private double _fieldOfView; 
        public double FieldOfView //Make into an ObservableCollection that can change?
        {
            get => _fieldOfView;
            set
            {
                if (_fieldOfView != value)
                {
                    _fieldOfView = value;
                    OnPropertyChanged(nameof(FieldOfView));
                }
            }
        }

        private Vector3D _lookDir;
        public Vector3D LookDir //Make into an ObservableCollection that can change?
        {
            get => _lookDir;
            set
            {
                if (_lookDir != value)
                {
                    _lookDir = value;
                    OnPropertyChanged(nameof(LookDir));
                }
            }
        }

        private double _sliderValue;
        public double SliderValue //Make into an ObservableCollection that can change?
        {
            get => _sliderValue;
            set
            {
                if (_sliderValue != value)
                {
                    _sliderValue = value;
                    GetCameraPosition();
                    OnPropertyChanged(nameof(SliderValue));
                }
            }
            //set
            //{
            //    _sliderValue = value;
            //    //RaisePropertyChanged("SliderValue"); Do not have the reqiured additions to use this.
            //    GetCameraPosition();
            //}
        }
        //Change the view angle based on sliderValue
        public void GetCameraPosition()
        {

            double y = _isoctr.Y/2; //Experimental
            var angle = SliderValue * Math.PI / 180;
            double x = -2500 * Math.Sin(angle);
            double z = -2500 * Math.Cos(angle);
            LookDir = new Vector3D(-x, y, -z); // LookDir = new Vector3D(-x, 0, -z);
            CameraPosition = new Point3D(x, y, z); // CameraPosition = new Point3D(x, 0, z);
            FieldOfView = 69; //New, testing to set it by code


            //FitObjectIntoView(CollimatorModel);

        }

        private bool _CCIsEnabled; //Collision control is enabled
        public bool CCIsEnabled
        {
            get => _CCIsEnabled;
            //set => _CCIsEnabled = value;//Set(ref _CCIsEnabled, value);
            set
            {
                if (_CCIsEnabled != value)
                {
                    _CCIsEnabled = value;
                    OnPropertyChanged(nameof(CCIsEnabled));
                }
            }
        }
        //Attempt to make the object (linac and patient) fit into the view.
        public void FitObjectIntoView( Model3D objectModel) //Viewport3D viewport
        {
            //if (viewport.ActualWidth == 0 || viewport.ActualHeight == 0)
            //{
            //    // Handle case where viewport size is not yet available (e.g., in Load event)
            //    // You might need to recalculate this when the window/viewport is loaded/resized
            //    return;
            //}

            // 1. Get the bounding box of the object
            Rect3D bounds = objectModel.Bounds;
            if (bounds.IsEmpty)
            {
                return; // Nothing to fit
            }

            // 2. Calculate the center and maximum dimension of the object
            Point3D center = new Point3D(
                (bounds.X + bounds.SizeX / 2),
                (bounds.Y + bounds.SizeY / 2),
                (bounds.Z + bounds.SizeZ / 2)
            );
            double maxDim = Math.Max(Math.Max(bounds.SizeX, bounds.SizeY), bounds.SizeZ);

            // 3. Determine the required distance
            // The FieldOfView is the horizontal FOV in degrees by default in WPF.
            double fovInRadians = FieldOfView * (Math.PI / 180.0);

            // Calculate the distance based on the object's size and FOV
            // The formula is derived from trigonometry (tan(fov/2) = (objectWidth/2) / distance)
            double distance = (maxDim / 2.0) / Math.Tan(fovInRadians / 2.0);

            // Add some margin so the object is not clipped exactly at the edges
            distance *= 1.1;

            // Adjust distance based on viewport aspect ratio if needed (more complex, but optional for basic fit)
            // The current formula assumes the camera's FOV handles the aspect ratio correctly relative to maxDim.

            // 4. Set the camera's position and look direction
            // Position the camera 'distance' units away from the center along the negative Z axis initially, 
            // and point it towards the center.
            CameraPosition = center + new Vector3D(0, 0, distance);
            LookDir = new Vector3D(0, 0, -distance); // Look from the camera position back to the center
            UpDir = new Vector3D(0, -1, 0); // Default up direction
        }



        //------------------
        // Business logic Methods
        //-----------------
        // Business logic: Populate structure list Boluses and HU overrides

        //Blueprint
        //public void BluePrintMethod(CheckScenarioResult CheckScenarioResult, EsapiWorker esapiWorker)
        //{
        //    esapiWorker.Run(patientContext =>
        //    {
        //        MessageBox.Show("Inside BlueprintMethod");


        //        LocalProgressValue = 10; //This will update the view while code is running, INotify and OnPropertyChanged implemented
        //        LocalProgressText = "BlueprintMethod";
        //        MessageBox.Show("Values updated inside BlueprintMethod");
        //    });
        //}




        public void PopulateStructureLists(PatientContext patientContext, CheckScenarioResult CheckScenarioResult) //, EsapiWorker esapiWorker
        {
            //esapiWorker.Run(patientContext =>  
            //{
                //MessageBox.Show("Inside PopulateStructureLists");

                List<StructureCheck> HUstructures = new List<StructureCheck>();
                List<StructureCheck> boluses = new List<StructureCheck>();
                if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage)
                {
                    HUstructures = StructureExtension.GetAssignedHUStructures(patientContext.ChosenStructureSet);
                    boluses = StructureExtension.GetBolusList(patientContext); //can run on only structureset, but also potentially need plan (attached boluses, eclipse boluses) so takes patientContext as input
                }
                _strukturer = HUstructures;
                _boluser = boluses;

            //LocalProgressValue = 10; //This will update the view while code is running, INotify and OnPropertyChanged implemented
            //LocalProgressText = "PopulateStructureLists";
            //MessageBox.Show("Values updated inside PopulateStructureLists");

            //});
            //OnPropertyChanged(nameof(EclipseCheckModel));
        }
        
        public void CreateMarginLists(PatientContext patientContext, CheckScenarioResult CheckScenarioResult)
        {


                //MessageBox.Show("Inside CreateMarginLists");

                List<MarginList> listOfMarginLists = new List<MarginList>();
            if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage)
            {
                    listOfMarginLists = MarginsExtension.CreateListOfMarginLists(patientContext, CheckScenarioResult.TemplateName); //This also calculates the margins - should be done in separate step! //Is used to create CheckPointList later.
                }
                _listOfMarginLists = listOfMarginLists;

                
                //LocalProgressValue = 20; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                //LocalProgressText = "CreateMarginLists";
                //MessageBox.Show("Values updated inside CreateMarginLists");

        }
        
        public void CreateReferencePointList(PatientContext patientContext, CheckScenarioResult CheckScenarioResult)
        {

                //MessageBox.Show("Inside CreateReferencePointList");
                
                //Get refpktdata
                List<RefPoint> rfpList = new List<RefPoint>();
                if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist)
                {
                    rfpList = ReferencePointExtension.GetRefPktListe(patientContext.ChosenPlan);
                    rfpList = ReferencePointExtension.SjekkRefPktListe(rfpList);
                }
                _showReferencePoints = ReferencePointExtension.ShouldReferencePointsBeShown(CheckScenarioResult.ValgtKontrollTask); //Checks if referencepoints should be shown for control task. See Constants.
                _rfpList = rfpList;

                //LocalProgressValue = 30; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                //LocalProgressText = "CreateReferencePointList";
                //MessageBox.Show("Values updated inside CreateReferencePointList");



        }
        
        public void FillUpCheckPointList(PatientContext patientContext, CheckScenarioResult CheckScenarioResult) //, List<MarginList> zlistOfMarginLists) //must be cleaned afterwards!
        {
            //Need to bring in listOfMarginLists to create margins checkpoints

            //Fill up entire CheckPointList, result not cleaned
            List<CheckPoint> checkPointList = new List<CheckPoint>();
            //ListOfMarginLists
            checkPointList = CreateCheckPoint.CreateCheckPointList(patientContext, CheckScenarioResult, ListOfMarginLists); //Set margins tolerances to -1 if no tolerance.
            _checkPointListAll = checkPointList;

            _checkPointListAll = UpdateCheckPoint.SetStatusToWorking(checkPointList); //"⌛..."

            // modify template values for display: Set in line breaks where logical
            _checkPointListAll = UpdateCheckPoint.ReformatTemplateValuesWithLineBreak(checkPointList);

            //-----
            //Temporarily send unfinished CheckPoint to the view as we want to see them! //similar to populateCheckPointList
            //----
            PopulateCheckPointLists(patientContext, CheckScenarioResult);

            

            
            //List<CheckPoint> sjekkpunktlisteCourse = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Course"));
            //List<CheckPoint> sjekkpunktlisteStruktur = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "CT og strukturer"));
            //List<CheckPoint> sjekkpunktlistePlan = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Plan"));
            //List<CheckPoint> sjekkpunktlisteTeknikk = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Teknikk"));
            //List<CheckPoint> sjekkpunktlisteRefpkt = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Refpkt"));
            //List<CheckPoint> sjekkpunktlisteDVH = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "DVH"));
            //List<CheckPoint> sjekkpunktlisteSUS = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "SUS"));

            //_checkPointListCourse = sjekkpunktlisteCourse;
            //_checkPointListStructures = sjekkpunktlisteStruktur;
            //_checkPointListPlan = sjekkpunktlistePlan;
            //_checkPointListTechnique = sjekkpunktlisteTeknikk;
            //_checkPointListReferencePoints = sjekkpunktlisteRefpkt;
            //_checkPointListDVH = sjekkpunktlisteDVH;
            //_checkPointListSUS = sjekkpunktlisteSUS;

        } //CleanUpCheckPointList

        public void CleanUpCheckPointList(PatientContext patientContext, CheckScenarioResult CheckScenarioResult) //must be cleaned afterwards!
        {
            //_checkPointListAll

            //List<CheckPoint> inactivatedCheckPoints = new List<CheckPoint>();
            //List<CheckPoint> sanityFailedCheckPoints = new List<CheckPoint>();
            //List<CheckPoint> controlTypeFailedCheckPoints = new List<CheckPoint>();

            //string numberOfInactivatedCheckPoints = "";
            //string numberOfFailedSanityCheckPoints = "";
            //string numberOfWrongControlTypeCheckPoints = "";
            //_checkPointListFailedSanityLevel; //_checkPointListInactivated //_checkPointListWrongControlType

            //Update debuglists
            List<CheckPoint> tempCheckPointListInactivated = CreateCheckPoint.GetInactivatedCheckpoints(_checkPointListAll);
            _checkPointListInactivated.AddRange(tempCheckPointListInactivated);
            _numberOfInactivatedCheckPoints = _checkPointListInactivated.Count.ToString();
            //Get failed sanity CheckPoints:
            List<CheckPoint> tempCheckPointListFailedSanityLevel = CreateCheckPoint.GetCheckpointsFailedSanity(_checkPointListAll, patientContext);
            _checkPointListFailedSanityLevel.AddRange(tempCheckPointListFailedSanityLevel); // = CreateCheckPoint.GetCheckpointsFailedSanity(_checkPointListAll, patientContext);
            _numberOfFailedSanityCheckPoints = _checkPointListFailedSanityLevel.Count.ToString();
            //Get CheckPoints discarded at runtime: //New
            List<CheckPoint> tempCheckPointListDiscarded = CreateCheckPoint.GetDiscardedCheckpoints(_checkPointListAll);
            _checkPointListDiscarded.AddRange(tempCheckPointListDiscarded); //= CreateCheckPoint.GetDiscardedCheckpoints(_checkPointListAll);
            _numberOfDiscardedCheckPoints = _checkPointListDiscarded.Count.ToString();

            //Remove inactivated CheckPoints:
            _checkPointListAll = CreateCheckPoint.RemoveInactivatedCheckpoints(_checkPointListAll);
            //Remove discarded CheckPoints: //New
            _checkPointListAll = CreateCheckPoint.RemoveDiscardedCheckpoints(_checkPointListAll);
            //Remove CheckPoints based on SanityLevel
            _checkPointListAll = CreateCheckPoint.RemoveCheckpointsFailedSanity(_checkPointListAll, patientContext);

            //Find CheckPoints with failed ControlType
            try
            {
                List<CheckPoint> tempCheckPointListWrongControlType = new List<CheckPoint>(_checkPointListAll.FindAll(a => !a.CheckTaskName.Contains(CheckScenarioResult.ValgtKontrollTask)));
                _checkPointListWrongControlType.AddRange(tempCheckPointListWrongControlType); //new List<CheckPoint>(_checkPointListAll.FindAll(a => !a.CheckTaskName.Contains(CheckScenarioResult.ValgtKontrollTask)));
                _numberOfWrongControlTypeCheckPoints = _checkPointListWrongControlType.Count.ToString();
            }
            catch
            {
                _numberOfWrongControlTypeCheckPoints = "0";
            }
            //Set list with only valid control type:
            try { _checkPointListAll = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckTaskName.Contains(CheckScenarioResult.ValgtKontrollTask))); }
            catch { _checkPointListAll = new List<CheckPoint>(); }
            

        }
        public void UpdateCheckPointListLoop(PatientContext patientContext, CheckScenarioResult CheckScenarioResult, List<CheckPoint> completeCheckPointList, double progressBarStart, double progressBarEnd, bool? calculateLate) //, IProgress<double> progress //must be cleaned afterwards!
        {
            //progress 

            double maxCheckPointsQuick = completeCheckPointList.Where(x => x.CalculateLate != true && x.CalculateDelayed != true).Count();
            double maxCheckPointsLate = completeCheckPointList.Where(x => x.CalculateLate == true && x.CalculateDelayed != true).Count();
            
            double maxCheckPoints = 0;
            string calculateLateOrQuick = "";
            bool? calculateLateAlternateValue;

            //Separete into Late and Quick
            if (calculateLate == true)
            {
                //List<CheckPoint> tempCheckPointList = completeCheckPointList.Where(x => x.CalculateLate != true).ToList();
                maxCheckPoints = maxCheckPointsLate;
                calculateLateOrQuick = "slow";
                calculateLateAlternateValue = calculateLate; //No alternate value possible. Must be false to be interpreted as false.
            }
            else
            {
                maxCheckPoints = maxCheckPointsQuick;
                calculateLateOrQuick = "quick";
                calculateLateAlternateValue = null; //We dont add calculateLate = false, we usually just dont set it, hence null. So count null as false.
            }
            if (maxCheckPoints == 0) { maxCheckPoints = 1; } //Prevent crash

            //Set starting progressbar
            double progressCheckPoints = 0;
            double progress_total = progressBarStart; // 25
            double checkPointNumber = 0; //Reset to 0.
            double reportProgressForEachIncrement = 0.1;
            double currentLastReportedProgress = 0;
            LocalProgressText = LocalProgressValue + "% Updating " + calculateLateOrQuick + " CheckPoints(" + checkPointNumber + "/" + maxCheckPoints + ")" + Environment.NewLine + LocalProgressText;

            //Only update either calculateLate = true checkpoints, or calculateLate = false or null checkpoints, never update calculateDelayed = true.
            foreach (CheckPoint s in completeCheckPointList.Where(x => (x.CalculateLate == calculateLate || x.CalculateLate == calculateLateAlternateValue) && x.CalculateDelayed != true)) //Only update for fast checkpoints or slow checkpoints
            {

                checkPointNumber = checkPointNumber + 1;
                progressCheckPoints = (double)(checkPointNumber / maxCheckPoints); //Number between 0 and 1.
                progress_total = progressBarStart + progressCheckPoints * (progressBarEnd - progressBarStart); //progressCheckPoints is 0.25. progressBarStart - progressBarEnd is 95-25 = 70. Then 0.25*70 = 17.5. And progress total = 25 + 17.5 = 42.5

                LocalProgressValue = Math.Round(progress_total, 1); //progressBarStart + checkPointNumber;  //progressBarStart + progress_total;
                if (progressCheckPoints - currentLastReportedProgress > reportProgressForEachIncrement)
                {
                    reportProgressForEachIncrement = progressCheckPoints;
                    LocalProgressText = LocalProgressValue + "% Updating " + calculateLateOrQuick + " CheckPoints (" + checkPointNumber + "/" + maxCheckPoints + ") " + s.CheckSwitchCode + Environment.NewLine + LocalProgressText;
                }
                //if(s.CheckNumber == "2.8") { MessageBox.Show(LocalProgressText); }
                //Run CheckPoint
                RunCheckPointSwitch(s, patientContext, CheckScenarioResult); //UpdateCheckPoint.RunCheckPointSwitch(s, patientContext, CheckScenarioResult);

                //Color CheckPoint
                UpdateCheckPoint.ColorCheckPointDependingOnStatus(s); //Color for each checkpoint, so we dont have to wait till all have finished to see color.
            }
        }
         public void UpdateCheckPointList(PatientContext patientContext, CheckScenarioResult CheckScenarioResult) //, IProgress<double> progress //must be cleaned afterwards!
        {

            List<CheckPoint> completeCheckPointList = _checkPointListAll;
            double progressBarStartQuick = 26;
            double progressBarEndQuick = 35;
            double progressBarStartLate = 36;
            double progressBarEndLate = 95;

            //Itererer gjennom sjekklisten og oppdaterer hvert punkt

            //Run QUICK checkpoints
            UpdateCheckPointListLoop(patientContext, CheckScenarioResult, completeCheckPointList, progressBarStartQuick, progressBarEndQuick, false);
            //PostProcessing (so the view is nicer, removes inactivated checpPoints)
            LocalProgressText = LocalProgressValue + "% CleanUp quick CheckPoints" + Environment.NewLine + LocalProgressText;
            CleanUpCheckPointList(patientContext, CheckScenarioResult);
            CountStatusesCheckPointList(patientContext, CheckScenarioResult);
            PopulateCheckPointLists(patientContext, CheckScenarioResult);

            //Run LATE checkpoints
            UpdateCheckPointListLoop(patientContext, CheckScenarioResult, completeCheckPointList, progressBarStartLate, progressBarEndLate, true);
            //PostProcessing (so the view is nicer)
            LocalProgressText = LocalProgressValue + "% CleanUp slow CheckPoints" + Environment.NewLine + LocalProgressText;
            CleanUpCheckPointList(patientContext, CheckScenarioResult);
            CountStatusesCheckPointList(patientContext, CheckScenarioResult);
            PopulateCheckPointLists(patientContext, CheckScenarioResult);

            //


            LocalProgressText = LocalProgressText = progressBarEndLate + 1 + "% CleanUp CheckPoints" + Environment.NewLine + LocalProgressText;
            //-----------------------------------------------------------
            //---- ColorSet: Fargelegger resultat: 
            //-----------------------------------------------------------
            completeCheckPointList = UpdateCheckPoint.ColorCheckPointsDependingOnStatus(completeCheckPointList);
            //----------------------------------------------------------------

            //-----------------------------------------------------------------
            // InvisibleUnlessWarningOrError:   Remove all checkpoints that do not have warning or error if CheckPoint Settings says so 
            //-----------------------------------------------------------------
            completeCheckPointList = UpdateCheckPoint.RemoveCheckPointsUnlessErrorOrWarningOrComment(completeCheckPointList);
            //----------------------------------------------------------------

            //-----------------------------------------------------------------
            // Inactive:   Remove all checkpoints that are inactivated if CheckPoint Settings says so 
            //-----------------------------------------------------------------
            completeCheckPointList = UpdateCheckPoint.RemoveCheckPointsIfInactive(completeCheckPointList);
            //----------------------------------------------------------------

            //-----------------------------------------------------------------
            // Reformat template value:   Set in line breaks where logical
            //-----------------------------------------------------------------
            completeCheckPointList = UpdateCheckPoint.ReformatTemplateValuesWithLineBreak(completeCheckPointList);
            //----------------------------------------------------------------

            _checkPointListAll = completeCheckPointList;


            //Original Code: Update and run remaining CheckPoints
            //---------------------------
            //_checkPointListAll = UpdateCheckPoint.UpdateCheckPointList(patientContext, _checkPointListAll, CheckScenarioResult, progress); //, boluser, listOfMarginLists  //Sending the progressbar further in the nested methods
            //---------------------------

        }
        
        public void CountStatusesCheckPointList(PatientContext patientContext, CheckScenarioResult CheckScenarioResult) //must be cleaned afterwards!
        {
            //Get Debug: Count OK, warning, errors and unknowns:
            _numberOfErrorStatusCheckPoints = _checkPointListAll.FindAll(a => a.CheckStatus == Constants.Error).Count.ToString();
            _numberOfWarningStatusCheckPoints = _checkPointListAll.FindAll(a => (a.CheckStatus == Constants.Warning || a.CheckStatus == Constants.Warning2)).Count.ToString();
            _numberOfOkStatusCheckPoints = _checkPointListAll.FindAll(a => a.CheckStatus == Constants.Ok).Count.ToString();
            _numberOfUnknownStatusCheckPoints = _checkPointListAll.FindAll(a => a.CheckStatus == Constants.Unknown).Count.ToString();
        }

        public void PopulateCheckPointLists(PatientContext patientContext, CheckScenarioResult CheckScenarioResult) //must be cleaned afterwards!
        {
            //Split CheckPointListAll into seperate lists grouped by different categories ("CheckListCategory").
            List<CheckPoint> sjekkpunktlisteCourse = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Course"));
            List<CheckPoint> sjekkpunktlisteStruktur = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "CT og strukturer"));
            List<CheckPoint> sjekkpunktlistePlan = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Plan"));
            List<CheckPoint> sjekkpunktlisteTeknikk = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Teknikk"));
            List<CheckPoint> sjekkpunktlisteRefpkt = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "Refpkt"));
            List<CheckPoint> sjekkpunktlisteDVH = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "DVH"));
            List<CheckPoint> sjekkpunktlisteSUS = new List<CheckPoint>(_checkPointListAll.FindAll(a => a.CheckListCategory == "SUS"));

            _checkPointListCourse = sjekkpunktlisteCourse;
            _checkPointListStructures = sjekkpunktlisteStruktur;
            _checkPointListPlan = sjekkpunktlistePlan;
            _checkPointListTechnique = sjekkpunktlisteTeknikk;
            _checkPointListReferencePoints = sjekkpunktlisteRefpkt;
            _checkPointListDVH = sjekkpunktlisteDVH;
            _checkPointListSUS = sjekkpunktlisteSUS;

        }

        //This method was made as a first attemt to run esapiWorker and concurrantly update GUI while running a "heavy" calculation. For instance to update the view with progressbar etc. It worked! 27.10.2025. Can be used as a blueprint.
        public void TestCalculateMeanDose( CheckScenarioResult CheckScenarioResult, EsapiWorker esapiWorker) //, EsapiWorker esapiWorker
        {
            //esapiWorker.Run(xpatientContext)
            MessageBox.Show("Inside TestCalculateMeanDose in EclipseCheckModel");
            esapiWorker.Run(patientContext =>  //Do we really need to pass patientContext from esapiworker afterall? It is available anyway if we just pass patientContext as an argument in the maiin function (TestCalculateMeanDose, but I guess we save some "passing" code.
            {
                MessageBox.Show("Inside RUN TestCalculateMeanDose in EclipseCheckModel");
                var dose = patientContext.ChosenPlan.Dose;
                var meanDose = new DoseValue(0.0, dose.DoseMax3D.Unit);
                LocalProgressValue = 0; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                LocalProgressText = "Starting calculation...";
                for (int z = 0; z < dose.ZSize; z++)
                {
                    LocalProgressValue = (double)(z + 1) / dose.ZSize * 100; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                    LocalProgressText = LocalProgressValue.ToString();
                    var buffer = new int[dose.XSize, dose.YSize];
                    dose.GetVoxels(z, buffer);

                    for (int x = 0; x < dose.XSize; x++)
                        for (int y = 0; y < dose.YSize; y++)
                            meanDose += dose.VoxelToDoseValue(buffer[x, y]);
                }

                meanDose /= dose.XSize * dose.YSize * dose.ZSize;
                LocalProgressText = "MeanDose er " + meanDose.ValueAsString;
                CheckPointListCourse_Title = "TEEEEEST  1"; //This will not update sinde it does not use OnPropertyChanged
                MessageBox.Show("Finished TestCalculateMeanDose in EclipseCheckModel");
            });
        }

        public void ScanMobiusFolder(EclipseCheckModel eclipseCheckResult, CheckScenarioResult CheckScenarioResult, EsapiWorker esapiWorker) //PatientContext patientContext, 
        {
            esapiWorker.Run(patientContext =>
            {
                //LocalProgressOngoing = true;//Change to ProgressBarWindow
                //LocalProgressText = "Running full update!";
                //LocalProgressValue = 2;
                if (patientContext.SanityLevel >= Constants.SanityLevelPatientExist)
                {
                    string test = PlanExtension.FindDirectoryWithFile(Constants.MobiusPath, patientContext.ChosenPatient.Id);
                }
                

                //LocalProgressValue = 100; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                //LocalProgressText = LocalProgressValue + "% Finished update!" + Environment.NewLine + LocalProgressText;
                //LocalProgressOngoing = false;
            });

        }
        public void ExportResultCSV(EclipseCheckModel eclipseCheckResult, CheckScenarioResult CheckScenarioResult, EsapiWorker esapiWorker) //PatientContext patientContext, 
        {
            esapiWorker.Run(patientContext =>
            {
                //LocalProgressOngoing = true;//Change to ProgressBarWindow
                //LocalProgressText = "Running full update!";
                //LocalProgressValue = 2;

                GeneralExtension.ExportResultAsCSV(eclipseCheckResult, patientContext, CheckScenarioResult);

                //LocalProgressValue = 100; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                //LocalProgressText = LocalProgressValue + "% Finished update!" + Environment.NewLine + LocalProgressText;
                //LocalProgressOngoing = false;
            });

        }

            //PopulateStructureLists CreateMarginLists  CreateReferencePointList FillUpCheckPointList  CleanUpCheckPointList UpdateCheckPointList CountStatusesCheckPointList PopulateCheckPointLists
        public void RunFullUpdate(CheckScenarioResult CheckScenarioResult, EsapiWorker esapiWorker) //PatientContext patientContext, 
        {

            // Use EsapiWorker to concurrently update the GUI:
            esapiWorker.Run(patientContext =>
            {
                //Mouse.OverrideCursor = Cursors.Wait; //This one is useless! No "wait" cursor appears!?!?

                try
                { }
                catch
                {
                }

                //ToDo: Add some kind of symbol image of "Calculation ongoing" and "Calculation finished"
                    // Add image

                LocalProgressOngoing = true;//Change to ProgressBarWindow
                LocalProgressText = "Running full update!";
                LocalProgressValue = 2;
                LocalProgressText = LocalProgressValue + "% PopulateStructureLists" + Environment.NewLine + LocalProgressText;
                PopulateStructureLists(patientContext, CheckScenarioResult);
                LocalProgressValue = 5; //This will update the view while code is running, INotify and OnPropertyChanged implemented


                LocalProgressValue = 8;
                LocalProgressText = LocalProgressValue + "% CreateMarginLists" + Environment.NewLine + LocalProgressText;
                CreateMarginLists(patientContext, CheckScenarioResult);
                LocalProgressValue = 14; //This will update the view while code is running, INotify and OnPropertyChanged implemented


                LocalProgressValue = 15;
                LocalProgressText = LocalProgressValue + "% CreateReferencePointList" + Environment.NewLine + LocalProgressText;
                CreateReferencePointList(patientContext, CheckScenarioResult);
                LocalProgressValue = 17; //This will update the view while code is running, INotify and OnPropertyChanged implemented

                LocalProgressValue = 18;
                LocalProgressText = LocalProgressValue + "% FillUpCheckPointList" + Environment.NewLine + LocalProgressText;
                FillUpCheckPointList(patientContext, CheckScenarioResult); //Also reformat TemplateDisplay values
                LocalProgressValue = 24; //This will update the view while code is running, INotify and OnPropertyChanged implemented


                //LocalProgressValue = 21; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                //LocalProgressText = LocalProgressValue + "% UpdateCollisionModel" + Environment.NewLine + LocalProgressText;

                LocalProgressValue = 24;
                CleanUpCheckPointList(patientContext, CheckScenarioResult); //remove all discarded and inactivated checkpoints. Send them to debug-list.
                LocalProgressValue = 25; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                LocalProgressText = LocalProgressValue + "% CleanUpCheckPointList" + Environment.NewLine + LocalProgressText;

                //Should Collision Check be visible or not?
                if (_checkPointListAll.Where(s => s.CheckSwitchCode == "Collision").Count()>0) //If checkpoint exist in list, make visible the graphics.
                    { CCIsEnabled = true; }
                    else    { CCIsEnabled = false; }



                LocalProgressText = LocalProgressValue + "% Starting UpdateCheckPointList..." + Environment.NewLine + LocalProgressText;
                UpdateCheckPointList(patientContext, CheckScenarioResult); //Both Quick  checkpoints and Late
                LocalProgressValue = 90; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                LocalProgressText = LocalProgressValue + "% Finished UpdateCheckPointList" + Environment.NewLine + LocalProgressText;

                // CleanUpCheckPointList //CountStatusesCheckPointList //PopulateCheckPointLists

                CountStatusesCheckPointList(patientContext, CheckScenarioResult);
                LocalProgressValue = 95; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                LocalProgressText = LocalProgressValue + "% CountStatusesCheckPointList" + Environment.NewLine + LocalProgressText;

                PopulateCheckPointLists(patientContext, CheckScenarioResult);
                LocalProgressValue = 99; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                LocalProgressText = LocalProgressValue + "% PopulateCheckPointLists" + Environment.NewLine + LocalProgressText;

                LocalProgressValue = 100; //This will update the view while code is running, INotify and OnPropertyChanged implemented
                LocalProgressText = LocalProgressValue + "% Finished update!" +Environment.NewLine + LocalProgressText;

                try
                { }
                catch
                {
                    MessageBox.Show("Failed RunFullUpdate method. Det var trist...");
                }
                finally
                {
                    LocalProgressOngoing = false; //Change to FocusWindow
                    //ToDo: Add some kind of symbol image of "Calculation finished"

                    Mouse.OverrideCursor = null;
                    Mouse.UpdateCursor();
                }

                //MessageBox.Show("Values updated RunFullUpdate");
            });
        }

        public void DelayedCalculation(CheckPoint cs, CheckScenarioResult CheckScenarioResult, EsapiWorker esapiWorker) //PatientContext patientContext, 
        {
            // Use EsapiWorker to concurrently update the GUI:
            esapiWorker.Run(patientContext =>
            {
                Mouse.OverrideCursor = Cursors.Wait;
                Mouse.UpdateCursor();

                //Change cs status while calculing!
                cs.CheckStatus = Constants.Calculating;
                cs.CheckResultValue = Constants.Calculating;
                //Start Progress bar
                LocalProgressOngoing = true;//Change to ProgressBarWindow
                LocalProgressText = "Updating Check " + cs.CheckNumber + Environment.NewLine + cs.CheckName; //Add checkName?
                LocalProgressValue = 2;
                //var localProgV = this.LocalProgressValue;
                //var localProgT = this.LocalProgressText;
                //MessageBox.Show(LocalProgressText);
                try //return cursor if any fail.
                {
                    //cs.CalculateDelayed = false; //Change this elsewhere!
                    bool runAsCalculateDelayed = true;
                    //Update that particular checkpoint:
                    RunCheckPointSwitch(cs, patientContext, CheckScenarioResult, runAsCalculateDelayed);       //UpdateCheckPoint.RunCheckPointSwitch(cs, patientContext, CheckScenarioResult, runAsCalculateDelaued);         //ref localProgV, ref localProgT, 
                    //gives me pretty colors!
                    UpdateCheckPoint.ColorCheckPointsDependingOnStatus(new List<CheckPoint> { cs });


                }
                catch
                {
                    MessageBox.Show("Failed RunFullUpdate method. Exits.");
                    cs.CheckStatus = Constants.Unknown;
                    cs.CheckComment = "Krasjet under kalkulering! Ikke ferdig utregnet sjekk!";
                }
                finally
                {
                    Mouse.OverrideCursor = null;
                    Mouse.UpdateCursor();
                    LocalProgressOngoing = false;
                }

            });
        }

        //Earlier it was public static Void (prevents updating ViewModel)
        public void RunCheckPointSwitch(CheckPoint s, PatientContext patientContext, CheckScenarioResult checkScenarioResultat, bool runAsCalculateDelayed = false) //ref double localProgV, ref string localProgT,
        {

            var stopwatch = Stopwatch.StartNew();
            //Set tenporarily to calculating:
            s.CheckResultValue = Constants.Calculating;
            s.CheckStatus = Constants.Calculating;
            //if(s.CheckNumber == "2.8")
            //{
            //    MessageBox.Show("Before." + Environment.NewLine +  "s.CalculateDelayed = " + s.CalculateDelayed.ToString() + Environment.NewLine + " runAsCalculateDelayed = " + runAsCalculateDelayed.ToString() + Environment.NewLine + " s.CheckSwitchCode=" + s.CheckSwitchCode + Environment.NewLine + " s.CheckName=" + s.CheckName);

            //}

            //Stoppes CalculateDelayed from being run unless they should. s.CalculateDelayed status is changed at the very end of this method.
            if (s.CalculateDelayed == true && runAsCalculateDelayed == false) //s.CalculateDelayed // Changed from CalculateLate to CalculateDelayed in v 1.1.5!
            {
                stopwatch.Stop();
                if (s.CheckResultValue == "" || s.CheckResultValue == null) { s.CheckResultValue = "▶️ Regn ut"; } //Always add button text if CalculateLate.
                s.CheckTimeElapsed = stopwatch.ElapsedMilliseconds.ToString();
                return; //Exits method early

            }

            //Stops checkpoints that are allready calculated from being run again:



            //if (s.CheckNumber == "2.8")
            //{
            //    MessageBox.Show("After." + Environment.NewLine + "s.CalculateDelayed = " + s.CalculateDelayed.ToString() + Environment.NewLine + " runAsCalculateDelayed = " + runAsCalculateDelayed.ToString() + Environment.NewLine + " s.CheckSwitchCode=" + s.CheckSwitchCode + Environment.NewLine + " s.CheckName=" + s.CheckName);

            //}

            //Setting technique and machine, fieldlist etc.
            //----------------------
            string chosenTemplateName = checkScenarioResultat.TemplateName;
            PlanTechnique planTechnique = checkScenarioResultat.CheckScenarioTechnique;


            //Setting template values
            EclipseCheckTemplate chosenEclipseTemplate = checkScenarioResultat.TemplateChosen;  //EclipseCheckTemplate ValgtEclipseTemplat = checkScenarioResultat.EclipseCheckTemplateList.Where(x => x.TemplateName == templatnavn).FirstOrDefault(); //templatFraksjoneringer 
            //----------------------

            //Set basic variables
            #region "Input variables"
            Patient patient = patientContext.ChosenPatient;//setter pasient
            ExternalPlanSetup plan = patientContext.ChosenPlan; //setter plan
            Course course = patientContext.ChosenCourse; //setter Course hvis plan eksisterer
            //Setter og sjekker struktursett - OBS: plansummer kan ha flere struktursett:
            StructureSet structureSet = patientContext.ChosenStructureSet;
            Structure ptv = patientContext.TargetVolume;
            string checkSwitchCode = "";
            #endregion



            //PD analysis variables
            bool pdPlanChecked = false;
            string pdPlanExist = Constants.False;
            double gyperFr = 0;
            double totMU = 0;
            double muperGy = 0; //"mange";
            string muperGyString = "";
            int antallFr = 0; //trenger som input til pdsjekk.
            string teknikkMLC = "";
            ExternalPlanSetup PDPlan = plan;
            var pdCheck = new PDCheck
            {
                CheckRationale = "",
                CheckNecessary = false,
                CheckToleranceLimit = ""
            };
            bool pdCheckNecessary = false; //.ToString();
            string rationalePDplan = ""; //Legg inn uthenting av kollimatorvinkel hvis den er i 90 grader som tekst i begrunnelse.
            string pdPlanId = "";
            string checkToleranceLimit = "";




            //Fra sus
            IEnumerable<ExternalPlanSetup> allAllPlans = patient.Courses.SelectMany(c => c.ExternalPlanSetups.OrderBy(p => p.Id));
            IEnumerable<ExternalPlanSetup> allPlans = patient.Courses.SelectMany(c => c.ExternalPlanSetups.Where(p => (p.ApprovalStatus == PlanSetupApprovalStatus.TreatmentApproved && !p.Id.StartsWith("QA") && !p.Course.Id.Contains("QA")) || p == plan)).OrderBy(p => p.Id);
            IEnumerable<Beam> nonSetupFields = plan.Beams.Where(b => !b.IsSetupField);

#if v18 //Comment "v18" in project properties -> Build -> Conditional Compilation Symbols to use ESAPI v.18 methods. Otherwise use custom code that can run on v16.
            Dictionary<string, bool> planBools = new Dictionary<string, bool>{
                { "isVmat" , nonSetupFields.Any(b => b.BeamTechnique == BeamTechnique.VMAT) },
                { "isImrt" , nonSetupFields.Any(b => b.IsIMRT) },
                { "isConventional" , nonSetupFields.Any(b => b.BeamTechnique == BeamTechnique.Static) }
                };

#else
            Dictionary<string, bool> planBools = new Dictionary<string, bool>{
                { "isVmat" , nonSetupFields.Any(b => FieldExtension.CheckIfFieldIsArc(b) == true || FieldExtension.CheckIfFieldIsSRSArc(b) == true ) },  // { "isVmat" , nonSetupFields.Any(b => b.BeamTechnique == BeamTechnique.VMAT) }, SUS uncomment
                { "isImrt" , nonSetupFields.Any(b => FieldExtension.CheckIfFieldIsIMRT(b) || FieldExtension.CheckIfFieldIsFiF(b))}, //{ "isImrt" , nonSetupFields.Any(b => b.IsIMRT) }, SUS uncomment
                { "isConventional" , nonSetupFields.Any(b => FieldExtension.CheckIfFieldIsStatic(b)) } //{ "isConventional" , nonSetupFields.Any(b => b.BeamTechnique == BeamTechnique.Static) } SUS uncomment
                };

#endif

            //End fra sus

            if(s.CheckSwitchCode == null)
            {
                checkSwitchCode = ""; //skips
            }
            else
            {
                checkSwitchCode = s.CheckSwitchCode; //checkName = s.CheckName;
                //if (s.CheckCategory.Contains("DVH")) { checkSwitchCode = s.CheckCategory; } //Alle DVH-sjekker kan bruke samme kode, så kun kategorien er viktig. //Does not exist anymore
            }

            

            //if (s.CheckName.Contains("Marginer")) { checkSwitchCode = "Marginer"; }



            switch (checkSwitchCode)
            {

                //-------------------------------------------
                //--------    Teknikk     -------------------
                //-------------------------------------------
                case "DoseRate": //"Doserate":

                    s = PlanExtension.CheckDoserate(plan, s);
                    break;

                case "WedgeMU": //"Kilefelt > 20 MU":
                    s = PlanExtension.CheckWedge(plan, s, checkScenarioResultat.CheckScenarioFieldList);
                    break;

                case "CollimatorAngle": //"Collimatorvinkel >= 2°":
                    s = PlanExtension.CheckCollimatorAngle(plan, s, checkScenarioResultat.CheckScenarioFieldList);
                    break;

                //Avoidance JawTracking Small Fieldsizw
                case "Avoidance": //"Avoidance":
                    s = PlanExtension.CheckAvoidance(plan, s);  //Reove if s.CheckComment == ""
                    break;

                case "JawTracking": //"JawTracking":
                    s = PlanExtension.CheckJawTrackingStatus(plan, s); //Only for vmat / srs

                    break;

                case "SmallFieldSize": //"Liten feltstørrelse":
                    s = FieldExtension.CheckFieldSize(plan, s, planTechnique.TechniqueName, checkScenarioResultat.CheckScenarioFieldList);
                    break;

                // ------------------------------------------
                // ------------------------------------------
                case "Intent": //"Intensjon":
                    s = CourseExtension.CheckIntention(s, course);
                    break;

                case "Diagnosis": //"Diagnose":
                    s = CourseExtension.CheckDiagnosis(s, course);
                    break;

                //Fraksjonering
                case "Fractionation": //"Fraksjonering":
                    s = PlanExtension.CheckFractionation(s, plan);
                    break;

                case "Normalization": //"Normalisering":
                    s = PlanExtension.CheckNormalizationMethod(s, plan);
                    break;

                case "CalcAlgo": //"Beregningsalgoritme":
                    s = PlanExtension.CheckCalculationAlgorithm(s, plan, planTechnique.TechniqueName);
                    break;

                case "CalcResolution": //"Kalkuleringsoppløsning (cm)":
                    s = PlanExtension.CheckCalculationResultion(s, plan, planTechnique.TechniqueName);
                    break;

                //UserOrigin lagt inn
                case "UserOrigin": //"UserOrigin:":
                    s = StructureExtension.CheckUserOrigin(s, structureSet, patientContext);
                    break;

                case "CouchNamesAndHUs":  //"Bord lagt inn": //"BordtoppSurface" replaced.
                    s = StructureExtension.CheckCouchStructures(s, structureSet, patientContext); //  s = StructureExtension.CheckCouchSurfaceID(s, structureSet, patientContext);
                    break;

                //case "BordtoppSurface HU": //This is replaced by above combined checkpoint
                //    s = StructureExtension.CheckCouchHU(s, structureSet, patientContext);
                //    break;

                case "EmptyStructures": //"Tomme strukturer":
                    s = StructureExtension.CheckEmptyStructures(s, structureSet);  //Inactivate if s.CheckResultValue == ""
                    break;

                case "HRStructures": // "HR strukturer":
                    s = StructureExtension.CheckHighResolutionStructures(s, structureSet, patientContext, chosenTemplateName);  //Inactivate if s.CheckResultValue == ""
                    break;

                //"HighResolution strukturer"

                case "PatientOrientation": //"PasientOrientering":
                    s = PlanExtension.CheckPlanPatientOrientation(s, plan);
                    break;

                case "CTSliceThickness": //"CT Slice Thickness":
                    s = CTExtension.CheckCTSliceThickness(s, patientContext.ChosenImage);
                    break;

                //Marginer
                case "Margins": //"Marginer":
                    //There are several of these checkpoints, one per match of smallStructure to largeStructure (for every CTV-PTV pair, and every GTV-CTV pair etc)

                    //List<MarginList> listOfMarginLists;
                    //listOfMarginLists = MarginsExtension.CreateListOfMarginLists(patientContext, checkScenarioResultat.TemplateName); ; //This also calculates the margins - should be done in separate step! //Is used to create CheckPointList later.
                    s = MarginsExtension.CheckMargins(s, _listOfMarginLists, patientContext.ChosenStructureSet, patientContext.BodyId, patientContext);
                    break;

                //BodyFreeBreathingExists
                case "BodyFreeBreathingExists": //"Marginer":
                    //There are several of these checkpoints, one per match of smallStructure to largeStructure (for every CTV-PTV pair, and every GTV-CTV pair etc)

                    //List<MarginList> listOfMarginLists;
                    //listOfMarginLists = MarginsExtension.CreateListOfMarginLists(patientContext, checkScenarioResultat.TemplateName); ; //This also calculates the margins - should be done in separate step! //Is used to create CheckPointList later.
                    s = CTExtension.BodyToFreeBreathingExist(patientContext, checkScenarioResultat.CheckScenarioFieldAnalysis, s);
                    break;

                case "PrimaryReferencePoint": //"Primært referansepunkt lik Target Structure":
                    s = ReferencePointExtension.CheckPrimaryReferencePointAgainstStructureID(s, plan, ptv, patientContext); //Requires TargetVolume tot exist! Needs patientContext
                    break;

                case "SecondaryReferencePoints": //"Sekundære referansepunkt lik strukturnavn":
                    s = ReferencePointExtension.CheckSecondaryReferencePointAgainstStructureID(s, plan, ptv, structureSet, patientContext); // inactivate if s.CheckResultValue == "" || s.CheckResultValue == null
                    break;

                case "CommonReferencePoint": //"Finnes bidrag fra annen plan til felles referansepunkt":
                    s = PlanExtension.SequentialPlanExist(s, patientContext); // inactivate if s.CheckResultValue == "" || s.CheckResultValue == null
                    break;

                case "ToleranceTableTreat": // "Toleransetabell beh.felt":
                    s = PlanExtension.CheckTolerancetableTreat(s, plan);
                    break;

                case "ToleranceTableSetup": //"Toleransetabell setupfelt":
                    s = PlanExtension.CheckTolerancetableSetup(s, plan);
                    break;

                case "NumberSetupFields": //"Antall setupfelt":
                    s = PlanExtension.CheckNumberOfSetupFields(s, plan); //Not testet since it was reqritten 05.05.2025
                    break;

                case "NumberBolusFields": //"Antall bolus setupfelt":
                    List<StructureCheck> boluses = StructureExtension.GetBolusList(patientContext);
                    s = PlanExtension.CheckNumberOfBolusSetupFields(s, plan, boluses, planTechnique.TechniqueName); //Inactivate if bolusAttached == false : completeCheckPointList.RemoveAt(i);
                    break;

                case "InvalidCharactersInID": //"Antall bolus setupfelt":
                    s = PlanExtension.CheckInvalidCharactersInID(s, plan); //Inactivate if bolusAttached == false : completeCheckPointList.RemoveAt(i);
                    break;

                case "Laterality":    // "Lateralitet":  //Only if known and tested patientOrientation!!!
                    s.CheckComment = "";
                    //Sjekker om lateraliteten fra isosenter stemmer med navngivningene av strukturer og MV
                    s = PlanExtension.CheckLaterality(checkScenarioResultat.CheckScenarioFieldAnalysis, chosenEclipseTemplate.TemplatePTVStructureIDs, chosenEclipseTemplate.TemplatePlanIDs, s, plan);
                    break;

                case "Mobius": //"Mobius":
                    s = PlanExtension.CheckMobius(plan, s);
                    //Sjekker mot templatet
                    s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(s.CheckResultValue, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);


                    break;



                // ----------------------------------
                // ---------- START PD --------------
                // ----------------------------------

                case string checkNamePD when checkNamePD.Contains("PD"):

                    // ----------------------------------
                    // ---------  PD  PRECHECK   --------
                    //-----------------------------------
                    //run only once. Several Checks are dependent on this being run. 
                    if (pdPlanChecked == false)
                    {
                        gyperFr = plan.PlannedDosePerFraction.Dose;
                        totMU = PlanExtension.HentTotMU(plan);
                        muperGy = PlanExtension.HentMUPerGy(plan); //"mange";
                        muperGyString = Math.Round(muperGy, 1).ToString();
                        antallFr = plan.NumberOfFractions ?? default(int); //trenger som input til pdsjekk.
                        teknikkMLC = PlanExtension.GetTechniqueMLC(plan);
                        pdCheck = PDExtension.PDCheckNecessary(muperGy, teknikkMLC, gyperFr, antallFr);  // Int32.Parse(plan.NumberOfFractions.ToString()
                        pdCheckNecessary = pdCheck.CheckNecessary; //.ToString();
                        rationalePDplan = pdCheck.CheckRationale; //Legg inn uthenting av kollimatorvinkel hvis den er i 90 grader som tekst i begrunnelse.
                        pdPlanId = PDExtension.GetPDPlan(patientContext, plan, pdCheck.CheckNecessary);
                        PDPlan = PDExtension.GetPDPlan_returnPlan(patientContext, plan, pdCheck.CheckNecessary); //Endrer til verifikasjonplanen
                        checkToleranceLimit = pdCheck.CheckToleranceLimit;
                        if (pdPlanId != "") { pdPlanExist = Constants.True; }
                        pdPlanChecked = true;
                        s.CheckDebug = s.CheckDebug + "Analyserer om PD nødvendig. ";
                    }
                    // ----------------------------------
                    // ----------------------------------


                    // ---------- PD-plan Nødvendig ------------
                    if (checkSwitchCode == "PDNecessary") //"PD nødvendig: (MU/Gy > grenseverdi)"
                    {
                        s = PDExtension.CheckIsPDNecessary(s, plan, pdCheck, pdPlanExist, muperGyString);

                    }

                    // ---------- PD-plan Generert ------------
                    if (checkSwitchCode == "PDCreated") //"PD: PD-plan generert"
                    {
                        s = PDExtension.CheckIsPDCreated(s, plan, pdCheck, pdPlanExist, pdPlanId);  //Remove if pdCheck.CheckNecessary != true

                    }

                    // ---------- PD-plan Schedulert ------------
                    if (checkSwitchCode == "PDScheduled") //"PD: PD-plan schedulerte behandlinger"
                    {
                        s = PDExtension.CheckIsPDPlanScheduled(s, plan, pdCheck, pdPlanExist, pdPlanId, PDPlan);  //Remove if pdCheck.CheckNecessary != true
                    }
                    //End PD sjekk
                    break;

                // ----------------------------------
                // ---------- END PD  ---------------
                // ----------------------------------

                case "ExtendedStatus":  //"Bakfrafelt og Extended-status"

                    s = PlanExtension.CheckExtendedFieldStatus(s, plan, checkScenarioResultat.CheckScenarioFieldAnalysis);
                    break;
                
               //add code here!  Now check is "done" before we get here. Output is simply "it exists" ish.
                case "GantryAngleExtended":
                    s.CheckStatus = Constants.Info; //If checkpoint exists (not discarded at runtime) then result is status: it exists....
                    s.CheckResultValue = "";
                    //TO DO
                    break;

                case string a when a.Contains("BasePlan"):  //Contains("Base Plan")

                    string basePlanId = PlanExtension.HentBasePlanString(plan);
                    //Legger kun til sjekkpunktet hvis base plan eksisterer
                    if (checkSwitchCode == "BasePlanExist") //"Base Plan"
                    {
                        s = PlanExtension.CheckBasePlan(plan, s, basePlanId);
                    }
                    else if (checkSwitchCode == "BasePlanContribution") //"Base Plan bidrag i %"
                    {
                        s = PlanExtension.CheckBasePlanPercentage(plan, s, basePlanId);
                    }

                    //Legge til Base Plan samme feltparametre:
                    //Legge til Baseplan

                    break;

                case string a when a.Contains("Fluence"): //a.Contains("Fluence")
                    //Fluence Max
                    string hasFluence = PlanExtension.PlanHasFluence(plan);

                    if (checkSwitchCode == "FluenceMaxPrint")  //"Fluence_Max fra IMRT-felt"
                    {
                        s = PlanExtension.CheckMaxFluenceMatrixPlan(plan, s, hasFluence);  // Remove if hasFluence = False
                    }
                    if (checkSwitchCode == "SmallestFluenceMax") // "Minste Fluence_Max"
                    {
                        s = PlanExtension.CheckSmallestMaxFluencePlan(plan, s, hasFluence);  // Remove if hasFluence = False
                    }
                    break;

                case "CouchAngle": //"Couchvinkel"
                    s = PlanExtension.CheckCouchvinkel(plan, s); //Remove if irrelevant s.CheckResultValue == Constants.False
                    break;

                case "EnergyChoice": //"Energivalg" //Add logics for if structure pacemaker/ICD etc exist.

                    s = PlanExtension.CheckEnergies(plan, s);
                    break;

                case "Machine": //"Maskin"
                    s.CheckStatus = Constants.Printout;
                    s = PlanExtension.CheckMachine(plan, s);
                    //Sjekker mot templatet
                    //CheckPointExtension.SjekkResultatMotTemplat(s.SjekkResultatVerdi, s.SjekkTemplatVerdi, s.SjekkTrafikklys, "string");
                    break;

                case "Technique": //"Teknikk"
                    s = FieldExtension.CheckTechnique(plan, s, planTechnique);
                    break;

                case "IsoLimitHalcyon": //"Isosenter-begrensning Halcyon"
                    s = PlanExtension.CheckIsosenterWarningHalcyonEthos(plan, s);
                    break;


                case "IsoLimitEthos": //"Isosenter-begrensning Ethos"
                    s = PlanExtension.CheckIsosenterWarningHalcyonEthos(plan, s);
                    break;

                //AvstandIsoBord = Hjelpefunksjoner.DistanceFromCouchToIsosenter_Corrected(plan); "Avstand Bordoverflate til isosenter"

                case "DistanceCouchIsosenter": //Does not exist any more
                    s = StructureExtension.CheckDistanceFromCouchToIsosenter_Corrected(plan, s);
                    break;

                case "Collision": //"Kollisjonsjekk mot Body og Couch"
                    CheckCollision(patientContext, s, checkScenarioResultat);  //s = CollisionCheck.CheckCollision(patientContext, s);
                    break;
                //Kollisjonsjekk mot Body og Couc


                case "ElectronCustomCode": //"Elektroner Applikator/Tray/CustomCode:"
                    s = PlanExtension.GetApplicatorTrayCode(plan, s);
                    break;

                //Elektroner Applikator/Tray/CustomCode:

                case string a when a.Contains("DVH"):  //a.Contains("DVH")
                    s = DVHExtension.GetDvhValue(plan, s, s.DvhValue);
                    break;


                //SUS CASES
                case "PrescriptionApproved": //"Rekvisisjon godkjent?"
                    SUSExtension.CheckPrescription(plan, s);
                    break;
                case "DosePlanNumberSUS": //"Doseplannummer"
                    SUSExtension.CheckDoseplanNumber(plan, s, nonSetupFields);
                    break;
                case "FormattingNamesSUS": //"Formatering plan og felt-navn"
                    SUSExtension.CheckPlanAndFieldName(plan, allPlans, s);
                    break;
                case "PortalDosePlanSUS": //"Plan har portal dose plan"
                    SUSExtension.CheckPortalDose(plan, allAllPlans, s, planBools);
                    break;
                case "PlanApprovedSUS": //"Plan godkjent og reviewed?"
                    SUSExtension.CheckPlanApproved(plan, s);
                    break;
                case "PlanUnapproved": //"Plan satt unapproved etter reviewed?"
                    SUSExtension.CheckUnapproved(plan, s);
                    break;
                case "NumberOfTreatments": // "Antall behandlinger"
                    SUSExtension.CheckTreatmentSessions(plan, s);
                    break;
                case "FiFMerged": // "Field-in-field-felt slått sammen"
                    SUSExtension.CheckFieldInField(plan, s);
                    break;
                case "MissingCTSlices": //"CT mangler ikke snitt"
                    SUSExtension.CheckMissingSlices(patientContext.ChosenImage, s);
                    break;
                case "HUinPTV": //"HU i PTV > -850"
                    //EclipseCheckModel ecm = new EclipseCheckModel();
                    CheckHuPtv(patientContext.ChosenImage, plan, s); //, ref localProgV, ref localProgT);
                    break;
                case "PlanUncertainties": //"Plan Uncertainties"
                    SUSExtension.CheckPlanUncertainties(s, plan);
                    break;
            }
            stopwatch.Stop();
            s.CheckTimeElapsed = stopwatch.ElapsedMilliseconds.ToString();

            //remove CalculateDelayed status when check is finally completed
            if (s.CalculateDelayed == true && runAsCalculateDelayed == true) { s.CalculateDelayed = false; }

            return;

        }




        // ------------------------------------
        //--- Specific SLOW CheckPoints ------------
        //-------------------------------------

        // These must be run insid EclipseCheckModel (at least I have not made it work outside) to simultaniously update GUI with progress.
        // Therefore moving all "slow" checks here.


        public void CheckHuPtv(EclipseImage img, ExternalPlanSetup plan, CheckPoint checkPoint) //, ref double localProgV, ref string localProgT)
        {
            /* Sjekk om det er voxler med HU < -850 i PTV
             * Rød: Hvis PTV ikke har volum
             * Gul: Hvis PTV har voxler med HU < -850 og det ikke er lagt til struktur for å overskrive HU, eller hvis struktur lagt til for å overskrive HU ikke dekker alle voxler under -850 HU
             * Grønn: Hvis ikke gul eller rød
             * Output: Om det er lagt til HU korrigering eller ikke, samt den minste HU verdien i PTV
             * Notat: 
             */

            LocalProgressValue = 0;
            LocalProgressText = "0% CheckPoint CheckHuPtv progress";

            //LocalProgressOngoing = true;
            if (checkPoint.CalculateDelayed == true) //FOR SOME REASON IT LOOSES THIS STATUS BEFORE HERE. THIS CODE IS NOT RUN. (I mean it does not matter as it can ONLY be run as in CalculateDelayed state...
            {
                _localProgressValue = 1;
                LocalProgressText = "1% CheckPoint CheckHuPtv progress";

                //Set progress bar
            }
            //MessageBox.Show("Check Which value is set to LocalProgressText!");
           

            var structure = plan.StructureSet.Structures.FirstOrDefault(s => s.Id == plan.TargetVolumeID);

            if (structure == null)
            {
                checkPoint.CheckComment = "Plan mangler target volume";
                checkPoint.CheckStatus = Constants.Error;
                return ;
            }


            if (structure.Volume == 0)
            {

                if (plan.TargetVolumeID.StartsWith("NV"))
                {
                    checkPoint.CheckComment = "PTV ikke definert i virtuell plan";
                    checkPoint.CheckStatus = Constants.Ok;
                    return ;
                }
                else
                {
                    checkPoint.CheckComment = "Har ikke volum";
                    checkPoint.CheckStatus = Constants.Error;
                    return ;
                }

            }

            double assignedHU = 0;
            var structAssignedHu = plan.StructureSet.Structures.FirstOrDefault(s => s.GetAssignedHU(out assignedHU));

            if (structure == null) { MessageBox.Show("PTV ikke funnet"); return  ; }

            var allHu = new List<double>(capacity: 100000); // guess
            var unassignedVoxelsPtv = new List<double>(capacity: 100000);

            // Precompute image bounds in DICOM mm
            double imgXMin = img.Origin.x;
            double imgYMin = img.Origin.y;
            double imgZMin = img.Origin.z;
            double imgXMax = imgXMin + (img.XSize - 1) * img.XRes;
            double imgYMax = imgYMin + (img.YSize - 1) * img.YRes;
            double imgZMax = imgZMin + (img.ZSize - 1) * img.ZRes;
            double progress = 0;

            for (int k = 0; k < img.ZSize; k++)
            {
                //if (checkPoint.CalculateDelayed == true)
                //{
                    //Main progress bar is used for delayedcalculation. Or we can use progressbar in the CheckPoint itself?
                    //This should also be implemented for LateCalculation CheckPoints (that is run last in the loop): that should be using secondary smaller progressbar, or in checkpoint it self.
                    progress = Math.Round((double)k / (double)img.ZSize * 100,1);
                    LocalProgressValue = progress;
                    LocalProgressText = progress.ToString() + "% CheckPoint (" + k + "/" + img.ZSize +")";

                    //Set progress bar
                //}


                // Use correct Z coord
                double zCoord = imgZMin + k * img.ZRes;

                // Get contours on this image plane
                var contours = structure.GetContoursOnImagePlane(k);
                //if (contours == null || contours.Length == 0) continue;

                // Flatten
                var pts = contours.SelectMany(loop => loop);
                if (!pts.Any()) continue;


                // # samples along X & Y (voxel centers)
                int xSamples = img.XSize;
                int ySamples = img.YSize;

                for (int j = 0; j < img.YSize; j++)
                {
                    double yCoord = imgYMin + j * img.YRes;  // go low→high; order doesn't matter

                    var startPt = new VVector { x = imgXMin, y = yCoord, z = zCoord };
                    var endPt = new VVector { x = imgXMax, y = yCoord, z = zCoord };

                    BitArray assignedHUArray = new BitArray(xSamples);

                    // Profiles
                    var imgProf = img.GetImageProfile(startPt, endPt, new double[xSamples]);
                    var segProf = structure.GetSegmentProfile(startPt, endPt, new BitArray(xSamples));
                    int n = Math.Min(imgProf.Count, segProf.Count);

                    SegmentProfile huProf;

                    if (structAssignedHu != null)
                        huProf = structAssignedHu.GetSegmentProfile(startPt, endPt, assignedHUArray);
                    else
                        huProf = new SegmentProfile(new VVector(), new VVector(), new BitArray(xSamples));


                    for (int i = 0; i < n; i++)
                    {
                        if (segProf[i].Value && !huProf[i].Value)   // inside structure
                            unassignedVoxelsPtv.Add(imgProf[i].Value);
                    }

                    for (int i = 0; i < n; i++)
                    {
                        if (segProf[i].Value)   // inside structure
                            allHu.Add(imgProf[i].Value);


                    }



                }

            }



            int missingVoxelsUnderThreshold = unassignedVoxelsPtv.Count(v => v < -850);
            int voxelsUnderThreshold = allHu.Count(v => v < -850);
            double volumePerVoxel = img.XRes * img.YRes * img.ZRes; // in mm^3

            string strCSV = "";

            var str = $"HU korrigering gjort: {assignedHU == -850}\n" +
                $"Minste HU i struktur: {unassignedVoxelsPtv.Min()}\n";
            var comment = "";
            checkPoint.CheckStatus = Constants.Ok;

            //CSV output:
            strCSV = assignedHU + ":" + unassignedVoxelsPtv.Min();

            if (assignedHU == -850 && unassignedVoxelsPtv.Min() < -850)
            {
                comment += $"Antall voxler som mangler å assignes under -850 HU: {missingVoxelsUnderThreshold}\n" +
                $"Prosentvoxler som mangler å assignes: {Math.Round(((double)missingVoxelsUnderThreshold / (double)allHu.Count()) * 100, 2)}%\n" +
                $"Volum som mangler å assignes: {Math.Round(volumePerVoxel * missingVoxelsUnderThreshold, 2)} mm^3";
                checkPoint.CheckStatus = Constants.Warning;
                checkPoint.CheckComment = comment;

                //CSV output:
                strCSV = strCSV + "|" + Math.Round(((double)missingVoxelsUnderThreshold / (double)allHu.Count()) * 100, 2).ToString() + "%" + ":" + Math.Round(volumePerVoxel * missingVoxelsUnderThreshold, 2).ToString() + "mm^3";
            }
            else if (allHu.Min() < -850)
            {
                comment += $"Antall voxler under -850 HU: {voxelsUnderThreshold}\n" +
                $"Prosentvoxler: {Math.Round(((double)voxelsUnderThreshold / (double)allHu.Count()) * 100)}%\n" +
                $"Volum: {Math.Round(volumePerVoxel * voxelsUnderThreshold, 2)} mm^3";
                checkPoint.CheckStatus = Constants.Warning;
                checkPoint.CheckComment = comment;

                //CSV output:
                strCSV = strCSV + "|" + Math.Round(((double)voxelsUnderThreshold / (double)allHu.Count()) * 100).ToString() + "%" + ":" + Math.Round(volumePerVoxel * voxelsUnderThreshold, 2).ToString() + "mm^3";
            }

            checkPoint.CheckResultValue = str;
            checkPoint.CheckResultValueCSV = strCSV;

            return ;
        }

        //---
        //Checks collision for the whole plan
        //input and output is a CheckPoint, that is sent to View.
        //---
        public void CheckCollision(PatientContext patientContext, CheckPoint s, CheckScenarioResult checkScenarioResult)
        {
            string debugGetBodyCouchModelMethodView = "";
            string debugGetBodyCouchModelMethodCalculation = "";


            //Only if correct (or semicorrect) patientorientation, AND not for electron plans.
            //patientContext.ChosenPlan.Beams.FirstOrDefault().EnergyModeDisplayName.Contains("E")
            if ((patientContext.ChosenPlan.TreatmentOrientation == PatientOrientation.HeadFirstSupine || patientContext.ChosenPlan.TreatmentOrientation == PatientOrientation.HeadFirstProne) && checkScenarioResult.CheckScenarioTechnique.TechniqueName != Constants.Teknikk.Electron_technique_forklaring)  //(patientContext.ChosenPlan.TreatmentOrientation != PatientOrientation.HeadFirstSupine  || patientContext.ChosenPlan.TreatmentOrientation != PatientOrientation.HeadFirstProne)
            {
                bool warning = false;
                bool error = false;
                bool obs = false;
                string finalStatus = "";
                int fieldNumber = 0;
                int? maxFieldNumber = patientContext.ChosenPlan.Beams.Count();

                ObservableCollection<CollisionCheckViewModel> collisionSummaries = new ObservableCollection<CollisionCheckViewModel>();
                string checkOutput = "";
                string checkOutputCSV = "";
                checkOutput = GeneralExtension.FormatString(18, 18, "FeltID" + Constants.StringSeparator + "GantryTilBody" + Constants.StringSeparator + "GantryTilBord" + Constants.StringSeparator + "Kollisjonsstatus");
                //checkOutputCSV =  "FeltID" + ":" + "GantryTilBody" + ":" + "GantryTilBord" + ":" + "Kollisjonsstatus";
                //Collimator-Gantry model
                Model3DGroup collimatorModel = new Model3DGroup(); //More complex collimatormodel for the View.
                Model3DGroup collimatorModel_calculation = new Model3DGroup(); //Simplified model used for calculation. Saves time (from 70 s -> 14 s ish).



                //--------------------
                //Couch and Body model for View
                //--------------------
                var stopwatch1 = Stopwatch.StartNew();
                Model3DGroup couchBodyModel = new Model3DGroup(); 
                //NEED TO ADD SEVERAL COUCHES!!!
                var couchBodyModel_mesh = CollisionCheck.AddCouchBodyMesh(patientContext.ChosenStructureSet.Structures.FirstOrDefault(o => o.Id == patientContext.BodyId), patientContext.ChosenStructureSet);
                //var couchBodyModel_mesh = CollisionCheck.AddCouchBodyMesh(patientContext.ChosenStructureSet.Structures.FirstOrDefault(o => o.Id == patientContext.BodyId), patientContext.ChosenStructureSet.Structures.FirstOrDefault(o => o.Id == patientContext.CouchId));
                couchBodyModel.Children.Add(couchBodyModel_mesh);
                stopwatch1.Stop();
                debugGetBodyCouchModelMethodView = "GetBodyCouchModel View: " + stopwatch1.ElapsedMilliseconds.ToString() + "ms";
                //--------------------

                //isosenter
                //---------------------------
                Beam firstField = patientContext.ChosenPlan.Beams.FirstOrDefault();
                if (firstField != null)
                {
                    _isoctr.X = firstField.IsocenterPosition.x;
                    _isoctr.Y = firstField.IsocenterPosition.y;
                    _isoctr.Z = firstField.IsocenterPosition.z;
                }
                //---------------------------

                //--------------------
                // Get Body and Couch mesh for calculation
                //--------------------
                var stopwatch2 = Stopwatch.StartNew();
                var body = patientContext.ChosenPlan.StructureSet.Structures.Where(x => x.Id.Contains("BODY")).First();
                Structure couch = null;
                MeshGeometry3D couchMesh = null;
                MeshBuilder couchMeshBuilder = new MeshBuilder(false, false); //Added 25.02 breped //False for normalization demanded
                try
                {
                    foreach (Structure structure in patientContext.ChosenPlan.StructureSet.Structures)
                    {
                        if (structure.StructureCodeInfos.FirstOrDefault().Code == "Support" && structure.HasSegment && !structure.IsEmpty) //Will crash if not properly segmented
                        {
                            couch = structure;
                            couchMesh = couch.MeshGeometry;
                            couchMeshBuilder.Append(couchMesh); //Added 25.02 breped
                        }
                    }
                    //Combine all couch structure in the end:
                    couchMesh = couchMeshBuilder.ToMesh(); //Added 25.02 breped
                }
                catch (Exception e)
                {
                    couch = null;
                    MessageBox.Show("Feilmelding oppstod i CalculateBeamCollision angående summering av support-strukturer. Så teit da. Hopper til neste punkt. Feilmelding: " + Environment.NewLine + e.Message); //Added 25.02 breped
                }
                var bodyMesh = body.MeshGeometry;
                stopwatch2.Stop();
                debugGetBodyCouchModelMethodCalculation = "GetBodyCouchModel Calculation: " + stopwatch2.ElapsedMilliseconds.ToString() + "ms";
                //--------------------


                //--------------------
                //Get Cameraposition:
                //--------------------
                Point3D cameraPosition = CollisionCheck.GetCameraPosition(patientContext.ChosenPlan.Beams.FirstOrDefault()); //just chosing the first field for starters

                foreach (Beam felt in patientContext.ChosenPlan.Beams)
                {
                    //Todo: Insert progressbar with max value max number of fields...
                    fieldNumber = fieldNumber + 1;
                    LocalProgressText = "CheckCollision (field " + fieldNumber + "/" + maxFieldNumber + ")" + Environment.NewLine + LocalProgressText;

                    if (felt.IsSetupField == false)
                    {

                        //Add meshes and to distance calculations:
                        CollisionCheckViewModel collisionCheckViewModel = new CollisionCheckViewModel();
                        //collisionCheckViewModel = CollisionCheck.CheckBeamCollision(felt, patientContext.ChosenPlan); 
                        collisionCheckViewModel = CollisionCheck.CalculateBeamCollision(patientContext.ChosenPlan,felt, couchMesh, bodyMesh, couch, body); //Edited 17.06.2026 breped
                        
                        //couchBodyModel already created before - it should not need to be recreated per field! Fix!
                        //Static method that cannot update the viewModel "live". Maybe move over to model.


                        collisionSummaries.Add(collisionCheckViewModel); //Need to update CollisionSummary in view.

                        //Add meshed to model sent to view.
                        var collimatorModel_beam = CollisionCheck.AddFieldMesh(felt, collisionCheckViewModel.Status);
                        collimatorModel.Children.Add(collimatorModel_beam);

                        string field = collisionCheckViewModel.FieldID;
                        string gantryToBody = collisionCheckViewModel.GantryToBody;
                        string gantryToTable = collisionCheckViewModel.GantryToTable;
                        string collisionStatus = collisionCheckViewModel.Status;
                        //Modify global status
                        if (collisionStatus == Constants.OBS)
                        {
                            obs = true;
                        }
                        if (collisionStatus == Constants.Warning)
                        {
                            warning = true;
                        }
                        if (collisionStatus == Constants.Error)
                        {
                            error = true;
                        }

                        checkOutput = checkOutput + Environment.NewLine + GeneralExtension.FormatString(18, 18, field + Constants.StringSeparator + gantryToBody + Constants.StringSeparator + gantryToTable + Constants.StringSeparator + collisionStatus);
                        
                        if (checkOutputCSV != "" && checkOutputCSV != null) { checkOutputCSV = checkOutputCSV + Constants.StringSeparator; } //Add separator
                        checkOutputCSV = checkOutputCSV + field + ":" + gantryToBody + ":" + gantryToTable + ":" + collisionStatus; //Add data

                    }
                }
                //Update viewModel:
                //_collisionSummaries = CollisionSummaries; //Update
                //_collimatorModel = collimatorModel;
                //_couchBodyModel = Already exists


                //set final status (Do not use traffic light, as there are already to levels of warning/error)
                if (error == true)
                { finalStatus = Constants.Error; }
                else if (warning == true)
                { finalStatus = Constants.Warning; }
                else if (obs == true)
                { finalStatus = Constants.OBS; s.CheckComment = s.CheckComment + "Ikke i stand til å kalkulere avstand til både Body og Couch."; }
                else
                { finalStatus = Constants.Ok; }
                s.CheckStatus = finalStatus;
                s.CheckResultValue = checkOutput;
                s.CheckResultValueCSV = checkOutputCSV;

                //-------------
                //  Debug tidsbruk
                //-------------
                s.CheckDebug = debugGetBodyCouchModelMethodView + " " + debugGetBodyCouchModelMethodCalculation;
                foreach (CollisionCheckViewModel summary in collisionSummaries)
                {
                    s.CheckDebug = s.CheckDebug + Environment.NewLine + summary.FieldID + ":" + summary.Debug;
                }
                //-------------

                LocalProgressText = "Sending Collision Result to View" + Environment.NewLine + LocalProgressText;


                //Running update inside the esapiworker:
                _collimatorModel = collimatorModel;
                _collisionSummaries = collisionSummaries;
                _couchBodyModel = couchBodyModel;
                _cameraPosition = cameraPosition;
                Vector3D upDir = new Vector3D(0, -1, 0);
                Vector3D lookDir = new Vector3D(0, 0, 1); //camera is in minus z direction and should be looking in positiv z direction

                collimatorModel.Freeze(); //DO NOT REMOVE! This was necessary to precent crash "DependencySource må opprettes på samme tråd som DependencyObject" I have no idea why this is the case only for 3D Models
                couchBodyModel.Freeze(); //DO NOT REMOVE! This was necessary to precent crash "DependencySource må opprettes på samme tråd som DependencyObject" I have no idea why this is the case only for 3D Models

                //collisionSummaries.Freeze();

                //cameraPosition.Freeze();
                //_CCIsEnabled = true;
                //CCIsEnabled = true;
                CollimatorModel = collimatorModel;
                //CollisionSummaries = collisionSummaries;
                CouchBodyModel = couchBodyModel;
                CameraPosition = cameraPosition;
                LookDir = lookDir;
                UpDir = upDir;

                //semicorrect patientorientation (that is, experimentally implemented) warning:
                if (patientContext.ChosenPlan.TreatmentOrientation != PatientOrientation.HeadFirstSupine)
                {
                    s.CheckComment = "Kode er ikke laget for PatientOrientation som ikke er 'HeadFirstSupine'! Nå er den '" + patientContext.ChosenPlan.TreatmentOrientation + "'" + Environment.NewLine + "Koordinatsystemet i beregninger kan endre seg da. Vær kritisk til resultatet!";

                }

            }
            else
            { //Invalid - cannot calculate!
                s.CheckStatus = Constants.Unknown;
                s.CheckResultValue = "Ikke mulig å kalkulere.";
                s.CheckComment = "Kode kan ikke sjekke kollisjon hvis:" + Environment.NewLine + " 1) PatientOrientation ikke er 'HeadFirstSupine'" + Environment.NewLine + " 2) det er en Elektron-plan. Ikke modellert riktig enda.";
            }



            //Debug:
            //MessageBox.Show(checkOutput);
            //MessageBox.Show(CCIsEnabled.ToString());
            //MessageBox.Show(CollisionSummaries.Count().ToString());
            //MessageBox.Show(collimatorModel.Children.Count().ToString());

            return;
        }


    }



}
