﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EclipsePlanCheck.Helpers;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

namespace EclipsePlanCheck
{
    /// <summary>
    /// Interaction logic for CheckScenarioView.xaml
    /// </summary>
    public partial class CheckScenarioView : Window
    {
        public CheckScenarioView(CheckScenario checkScenario, PatientContext patientContext)  //, string value)
        {
            
            InitializeComponent();
            DataContext = checkScenario;
            //oppretter et element vi kan manipulere og sende tilbake.
            checkScenarioMod = checkScenario;


            //PlanExtension.FindDirectoryWithFile(Constants.MobiusPath, patientContext.ChosenPatient.Id); //Test loading in cache folder information for Mobius.

     //overrider tooltip duration - Denne kan kun kalles en gang i programmet! Om det gjores flere ganger (i en annet code-behind eller annet program som blir kjørt) vil det krasje! Bare glem det, dette blir altfor volatilt.
     //        ToolTipService.ShowDurationProperty.OverrideMetadata(
     //typeof(DependencyObject), new FrameworkPropertyMetadata(Int32.MaxValue));
     //

            //Gammel kode for å fylle templater i drop-down meny øverst.
            //Grid_templater.SelectedIndex = checkScenarioMod.EclipseCheckTemplatResultat.TemplatIndex;

            //Flytter fokus til cellen med korrekt templat:
            //for (int i = 0; i < Grid_templater.Items.Count; i++)
            //{
            //    //DataGridRow row = (DataGridRow)Grid_templater.ItemContainerGenerator.ContainerFromIndex(i);
            //    //TextBlock cellContent = Grid_templater.Columns[0].GetCellContent(row) as TextBlock;
            //    //if (cellContent != null) { MessageBox.Show(cellContent.Text); }
            //    //if (cellContent != null && cellContent.Text.Equals(checkScenarioMod.EclipseCheckTemplatResultat.TemplatNavn))
            //    //{
            //    //    object item = Grid_templater.Items[i];
            //    //    Grid_templater.SelectedItem = item;
            //    //    Grid_templater.ScrollIntoView(item);
            //    //    row.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            //    //    break;
            //    //}
            //}
            //if (Grid_templater.SelectedIndex != -1)
            //{
            //    MessageBox.Show("SelectedIndex != -1. Selected Index: " + Grid_templater.SelectedIndex.ToString());
            //    //Setter fokus på datagrid.
            //    var selectedRow = (DataGridRow)Grid_templater.ItemContainerGenerator.ContainerFromIndex(Grid_templater.SelectedIndex);
            //    FocusManager.SetIsFocusScope(selectedRow, true);
            //    FocusManager.SetFocusedElement(selectedRow, selectedRow);
            //}


        }

        public EclipsePlanCheck.CheckScenario checkScenarioMod { get; set; }

        //public string myString { get; set; }
        

        private void okButton_Click(object sender, RoutedEventArgs e) //=> DialogResult = true;
        {
            DialogResult = true;
            if (Grid_templater.SelectedIndex != -1)
            {
                //Henter ut templatnavn valgt
                string resultatTemplat = "";
                DataGrid dataGrid = sender as DataGrid;
                DataGridRow row = (DataGridRow)Grid_templater.ItemContainerGenerator.ContainerFromIndex(Grid_templater.SelectedIndex);
                DataGridCell RowColumn = Grid_templater.Columns[0].GetCellContent(row).Parent as DataGridCell;
                resultatTemplat = ((TextBlock)RowColumn.Content).Text;
                //Overrider templat
                EclipseCheckTemplate overridetemplat = (EclipseCheckTemplate)checkScenarioMod.CheckScenarioResult.EclipseCheckTemplateList.Where(x => x.TemplateName == resultatTemplat).FirstOrDefault();

                //MessageBox.Show(resultatTemplat);
                if (Grid_TaskType.SelectedIndex != -1)
                {
                    //Henter hvilken KontrollTask valgt
                    resultatTemplat = "";
                    DataGrid dataGrid2 = sender as DataGrid;
                    DataGridRow row2 = (DataGridRow)Grid_TaskType.ItemContainerGenerator.ContainerFromIndex(Grid_TaskType.SelectedIndex);
                    DataGridCell RowColumn2 = Grid_TaskType.Columns[0].GetCellContent(row2).Parent as DataGridCell;
                    resultatTemplat = ((TextBlock)RowColumn2.Content).Text;

                    checkScenarioMod.CheckScenarioResult.ValgtKontrollTask = resultatTemplat;
                    //MessageBox.Show(resultatTemplat);
                }
                else
                { checkScenarioMod.CheckScenarioResult.ValgtKontrollTask = Constants.DefaultTaskType; } //Default


                //Sender til checkScenarioMod
                checkScenarioMod.CheckScenarioResult.TemplateChosen = overridetemplat;
                checkScenarioMod.CheckScenarioResult.TemplateName = overridetemplat.TemplateName;
                checkScenarioMod.CheckScenarioResult.TemplateScore = overridetemplat.TemplateScore;

                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatPlanIDer = overridetemplat.TemplatePlanIDs;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatDiagnoser = overridetemplat.TemplateDiagnosis;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatFraksjoneringer = overridetemplat.TemplateFractionations;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatCourseIDer = overridetemplat.TemplateCourseIDs;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatOARStrukturIDer = overridetemplat.TemplateOARStructureIDs;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatStrukturSetIDer = overridetemplat.TemplateStrukturSetIDs;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatAndreStrukturIDer = overridetemplat.TemplateOtherStructureIDs;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatPTVStrukturIDer = overridetemplat.TemplatePTVStructureIDs;
                //checkScenarioMod.EclipseCheckTemplatResultat.TemplatCTVStrukturIDer = overridetemplat.TemplateCTVStructureIDs;
            }
            else 
            {
                DialogResult = false;
                MessageBox.Show("Du mislyktes i å velge et templat. Wow! Skikkelig lame. Avslutter koden. Prøv å kjør skript igjen og sørg for at et templat er valgt før du trykker ok."); 
            }


        }

        private void cancelButton_Click(object sender, RoutedEventArgs e) //=> DialogResult = false;
        {
            DialogResult = false;
        }


        void Documentation_Click(object sender, RoutedEventArgs e) //, MainViewModel mainViewModel
        {
            CheckScenarioResult checkScenarioResult = (CheckScenarioResult)((Button)sender).Tag;
            string documentation = checkScenarioResult.Documentation;
            GeneralExtension.PrintTxtDocument(documentation);


        }
    }
}
