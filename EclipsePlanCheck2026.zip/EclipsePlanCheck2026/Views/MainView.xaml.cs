﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using EclipsePlanCheck.Helpers;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

namespace EclipsePlanCheck
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        public List<EclipseCheckTemplate> templat = new List<EclipseCheckTemplate>();

        //Run code after
        private void Window1_ContentRendered(object sender, EventArgs e) 
        {
            Mouse.OverrideCursor = Cursors.Wait;
            var mainViewModel = this.DataContext as MainViewModel;
            // Place the code you want to run after the window is visible here
            mainViewModel.EclipseCheckResult.LocalProgressValue = 0;
            mainViewModel.EclipseCheckResult.LocalProgressText = mainViewModel.EclipseCheckResult.LocalProgressValue + "Updating View...";
            //MessageBox.Show("start RunFullUpdateCommand...");


            //Run full update on new thread
            if (mainViewModel.RunFullUpdateCommand.CanExecute(null))
                mainViewModel.RunFullUpdateCommand.Execute(null);

            //Begin process ScanMobiusFolderCommand on serparate thread to scan Mobius folder - result is kept in cache and makes the check faster when it is done.
            //if (mainViewModel.ScanMobiusFolderCommand.CanExecute(null))
            //    mainViewModel.ScanMobiusFolderCommand.Execute(null);



            //Set Window Height
            double margin = 50; // Define the desired margin
            //this.Width = SystemParameters.PrimaryScreenWidth - (margin * 2);
            this.Height = SystemParameters.PrimaryScreenHeight - (margin * 2);

            // Center the window on the screen
            //this.Left = margin;
            //this.Top = margin;



            Mouse.OverrideCursor = null;
        }

        public Window1(MainViewModel mainViewModel, PatientContext patientContext, CheckScenarioResult checkScenarioResult) //also send checkScenarioResult here?
        {


            InitializeComponent();
            DataContext = mainViewModel;//ShowReferencePoints

            ContentRendered += Window1_ContentRendered;

            //Hide reference points for certain control types. Should be moved to the XAML-file. Or should be dynamic somehow!
            if (mainViewModel.EclipseCheckResult.ShowReferencePoints == false) //Constants.False
            {
                Grid_refpkt.Visibility = Visibility.Hidden;
            }


            //Run update only when fully loaded and idle:
            //System.Windows.Application.Current.Dispatcher.Invoke(
            //DispatcherPriority.ApplicationIdle,
            //new Action(() =>
            //{

            //    Mouse.OverrideCursor = Cursors.Wait;
            //    try
            //    {

            //        if (mainViewModel.PopulateStructureListsCommand.CanExecute(null))
            //            mainViewModel.PopulateStructureListsCommand.Execute(null);

            //    }
            //    finally
            //    {
            //        Mouse.OverrideCursor = null;
            //        //mainViewModel.ProgressText = "Finished";
            //        //mainViewModel.ProgressValue = 100;
            //    }

            //    //MessageBox.Show("Try FullUpdateCommand");
            //    //if (mainViewModel.RunFullUpdateCommand.CanExecute(null))
            //    //    mainViewModel.RunFullUpdateCommand.Execute(null);

            //    //Add updating interface progress to focus window. ProgressMessage "Adding structure lists: Boluses and HU-overrides." Progress = current / max 

            //}));



            //This did not work -dot use!:
            //overrider tooltip duration - Allerede kalt i "CheckScenarioView". Denne kan kun kalles en gang i programmet! Om det gjores flere ganger (i et annet code-behind) vil det krasje! Teit!
            //        ToolTipService.ShowDurationProperty.OverrideMetadata(
            //typeof(DependencyObject), new FrameworkPropertyMetadata(Int32.MaxValue));
        }

        private void Grid_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (e.Delta > 0) // Mouse wheel scrolled up
            {
                ScrollViewerCheckPoints.LineUp();
            }
            else // Mouse wheel scrolled down
            {
                ScrollViewerCheckPoints.LineDown();
            }

            e.Handled = true; // Mark the event as handled
        }

        private void MyDataGrid_MouseMove(object sender, MouseEventArgs e)
        {
            //Default
            bool hit = false;

            var viewModel = this.DataContext as MainViewModel;
            //Test for hit on many elements
            var hitResult = VisualTreeHelper.HitTest(Grid_sjekkpunkt1, e.GetPosition(Grid_sjekkpunkt1));
            if (hitResult != null) 
            { hit = true; };
            var hitTestResult2 = VisualTreeHelper.HitTest(Grid_sjekkpunkt2, e.GetPosition(Grid_sjekkpunkt2));
            if (hitTestResult2 != null) 
            { hit = true; hitResult = hitTestResult2; };
            var hitTestResult3 = VisualTreeHelper.HitTest(Grid_sjekkpunkt3, e.GetPosition(Grid_sjekkpunkt3));
            if (hitTestResult3 != null) 
            { hit = true; hitResult = hitTestResult3; };
            var hitTestResult4 = VisualTreeHelper.HitTest(Grid_sjekkpunkt4, e.GetPosition(Grid_sjekkpunkt4));
            if (hitTestResult4 != null) 
            { hit = true; hitResult = hitTestResult4; };
            var hitTestResult5 = VisualTreeHelper.HitTest(Grid_sjekkpunkt5, e.GetPosition(Grid_sjekkpunkt5));
            if (hitTestResult5 != null) 
            { hit = true; hitResult = hitTestResult5; };
            var hitTestResult6 = VisualTreeHelper.HitTest(Grid_sjekkpunkt6, e.GetPosition(Grid_sjekkpunkt6));
            if (hitTestResult6 != null) 
            { hit = true; hitResult = hitTestResult6; };
            //var hitTestResult7 = VisualTreeHelper.HitTest(Grid_sjekkpunkt7, e.GetPosition(Grid_sjekkpunkt7));
            //if (hitTestResult7 != null) 
            //{ hit = true; hitResult = hitTestResult7; };
            
            //If not any hit
            if (hit != true) return;

            var row = FindVisualParent<DataGridRow>(hitResult.VisualHit);
            if (row != null)
            {
                var dataItem = row.Item as CheckPoint; //MyDataItem;
                if (dataItem != null)
                {
                    viewModel.EclipseCheckResult.HoveredItemTitle = $"{dataItem.CheckName}".Replace("\r\n", " "); //Remove all line breaks and place a space instead
                    viewModel.EclipseCheckResult.HoveredItemText = $"{dataItem.CheckExplanation}";
                }
            }
            else
            {
                //viewModel.EclipseCheckResult.HoveredItemText = string.Empty; // Clear text if not hovering over a row
                //Change code to ClearText if not something else instead? Want the focusWindow to retain information until next element is hoovered over.
            }
        }

        private void MyDataGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            var viewModel = this.DataContext as MainViewModel;
            //viewModel.EclipseCheckResult.HoveredItemText = string.Empty; // Clear text when mouse leaves the DataGrid
        }

        // Helper method to find a visual parent of a specific type
        private T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
        {
            var parent = VisualTreeHelper.GetParent(child);
            while (parent != null && !(parent is T))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }
            return parent as T;
        }

        private void dg_TargetUpdated(object sender, DataTransferEventArgs e)
        {

             //Update the width of columns to the new data
                foreach (DataGridColumn column in Grid_sjekkpunkt5.Columns.Where(c => c.Width.IsSizeToCells)) //Every column with "IsAuto" should be resized
                {
                    column.Width = 50;
                    Grid_sjekkpunkt5.UpdateLayout();
                    column.Width = new DataGridLength(1, DataGridLengthUnitType.SizeToCells);
                }
                foreach (DataGridColumn column in Grid_sjekkpunkt1.Columns.Where(c => c.Width.IsSizeToCells)) //Every column with "IsAuto" should be resized
                {
                    column.Width = 50;
                    Grid_sjekkpunkt1.UpdateLayout();
                    column.Width = new DataGridLength(1, DataGridLengthUnitType.SizeToCells);
                }
                foreach (DataGridColumn column in Grid_sjekkpunkt2.Columns.Where(c => c.Width.IsSizeToCells)) //Every column with "IsAuto" should be resized
                {
                    column.Width = 50;
                    Grid_sjekkpunkt2.UpdateLayout();
                    column.Width = new DataGridLength(1, DataGridLengthUnitType.SizeToCells);
                }
                foreach (DataGridColumn column in Grid_sjekkpunkt3.Columns.Where(c => c.Width.IsSizeToCells)) //Every column with "IsAuto" should be resized
                {
                    column.Width = 50;
                    Grid_sjekkpunkt3.UpdateLayout();
                    column.Width = new DataGridLength(1, DataGridLengthUnitType.SizeToCells);
                }
                foreach (DataGridColumn column in Grid_sjekkpunkt4.Columns.Where(c => c.Width.IsSizeToCells)) //Every column with "IsAuto" should be resized
                {
                    column.Width = 50;
                    Grid_sjekkpunkt4.UpdateLayout();
                    column.Width = new DataGridLength(1, DataGridLengthUnitType.SizeToCells);
                }
            foreach (DataGridColumn column in Grid_sjekkpunkt6.Columns.Where(c => c.Width.IsSizeToCells)) //Every column with "IsAuto" should be resized
            {
                column.Width = 0;
                Grid_sjekkpunkt6.UpdateLayout();
                column.Width = new DataGridLength(1, DataGridLengthUnitType.SizeToCells);
            }

            //Grid_sjekkpunkt5.Columns[0].Width = 0;
            //Grid_sjekkpunkt5.UpdateLayout();
            //Grid_sjekkpunkt5.Columns[0].Width = new DataGridLength(1, DataGridLengthUnitType.Star);
        }

        void OpenMobiusPdf_Click(object sender, RoutedEventArgs e) //, MainViewModel mainViewModel
        {

            var viewModel = this.DataContext as MainViewModel;
            CheckPoint cp = viewModel.EclipseCheckResult.CheckPointListPlan.Where(x => x.CheckName == "Mobius").FirstOrDefault(); //Must not change name of checkpoint and list it is in!
            //string mobiuspath = ((Button)sender).Tag.ToString(); //Retrieving it through the button binding - silly way - should not be used

            var p = new Process();

            string mobiuspath = "";
            if (cp != null) // if checkpoint exist, set value
            {
                mobiuspath = cp.CheckResultRawValue; //Get path from the checkpoint Mobius. 
            }
            
            try
            {
                if ((mobiuspath != null) && (mobiuspath != "") && (Directory.Exists(Constants.MobiusPath)))
                {
                    try
                    {
                        p.StartInfo = new ProcessStartInfo(mobiuspath)
                        {
                            UseShellExecute = true
                        };
                        p.Start();
                    }
                    catch
                    {
                        MessageBox.Show("Klarer ikke åpne Mobius-pdf: '" + mobiuspath + "'. Sannsynligvis fordi det ikke er sendt til Mobius.");
                    }
                }
                else
                {
                    MessageBox.Show("Ikke gyldig sti til Mobius-pdf: '" + mobiuspath + "'. Finner ikke pdf eller får ikke tilgang til folderen.");
                }
            }
            catch
            {
                MessageBox.Show("Klarer ikke åpne Mobius-pdf.");
            }
        }
        void Debug_Click(object sender, RoutedEventArgs e) //, MainViewModel mainViewModel
        {
            //Mouse.OverrideCursor = Cursors.Wait;
            //EclipseCheckModel eclipseCheckModel = (EclipseCheckModel)((Button)sender).Tag;
            var viewModel = this.DataContext as MainViewModel;
            
            //TEST
            //MessageBox.Show("start TestCalculateMeanDoseCommand...");
            //if (viewModel.TestCalculateMeanDoseCommand.CanExecute(null))
            //    viewModel.TestCalculateMeanDoseCommand.Execute(null);
            //------------------


            //MessageBox.Show("start RunFullUpdateCommand...");
            //if (viewModel.RunFullUpdateCommand.CanExecute(null))
            //    viewModel.RunFullUpdateCommand.Execute(null);


            RerunDebug(viewModel);


            var debugView = new DebugView(viewModel.EclipseCheckResult);

            ////place window
            debugView.Top = 5;
            debugView.Left = 50;


            debugView.ShowDialog(); //Show() ShowDialog(); //locks the screen


        }
        void Custom_Click(object sender, RoutedEventArgs e) //, MainViewModel mainViewModel
        {
            EclipseCheckModel eclipseCheckModel = (EclipseCheckModel)((Button)sender).Tag;
            string hospital = eclipseCheckModel.Hospital;
            var mainViewModel = this.DataContext as MainViewModel;

            //MessageBox.Show("eclipseCheckModel.CCIsEnabled: " + eclipseCheckModel.CCIsEnabled.ToString());

            //MessageBox.Show("start TestCalculateMeanDoseC directly in viewModel..");
            //Test
            //if (mainViewModel.TestCalculateMeanDoseCommand.CanExecute(null))
            //    mainViewModel.TestCalculateMeanDoseCommand.Execute(null);
                //mainViewModel.TestCalculateMeanDose();

            MessageBox.Show("Here you can add hospital specific scode... Nothing for now.");


            if (hospital == "HUS")
            {
                //My code

                Mouse.OverrideCursor = Cursors.Wait;
                try
                {
                
                    //if (mainViewModel.PopulateStructureListsCommand.CanExecute(null))
                    //    mainViewModel.PopulateStructureListsCommand.Execute(null);

                    //if (mainViewModel.CreateMarginListsCommand.CanExecute(null))
                    //    mainViewModel.CreateMarginListsCommand.Execute(null);

                    //if (mainViewModel.CreateReferencePointListCommand.CanExecute(null))
                    //    mainViewModel.CreateReferencePointListCommand.Execute(null);

                    //if (mainViewModel.FillUpCheckPointListCommand.CanExecute(null))
                    //    mainViewModel.FillUpCheckPointListCommand.Execute(null);

                    //if (mainViewModel.CleanUpCheckPointListCommand.CanExecute(null))
                    //    mainViewModel.CleanUpCheckPointListCommand.Execute(null);

                    //if (mainViewModel.UpdateCheckPointListCommand.CanExecute(null))
                    //    mainViewModel.UpdateCheckPointListCommand.Execute(null);

                    //if (mainViewModel.CountStatusesCheckPointListCommand.CanExecute(null))
                    //    mainViewModel.CountStatusesCheckPointListCommand.Execute(null);

                    //if (mainViewModel.PopulateCheckPointListsCommand.CanExecute(null))
                    //    mainViewModel.PopulateCheckPointListsCommand.Execute(null);

                }
                finally
                {
                    Mouse.OverrideCursor = null;
                }

                //if (mainViewModel.RunFullUpdateCommand.CanExecute(null))
                //    mainViewModel.RunFullUpdateCommand.Execute(null);

                //Add updating interface progress to focus window. ProgressMessage "Adding structure lists: Boluses and HU-overrides." Progress = current / max 

            }


        }
        void Documentation_Click(object sender, RoutedEventArgs e) //, MainViewModel mainViewModel
        {
            //PatientContext patientContext = (PatientContext)((Button)sender).Tag;
            //CheckScenarioResult checkScenarioResult = (CheckScenarioResult)((Button)sender).Tag;
            //Generate documentation:
            //string documentation = GeneralExtension.GenerateDocumentation(patientContext, checkScenarioResult);
            //GeneralExtension.PrintTxtDocument(documentation);

            //checkScenarioResultat.Documentation = documentation;
            //string documentation = checkScenarioResult.Documentation;
            EclipseCheckModel eclipseCheckModel = (EclipseCheckModel)((Button)sender).Tag;
            string documentation = eclipseCheckModel.Documentation;
            GeneralExtension.PrintTxtDocument(documentation);


        }
        void ExportCSV_Click(object sender, RoutedEventArgs e) //, MainViewModel mainViewModel
        {
            EclipseCheckModel eclipseCheckResult = (EclipseCheckModel)((Button)sender).Tag;
            var viewModel = this.DataContext as MainViewModel;


            PatientContext patCon = viewModel.Context;
            CheckScenarioResult chScRes = viewModel.ScenarioResult;

            //PatientContext patientContext = (PatientContext)((Button)sender).Tag;
            //CheckScenarioResult checkScenarioResult = (CheckScenarioResult)((Button)sender).Tag;
            //Generate documentation:
            //string documentation = GeneralExtension.GenerateDocumentation(patientContext, checkScenarioResult);
            //GeneralExtension.PrintTxtDocument(documentation);

            //checkScenarioResultat.Documentation = documentation;
            //string documentation = checkScenarioResult.Documentation;
            //MessageBox.Show("Starting Command: Exporting as CSV");
            if (viewModel.ExportResultCSVCommand.CanExecute(eclipseCheckResult)) //Sending CheckPoint
                viewModel.ExportResultCSVCommand.Execute(eclipseCheckResult);

            
            //GeneralExtension.ExportResultAsCSV(eclipseCheckResult, patCon, chScRes);


        }

        private void CalculateCheckValue(object sender, RoutedEventArgs e) // private async void  //Can we also do this for each checkpoint in checkpointlist with CalculateLate = true, also a complete Rerun of all.
        {
            //LateCalculation
                var button = sender as Button;
                var checkPoint = button?.DataContext as CheckPoint;
                var viewModel = this.DataContext as MainViewModel;
                checkPoint.CalculateDelayed = false;
                if (viewModel.DelayedCalculationCommand.CanExecute(checkPoint)) //Sending CheckPoint
                    viewModel.DelayedCalculationCommand.Execute(checkPoint);



            //Original Code:
            //Mouse.OverrideCursor = Cursors.Wait;
            //    try
            //    {
            //        var button = sender as Button;
            //        var checkPoint = button?.DataContext as CheckPoint;
            //        var viewModel = this.DataContext as MainViewModel;
            //        checkPoint.CalculateLate = false;
            //        UpdateCheckPoint.RunCheckPointSwitch(checkPoint, viewModel.Context, viewModel.ScenarioResult);
            //        UpdateCheckPoint.ColorCheckPointsDependingOnStatus(new List<CheckPoint> { checkPoint });

            //    }
            //    finally
            //    {
            //        Mouse.OverrideCursor = null; 
            //    }



        }

        private void RerunDebug(MainViewModel viewModel)
        {

            EclipseCheckModel res = viewModel.EclipseCheckResult;

            List<CheckPoint> allCheckpoints = new List<CheckPoint>();
            allCheckpoints.AddRange(res.CheckPointListCourse);
            allCheckpoints.AddRange(res.CheckPointListStructures);
            allCheckpoints.AddRange(res.CheckPointListPlan);
            allCheckpoints.AddRange(res.CheckPointListTechnique);
            allCheckpoints.AddRange(res.CheckPointListReferencePoints);
            allCheckpoints.AddRange(res.CheckPointListDVH);
            allCheckpoints.AddRange(res.CheckPointListSUS);



            //Count OK, warning, errors and unknowns:
            var numberOfErrorStatusCheckPoints = allCheckpoints.FindAll(a => a.CheckStatus == Constants.Error).Count.ToString();
            var numberOfWarningStatusCheckPoints = allCheckpoints.FindAll(a => (a.CheckStatus == Constants.Warning || a.CheckStatus == Constants.Warning2)).Count.ToString();
            var numberOfOkStatusCheckPoints = allCheckpoints.FindAll(a => a.CheckStatus == Constants.Ok).Count.ToString();
            var numberOfUnknownStatusCheckPoints = allCheckpoints.FindAll(a => a.CheckStatus == Constants.Unknown).Count.ToString();

            res.NumberOfErrorStatusCheckPoints = numberOfErrorStatusCheckPoints;
            res.NumberOfWarningStatusCheckPoints = numberOfWarningStatusCheckPoints;   
            res.NumberOfOkStatusCheckPoints = numberOfOkStatusCheckPoints;
            res.NumberOfUnknownStatusCheckPoints = numberOfUnknownStatusCheckPoints;
        }
        //public DetailViewModel DetailViewModel { get; private set; }
    }
}
