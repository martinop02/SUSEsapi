﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;


namespace EclipsePlanCheck.Helpers
{
    public class EsapiWorker
    {
        private readonly PatientContext _patientContext;

        private readonly Dispatcher _dispatcher;

        public EsapiWorker(PatientContext patientContext) //,CheckScenarioResult checkScenarioResult
        {
            _patientContext = patientContext;
            _dispatcher = Dispatcher.CurrentDispatcher;
        }

        public void Run(Action<PatientContext> a)
        {
            _dispatcher.BeginInvoke(a, _patientContext);
        }

    }
}
