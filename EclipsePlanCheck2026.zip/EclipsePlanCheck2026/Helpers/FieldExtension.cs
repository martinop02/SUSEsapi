﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Text.RegularExpressions;

namespace EclipsePlanCheck.Helpers
{
    class FieldExtension
    {



        public static PlanTechnique GetTechniqueFromPlan(ExternalPlanSetup plan, PatientContext patientContext) //Paa plannivaa totalt sett
        {


            PlanTechnique teknikk = new PlanTechnique();

            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist)
            {
                // ---- Teknikk: ----
                int antallFelt = FieldExtension.NumberOfFields(plan, "");

                int antallStFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.Static_technique_forklaring); //(plan, "STATIC", "Static");
                int antallFiFFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.FiF_technique_forklaring); //(plan, "STATIC", "DoseDynamic", "FiF");
                int antallIntFFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.IMRT_technique_forklaring); //(plan, "STATIC", "DoseDynamic", "IMRT");
                int antallArcFFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.Arc_technique_forklaring); //(plan, "ARC", "VMAT");
                int antallSRSArcFFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.SRS_Arc_technique_forklaring); //(plan, "SRS ARC", "VMAT");
                int antallTotalBodyFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.TotalBody_technique_forklaring); //(plan, "TOTAL", "");
                int antallElektronFelt = FieldExtension.NumberOfFields(plan, Constants.Teknikk.Electron_technique_forklaring); //(plan, "TOTAL", "");   Konstanter.Teknikk.Electron_technique_MLCPlanType_name_Aria

                string teknikkForklaring = PlanExtension.GetTechniqueExlanation(antallStFelt, antallFiFFelt, antallIntFFelt, antallArcFFelt, antallSRSArcFFelt, antallTotalBodyFelt, antallElektronFelt);

                //Setter verdier:
                teknikk.NumberOfStaticFields = antallStFelt.ToString();
                teknikk.NumberOfFifFields = antallFiFFelt.ToString();
                teknikk.NumberOfIMRTFields = antallIntFFelt.ToString();
                teknikk.NumberOfArcFields = antallArcFFelt.ToString();
                teknikk.NumberOfSRSArcFields = antallSRSArcFFelt.ToString();
                teknikk.NumberOfTotBodyFields = antallTotalBodyFelt.ToString();
                teknikk.NumberOfElectronFields = antallElektronFelt.ToString();
                teknikk.TechniqueName = teknikkForklaring;
            }
            else
            {
                teknikk.NumberOfStaticFields = "";
                teknikk.NumberOfFifFields = "";
                teknikk.NumberOfIMRTFields = "";
                teknikk.NumberOfArcFields = "";
                teknikk.NumberOfSRSArcFields = "";
                teknikk.NumberOfTotBodyFields = "";
                teknikk.NumberOfElectronFields = "";
                teknikk.TechniqueName = "";
            }

            //Brukes til teknikk-spesifikke sjekker:

            return teknikk;

        }
        public static string GetTechniqueFromField(Beam felt)
        {
            string _teknikk = "";

            if (CheckIfFieldIsStatic(felt) == true)
            {
                _teknikk = Constants.Teknikk.Static_technique_forklaring;
            }
            else if (CheckIfFieldIsIMRT(felt) == true)
            {
                _teknikk = Constants.Teknikk.IMRT_technique_forklaring;
            }
            else if (CheckIfFieldIsFiF(felt) == true)
            {
                _teknikk = Constants.Teknikk.FiF_technique_forklaring;
            }
            else if (CheckIfFieldIsArc(felt) == true)
            {
                _teknikk = Constants.Teknikk.Arc_technique_forklaring;
            }
            else if (CheckIfFieldIsSRSArc(felt) == true)
            {
                _teknikk = Constants.Teknikk.SRS_Arc_technique_forklaring;
            }
            else if (CheckIfFieldIsTotalBody(felt) == true)
            {
                _teknikk = Constants.Teknikk.TotalBody_technique_forklaring;
            }
            else if (CheckIfFieldIsElectron(felt) == true)
            {
                _teknikk = Constants.Teknikk.Electron_technique_forklaring;
            }
            else
            {
                _teknikk = Constants.Teknikk.Unknown_technique_forklaring; //"Skriptet klarer ikke identifisere teknikk";
            }

            return _teknikk;

        }
        //string SjekkTeknikk, string SjekkMLCPlanType, string optionalInfo = ""
        public static int NumberOfFields(ExternalPlanSetup plan, string TeknikkForklaring)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            //Teller opp antall felt av forskjellige kategorier.
            int numberOfFields = 0;
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {

                    if (TeknikkForklaring == Constants.Teknikk.IMRT_technique_forklaring) //"DoseDynamic"   "IMRT"
                    {
                        if (CheckIfFieldIsIMRT(felt)) { numberOfFields = numberOfFields + 1; }
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.FiF_technique_forklaring) //"DoseDynamic"  //"FiF"
                    {
                        if (CheckIfFieldIsFiF(felt)) { numberOfFields = numberOfFields + 1; }
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.TotalBody_technique_forklaring) //""  //"Total Body"
                    {
                        if (CheckIfFieldIsTotalBody(felt)) { numberOfFields = numberOfFields + 1; }
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.Arc_technique_forklaring)
                    {
                        if (CheckIfFieldIsArc(felt)) { numberOfFields = numberOfFields + 1; }
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.SRS_Arc_technique_forklaring)
                    {
                        if (CheckIfFieldIsSRSArc(felt)) { numberOfFields = numberOfFields + 1; }
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.Static_technique_forklaring)
                    {
                        if (CheckIfFieldIsStatic(felt)) { numberOfFields = numberOfFields + 1; }
                        if (CheckIfFieldIsStaticNoMLC(felt)) { numberOfFields = numberOfFields + 1; } //Skiller ikke disse per naa
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.IMRT_technique_forklaring)
                    {
                        if (CheckIfFieldIsIMRT(felt)) { numberOfFields = numberOfFields + 1; }
                    }
                    else if (TeknikkForklaring == Constants.Teknikk.Electron_technique_forklaring)
                    {
                        if (CheckIfFieldIsElectron(felt)) { numberOfFields = numberOfFields + 1; }
                    }


                }
            }
            return numberOfFields;
        }


        public static CheckPoint CheckTechnique(ExternalPlanSetup plan, CheckPoint s, PlanTechnique planTechnique)
        {
            s.CheckResultValue = planTechnique.TechniqueName;
            s.CheckResultValueCSV = planTechnique.TechniqueName;
            s.CheckDebug = s.CheckDebug + "Antall statiske felt: " + planTechnique.NumberOfStaticFields;
            s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall FiF-felt: " + planTechnique.NumberOfFifFields;
            s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall IMRT-felt: " + planTechnique.NumberOfIMRTFields;
            s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall Arc-felt: " + planTechnique.NumberOfArcFields;
            s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall SRS-felt: " + planTechnique.NumberOfSRSArcFields;
            s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall Elektronfelt: " + planTechnique.NumberOfElectronFields;
            s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall Tot Body felt: " + planTechnique.NumberOfTotBodyFields;

            //Sjekker mot templatet
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(s.CheckResultValue, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            return s;
        }

        public static string FieldHas
            (ExternalPlanSetup plan)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            //Henter total antall MU
            int AntallFeltUtenDRR = 0;
            string IngenDRR = "False"; //Finnes det felt uten DRR i hele planen
            string test = "";

            foreach (Beam felt in plan.Beams) //sjekker nå alle felt (er det noen unntak her?)
            {
                //Maatte legge testen i en try-catch fordi hvis referancebildet ikke eksisterer krasjer koden. 12.02.2024 BP
                try
                {
                    test = felt.ReferenceImage.Id;  //if (felt.ReferenceImage.Id == null) {}
                    // MessageBox.Show("ReferenceImage ID:" + felt.ReferenceImage.Id + " Antall uten DRR:" + AntallFeltUtenDRR); 
                }
                catch
                {
                    AntallFeltUtenDRR = AntallFeltUtenDRR + 1;
                    //MessageBox.Show("Felt ID:" + felt.Id + " Antall uten DRR:" + AntallFeltUtenDRR);
                }

            }
            //Setter statusen
            if (AntallFeltUtenDRR > 0)
            {
                IngenDRR = "True";
                //MessageBox.Show("Til info: Finnes felt uten DRR. Antall: " + AntallFeltUtenDRR + ".");
            }
            return IngenDRR;
        }
        //

        public static bool CheckIfFieldIsFiF(Beam felt)
        {
            bool _FiF = false;
            string teknikk = felt.Technique.Id;
            bool test = (teknikk == Constants.Teknikk.FiF_technique_name_Aria && felt.IsSetupField == false && felt.MLCPlanType.ToString() == Constants.Teknikk.FiF_technique_MLCPlanType_name_Aria); //"STATIC" //"DoseDynamic"
            if (test)
            {
                int _antallCP = felt.ControlPoints.Count;
                // logikk for antall CP for aa sjekke om DoseDynamic er FiF eller IMRT - maa legge inn en kunstig grense ved 30 CP:
                if (_antallCP < Constants.DefinitionLessThanThisNumberOfControlPointsToBeFiFTechnique) { _FiF = true; }
            }
            return _FiF;
        }
        public static bool CheckIfFieldIsIMRT(Beam felt)
        {
            bool _IMRT = false;
            string teknikk = felt.Technique.Id;
            bool test = (teknikk == Constants.Teknikk.IMRT_technique_name_Aria && felt.IsSetupField == false && felt.MLCPlanType.ToString() == Constants.Teknikk.IMRT_technique_MLCPlanType_name_Aria); //  "STATIC"   "DoseDynamic"
            if (test)
            {
                int _antallCP = felt.ControlPoints.Count;
                // logikk for antall CP for aa sjekke om DoseDynamic er FiF eller IMRT - maa legge inn en kunstig grense ved 30 CP:
                if (_antallCP >= Constants.DefinitionLessThanThisNumberOfControlPointsToBeFiFTechnique) { _IMRT = true; }
            }
            return _IMRT;
        }
        public static bool CheckIfFieldIsArc(Beam felt)
        {
            bool _resultat = false;
            String teknikk = felt.Technique.Id; //setter teknikk
            MLCPlanType mlcType = felt.MLCPlanType; //setter MLC-type

            if (teknikk == Constants.Teknikk.Arc_technique_name_Aria && mlcType.ToString() == Constants.Teknikk.Arc_technique_MLCPlanType_name_Aria)  //"ARC"  "VMAT"
            {
                _resultat = true;
            }

            return _resultat;
        }

        public static bool CheckIfFieldIsSRSArc(Beam felt)
        {
            bool _resultat = false;
            String teknikk = felt.Technique.Id; //setter teknikk
            MLCPlanType mlcType = felt.MLCPlanType; //setter MLC-type
            if (teknikk == Constants.Teknikk.SRS_Arc_technique_name_Aria && mlcType.ToString() == Constants.Teknikk.SRS_Arc_technique_MLCPlanType_name_Aria) //"SRS ARC" "VMAT"
            {
                _resultat = true;
            }
            return _resultat;
        }
        public static bool CheckIfFieldIsTotalBody(Beam felt)
        {
            bool _resultat = false;
            String teknikk = felt.Technique.Id; //setter teknikk
            MLCPlanType mlcType = felt.MLCPlanType; //setter MLC-type
            if (teknikk == Constants.Teknikk.TotalBody_technique_name_Aria && mlcType.ToString() == Constants.Teknikk.TotalBody_technique_MLCPlanType_name_Aria)
            {
                _resultat = true;
            }
            return _resultat;
        }
        public static bool CheckIfFieldIsStatic(Beam felt)
        {
            bool _resultat = false;
            String teknikk = felt.Technique.Id; //setter teknikk
            MLCPlanType mlcType = felt.MLCPlanType; //setter MLC-type
            if (teknikk == Constants.Teknikk.Static_technique_name_Aria && mlcType.ToString() == Constants.Teknikk.Static_technique_MLCPlanType_name_Aria) //"STATIC"  "Static"
            {
                _resultat = true;
            }
            return _resultat;
        }

        public static bool CheckIfFieldIsElectron(Beam felt)
        {
            bool _resultat = false;
            String teknikk = felt.Technique.Id; //setter teknikk
            string _energyDisplayName = felt.EnergyModeDisplayName;
            var _MLC = felt.MLC;
            if (_energyDisplayName.Contains("E") && teknikk == Constants.Teknikk.Static_technique_name_Aria)
            {
                _resultat = true;
            }

            return _resultat;
        }
        public static bool CheckIfFieldIsStaticNoMLC(Beam felt)
        {
            bool _resultat = false;
            String teknikk = felt.Technique.Id; //setter teknikk
            var _MLC = felt.MLC;
            //Ingen MLC og ikke elektron og teknikk = "STATIC".
            if (teknikk == Constants.Teknikk.Static_technique_name_Aria && CheckIfFieldIsElectron(felt) == false && _MLC == null)
            {
                _resultat = true;
            }

            return _resultat;
        }


        //advarsel om for lite feltstorrelse ved jaw tracking paa vmat felt. Sender tilbake prosent av kontrollpunktene som er for smaa.
        public class FeltStorrelseStatistikk  //Forbedring: gjore om til "Public struct"
        {
            public bool liteFelt { get; set; }
            public double prosentLiteFeltX { get; set; }
            public double prosentLiteFeltY { get; set; }
            public double prosentLiteFeltXY { get; set; }
            public string minsteFelt { get; set; }
            public double averageFeltStorrelse_cm2 { get; set; }
            public string beskjed { get; set; }

            public double minsteFeltX { get; set; }
            public double minsteFeltY { get; set; }
            public double minsteFeltXY { get; set; }

            //constructors
            public FeltStorrelseStatistikk()
            {
            }

            public FeltStorrelseStatistikk(bool _liteFelt, double _prosentLiteFeltX, double _prosentLiteFeltY, double _prosentLiteFeltXY, string _minsteFelt, double _averageFeltStorrelse_cm2, string _beskjed, double _minsteFeltX, double _minsteFeltY, double _minsteFeltXY)
            {
                liteFelt = _liteFelt;
                prosentLiteFeltX = _prosentLiteFeltX;
                prosentLiteFeltY = _prosentLiteFeltY;
                prosentLiteFeltXY = _prosentLiteFeltXY;
                minsteFelt = _minsteFelt;
                averageFeltStorrelse_cm2 = _averageFeltStorrelse_cm2;
                minsteFeltX = _minsteFeltX;
                minsteFeltY = _minsteFeltY;
                minsteFeltXY = _minsteFeltXY;
                beskjed = _beskjed;
            }


            public FeltStorrelseStatistikk(Beam felt)
                : this()
            {
            }


        }

        public static CheckPoint CheckFieldSize(ExternalPlanSetup plan, CheckPoint s, string teknikk, List<Field> feltListe)
        {

            bool smallFieldBool = false;
            string smallFieldInfo = "";
            double minstefeltX = 9999;
            double minstefeltY = 9999;
            double minstefeltXY = 9999;

            //VMAT-test av feltstorrelse
            if (teknikk == Constants.Teknikk.Arc_technique_forklaring || teknikk == Constants.Teknikk.SRS_Arc_technique_forklaring || teknikk == Constants.Teknikk.TotalBody_technique_forklaring)
            {
                bool _feltFeil = false;
                List<FieldExtension.FeltStorrelseStatistikk> ListfeltStorrelseVMAT = new List<FieldExtension.FeltStorrelseStatistikk>();
                foreach (Beam felt_n in plan.Beams)
                {
                    if (FieldExtension.CheckIfFieldIsArc(felt_n) || FieldExtension.CheckIfFieldIsSRSArc(felt_n))
                    {
                        var t = FieldExtension.GenerateFieldSizeStatistics(felt_n);
                        //sjekken kjorer paa hvert felt, men onsker ikke aa overstyre ett felt som er feil med ett som er rett. Beholder kun det forste feltet som er feil.

                        if (t.liteFelt == true && _feltFeil == false)
                        {
                            _feltFeil = t.liteFelt;
                            //legger feltdetaljene i en liste 
                            ListfeltStorrelseVMAT.Add(new FieldExtension.FeltStorrelseStatistikk(t.liteFelt, t.prosentLiteFeltX, t.prosentLiteFeltY, t.prosentLiteFeltXY, t.minsteFelt, t.averageFeltStorrelse_cm2, t.beskjed, t.minsteFeltX, t.minsteFeltY, t.minsteFeltXY));
                            smallFieldBool = t.liteFelt;
                            smallFieldInfo = smallFieldInfo + Environment.NewLine + t.beskjed;
                            //MessageBox.Show(t.liteFelt.ToString() + " " + t.beskjed);
                        }
                        //Oppdaterer minste felt
                        if (t.minsteFeltX < minstefeltX)
                        { minstefeltX = t.minsteFeltX; }
                        if (t.minsteFeltY < minstefeltY)
                        { minstefeltY = t.minsteFeltY; }
                        if (t.minsteFeltXY < minstefeltXY)
                        { minstefeltXY = t.minsteFeltXY; }

                    }
                }
            }
            s.CheckResultValueCSV = minstefeltX + Constants.StringSeparator + minstefeltY + Constants.StringSeparator + minstefeltXY;
            s.CheckResultValue = "Minimum:" + Environment.NewLine + "X: " + minstefeltX + "cm" + Environment.NewLine + "Y: " + minstefeltY + "cm" + Environment.NewLine + " X*Y:" + minstefeltXY + "cm2";// "X: " + minstefeltX + "cm, Y: " + minstefeltY + "cm, X*Y:" + minstefeltXY + "cm2";
            //MessageBox.Show(s.SjekkResultatVerdi);
            s.CheckComment = smallFieldInfo;
            if (smallFieldBool == true)
            {
                s.CheckStatus = s.CheckTrafficLight;
            }
            else
            {
                s.CheckStatus = Constants.Ok;
            }


            return s;
        }

        public static FeltStorrelseStatistikk GenerateFieldSizeStatistics(Beam felt)
        {
            bool _liteFelt = false;
            double _prosentLiteFeltX = 0;
            double _prosentLiteFeltY = 0;
            double _prosentLiteFeltXY = 0;
            double _XYsum = 0;
            double _averageFeltStorrelse_cm2 = 0;
            string teknikk = felt.Technique.Id;
            string _minsteFelt = "";

            int teller = 0; //antall CP
            double tempX, tempY, tempXY;
            double antall_x_liten = 0, antall_y_liten = 0, antall_xy_liten = 0;
            double _minsteX = 999, _minsteY = 999, _minsteXY = 999;
            int cp_max = felt.ControlPoints.Count;
            double[,] arrayCP = new double[5, cp_max];


            //if (felt.IsSetupField == false && felt.Technique.Id.Contains("ARC")) //enten for 'ARC' og 'SRS ARC'. On second thought - hvorfor ikke kjore det for alle felt.
            //{


            foreach (ControlPoint cp in felt.ControlPoints)
            {
                //lager en Array med alle jawpositions for aa ha oversikt og lage average, ikke sikkert vi trenger dette til senere. Kan slette og kun bruke temp-verdier med sum x og sum av y...
                arrayCP[0, teller] = cp.JawPositions.X1 / 10; //endrer fra mm til cm
                arrayCP[1, teller] = cp.JawPositions.X2 / 10;
                arrayCP[2, teller] = cp.JawPositions.Y1 / 10;
                arrayCP[3, teller] = cp.JawPositions.Y2 / 10;
                // arrayCP[4, teller] lagres med average-verdien etter at alle sjekkene er gjort

                tempX = 0;
                tempY = 0;
                tempXY = 0;
                //finner x-storrelsen
                tempX = arrayCP[1, teller] - arrayCP[0, teller];
                if (tempX < _minsteX) { _minsteX = tempX; }

                //finner y-storrelsen
                tempY = arrayCP[3, teller] - arrayCP[2, teller];
                if (tempY < _minsteY) { _minsteY = tempY; }

                //finner arealet i x * y (cm2)
                tempXY = Math.Abs(tempX) * Math.Abs(tempY);
                arrayCP[4, teller] = tempXY;
                if (tempXY < _minsteXY) { _minsteXY = tempXY; }
                _XYsum = _XYsum + tempXY;
                arrayCP[4, teller] = tempXY; //egentlig ikke bruk for arrayen. Kan slette, har _XYsum man kan bruke til aa finne average.

                //legger til antall cp som er for liten saa langt (skal sammenlignes med variablen teller for prosentandel)
                if (tempX < Constants.ToleranceFieldsize_x) { antall_x_liten = antall_x_liten + 1; }
                if (tempY < Constants.ToleranceFieldsize_y) { antall_y_liten = antall_y_liten + 1; }
                if (tempXY < Constants.ToleranceFieldsize_xy) { antall_xy_liten = antall_xy_liten + 1; }

                //antall cp totalt
                teller = teller + 1;
            }
            //}

            //Setter alle verdiene vi skal sende ut
            if (teller > 0) //unngaa dele paa 0
            {
                _prosentLiteFeltX = System.Math.Round(antall_x_liten / teller * 100, 1);
                _prosentLiteFeltY = System.Math.Round(antall_y_liten / teller * 100, 1);
                _prosentLiteFeltXY = System.Math.Round(antall_xy_liten / teller * 100, 1);
                if (antall_x_liten > 0 || antall_y_liten > 0 || antall_xy_liten > 0)
                {
                    _liteFelt = true;
                }
                _averageFeltStorrelse_cm2 = System.Math.Round(_XYsum / teller, 2);
            }


            _minsteFelt = "Min(X): " + _minsteX + "cm" + Environment.NewLine + "Min(Y): " + _minsteY + "cm" + Environment.NewLine + "Min(X*Y): " + _minsteXY + "cm2";

            string _beskjed = "";
            //Forelopig sendes dette til en messageBox, onsker aa endre dette senere til aa sende en liste til View:
            if (_liteFelt == true)
            {
                _beskjed = "OBS! Liten feltstorrelse (<3cm) for felt" + felt.Id + ":" + Environment.NewLine + "-------------------------" + Environment.NewLine + _minsteFelt + Environment.NewLine + "Prosent CP med smaa felt X: " + _prosentLiteFeltX + "% (tol: " + Constants.ToleranceFieldsize_x + "cm)" + Environment.NewLine + "Prosent CP med smaa felt Y: " + _prosentLiteFeltY + "(tol:" + Constants.ToleranceFieldsize_y + "cm)" + Environment.NewLine + "Prosent CP med smaa felt X*Y: " + _prosentLiteFeltXY + "(tol:" + Constants.ToleranceFieldsize_xy + "cm2)" + Environment.NewLine + "Average felt X*Y: " + _averageFeltStorrelse_cm2 + "cm2"; //_averageFeltStorrelse_cm2
                //MessageBox.Show(_beskjed);
            }


            //Sender de ut via klassen for aa kunne returnere flere enn en variabel:
            var feltStorrelseVMAT = new FeltStorrelseStatistikk
            {

                liteFelt = _liteFelt,
                prosentLiteFeltX = _prosentLiteFeltX,
                prosentLiteFeltY = _prosentLiteFeltY,
                prosentLiteFeltXY = _prosentLiteFeltXY,
                minsteFelt = _minsteFelt,
                averageFeltStorrelse_cm2 = _averageFeltStorrelse_cm2,
                beskjed = _beskjed,
                minsteFeltX = System.Math.Round(_minsteX, 1),
                minsteFeltY = System.Math.Round(_minsteY, 1),
                minsteFeltXY = System.Math.Round(_minsteXY, 1),
            };




            return feltStorrelseVMAT;
        }
        public static string ForsteFeltMaskin(ExternalPlanSetup planen)
        {
            string maskin = planen.Beams.FirstOrDefault().TreatmentUnit.Id.ToString();
            return maskin;
        }


    }
}
