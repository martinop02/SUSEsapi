﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

namespace EclipsePlanCheck.Helpers
{
    class PDExtension
    {

        //------- PD-sjekker ------------------------

        //Aarsak til opprettelse av klassen: Onsker ikke duplisering av logikken for PD-sjekk. "Tuple" (hente to variabler) er dessverre ikke stottet uten ny installasjon til VS, saa maa bruke en klasse for aa sette og hente to variabler med samme funksjon. 


        //Selve sjekk-metoden returnerer klassen "PDSjekk"

        public static PDCheck PDCheckNecessary(double totMuperGy, string teknikkogMLC, double gyperFr, int antFr)  //Logikk for om PD-plan maa lages. Baseres på total MU/Gy og teknikk og MLC som er valgt (IMRT eller VMAT/ARC)
        {
            //variablene som settes og returneres
            bool pdNeceassary = false; //nodvendig eller ikke med PD
            string explanation = ""; //Hvorfor det er nodvendig: "Tja, hvorfor ikke..." feks.
                                     //nyttige variabler
            string techniqueUsed = "";
            int toleranceLimitMUperGy = 0; //Default, before it is adjusted by technique

            if (teknikkogMLC.Contains("Arc Therapy") || teknikkogMLC.Contains("Arc Therapy") || teknikkogMLC.Contains("VMAT") || teknikkogMLC.Contains("SRS ARC") || teknikkogMLC.Contains("DoseDynamic"))  //VMAT-plan
            {
                // VMAT eller SRS (toleransegrense og returnstring annerledes)
                if (teknikkogMLC.Contains("Arc Therapy") || teknikkogMLC.Contains("Arc Therapy") || teknikkogMLC.Contains("VMAT") || teknikkogMLC.Contains("SRS ARC"))
                {
                    toleranceLimitMUperGy = Constants.VMAT_PD_MUperGy;
                    techniqueUsed = "VMAT";
                }
                //IMRT (toleransegrense og returnstring annerledes)
                else if (teknikkogMLC.Contains("DoseDynamic"))
                {
                    toleranceLimitMUperGy = Constants.IMRT_PD_MUperGy;
                    techniqueUsed = "IMRT";
                }
                //hvis hoy MU per Gy ELLER stereotaksi ELLER hoy dose per fraksjon (unntak:8Gy x 1) skal det vaere PD-plan.
                if (totMuperGy > toleranceLimitMUperGy || teknikkogMLC.Contains("SRS") || ((gyperFr > 4) && !(gyperFr == 8 && antFr == 1))) //unntak for 8Gy x 1
                {
                    //hvis en av alternative over er sann, havner vi her, må legge inn unntak for 8Gy x 1
                    pdNeceassary = true;
                    explanation = explanation + "PD nødvendig! ";
                    if (totMuperGy > toleranceLimitMUperGy)
                    {
                        explanation = explanation + "Høy MU/Gy (" + techniqueUsed + ")";
                    }
                    if ((gyperFr > 4) && (totMuperGy > toleranceLimitMUperGy))
                    {
                        explanation = explanation + "Høy MU/Gy (" + techniqueUsed + ")";
                    }
                    if ((gyperFr > 4) && (totMuperGy < toleranceLimitMUperGy) && !(gyperFr == 8 && antFr == 1))
                    {
                        explanation = explanation + "Høy dose/fr. (" + techniqueUsed + ")";
                    }
                    if (teknikkogMLC.Contains("SRS"))
                    {
                        explanation = explanation + "FFF: PD før 1.beh!";
                    }
                    if ((gyperFr > 4) && (gyperFr == 8 && antFr == 1) && totMuperGy < toleranceLimitMUperGy) //unntak hvs 8Gy x 1, men ikke hvis MU/Gy for hoy samtidig.
                    {
                        explanation = "PD ikke nødvendig. Unntak 8Gy x 1";
                        pdNeceassary = false;
                    }
                }
                else
                {
                    pdNeceassary = false;
                    explanation = "PD ikke nødvendig.";
                    //hvis grunnen til at det ikke skal vaere PD er det er unntak for 8Gy x 1
                    if ((gyperFr == 8 && antFr == 1) && (totMuperGy < toleranceLimitMUperGy)) { explanation = "PD ikke nødvendig. Unntak 8Gy x 1"; } //unntak
                }
            }


            var pdSjekk = new PDCheck
            {
                CheckRationale = explanation,
                CheckNecessary = pdNeceassary,
                CheckToleranceLimit = toleranceLimitMUperGy.ToString()

            };


            return pdSjekk;
        }



        public static CheckPoint CheckIsPDNecessary(CheckPoint s, ExternalPlanSetup plan, PDCheck pdCheck, string pdPlanExist, string muPerGyString)
        {
            // PD --- setter resultat -----
            //Legg inn comment for hvorfor nodvendig hvis doseperfraksjon hoy etc.
            string temporaryStatus = "";
            string rationalePDplan = pdCheck.CheckRationale;
            string checkToleranceLimit = pdCheck.CheckToleranceLimit;
            s.CheckResultValue = muPerGyString;
            s.CheckResultValueCSV = muPerGyString;

            if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.True)
            {
                temporaryStatus = Constants.Info;
                s.CheckDebug = s.CheckDebug + "PD-Sjekk er nødvendig. ";
            }
            else if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.False && !rationalePDplan.Contains("FFF"))
            {
                temporaryStatus = Constants.Warning;
                s.CheckDebug = s.CheckDebug + "PD-Sjekk er nødvendig. Ikke FFF. "; //Legg inn comment for hvorfor nodvendig hvis doseperfraksjon hoy etc.
            }
            else if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.False && rationalePDplan.Contains("FFF"))
            {
                temporaryStatus = Constants.Warning2;
                s.CheckDebug = s.CheckDebug + "PD-Sjekk er nødvendig. FFF-plan. ";
            }
            else //PD ikke nodvendig:  pdsjekk.sjekknodvendig == false
            {
                temporaryStatus = Constants.Ok;
            }
            s.CheckStatus = temporaryStatus;
            s.CheckComment = rationalePDplan;
            s.CheckTemplateValue = checkToleranceLimit;
            // ----------------------------

            return s;
        }

        public static CheckPoint CheckIsPDCreated(CheckPoint s, ExternalPlanSetup plan, PDCheck pdCheck, string pdPlanExist, string pdPlanId)
        {
            // PD --- setter resultat -----
            //Legg inn comment for hvorfor nodvendig hvis doseperfraksjon hoy etc.
            string temporaryStatus = "";
            string rationalePDplan = pdCheck.CheckRationale;
            string checkToleranceLimit = pdCheck.CheckToleranceLimit;
            s.CheckResultValue = pdPlanId;
            s.CheckResultValueCSV = pdPlanId;

            //Sjekken skal bare legges til hvis PD er nodvendig
            if (pdCheck.CheckNecessary == true)
            {
                // PD --- setter resultat -----

                s.CheckResultValue = pdPlanId;
                if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.True)
                {
                    temporaryStatus = Constants.Info;
                    s.CheckDebug = s.CheckDebug + "PD-plan er generert. ";
                    s.CheckComment = "PD-plan generert";
                    s.CheckResultValue = pdPlanId;
                }
                else if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.False && !rationalePDplan.Contains("FFF"))
                {
                    temporaryStatus = Constants.Warning;
                    s.CheckDebug = s.CheckDebug + "PD-plan er ikke generert. Ikke FFF. ";
                    s.CheckComment = "PD-plan ikke generert";
                }
                else if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.False && rationalePDplan.Contains("FFF"))
                {
                    temporaryStatus = Constants.Warning2;
                    s.CheckDebug = s.CheckDebug + "PD-plan er ikke generert. FFF ";
                    s.CheckComment = "PD-plan ikke generert";
                }
                else
                {
                    temporaryStatus = Constants.Ok;
                    s.CheckDebug = s.CheckDebug + "Bug i sjekken 'PD-plan generert'. ";
                }
                s.CheckStatus = temporaryStatus;

                if (pdPlanExist == Constants.True)
                { s.CheckComment = "PD-plan er generert."; }
                else { }
                s.CheckTemplateValue = pdPlanId;
                // ----------------------------
            }
            else //Fjerner hele sjekkpunktet da det ikke er nødvendig
            {
                s.CheckInactivated = Constants.True;
            }
            return s;
        }

        public static CheckPoint CheckIsPDPlanScheduled(CheckPoint s, ExternalPlanSetup plan, PDCheck pdCheck, string pdPlanExist, string pdPlanId, ExternalPlanSetup PDPlan)
        {
            // PD --- setter resultat -----
            //Legg inn comment for hvorfor nodvendig hvis doseperfraksjon hoy etc.
            string rationalePDplan = pdCheck.CheckRationale;
            string checkToleranceLimit = pdCheck.CheckToleranceLimit;
            s.CheckResultValue = pdPlanId;
            s.CheckResultValueCSV = pdPlanId;

            if (pdCheck.CheckNecessary == true && pdPlanExist == Constants.True)
            {
                // Setter resultatet
                string scheduling = PlanExtension.NumberOFTreatmentsScheduled(PDPlan);
                if (scheduling == "0")
                {
                    s.CheckStatus = s.CheckTrafficLight;
                    s.CheckComment = "PD-plan ikke schedulert.";
                    s.CheckDebug = s.CheckDebug + "PD-plan er ikke schedulert. ";
                }
                else
                {
                    s.CheckStatus = Constants.Ok;
                }
                s.CheckResultValue = scheduling;
                s.CheckResultValueCSV = scheduling;
                // ----------------------------
            }
            else //Fjerner hele sjekkpunktet da det ikke er nødvendig
            {
                s.CheckInactivated = Constants.True;
            }
            return s;
        }


        public static string GetPDPlan(PatientContext patientContext, ExternalPlanSetup plan, bool pDnodvendig)
        {
            //Henter PD-plannavn som er assosiert til valgt plan
            string PDplannavn = @""; // @"Ingen funnet ¯\_(ツ)_/¯
            int teller = 0;
            foreach (Course course in patientContext.ChosenPatient.Courses)
            {
                try
                {   //hvis den krasjer paa pga protonplaner etc, hvor syntaksen er annereledes.

                    foreach (ExternalPlanSetup vp in course.PlanSetups)
                    {

                        try //Kan få krasj her i leting etter verifikasjonsplan, TargetInvocationException. Skipper sjekk hvis det er tilfelle. Fungerte ikke med "if vp.VerifiedPlan != null"
                        {
                            if (vp.VerifiedPlan == plan)
                            {
                                teller = teller + 1;
                                if (teller == 1)
                                { PDplannavn = vp.Id; }
                                else { PDplannavn = PDplannavn + " + " + vp.Id; }
                            }
                        }
                        catch
                        {
                            string message = "Koden klarer ikke hente ut verifikasjonsplan-navn. Skipper sjekk." + Environment.NewLine +  "Debug - siste variabler hentet ut før krasj:" +Environment.NewLine + "Antall verifiserings-planer detektert så langt: " + teller + "."+ Environment.NewLine +  "Verifikasjonsplan(enes)-navn detektert så langt: " + PDplannavn;
                            //MessageBox.Show(message);
                            PDplannavn = PDplannavn + message;

                        }
                    }
                }
                catch { }
            }
            if (teller == 0 && pDnodvendig == true)
            {
                //MessageBox.Show(@"PD nodvendig. Ingen assosiert verifikasjonsplan detektert! (.•̵̑⌓•̵̑ )");
            }
            else if (teller == 1)
            {
                //MessageBox.Show("1 verifikasjonsplan");
                //Sjekk om det er kjort PD-plan paa maskin og kjor automatisk PD-analyse
                //Maa sannsynligvis kjores som separat skript i PD-skripting
            }
            else if (teller > 1 && pDnodvendig == true)
            {
                //MessageBox.Show("PD nodvendig. " + teller + @" assosierte verifikasjonsplaner detektert! (ー_ーゞ");
                //Forbedring: Legg inn warning om flere assosierte verifikasjonsplaner 
            }
            return PDplannavn;
        }

        public static ExternalPlanSetup GetPDPlan_returnPlan(PatientContext patientContext, ExternalPlanSetup plan, bool pDnodvendig)
        {
            //Henter PD-plannavn som er assosiert til valgt plan
            string PDplannavn = @""; // @"Ingen funnet ¯\_(ツ)_/¯
            int teller = 0;
            ExternalPlanSetup vp_plan = plan;
            foreach (Course course in patientContext.ChosenPatient.Courses)
            {
                try
                {   //hvis den krasjer paa pga protonplaner etc, hvor syntaksen er annereledes.

                    foreach (ExternalPlanSetup vp in course.PlanSetups)
                    {

                        try //Kan få krasj her i leting etter verifikasjonsplan, TargetInvocationException. Skipper sjekk hvis det er tilfelle. Fungerte ikke med "if vp.VerifiedPlan != null"
                        {
                            if (vp.VerifiedPlan == plan)
                            {
                                teller = teller + 1;
                                if (teller == 1)
                                {
                                    PDplannavn = vp.Id;
                                    vp_plan = vp;
                                }
                                else { PDplannavn = PDplannavn + " + " + vp.Id; }
                            }
                        }
                        catch
                        {
                            string message = "Feilmelding! Koden krasjer i forsøket på å hente ut verifikasjonsplan-navn. Skipper dette punkt og hopper til neste punkt. Debug - siste variabler hentet ut før krasj:" + Environment.NewLine + "Antall verifiserings-planer detektert så langt: " + teller + Environment.NewLine + "Verifikasjonsplan(enes)-navn detektert så langt: " + PDplannavn;
                            //MessageBox.Show(message);
                            PDplannavn = message;

                        }
                    }
                }
                catch { }
            }
            return vp_plan;
        }

        //------- PD-sjekker End --------------------




    }
}
