﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Windows.Media.Media3D;
using System.Windows;
using System.Windows.Media;
using EclipsePlanCheck.Helpers;
using System.IO;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Reflection;

namespace EclipsePlanCheck.Helpers
{
    class MarginsExtension
    {

        // ----  Margins -------



        public static Margins CreateDefaultMargins()
        {
            //Oppretter ny tom MarginResult
            Margins MarginsResult = new Margins()
            {

                LargeStructureID = "",
                SmallStructureID = "",
                LargeStructureStartWith = "",
                SmallStructureStartWith = "",
                X_origin_diff = -1,
                X_size_diff = -1,
                Y_origin_diff = -1,
                Y_size_diff = -1,
                Z_origin_diff = -1,
                Z_size_diff = -1,

                X_Minus_Mean_Margin = -1,
                X_Pluss_Mean_Margin = -1,
                Y_Minus_Mean_Margin = -1,
                Y_Pluss_Mean_Margin = -1,
                Z_Minus_Mean_Margin = -1,
                Z_Pluss_Mean_Margin = -1,


                X_Minus_Mean_Count = 0,
                X_Pluss_Mean_Count = 0,
                Y_Minus_Mean_Count = 0,
                Y_Pluss_Mean_Count = 0,
                Z_Minus_Mean_Count = 0,
                Z_Pluss_Mean_Count = 0,

                Origin_LargeStructure_X = -1,
                Origin_LargeStructure_Y = -1,
                Origin_LargeStructure_Z = -1,
                Size_LargeStructure_X = -1,
                Size_LargeStructure_Y = -1,
                Size_LargeStructure_Z = -1,

                X_Minus_Maximum_Coordinate = -1,
                X_Pluss_Minimum_Coordinate = -1,
                Y_Minus_Maximum_Coordinate = -1,
                Y_Pluss_Minimum_Coordinate = -1,
                Z_Minus_Maximum_Coordinate = -1,
                Z_Pluss_Minimum_Coordinate = -1,
                

                Warning = "",
                Comment = "",
                Debug = "",

                IsSmallStructureWithinLargeStructure = "",
                AreStructureOriginsClose = "",

                Origin_XYZ = "",

                X_Minus_Margin = -1,
                X_Pluss_Margin = -1,
                Y_Minus_Margin = -1,
                Y_Pluss_Margin = -1,
                Z_Minus_Margin = -1,
                Z_Pluss_Margin = -1,
                MeanMargin = -1,
                MeanMarginNotCroppedToBody = -1,

                //Set tolerances to default value:
                ExpectedMeanMargin = -1,
                MeanMarginHighError = -1,
                MeanMarginHighWarning = -1,
                MeanMarginLowError = -1,
                MeanMarginLowWarning = -1,

                X_Minus_Margin_tolerance = -1,
                X_Pluss_Margin_tolerance = -1,
                Y_Minus_Margin_tolerance = -1,
                Y_Pluss_Margin_tolerance = -1,
                Z_Minus_Margin_tolerance = -1,
                Z_Pluss_Margin_tolerance = -1,


                X_Minus_Margin_HighWarning = -1,
                X_Minus_Margin_HighError = -1,
                X_Minus_Margin_LowWarning = -1,
                X_Minus_Margin_LowError = -1,

                X_Pluss_Margin_HighWarning = -1,
                X_Pluss_Margin_HighError = -1,
                X_Pluss_Margin_LowWarning = -1,
                X_Pluss_Margin_LowError = -1,


                Y_Minus_Margin_HighWarning = -1,
                Y_Minus_Margin_HighError = -1,
                Y_Minus_Margin_LowWarning = -1,
                Y_Minus_Margin_LowError = -1,


                Y_Pluss_Margin_HighWarning = -1,
                Y_Pluss_Margin_HighError = -1,
                Y_Pluss_Margin_LowWarning = -1,
                Y_Pluss_Margin_LowError = -1,


                Z_Minus_Margin_HighWarning = -1,
                Z_Minus_Margin_HighError = -1,
                Z_Minus_Margin_LowWarning = -1,
                Z_Minus_Margin_LowError = -1,


                Z_Pluss_Margin_HighWarning = -1,
                Z_Pluss_Margin_HighError = -1,
                Z_Pluss_Margin_LowWarning = -1,
                Z_Pluss_Margin_LowError = -1,

                WarningMarginsHigh = "",
                WarningMarginsLow = "",

                MeanExpectedToleranceExplicitlySet = Constants.False,
                MeanUpperLowerToleranceExplicitlySet = Constants.False,
                MeanExpectedDirectionlToleranceExplicitlySet = Constants.False,
                MeanUpperLowerDirectionlToleranceExplicitlySet = Constants.False,


                //AnteriorMargin = 0,
                //PosteriorMargin = 0,
                //KaudalMargin = 0,
                //CranialMargin = 0,
                //LeftMargin = 0,
                //RightMargin = 0,
            };

            return MarginsResult;
        }

        public static TargetStructures CreateDefaultTargetStructure()
        {
            //Oppretter ny tom targetstructures
            TargetStructures targetstructures = new TargetStructures()
            {
                TargetStructureId = "",
                TargetStructureDose = "",
                TargetStructureCode = "",
                TargetStructureHasDose = "",
                TargetStructureDescription = "",

            };

            return targetstructures;
        }



        public static VVector Convert3DPointToVvector(Point3D point)
        {
            VVector vvector = new VVector(point.X, point.Y, point.Z);
            return vvector;
        }

        private static Margins CheckIfStructureIsOutsideStructureWhereNotCroppedToBody(Margins marginResult, Structure structureSmall, Structure structureLarge, Structure structureBody, StructureSet structureSet, PatientContext patientContext, CheckPoint s) //Modified from CheckForOverlap, breped
        {

            //Debug:
            string startDebugMessage = "";
            string debugMessage = "";
            string exeptionStructureOutsideStructureButCloseToBodyDicom = "";
            string exeptionStructureOutsideStructureAndNotCloseToBodyDicom = "";
            string exeptionStructureOutsideStructureAndNotCloseToBodyUser = "";
            string exeptionStructureEqualToStructure = "";
            string exeptionStructureBadResolution = "";
            string exeptionStructureNotEqualToStructure = "";
            string minDistanceSmallStructureToBody = "";
            double maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside = 0;
            string distancesSmallStructureToLargeStructure = "";
            string comment = "";


            string coordinateSmallStructureWithMaxDistance = "";
            string coordinateLargeStructureWithMaxDistance = "";
            string coordinateLargeStructureSecondPoint = "";

            //necessary to use method DicomToImage: 
            //Image image = structureSet.Image;

            int numberOfPointsOk = 0; //countvVectorsOk
            int numberOfPointsTotal = 0;//countvVectorsTotal
            int numberOfPointsWhereStructureOutsideStructureButBadResolution = 0;
            int numberOfPointsWhereStructureOutsideStructureButCloseToBody = 0;
            int numberOfPointsWhereStructureOutsideStructure = 0;
            int numberOfPointsWhereStructureEqualToStructure = 0;
            int numberOfPointsWhereStructureOutsideStructureAndNoExcuses = 0;
            string distancesToBody = "";

            double averageDistanceOutsideLargeStructure = 0;
            double totalDistanceOutsideLargeStructure = 0;

            double numberOfPointsWhereLineIsRejected = 0;

            //First structure = small volume (CTV).  Second structure = Large volume (PTV)
            string resultStructureIsInsidetructure = Constants.True; //Final status. status true before check, set to false if any error.
            bool structureIsInsideStructure = true; //temporary variable reset on every point checked
            int slicesInImage = structureSet.Image.ZSize;
            List<VVector[][]> firstStructureCoords = new List<VVector[][]>();

            //Structure highBody = structureBody;
            //highBody.ConvertToHighResolution();
            //Structure highSmall = structureSmall; //copy to work on
            //highSmall.ConvertToHighResolution();
            //Structure highLarge = structureLarge; //copy to work on
            //highLarge.ConvertToHighResolution();

            List<Point3D> setBody = structureBody.MeshGeometry.Positions.ToList();
            List<Point3D> setStructureLarge = structureLarge.MeshGeometry.Positions.ToList();
            List<Point3D> setStructureSmall = structureSmall.MeshGeometry.Positions.ToList();


            Point3D closestPointInLargeStructure = new Point3D { X = 0, Y = 0, Z = 0 };
            Point3D secondClosestPointInLargeStructure = new Point3D { X = 0, Y = 0, Z = 0 };


            //Check for bad resolutions in large structure, and add points to list:
            marginResult = GetBadResolutionDebug(marginResult, setStructureLarge, patientContext);

            int pointsCountMax = setStructureSmall.Count();
            int pointsCountCurrent = 0;

            //Iterate over small structure points
            foreach (Point3D pointInSmallStructure in setStructureSmall)   //var
            {
                pointsCountCurrent = pointsCountCurrent + 1;

                //if( pointsCountCurrent/ pointsCountMax*100 > s.Progress + 3) //only if progress has continued at least 3 percentages
                //{
                //    _ = s.UpdateTaskProgress(pointsCountMax, pointsCountCurrent); //Fire and forget asynch update
                //}
                    

                //-------------------------------
                //Inside structure?
                //-------------------------------
                structureIsInsideStructure = true; //resetter variabel for ny sjekk
                VVector contours = new VVector(pointInSmallStructure.X, pointInSmallStructure.Y, pointInSmallStructure.Z); //Point in Smallest Structure turn into vVector
                if (structureLarge.IsPointInsideSegment(contours) == false)
                {
                    structureIsInsideStructure = false;             //structureIsInsideStructure = structureLarge.IsPointInsideSegment(vVector);
                }
                //-------------------------------

                if (structureIsInsideStructure == false) //If small strucutre point is not inside large structure
                {

                    //point in small structure where smallstructure is outside largestructure
                    Point3D pointInSmallStructureOutsideOfLargeStructure = pointInSmallStructure;  //new Point3D { X = vVector.x, Y = vVector.y, Z = vVector.z };


                    //-------------------------------
                    //Look for closest point in the Body structure from vVector point giving error in small_structure :
                    //-------------------------------
                    double distanceSmallStructureToBody = double.MaxValue; //9999
                    //Find smallest distance from small structure to body
                    foreach (var pointInBody in setBody)
                    {
                        double tempdistance = DistanceSquared(pointInSmallStructureOutsideOfLargeStructure, pointInBody);
                        if (tempdistance < distanceSmallStructureToBody)
                        {
                            distanceSmallStructureToBody = tempdistance;
                            //point_outside_large_structure = p3;
                        }
                    }
                    distanceSmallStructureToBody = Math.Sqrt(distanceSmallStructureToBody);
                    minDistanceSmallStructureToBody = Math.Round(distanceSmallStructureToBody, 5).ToString();
                    //-------------------------------


                    //------------------
                    //Check distance from small to large structure where point is not near cropping to body
                    //------------------
                    double smallestDistanceSmallStructureToLargeStructure = 9999;
                    double distanceSmallStructureToLargeStructureLine = 9999;
                    //double minDistance = setStructureLarge.Min(p2 => Distance(point_outside_large_structure, p2));

                    //create list of distance between small and large structure, and a list of points
                    List<MarginsMeasuringPoint> marginMeasuringPoints = new List<MarginsMeasuringPoint>();
                    //List<MarginsMeasuringPoint> marginMeasuringPointsOrdered = new List<MarginsMeasuringPoint>();
                    MarginsMeasuringPoint measuringPointSmallestDistanceSmallStructureToLargeStructure = new MarginsMeasuringPoint();
                    MarginsMeasuringPoint measuringPointSecondSmallestDistanceSmallStructureToLargeStructure = new MarginsMeasuringPoint();
                    MarginsMeasuringPoint measuringPointThirdSmallestDistanceSmallStructureToLargeStructure = new MarginsMeasuringPoint();
                    //List<double> distancesSmallStructurePointToLargeStructure = new List<double>();
                    //List<Point3D> pointsSmallStructurePointToLargeStructure = new List<Point3D> ();
                    foreach (var pointInLargeStructure in setStructureLarge)
                    {
                        double tempdistance = Distance(pointInSmallStructureOutsideOfLargeStructure, pointInLargeStructure);
                        MarginsMeasuringPoint measuringPoint = new MarginsMeasuringPoint { Distance = tempdistance, point3D = pointInLargeStructure };
                        marginMeasuringPoints.Add(measuringPoint);
                    }


                    //reorder measuringPoints by distance, smallest distance first

                    marginMeasuringPoints = marginMeasuringPoints.OrderBy(num => num.Distance).ToList();  //Ascending by default, smallest distance first.
                    //Set measuringPoints of interest
                    measuringPointSmallestDistanceSmallStructureToLargeStructure = marginMeasuringPoints.ElementAt(0); //Smallest distance     //marginMeasuringPoints.OrderBy(num => num.Distance).ElementAt(0);
                    measuringPointSecondSmallestDistanceSmallStructureToLargeStructure = marginMeasuringPoints.ElementAt(1); //Second smallest distance //Debug
                    measuringPointThirdSmallestDistanceSmallStructureToLargeStructure = marginMeasuringPoints.ElementAt(2); //Third smallest distance //Debug

                    //Retrieve data:
                    smallestDistanceSmallStructureToLargeStructure = measuringPointSmallestDistanceSmallStructureToLargeStructure.Distance;
                    closestPointInLargeStructure = measuringPointSmallestDistanceSmallStructureToLargeStructure.point3D;
                    secondClosestPointInLargeStructure = measuringPointSecondSmallestDistanceSmallStructureToLargeStructure.point3D;

                    //Check more accurate distance between line and point, set it:
                    double tempDistanceLine = DistanceFromPointP0ToLineP1P2(pointInSmallStructureOutsideOfLargeStructure, closestPointInLargeStructure, secondClosestPointInLargeStructure);
                    if (tempDistanceLine <= smallestDistanceSmallStructureToLargeStructure)
                    {
                        distanceSmallStructureToLargeStructureLine = tempDistanceLine;
                    }
                    else
                    {
                        numberOfPointsWhereLineIsRejected++; //should not happen, something is fishy. Maybe set rejectMeasurement = true; (remember to reset before then).
                    }




                    //-------------------------------
                    //Print temporary coordinates
                    //-------------------------------
                    //check the coordinate of point in small structure
                    VVector dicomToUserMaxDistancevVector = Convert3DPointToVvector(pointInSmallStructureOutsideOfLargeStructure);
                    dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                    coordinateSmallStructureWithMaxDistance = PrintVvectorCoordinates(dicomToUserMaxDistancevVector);

                    //check the coordinate  of point in large structure
                    dicomToUserMaxDistancevVector = Convert3DPointToVvector(closestPointInLargeStructure);
                    dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                    coordinateLargeStructureWithMaxDistance = PrintVvectorCoordinates(dicomToUserMaxDistancevVector);

                    dicomToUserMaxDistancevVector = Convert3DPointToVvector(secondClosestPointInLargeStructure);
                    dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                    coordinateLargeStructureSecondPoint = PrintVvectorCoordinates(dicomToUserMaxDistancevVector);
                    //-------------------------------

                    //-------------------------------
                    //Reject point if bad resoltion --- removed this code. Line calculation solves this issue.
                    //-------------------------------
                    bool rejectMeasurement = false;
                    //string rejectMeasurementDebug = "";
                    string rejectMeasurmentMark = "";
                    //foreach (Point3D pointWithBadResolution in marginResult.BadResolutionPoints)
                    //{
                    //    //check the coordinate  of point in large structure
                    //    dicomToUserMaxDistancevVector = Convert3DPointToVvector(pointWithBadResolution);
                    //    dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                    //    string coordinatePointWithBadResolution = PrintVvectorCoordinates(dicomToUserMaxDistancevVector);
                    //    //rejectMeasurementDebug = rejectMeasurementDebug + coordinateLargeStructureWithMaxDistance + " / " + coordinatePointWithBadResolution;
                    //    if (pointWithBadResolution == closestPointInLargeStructure)
                    //    {
                    //        //Reject point:
                    //        rejectMeasurement = true;
                    //        rejectMeasurmentMark = "*";
                    //        //rejectMeasurementDebug = rejectMeasurementDebug + rejectMeasurmentMark;

                    //    }
                    //    //rejectMeasurementDebug = rejectMeasurementDebug + Environment.NewLine;
                    //}
                    //-------------------------------


                    //only if measurment is not too bad resolution
                    if (rejectMeasurement == false)
                    {

                        //Debug: 
                        distancesSmallStructureToLargeStructure = distancesSmallStructureToLargeStructure + Math.Round(smallestDistanceSmallStructureToLargeStructure, 1).ToString()
                            + rejectMeasurmentMark
                            + " (Small:" + coordinateSmallStructureWithMaxDistance + ")"
                            + " (Large1:" + coordinateLargeStructureWithMaxDistance + ")"
                            + " (Large2:" + coordinateLargeStructureSecondPoint + ")" + " || ";


                        //reset max distance:
                        if (smallestDistanceSmallStructureToLargeStructure > maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside)
                        { maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside = smallestDistanceSmallStructureToLargeStructure; }


                        ////Headsup if CTV to far outsidePTV, even if it is cropped. Gives too many false positives...
                        //if (distanceSmallStructureToLargeStructure > Constants.DefinitionCroppingPTVToCTVDistanceMarginCalculationMm && distanceSmallStructureToLargeStructure >= maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside)
                        //{
                        //    comment = "*" + marginResult.SmallStructureStartWith + " utenfor " + marginResult.LargeStructureStartWith + " med opptil " + Math.Round(distanceSmallStructureToLargeStructure, 2) + "mm.";
                        //    VVector dicomToUservVector = Convert3DPointToVvector(pointInSmallStructureOutsideOfLargeStructure);
                        //    dicomToUservVector = ConvertVvectorToUserCoordinates(dicomToUservVector, patientContext);
                        //    comment = comment + " (sjekk " + PrintVvectorCoordinates(dicomToUservVector) + ")";
                        //}

                    }




                    //If not close to body and small structure outside large structure - finally give an error
                    if (distanceSmallStructureToBody > Constants.ExceptionDistanceCTVToBodyInStructureInsideStructureCheckMm)
                    {


                        //Debug small structure is outside large structure and not close to body:
                        //exeptionStructureOutsideStructureAndNotCloseToBodyDicom = exeptionStructureOutsideStructureAndNotCloseToBodyDicom + "x: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.X, 2) + " y: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Y, 2) + " z: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Z, 2) + " , "; //Endre til koordinatsystem DicomToUser
                        VVector dicomToUserNotCloseToBodyvVector = Convert3DPointToVvector(pointInSmallStructureOutsideOfLargeStructure);
                        dicomToUserNotCloseToBodyvVector = ConvertVvectorToUserCoordinates(dicomToUserNotCloseToBodyvVector, patientContext);
                        exeptionStructureOutsideStructureAndNotCloseToBodyDicom = PrintVvectorCoordinates(dicomToUserNotCloseToBodyvVector);
                        //exeptionStructureOutsideStructureAndNotCloseToBodyDicom =  "x: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.X, 2) + " y: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Y, 2) + " z: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Z, 2) + " , "; //Endre til koordinatsystem DicomToUser

                        //Total distance fails
                        totalDistanceOutsideLargeStructure = totalDistanceOutsideLargeStructure + smallestDistanceSmallStructureToLargeStructure;
                        numberOfPointsWhereStructureOutsideStructure++;

                        //tolerate a litte difference. if distance is very small -> small structure can be considered equal to large structure and not outside structure
                        if (smallestDistanceSmallStructureToLargeStructure < Constants.ExceptionDistanceCTVToPTVIsEqualInStructureInsideStructureCheckMm || rejectMeasurement == true)  // ADD THIS: or point is in bad resolution area: "point exist in list BadResolutionPoints"
                        {
                            VVector dicomToUserEqualvVector = Convert3DPointToVvector(pointInSmallStructureOutsideOfLargeStructure);
                            dicomToUserEqualvVector = ConvertVvectorToUserCoordinates(dicomToUserEqualvVector, patientContext);

                            if (rejectMeasurement == true)
                            {
                                exeptionStructureBadResolution = PrintVvectorCoordinates(dicomToUserEqualvVector);
                                numberOfPointsWhereStructureOutsideStructureButBadResolution++;
                            }
                            else
                            {
                                numberOfPointsWhereStructureEqualToStructure++;
                                exeptionStructureEqualToStructure = PrintVvectorCoordinates(dicomToUserEqualvVector);
                                //exeptionStructureEqualToStructure =  "x: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.X, 2) + " y: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Y, 2) + " z: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Z, 2) + " , "; //Endre til koordinatsystem DicomToUser
                            }
                        }
                        else
                        {

                            numberOfPointsWhereStructureOutsideStructureAndNoExcuses++;
                            //Change status and write debug:
                            dicomToUserMaxDistancevVector = Convert3DPointToVvector(pointInSmallStructureOutsideOfLargeStructure);
                            dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                            exeptionStructureNotEqualToStructure = PrintVvectorCoordinates(dicomToUserMaxDistancevVector);

                            if (smallestDistanceSmallStructureToLargeStructure >= maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside) //If value equals (or over) maxdistance, print it.
                            { //Print the coordinates of max distance
                                marginResult.ExceptionMaxDistanceSmallStructureToLargeStructureWhereSmallStructureOutsideDicomCoordinates = exeptionStructureNotEqualToStructure;
                                //exeptionStructureNotEqualToStructure = exeptionStructureNotEqualToStructure + "x: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.X, 2) + " y: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Y, 2) + " z: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Z, 2) + " , "; //Endre til koordinatsystem DicomToUser
                            }
                            maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside = Math.Round(maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside, 3); //Change number of decimals for printing to debug

                            resultStructureIsInsidetructure = Constants.False;


                            //startDebugMessage = "Early exit function. ";
                            //goto EndMethodEarly;
                        }
                        //exeptionStructureOutsideStructureAndNotCloseToBodyUser = "x: " + vVectorCorrected.x + " y: " + vVectorCorrected.y + " z: " + vVectorCorrected.z + " , "; //Endre til koordinatsystem DicomToUser

                        //return resultStructureIsOutsideStructure;
                    }
                    else //Otherwise ignore small structure outside large structure if too close to body
                    {
                        //Debug but continue
                        numberOfPointsWhereStructureOutsideStructureButCloseToBody++;
                        //exeptionStructureOutsideStructureButCloseToBodyDicom = exeptionStructureOutsideStructureButCloseToBodyDicom + "x: " + pointInSmallStructureOutsideOfLargeStructure.X + " y: " + pointInSmallStructureOutsideOfLargeStructure.Y + " z: " + pointInSmallStructureOutsideOfLargeStructure.Z + " , ";
                        //exeptionStructureOutsideStructureButCloseToBodyDicom = "x: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.X,2) + " y: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Y,2) + " z: " + Math.Round(pointInSmallStructureOutsideOfLargeStructure.Z,2) + " , ";
                        //Give coordinates in eclipse:
                        VVector dicomToUservVector = Convert3DPointToVvector(pointInSmallStructureOutsideOfLargeStructure);
                        dicomToUservVector = ConvertVvectorToUserCoordinates(dicomToUservVector, patientContext);
                        exeptionStructureOutsideStructureButCloseToBodyDicom = PrintVvectorCoordinates(dicomToUservVector);

                        distancesToBody = distancesToBody + Math.Round(distanceSmallStructureToBody, 2).ToString() + ", ";
                    }
                }
                else
                {
                    numberOfPointsOk++;
                }
                numberOfPointsTotal++;
            }

            averageDistanceOutsideLargeStructure = Math.Round(totalDistanceOutsideLargeStructure / numberOfPointsWhereStructureOutsideStructure, 2);


            //Debug reached end without error:
            if (startDebugMessage == "") { startDebugMessage = "End function. "; }
            //maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside = Math.Round(maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside, 5);
            //Old Code: //debugMessage = startDebugMessage + Environment.NewLine + "Structure small:" + Environment.NewLine + "Structure small:" + structureName_small.Id + Environment.NewLine + "Structure large:" + structureName_large.Id + Environment.NewLine + "count vVectors: " + countvVectors + Environment.NewLine + "structureIsOutsideStructure: " + resultStructureIsOutsideStructure + Environment.NewLine + "NumberOfPointstructureOutsideStructureButCloseToBody: " + NumberOfPointsWhereStructureOutsideStructureButCloseToBody + Environment.NewLine + "exeptionStructureOutsideStructureButCloseToBody: " + exeptionStructureOutsideStructureButCloseToBodyDicom + Environment.NewLine + "distancesToBody: " + distancesToBody + Environment.NewLine + "exeptionStructureOutsideStructureAndNotCloseToBodyUser: " + exeptionStructureOutsideStructureAndNotCloseToBodyUser;

            //EndMethodEarly:
            //Debug:
            debugMessage = startDebugMessage + Environment.NewLine
                + "Structure small:" + structureSmall.Id + Environment.NewLine
                + "Structure large:" + structureLarge.Id + Environment.NewLine
                + "count ok points: " + numberOfPointsOk + Environment.NewLine
                + "resultStructureIsInsidetructure: " + resultStructureIsInsidetructure + Environment.NewLine
                + "NumberOfPointStructureOutsideStructureButCloseToBody: " + numberOfPointsWhereStructureOutsideStructureButCloseToBody + Environment.NewLine
                + "exeptionStructureOutsideStructureButCloseToBody: " + exeptionStructureOutsideStructureButCloseToBodyDicom + Environment.NewLine
                + "exeptionStructureOutsideStructureAndNotCloseToBodyUser: " + exeptionStructureOutsideStructureAndNotCloseToBodyUser + Environment.NewLine
                + "numberOfPointsWhereStructureEqualToStructure: " + numberOfPointsWhereStructureEqualToStructure + Environment.NewLine
                + "exeptionStructureBadResolution: " + exeptionStructureBadResolution + Environment.NewLine
                + "averageDistanceOutsideLargeStructure: " + averageDistanceOutsideLargeStructure + Environment.NewLine
                + "Max distanceSmallStructureToBody (that caused StructureIsOutsideStructure to become true): " + minDistanceSmallStructureToBody + Environment.NewLine  //+ exeptionStructureOutsideStructureAndNotCloseToBodyUser 
                 + "exeptionStructureEqualToStructure: " + exeptionStructureEqualToStructure + Environment.NewLine
                + "maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside: " + maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside + Environment.NewLine
                + "NumberOfPointsWhereStructureEqualToStructure: " + numberOfPointsWhereStructureEqualToStructure + Environment.NewLine
                + "numberOfPointsWhereStructureOutsideStructureAndNoExcuses: " + numberOfPointsWhereStructureOutsideStructureAndNoExcuses + Environment.NewLine
                + "distancesSmallStructureToLargeStructure: " + distancesSmallStructureToLargeStructure + Environment.NewLine
                + "exeptionStructureNotEqualToStructure positin that caused exit function: " + exeptionStructureNotEqualToStructure + Environment.NewLine
                + "distancesToBody: " + distancesToBody;  //distancesSmallStructureToLargeStructure2


            if (marginResult.Debug != "") { marginResult.Debug = marginResult.Debug + Environment.NewLine; }
            marginResult.Debug = marginResult.Debug + debugMessage;
            marginResult.IsSmallStructureWithinLargeStructure = resultStructureIsInsidetructure;
            marginResult.NumberOfPointsTotal = numberOfPointsTotal;
            marginResult.NumberOfPointsOk = numberOfPointsOk;
            marginResult.NumberOfPointsWhereStructureEqualToStructure = numberOfPointsWhereStructureEqualToStructure;
            marginResult.NumberOfPointsWhereStructureOutsideStructureButCloseToBody = numberOfPointsWhereStructureOutsideStructureButCloseToBody;
            marginResult.NumberOfPointsWhereStructureOutsideStructureAndNoExcuses = numberOfPointsWhereStructureOutsideStructureAndNoExcuses;
            marginResult.MaxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside = maxDistanceSmallStructureToLargeStructureWhereSmallStructureOutside;
            marginResult.Comment = marginResult.Comment + comment;
            marginResult.AverageDistanceOutsideLargeStructure = averageDistanceOutsideLargeStructure;
            if (numberOfPointsTotal == 0) { marginResult.PercentagePointsWhereStructureOutsideStructureAndNoExcuses = 0; }
            else { marginResult.PercentagePointsWhereStructureOutsideStructureAndNoExcuses = Math.Round((double)numberOfPointsWhereStructureOutsideStructureAndNoExcuses / numberOfPointsTotal, 2); }

            //MessageBox.Show(debugMessage);
            return marginResult; // resultStructureIsOutsideStructure;
        }

        public static double Distance(Point3D p1, Point3D p2)
        {

            double x = (p1.X - p2.X);
            double y = (p1.Y - p2.Y);
            double z = (p1.Z - p2.Z);
            double distance = (x * x) + (y * y) + (z * z);
            return Math.Sqrt(distance);
        }
        //return Math.Sqrt((p1.X - p2.X) * (p1.X - p2.X) + (p1.Y - p2.Y) * (p1.Y - p2.Y) + (p1.Z - p2.Z) * (p1.Z - p2.Z)); //Raskere enn Math.Pow?  //Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2) + Math.Pow(p1.Z - p2.Z, 2));


        public static double DistanceSquared(Point3D p1, Point3D p2)
        {
            double x = (p1.X - p2.X);
            double y = (p1.Y - p2.Y);
            double z = (p1.Z - p2.Z);
            double distance = (x * x) + (y * y) + (z * z);
            return distance; 
        }

        static double DistanceFromPointP0ToLineP1P2(Point3D p0, Point3D p1, Point3D p2) //two closest p1 og P2 forms a line. Finds distance from P0 to that line.
        {
            //Hentet fra   https://en.wikipedia.org/wiki/Distance_from_a_point_to_a_line
            double aboveDivision = Math.Abs((p2.Y - p1.Y) * p0.X - (p2.X - p1.X) * p0.Y + (p2.X * p1.Y) - (p2.Y * p1.X));
            double belowDivision = Math.Sqrt((p2.Y - p1.Y) * (p2.Y - p1.Y) + (p2.X - p1.X) * (p2.X - p1.X));

            return aboveDivision / belowDivision;
        }


        public static TargetStructures ParseTargetStructure(TargetStructures targetstructures, Structure strukt)
        {
            string strukturID = strukt.Id;
            //ID
            targetstructures.TargetStructureId = strukturID;

            //Get Code
            try
            {
                targetstructures.TargetStructureCode = strukt.StructureCode.Code;
            }
            catch { targetstructures.TargetStructureCode = ""; } //If not able to get StrucureCode



            //Dosenivaa og HarDose
            var NumberAtEndOfString = Regex.Match(strukturID, @"\d+$", RegexOptions.RightToLeft).Value; //string
            if (NumberAtEndOfString != null && NumberAtEndOfString != string.Empty)
            {
                targetstructures.TargetStructureDose = NumberAtEndOfString;
                targetstructures.TargetStructureHasDose = Constants.True;
                //MessageBox.Show(NumberAtEndOfString + " / " + strukturID);
            }
            else
            { targetstructures.TargetStructureHasDose = Constants.False; }

            //Description 
            if (NumberAtEndOfString != null && NumberAtEndOfString != string.Empty)
            {
                //minus dosenivaa (med og uten "_")
                strukturID = strukturID.Replace("_" + NumberAtEndOfString, "");
                strukturID = strukturID.Replace(NumberAtEndOfString, "");
            }
            //minus PTV, CTV, ITV (inkludert "_")
            strukturID = strukturID.Replace(Constants.PTV_StartWith + "_", "");
            strukturID = strukturID.Replace(Constants.CTV_StartWith + "_", "");
            strukturID = strukturID.Replace(Constants.ITV_StartWith + "_", "");
            strukturID = strukturID.Replace(Constants.IGTV_StartWith + "_", "");


            //minus PTV, CTV, ITV (uten "_")
            strukturID = strukturID.Replace(Constants.PTV_StartWith, "");
            strukturID = strukturID.Replace(Constants.CTV_StartWith, "");
            strukturID = strukturID.Replace(Constants.ITV_StartWith, "");
            strukturID = strukturID.Replace(Constants.IGTV_StartWith, "");
            targetstructures.TargetStructureDescription = strukturID;

            return targetstructures;
        }



        public static VVector ConvertVvectorToUserCoordinates(VVector vvector, PatientContext patientContext)
        {

            VVector dicomToUservVector = vvector;
            if (patientContext.SanityLevel > Constants.SanityLevelPlanExist)
            {
                dicomToUservVector = patientContext.ChosenImage.DicomToUser(dicomToUservVector, patientContext.ChosenPlan);
            }
            return dicomToUservVector;
        }

        public static string PrintVvectorCoordinates(VVector vvector)
        {
            string vVectorCoordinates = "";
            vVectorCoordinates = "x: " + Math.Round(vvector.x / 10, 2) + " y: " + Math.Round(vvector.y / 10, 2) + " z: " + Math.Round(vvector.z / 10, 2) + " , ";
            return vVectorCoordinates;
        }


        private static Margins GetBadResolutionDebug(Margins marginResult, List<Point3D> setStructureLarge, PatientContext patientContext) //Modified from CheckForOverlap, breped
        {
            //Check resolution of structure measuring points:
            //------------------------------------------

            double distanceLargeStructureResolution_total = 0;
            double numberOfLargeStructurePoints = setStructureLarge.Count();
            double numberOfBadResolutionPoints = 0;
            double percentageBadResolutionPoints = 0;
            double meanDistanceLargeStructureResolution = 0;
            double largestDistanceLargeStructureResolution = 0;
            double? modeDistanceLargeStructureResolution = 0;
            Point3D pointLargestDistanceResolution1 = new Point3D { X = 0, Y = 0, Z = 0 };
            Point3D pointLargestDistanceResolution2 = new Point3D { X = 0, Y = 0, Z = 0 };
            Point3D TemporaryPointLargestDistanceResolution1 = new Point3D { X = 0, Y = 0, Z = 0 };
            Point3D TemporaryPointLargestDistanceResolution2 = new Point3D { X = 0, Y = 0, Z = 0 };
            string coordinatesLargestDistanceResolution = "";
            string AllDistancesResolution = "";
            List<double> listOfResolutions = new List<double>();
            List<Point3D> badResolutionPoints = new List<Point3D>();
            foreach (Point3D pointInLargeStructure in setStructureLarge)
            {
                //------------------------------------
                //Find smallest distance to other point
                //------------------------------------
                double distanceLargeStructureResolution = double.MaxValue; //9999; //smallest distance in a comparison between one point and all other points. Must be reset for each point.
                foreach (Point3D otherPointInLargeStructure in setStructureLarge)
                {
                    if (otherPointInLargeStructure != pointInLargeStructure)
                    //if ((otherPointInLargeStructure.X != pointInLargeStructure.X) || (otherPointInLargeStructure.Y != pointInLargeStructure.Y) || (otherPointInLargeStructure.Z != pointInLargeStructure.Z))
                    {

                        double tempdistance = DistanceSquared(pointInLargeStructure, otherPointInLargeStructure);
                        if (tempdistance < distanceLargeStructureResolution)
                        {
                            distanceLargeStructureResolution = tempdistance;
                            TemporaryPointLargestDistanceResolution1 = pointInLargeStructure;
                            TemporaryPointLargestDistanceResolution2 = otherPointInLargeStructure;
                        }

                    }

                }
                distanceLargeStructureResolution = Math.Sqrt(distanceLargeStructureResolution);

                //------------------------------------

                //add to list
                double distanceRounded = Math.Round(distanceLargeStructureResolution, 2);
                listOfResolutions.Add(distanceRounded);
                AllDistancesResolution = AllDistancesResolution + ", " + distanceRounded;
                //Set distance
                distanceLargeStructureResolution_total = distanceLargeStructureResolution_total + distanceLargeStructureResolution;


                //Create a list of "bad resolution" points:
                if (distanceLargeStructureResolution > Constants.ToleranceBadResolutionMm)
                {
                    badResolutionPoints.Add(TemporaryPointLargestDistanceResolution1); //Only add
                    //BadResolutionPoints.Add(TemporaryPointLargestDistanceResolution2);

                }

                //Get the largest distance
                if (distanceLargeStructureResolution > largestDistanceLargeStructureResolution)
                {
                    largestDistanceLargeStructureResolution = Math.Round(distanceLargeStructureResolution, 3);
                    VVector dicomToUserMaxDistancevVector = Convert3DPointToVvector(TemporaryPointLargestDistanceResolution1);
                    dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                    coordinatesLargestDistanceResolution = PrintVvectorCoordinates(dicomToUserMaxDistancevVector);
                    dicomToUserMaxDistancevVector = Convert3DPointToVvector(TemporaryPointLargestDistanceResolution2);
                    dicomToUserMaxDistancevVector = ConvertVvectorToUserCoordinates(dicomToUserMaxDistancevVector, patientContext);
                    coordinatesLargestDistanceResolution = coordinatesLargestDistanceResolution + " & " + PrintVvectorCoordinates(dicomToUserMaxDistancevVector);
                }
            }

            modeDistanceLargeStructureResolution = Math.Round((double)GetModeOfList(listOfResolutions), 3);
            meanDistanceLargeStructureResolution = Math.Round(distanceLargeStructureResolution_total / numberOfLargeStructurePoints, 3);
            numberOfBadResolutionPoints = badResolutionPoints.Count;
            percentageBadResolutionPoints = numberOfBadResolutionPoints / numberOfLargeStructurePoints;
            string resolution_analysis = ""
                + "meanDistanceLargeStructureResolution: " + meanDistanceLargeStructureResolution + Environment.NewLine
                + "modeDistanceLargeStructureResolution: " + modeDistanceLargeStructureResolution + Environment.NewLine
                + "largestDistanceLargeStructureResolution: " + largestDistanceLargeStructureResolution + Environment.NewLine
                + "coordinatesLargestDistanceResolution: " + coordinatesLargestDistanceResolution + Environment.NewLine
                + "numberOfBadResolutionPoints: " + numberOfBadResolutionPoints + Environment.NewLine
                + "AllDistancesResolution: " + AllDistancesResolution + Environment.NewLine;

            //MessageBox.Show(resolution_analysis);
            //------------------------------------------

            marginResult.MeanDistanceLargeStructureResolution = meanDistanceLargeStructureResolution;
            marginResult.ModeDistanceLargeStructureResolution = (double)modeDistanceLargeStructureResolution;
            marginResult.LargestDistanceLargeStructureResolution = largestDistanceLargeStructureResolution;
            marginResult.NumberOfBadResolutionPoints = numberOfBadResolutionPoints;
            marginResult.NumberOfLargeStructurePoints = numberOfLargeStructurePoints;
            marginResult.PercentageBadResolutionPoints = percentageBadResolutionPoints;
            marginResult.BadResolutionPoints = badResolutionPoints;


            //-----------------------------------------

            return marginResult;

        }

        private static double? GetModeOfList(List<double> list)
        {
            double? modeValue =
             list
             .GroupBy(x => x)
             .OrderByDescending(x => x.Count()).ThenBy(x => x.Key)
             .Select(x => (double?)x.Key)
             .FirstOrDefault();
            if (modeValue == null)
            {
                modeValue = 0;
            }

            return modeValue;
        }


        public static MarginList DefineTypeOfMargin(MarginList marginList, string TypeOfMargin)
        {

            string largeStructureStartWith = "";
            string smallStructureStartWith = "";

            //Number of structures which starts with PTV and CTV:
            if (TypeOfMargin == "CTV-PTV")
            {
                largeStructureStartWith = Constants.PTV_StartWith;
                smallStructureStartWith = Constants.CTV_StartWith;
            }
            else if (TypeOfMargin == "ITV-PTV")
            {
                largeStructureStartWith = Constants.PTV_StartWith;
                smallStructureStartWith = Constants.ITV_StartWith;
            }
            else if (TypeOfMargin == "GTV-CTV")
            {
                largeStructureStartWith = Constants.CTV_StartWith;
                smallStructureStartWith = Constants.GTV_StartWith;
            }
            else if (TypeOfMargin == "CTV-ITV")
            {
                largeStructureStartWith = Constants.ITV_StartWith;
                smallStructureStartWith = Constants.CTV_StartWith;
            }
            else if (TypeOfMargin == "IGTV-CTV")
            {
                largeStructureStartWith = Constants.CTV_StartWith;
                smallStructureStartWith = Constants.IGTV_StartWith;
            }
            else if (TypeOfMargin == "GTV-IGTV")
            {
                largeStructureStartWith = Constants.IGTV_StartWith;
                smallStructureStartWith = Constants.GTV_StartWith;
            }
            else //Default
            {
                largeStructureStartWith = Constants.PTV_StartWith;
                smallStructureStartWith = Constants.CTV_StartWith;
            }

            marginList.SmallStructureStartWith = smallStructureStartWith;
            marginList.LargeStructureStartWith = largeStructureStartWith;

            return marginList;
        }

        //RemoveNotNecessaryMargins
        public static List<MarginList> RemoveNotNecessaryMargins(List<MarginList> listOfMarginLists)
        {
            int countOfTargetStructurePairs = 0; //Set later
            int countOfTargetStructurePairsToRemove = 0; //set later
            int countOfMarginLists = listOfMarginLists.Count;

            List<String> listOfGTVStructuresToRemoveFromGTVToCTVList = new List<String>(); //Because we use IGTV instead as intermediate
            List<String> listOfCTVStructuresToRemoveFromCTVToPTVList = new List<String>(); //Because we use ITV instead as intermediate
            //--If GTV-IGTV  and  IGTV-CTV, remove (or no tolernace limit?) on GTV-CTV
            for (int i = 0; i < countOfMarginLists; i++)
            {
                if (listOfMarginLists[i].LargeStructureStartWith == Constants.IGTV_StartWith)
                {
                    countOfTargetStructurePairs = listOfMarginLists[i].ListOfMargins.Count;
                    for (int j = 0; j < countOfTargetStructurePairs; j++)
                    {
                        if (listOfMarginLists[i].ListOfMargins[j].LargeStructureStartWith == Constants.IGTV_StartWith)
                        {
                            listOfGTVStructuresToRemoveFromGTVToCTVList.Add(listOfMarginLists[i].ListOfMargins[j].SmallStructureID);
                        }
                    }

                }
            }
            //--If CTV-ITV  and  ITV-PTV, remove (or no tolernace limit?) CTV-PTV
            for (int i = 0; i < countOfMarginLists; i++)
            {
                if (listOfMarginLists[i].LargeStructureStartWith == Constants.ITV_StartWith)
                {
                    countOfTargetStructurePairs = listOfMarginLists[i].ListOfMargins.Count;
                    for (int j = 0; j < countOfTargetStructurePairs; j++)
                    {
                        if (listOfMarginLists[i].ListOfMargins[j].LargeStructureStartWith == Constants.ITV_StartWith)
                        {
                            listOfCTVStructuresToRemoveFromCTVToPTVList.Add(listOfMarginLists[i].ListOfMargins[j].SmallStructureID);
                        }
                    }

                }
            }
            //Remove GTV-CTV from list
            for (int i = 0; i < countOfMarginLists; i++)
            {
                //find list to edit
                if (listOfMarginLists[i].LargeStructureStartWith == Constants.CTV_StartWith && listOfMarginLists[i].SmallStructureStartWith == Constants.GTV_StartWith)
                {
                    //iterate through structures to remove
                    countOfTargetStructurePairsToRemove = listOfGTVStructuresToRemoveFromGTVToCTVList.Count;
                    for (int k = 0; k < countOfTargetStructurePairsToRemove; k++)
                    {
                        string GtvId = listOfGTVStructuresToRemoveFromGTVToCTVList[k];

                        //Check through list of list of margins
                        countOfTargetStructurePairs = listOfMarginLists[i].ListOfMargins.Count;
                        for (int j = 0; j < countOfTargetStructurePairs; j++)
                        {
                            //Remove matches
                            if (listOfMarginLists[i].ListOfMargins[j].SmallStructureID == GtvId)
                            {
                                listOfMarginLists[i].ListOfMargins.RemoveAt(j); //
                                countOfTargetStructurePairs = countOfTargetStructurePairs - 1;
                            }

                        }
                    }
                }
                listOfMarginLists[i].ListOfGTVStructuresToRemoveFromGTVToCTVList = listOfGTVStructuresToRemoveFromGTVToCTVList;
            }

            //Remove CTV-PTV from list
            for (int i = 0; i < countOfMarginLists; i++)
            {
                //find list to edit
                if (listOfMarginLists[i].LargeStructureStartWith == Constants.PTV_StartWith && listOfMarginLists[i].SmallStructureStartWith == Constants.CTV_StartWith)
                {
                    //Find structures to remove
                    countOfTargetStructurePairsToRemove = listOfCTVStructuresToRemoveFromCTVToPTVList.Count;
                    for (int k = 0; k < countOfTargetStructurePairsToRemove; k++)
                    {
                        string CtvId = listOfCTVStructuresToRemoveFromCTVToPTVList[k];

                        //Check through list of list of margins
                        countOfTargetStructurePairs = listOfMarginLists[i].ListOfMargins.Count;
                        for (int j = 0; j < countOfTargetStructurePairs; j++)
                        {
                            //Remove matches
                            if (listOfMarginLists[i].ListOfMargins[j].SmallStructureID == CtvId)
                            {
                                listOfMarginLists[i].ListOfMargins.RemoveAt(j); //
                                countOfTargetStructurePairs = countOfTargetStructurePairs - 1;
                            }

                        }
                    }
                    listOfMarginLists[i].ListOfCTVStructuresToRemoveFromCTVToPTVList = listOfCTVStructuresToRemoveFromCTVToPTVList;
                }
            }



            return listOfMarginLists;
        }

        public static List<MarginList> CreateListOfMarginLists(PatientContext patientContext, string eclipseTemplateName)
        {
            //yep, as the name says, a list of lists

            string TypesOfMarginString = "GTV-CTV|GTV-IGTV|IGTV-CTV|CTV-ITV|CTV-PTV|ITV-PTV"; //Differente types of margins desired - this could be gotten from marginsTemplate instead perhaps.
            List<String> TypesOfMargins = TypesOfMarginString.Split(Constants.CharSeparator).ToList();


            List<MarginList> listOfMarginLists = new List<MarginList>();

            //Create default templates
            foreach (string typeOfMargin in TypesOfMargins)
            {
                MarginList marginList = CreateDefaultMarginList(patientContext);
                listOfMarginLists.Add(marginList);
            }

            //Create Margin lists with target structures
            int countOfMarginLists = listOfMarginLists.Count;

            for (int i = 0; i < countOfMarginLists; i++)
            {
                listOfMarginLists[i] = DefineTypeOfMargin(listOfMarginLists[i], TypesOfMargins[i]); //CTV-PTV or ITV-PTV for instance
                listOfMarginLists[i] = CreateListOfTargetStructures(listOfMarginLists[i]);
                listOfMarginLists[i] = MatchTargetStructures(listOfMarginLists[i], patientContext); //This also calculates the actual margins at the same time! Should maybe be done at separate stage?
                //GeneralExtension.PrintObject(listOfMarginLists[i]);
            }

            //-----------------------------
            //If no matches at all, maybe try different TypesOfMarginString = "GTV-ITV" //Stereotaksi
            //-----------------------------

            //Load margins templates
            string filePathMarginTemplates = PlanTemplateExtension.SetFilePathMarginsTemplates();
            List<Margins> marginsTemplates = MarginsExtension.LoadMarginsTemplates(filePathMarginTemplates, eclipseTemplateName);

            //Update marginlist with templates
            countOfMarginLists = listOfMarginLists.Count;
            //MessageBox.Show("countOfMarginLists: " + countOfMarginLists.ToString());
            for (int i = 0; i < countOfMarginLists; i++)
            {
                //Update marginResult with marginTemplate values
                listOfMarginLists[i] = MarginsExtension.UpdateMarginTolerances(listOfMarginLists[i], marginsTemplates);
            }

            //Remove Margins that are not necessary: For instance if CTV-ITV exist, no need for CTV-PTV for that specific target structure pair
            listOfMarginLists = RemoveNotNecessaryMargins(listOfMarginLists);


            return listOfMarginLists;
        }

        public static MarginList CreateDefaultMarginList(PatientContext patientContext)
        {
            Structure bodyID;
            bodyID = patientContext.ChosenStructureSet.Structures.Where(x => x.Id == patientContext.BodyId).FirstOrDefault(); //needed to check for cropping against body


            List<TargetStructures> largeTargetStructureList = new List<TargetStructures>();
            List<TargetStructures> smallTargetStructureList = new List<TargetStructures>();

            List<String> listOfGTVStructuresToRemoveFromGTVToCTVList = new List<String>(); //Because we use IGTV instead as intermediate
            List<String> listOfCTVStructuresToRemoveFromCTVToPTVList = new List<String>(); //Because we use ITV instead as intermediate


            //Oppretter ny tom targetstructures
            MarginList marginList = new MarginList()
            {
                ListOfMargins = new List<Margins>(),
                StructureSet = patientContext.ChosenStructureSet,
                StructureBody = bodyID,
                LargeStructureStartWith = "",
                SmallStructureStartWith = "",
                LargeTargetStructureList = largeTargetStructureList,
                SmallTargetStructureList = smallTargetStructureList,
                OriginalLargeTargetStructureListIds = "",
                OriginalSmallTargetStructureListIds = "",
                NumberOfSmallStructures = 0,
                NumberOfLargeStructures = 0,
                Debug = "",
                FinalLargeTargetStructureListIds = "",
                FinalSmallTargetStructureListIds = "",
                ListOfCTVStructuresToRemoveFromCTVToPTVList = listOfCTVStructuresToRemoveFromCTVToPTVList,
                ListOfGTVStructuresToRemoveFromGTVToCTVList = listOfGTVStructuresToRemoveFromGTVToCTVList
            };

            return marginList;
        }


        public static MarginList CreateListOfTargetStructures(MarginList marginList)
        {
            //marginList = DefineTypeOfMargin(marginList, TypeOfMargin);

            string LargeStructureStartWith = marginList.LargeStructureStartWith;
            string SmallStructureStartWith = marginList.SmallStructureStartWith;



            //Number of structures:
            int numberOfLargeStructures = marginList.StructureSet.Structures.Count(x => x.Id.ToUpper().StartsWith(LargeStructureStartWith));
            int numberOfSmallStructures = marginList.StructureSet.Structures.Count(x => x.Id.ToUpper().StartsWith(SmallStructureStartWith));

            //Liste umatchede ptv i strukturset
            List<TargetStructures> largeStructureList = new List<TargetStructures>();
            //Liste umatchede ctv i structurset
            List<TargetStructures> smallStructureList = new List<TargetStructures>();

            string stringLargeStructureList = "";
            string stringSmallStructureList = "";

            //-----------------------------------------------------
            //Oppretter lister med CTV og PTV og parser informasjon. 
            //-----------------------------------------------------
            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                string strukturID = strukt.Id;
                //Legger i liste:
                if (strukt.Id.StartsWith(LargeStructureStartWith))
                {
                    TargetStructures targetstructures = CreateDefaultTargetStructure();
                    //Parser
                    targetstructures = ParseTargetStructure(targetstructures, strukt);
                    largeStructureList.Add(targetstructures);
                }

                //Legger i liste:
                if (strukt.Id.StartsWith(SmallStructureStartWith))
                {
                    TargetStructures targetstructures = CreateDefaultTargetStructure();
                    //Parser
                    targetstructures = ParseTargetStructure(targetstructures, strukt);
                    smallStructureList.Add(targetstructures);
                }
            }
            //Set lists:
            marginList.LargeTargetStructureList = largeStructureList;
            marginList.SmallTargetStructureList = smallStructureList;

            marginList.NumberOfLargeStructures = numberOfLargeStructures;
            marginList.NumberOfSmallStructures = numberOfSmallStructures;

            //Send debug about creating List
            if (marginList.Debug != "") { marginList.Debug = marginList.Debug + Environment.NewLine; }
            foreach (TargetStructures ts in largeStructureList)
            {
                if (stringLargeStructureList != "") { stringLargeStructureList = stringLargeStructureList + ", "; }
                stringLargeStructureList = stringLargeStructureList + ts.TargetStructureId;
            }
            foreach (TargetStructures ts in smallStructureList)
            {
                if (stringSmallStructureList != "") { stringSmallStructureList = stringSmallStructureList + ", "; }
                stringSmallStructureList = stringSmallStructureList + ts.TargetStructureId;
            }

            marginList.OriginalLargeTargetStructureListIds = stringLargeStructureList;
            marginList.OriginalSmallTargetStructureListIds = stringSmallStructureList; //marginList.OriginalLargeTargetStructureListIds = stringSmallStructureList;

            marginList.Debug = marginList.Debug + "Original large structure list:" + Environment.NewLine + stringLargeStructureList;
            marginList.Debug = marginList.Debug + Environment.NewLine + "Original small structure list:" + Environment.NewLine + stringSmallStructureList;




            return marginList; //Where should s.Debug go?
        }



        public static MarginList MatchTargetStructures(MarginList marginList, PatientContext patientContext) //ok //What happens if marginList is null
        {

            //Run through matching attempts in priority
            marginList = MatchTargetStructuresBasedOnIdenticalNames(marginList, patientContext);
            //TO ADD: MatchTargetStructuresBasedOnForcedMatchFromMarginTemplate - if template is matching, and BOTH structures exist (small and big), and it matches patient orientation in template. Requires template is chosen...
            marginList = MatchTargetStructuresBasedOnDescriptionAndDose(marginList, patientContext);
            marginList = MatchTargetStructuresBasedOnDescriptionAndCode(marginList, patientContext);  //MatchTargetStructuresBasedOnDescriptionAndCode
            marginList = MatchTargetStructuresBasedOnDose(marginList, patientContext);
            marginList = MatchTargetStructuresBasedOnCode(marginList, patientContext);
            marginList = MatchTargetStructuresBasedOnDescription(marginList, patientContext);

            //get remaining unmatched structures
            marginList = GetRemainingUnmatchedTargetStructureLists(marginList);

            /// IDEA: seperate modified (adapted) radiotherapy check? ("art", other?)
            // Sjekk om det fortsatt finnes en PTV med "art" i seg igjen i PTV-liste. Kjor ekstra kobling av denne PTV til CTV (uten "art" i navn)?

            //if only one pair of CTV and CTV, match them regardless:
            marginList = MatchTargetStructuresIfOnlyOnePair(marginList, patientContext);

            //marginList = StructureExtension.MatchTargetStructuresIfOneSmallVsTwoLarge(marginList, patientContext);  THis one produces errors...

            return marginList;
        }

        public static MarginList MatchTargetStructuresBasedOnIdenticalNames(MarginList marginList, PatientContext patientContext) //ok //What happens if marginList is null
        {
            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved identisk match paa navn:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            string debugDescription = "Match på navn.";

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;
                    //Sjekker kun hvis den fortsatt er i PTV-liste
                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        smallStructureID = largeStructureID.Replace(marginList.LargeStructureStartWith, marginList.SmallStructureStartWith); //Change name to fit smaller structure
                        smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == smallStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                        largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == largeStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                        marginList = MarginsExtension.ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);
                    }
                }
            }
            //-----------------------------------------------------
            return marginList;
        }



        public static MarginList MatchTargetStructuresBasedOnDescriptionAndDose(MarginList marginList, PatientContext patientContext) //ok
        {
            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende description og dose:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            int NumberOfTargetStructuresWithMatch = 0;
            string debugDescription = "Match på description og dose.";

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Looking for large structures:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    //Only if it is still in the Large Structure List
                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {

                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);
                        //Only if it has a doselevel parsed out
                        if (valgtstruktur.TargetStructureHasDose == Constants.True)
                        {
                            NumberOfTargetStructuresWithMatch = 0;
                            //--------------  Find matching doselevel in small structure list --------
                            List<TargetStructures> smallStructureListMatch = new List<TargetStructures>(marginList.SmallTargetStructureList.FindAll(x => x.TargetStructureDose.Contains(valgtstruktur.TargetStructureDose) && x.TargetStructureDescription.ToLower() != "" && x.TargetStructureDescription.ToLower() == valgtstruktur.TargetStructureDescription.ToLower()));
                            //-----------------------------------------------------
                            NumberOfTargetStructuresWithMatch = smallStructureListMatch.Count();  // List<TargetStructures> CTVListMatch = new List<TargetStructures>(CTVList.FindAll(x => x.TargetStructureDose.Contains(valgtstruktur.TargetStructureDose) && x.TargetStructureCode.Contains(valgtstruktur.TargetStructureCode.Replace("PTV","")) && x.TargetStructureDescription.Contains(valgtstruktur.TargetStructureDescription)));
                            ///----------------------------------------------------------------
                            ///----------------------------------------------------------------
                            if (NumberOfTargetStructuresWithMatch == 1) //only if there is just ONE match, so no ambiguity
                            {
                                smallStructureID = smallStructureListMatch.First().TargetStructureId;
                                smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == smallStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                                largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == largeStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                                marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);

                            }
                        }
                    }
                }
            }
            //-----------------------------------------------------
            return marginList;
        }

        public static MarginList MatchTargetStructuresBasedOnDescriptionAndCode(MarginList marginList, PatientContext patientContext) //ok
        {

            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende description og code:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            int NumberOfTargetStructuresWithMatch = 0;
            string debugDescription = "Match på description og kode.";

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    //If it exist i the list
                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);

                        NumberOfTargetStructuresWithMatch = 0;
                        //Finner matchende dosenivå i CTV-liste    // List<TargetStructures> CTVListMatch = new List<TargetStructures>(CTVList.FindAll(x => x.TargetStructureDose.Contains(valgtstruktur.TargetStructureDose) && x.TargetStructureCode.Contains(valgtstruktur.TargetStructureCode.Replace("PTV","")) && x.TargetStructureDescription.Contains(valgtstruktur.TargetStructureDescription)));

                        //--------------  matchende description og code --------
                        List<TargetStructures> smallStructureMatchList = new List<TargetStructures>(marginList.SmallTargetStructureList.FindAll(x => x.TargetStructureCode.Contains(valgtstruktur.TargetStructureCode.Replace(marginList.LargeStructureStartWith, "")) && x.TargetStructureDescription.ToLower() == valgtstruktur.TargetStructureDescription.ToLower())); //&& x.TargetStructureDescription.ToLower() != ""
                        //-----------------------------------------------------
                        NumberOfTargetStructuresWithMatch = smallStructureMatchList.Count();

                        if (NumberOfTargetStructuresWithMatch == 1)
                        {
                            smallStructureID = smallStructureMatchList.First().TargetStructureId;
                            smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == smallStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                            largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == largeStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                            marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);

                        }
                    }
                }
            }
            return marginList;
        }

        public static MarginList MatchTargetStructuresBasedOnDose(MarginList marginList, PatientContext patientContext) //ok
        {
            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende dose:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            int NumberOfTargetStructuresWithMatch = 0;
            string debugDescription = "Match på dose.";

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);
                        //Sjekker kun hvis den har dosenivaa
                        if (valgtstruktur.TargetStructureHasDose == Constants.True)
                        {
                            NumberOfTargetStructuresWithMatch = 0;
                            //-------------Finner matchende dosenivå i small structure list----------
                            List<TargetStructures> smallStructureMatchList = new List<TargetStructures>(marginList.SmallTargetStructureList.FindAll(x => x.TargetStructureDose.Contains(valgtstruktur.TargetStructureDose)));
                            //-----------------------------------------------------------
                            NumberOfTargetStructuresWithMatch = smallStructureMatchList.Count();

                            if (NumberOfTargetStructuresWithMatch == 1)
                            {
                                smallStructureID = smallStructureMatchList.First().TargetStructureId;
                                smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == smallStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                                largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == largeStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                                marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);

                            }
                        }
                    }
                }
            }
            return marginList;
        }


        public static MarginList MatchTargetStructuresBasedOnCode(MarginList marginList, PatientContext patientContext)
        {
            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende kode:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            int NumberOfTargetStructuresWithMatch = 0;
            string debugDescription = "Match på kode.";

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);

                        NumberOfTargetStructuresWithMatch = 0;
                        //---------------- matchende Code   ----------------------------------  
                        List<TargetStructures> smallStructureMatchList = new List<TargetStructures>(marginList.SmallTargetStructureList.FindAll(x => x.TargetStructureCode.Contains(valgtstruktur.TargetStructureCode.Replace(marginList.LargeStructureStartWith, ""))));
                        //-------------------------------------------------------------------
                        NumberOfTargetStructuresWithMatch = smallStructureMatchList.Count();

                        if (NumberOfTargetStructuresWithMatch == 1)
                        {
                            //Sjekker kun hvis den fortsatt er i large structure list
                            smallStructureID = smallStructureMatchList.First().TargetStructureId;
                            smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == smallStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                            largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == largeStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                            marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);

                        }

                    }
                }
            }
            return marginList;
        }


        public static MarginList MatchTargetStructuresBasedOnDescription(MarginList marginList, PatientContext patientContext)
        {
            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende description:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            int NumberOfTargetStructuresWithMatch = 0;
            string debugDescription = "Match på description.";

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);

                        NumberOfTargetStructuresWithMatch = 0;
                        //---------------- matchende Code   ----------------------------------  
                        List<TargetStructures> smallStructureMatchList = new List<TargetStructures>(marginList.SmallTargetStructureList.FindAll(x => x.TargetStructureDescription.ToLower() != "" && x.TargetStructureDescription.ToLower() == valgtstruktur.TargetStructureDescription.ToLower()));
                        //-------------------------------------------------------------------
                        NumberOfTargetStructuresWithMatch = smallStructureMatchList.Count();

                        if (NumberOfTargetStructuresWithMatch == 1)
                        {
                            //Sjekker kun hvis den fortsatt er i large structure list
                            smallStructureID = smallStructureMatchList.First().TargetStructureId;
                            smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == smallStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                            largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id == largeStructureID);  //kan ikke eksistere flere med samme navn så entydig match.
                            marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);
                        }
                    }
                }
            }
            //List<TargetStructures> CTVListMatch = new List<TargetStructures>(SmallTargetStructureList.FindAll(x => x.TargetStructureDescription.ToLower() == valgtstruktur.TargetStructureDescription.ToLower()));
            return marginList;
        }

        public static MarginList MatchTargetStructuresIfOnlyOnePair(MarginList marginList, PatientContext patientContext)
        {

            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende description:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            string debugDescription = "Match when only one " + marginList.SmallStructureStartWith + " and only one " + marginList.LargeStructureStartWith;

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);
                        if (!marginList.ListOfMargins.Any()) //If nothing has been put in the margin list yet
                        {
                            //Only one pair exist - lucky us! Just close your eyes and match them!
                            if (marginList.NumberOfLargeStructures == 1 && marginList.NumberOfSmallStructures == 1)
                            {
                                //Sjekker kun hvis den fortsatt er i large structure list
                                smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id.ToLower().StartsWith(marginList.SmallStructureStartWith.ToLower()));  //kan ikke eksistere flere med samme navn så entydig match.
                                smallStructureID = smallStructure.Id;
                                largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id.ToLower().StartsWith(marginList.LargeStructureStartWith.ToLower()));   //kan ikke eksistere flere med samme navn så entydig match.
                                marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);
                            }
                        }
                    }
                }
            }
            return marginList;
        }

        public static MarginList MatchTargetStructuresIfOneSmallVsTwoLarge(MarginList marginList, PatientContext patientContext)
        {

            //-----------------------------------------------------
            //itererer over struktsett paa leting etter PTV-CTV-par ved matchende description:
            //-----------------------------------------------------
            string largeStructureID = "";
            string smallStructureID = "";
            Structure smallStructure; //largeStructure
            Structure largeStructure; //smallStructure
            string debugDescription = "Match when only one " + marginList.SmallStructureStartWith + " and two " + marginList.LargeStructureStartWith;

            foreach (Structure strukt in marginList.StructureSet.Structures)
            {
                //Leter etter PTV-strukter:
                if (strukt.Id.StartsWith(marginList.LargeStructureStartWith))
                {
                    largeStructureID = strukt.Id;

                    if (marginList.LargeTargetStructureList.Any(x => x.TargetStructureId == largeStructureID))
                    {
                        TargetStructures valgtstruktur = marginList.LargeTargetStructureList.FirstOrDefault(x => x.TargetStructureId == largeStructureID);
                        if (!marginList.ListOfMargins.Any()) //If nothing has been put in the margin list yet
                        {
                            //Only one Small structure exists, and Two Large Structures. Try matching with both of them, as it could be an edit, and its nice to see the difference.
                            if (marginList.NumberOfLargeStructures == 2 && marginList.NumberOfSmallStructures == 1)
                            {
                                //copy target structure:
                                TargetStructures targetstructures = marginList.SmallTargetStructureList.FirstOrDefault();

                                //Sjekker kun hvis den fortsatt er i large structure list
                                smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id.ToLower().StartsWith(marginList.SmallStructureStartWith.ToLower()));  //kan ikke eksistere flere med samme navn så entydig match.
                                smallStructureID = smallStructure.Id;
                                largeStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id.ToLower().StartsWith(marginList.LargeStructureStartWith.ToLower()));   //kan ikke eksistere flere med samme navn så entydig match.
                                marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);

                                //Re-add small target structure and run again
                                marginList.SmallTargetStructureList.Add(targetstructures);

                                //Sjekker kun hvis den fortsatt er i large structure list
                                smallStructure = marginList.StructureSet.Structures.FirstOrDefault(x => x.Id.ToLower().StartsWith(marginList.SmallStructureStartWith.ToLower()));  //kan ikke eksistere flere med samme navn så entydig match.
                                smallStructureID = smallStructure.Id;
                                largeStructure = marginList.StructureSet.Structures.LastOrDefault(x => x.Id.ToLower().StartsWith(marginList.LargeStructureStartWith.ToLower()));   //kan ikke eksistere flere med samme navn så entydig match.
                                largeStructureID = largeStructure.Id;
                                marginList = ValidateTargetStructureMatchAndCalculateMargins(marginList, smallStructure, largeStructure, smallStructureID, largeStructureID, debugDescription, patientContext);

                            }
                        }
                    }
                }
            }
            return marginList;
        }

        public static MarginList GetRemainingUnmatchedTargetStructureLists(MarginList marginList)
        {
            // ----------------------------------------------------
            // Sender remaining list to debug
            //----------------------------------------------------
            string finalLargeTargetStructureListIds = "";
            string finalSmallTargetStructureListIds = "";
            if (marginList.Debug != "") { marginList.Debug = marginList.Debug + Environment.NewLine; }
            foreach (TargetStructures targets in marginList.LargeTargetStructureList)
            {
                if (finalLargeTargetStructureListIds != "") { finalLargeTargetStructureListIds = finalLargeTargetStructureListIds + ", "; }
                finalLargeTargetStructureListIds = finalLargeTargetStructureListIds + targets.TargetStructureId;
            }
            foreach (TargetStructures targets in marginList.SmallTargetStructureList)
            {
                if (finalSmallTargetStructureListIds != "") { finalSmallTargetStructureListIds = finalSmallTargetStructureListIds + ", "; }
                finalSmallTargetStructureListIds = finalSmallTargetStructureListIds + targets.TargetStructureId;
            }
            marginList.FinalLargeTargetStructureListIds = finalLargeTargetStructureListIds;
            marginList.FinalSmallTargetStructureListIds = finalSmallTargetStructureListIds;

            //s.CheckDebug = s.CheckDebug + "Rest ikke matchet PTV-list:" + Environment.NewLine + finalLargeTargetStructureListIds;
            //s.CheckDebug = s.CheckDebug + Environment.NewLine + "Rest ikke matchet CTV-list:" + Environment.NewLine + finalSmallTargetStructureListIds;

            return marginList;
        }

        public static MarginList GenerateCheckpointListForMarginChecks(MarginList marginList)
        {

            return marginList;
        }

        public static Margins BasicCheckNegativeMargin(Margins marginResult, string smallStructureID, string largeStructureID)
        {
            //Simple check that takes little processing:
            bool basicCheckNegativMargin = (marginResult.X_Minus_Margin < 0 || marginResult.X_Pluss_Margin < 0 || marginResult.Y_Minus_Margin < 0 || marginResult.Y_Pluss_Margin < 0 || marginResult.Z_Minus_Margin < 0 || marginResult.Z_Pluss_Margin < 0);
            //More advanced check. Can skip it if the simple check already has cought the error, otherwise run:

            // Find negativ margin direction, if possible
            if (basicCheckNegativMargin == true)
            {
                string negativ_margin = "";
                if (marginResult.X_Minus_Margin < 0)
                { negativ_margin = negativ_margin + "X-;"; }
                if (marginResult.X_Pluss_Margin < 0)
                { negativ_margin = negativ_margin + "X+;"; }
                if (marginResult.Y_Minus_Margin < 0)
                { negativ_margin = negativ_margin + "Y-;"; }
                if (marginResult.Y_Pluss_Margin < 0)
                { negativ_margin = negativ_margin + "Y+;"; }
                if (marginResult.Z_Minus_Margin < 0)
                { negativ_margin = negativ_margin + "Z-;"; }
                if (marginResult.Z_Pluss_Margin < 0)
                { negativ_margin = negativ_margin + "Z+;"; }

                //result_output = result_output + "*Negativ margin oppdaget for retningen " + negativ_margin + Environment.NewLine; //Lage en egen parameter for dette i Margin.NegativMargin (basic sjekk).
                marginResult.Debug = marginResult.Debug + "*" + smallStructureID + " utenfor " + largeStructureID + " i MeshGeometry Bounds (basic sjekk)." + Environment.NewLine; //MarginsResult //marginList.ListOfMargins.ElementAt(iterator).Debug
                marginResult.BasicCheckNegativMarginDetected = Constants.Warning; //arginList.ListOfMargins.ElementAt(iterator).BasicCheckNegativMarginDetected
                                                                                  //s.CheckStatus = Constants.Warning;
            }
            else
            {
                marginResult.BasicCheckNegativMarginDetected = Constants.Ok;
            }


            return marginResult;
        }

        public static Margins UpdateMeanMarginStatus(Margins marginResult, bool meanToleranceExistHigh, bool meanToleranceExistLow, string marginType, CheckPoint s)
        {

            string tempdebug = "";
            string result_comment = "";
            string debugMarginVsTemplate = "";

            //Check margins High
            string checkMarginVsTemplateHigh = Constants.Ok; //set temporary status.

            tempdebug = "--  " + marginType + " margins  --" + Environment.NewLine + "meanToleranceExistHigh: " + meanToleranceExistHigh + Environment.NewLine + "meanToleranceExistLow : " + meanToleranceExistLow;

            if (meanToleranceExistHigh == true)
            {
                //Error
                if (marginResult.MeanMarginHighError != -1)
                {
                    checkMarginVsTemplateHigh = CheckPointExtension.CheckResultVsTemplate(marginResult.MeanMarginNotCroppedToBody.ToString(), marginResult.MeanMarginHighError.ToString(), Constants.Error, "numerisk", s, "<="); //= is ok
                }
                //Warning
                if (checkMarginVsTemplateHigh != Constants.Error)
                {
                    if (marginResult.MeanMarginHighWarning != -1)
                    {
                        checkMarginVsTemplateHigh = CheckPointExtension.CheckResultVsTemplate(marginResult.MeanMarginNotCroppedToBody.ToString(), marginResult.MeanMarginHighWarning.ToString(), Constants.Warning, "numerisk", s, "<="); //= is ok
                    }
                }
                //Set result
                if (checkMarginVsTemplateHigh == Constants.Error)
                {
                    debugMarginVsTemplate = debugMarginVsTemplate + "Gj.snittmargin større enn templatet. ";
                    result_comment = result_comment + "Gj.snittmargin større enn templatet. ";
                }
                if (checkMarginVsTemplateHigh == Constants.Warning)
                {
                    debugMarginVsTemplate = debugMarginVsTemplate + "Gj.snittmargin litt større enn templatet. ";
                    result_comment = result_comment + "Gj.snittmargin litt større enn templatet. ";
                }
            }

            //Check margins Low
            string checkMarginVsTemplateLow = Constants.Ok;
            if (meanToleranceExistLow == true)
            {
                //Error
                if (marginResult.MeanMarginLowError != -1)
                {
                    checkMarginVsTemplateLow = CheckPointExtension.CheckResultVsTemplate(marginResult.MeanMarginNotCroppedToBody.ToString(), marginResult.MeanMarginLowError.ToString(), Constants.Error, "numerisk", s, ">="); //= is ok
                }
                //Warning
                if (checkMarginVsTemplateLow != Constants.Error)
                {
                    if (marginResult.MeanMarginLowWarning != -1)
                    {
                        checkMarginVsTemplateLow = CheckPointExtension.CheckResultVsTemplate(marginResult.MeanMarginNotCroppedToBody.ToString(), marginResult.MeanMarginLowWarning.ToString(), Constants.Warning, "numerisk", s, ">="); //= is ok
                    }
                }
                //Set result
                if (checkMarginVsTemplateLow == Constants.Error)
                {
                    debugMarginVsTemplate = debugMarginVsTemplate + "Gj.snittmargin mindre enn templatet. ";
                    result_comment = result_comment + "Gj.snittmargin mindre enn templatet. ";
                }
                if (checkMarginVsTemplateLow == Constants.Warning)
                {
                    debugMarginVsTemplate = debugMarginVsTemplate + "Gj.snittmargin litt mindre enn templatet. ";
                    result_comment = result_comment + "Gj.snittmargin litt mindre enn templatet. ";
                }
            }
            //tempdebug = tempdebug + debugMarginVsTemplate + Environment.NewLine + " status: high: " + checkMarginVsTemplateHigh + Environment.NewLine + " status: low: " + checkMarginVsTemplateLow;
            //MessageBox.Show(tempdebug);

            //Final Status for mean margins
            if (meanToleranceExistLow == true && meanToleranceExistHigh == true)
            {
                if (marginResult.OnlyPrintTolerance == Constants.True)
                {
                    if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error) //Dont override other warnings and errors
                    {
                        marginResult.Status = Constants.Info;
                    }
                }
                else
                {
                    if (checkMarginVsTemplateLow == Constants.Error || checkMarginVsTemplateHigh == Constants.Error)
                    {
                        marginResult.Status = Constants.Error;
                    }
                    if ((checkMarginVsTemplateLow == Constants.Warning || checkMarginVsTemplateHigh == Constants.Warning) && (marginResult.Status != Constants.Error))
                    {
                        marginResult.Status = Constants.Warning;
                    }
                    if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error && marginResult.Status != Constants.Info && ((meanToleranceExistHigh) && (meanToleranceExistLow)))
                    {
                        marginResult.Status = Constants.Ok;
                    }//marginResult.Status = Constants.Info;
                    if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error && ((!meanToleranceExistHigh) && (!meanToleranceExistLow)))
                    {
                        marginResult.Status = Constants.Info;
                    }
                }

            }


            //Result:
            marginResult.Debug = marginResult.Debug + debugMarginVsTemplate;
            if (marginResult.Comment != "" && marginResult.Comment != null && result_comment != "")
            {
                marginResult.Comment = marginResult.Comment + Environment.NewLine;
            }
            marginResult.Comment = marginResult.Comment + result_comment;

            return marginResult;
        }


        //marginResult.X_Pluss_Margin_tolerance, X_Minus_Margin_HighError, marginResult.X_Pluss_Margin_HighWarning, marginResult.X_Pluss_Margin_LowError, marginResult.X_Pluss_Margin_LowWarning
        public static Margins UpdateDirectionalMarginStatus(Margins marginResult, double directionalMeanMargin, bool meanToleranceExistDirectional, bool meanToleranceExistDirectionalUpperAndLower, double directionalTolerance, double toleranceHighError, double toleranceHighWarning, double toleranceLowError, double toleranceLowWarning, string marginDirection, CheckPoint s)
        {

            // IMPLEMENT meanToleranceExistDirectionalUpperAndLower !!!!

            if (meanToleranceExistDirectional == true)
            { //Create warning and error tolerances, high and low (not done here anymore but is done upon loading of template!):


                //------------------------------------------------
                //Default if no tolerances. Prevent crash
                //double toleranceLowWarning = -1;
                //double toleranceHighWarning = -1;
                //double toleranceLowError = -1;
                //double toleranceHighError = -1;
                //double toleranceWarning = 1;
                //double toleranceError = 1;

                //set standard tolerances based on Constants
                //if (directionalTolerance != -1)
                //{
                //    toleranceWarning = directionalTolerance * Constants.TolerancesMarginsPercentageWarning;
                //    toleranceError = directionalTolerance * Constants.TolerancesMarginsPercentageWarning;
                //    if (directionalMeanMargin > Constants.TolerancesMarginsMinimumError*2) // Only add minimum margin if margin is higher than 2 time minimum margin tolerance
                //    {
                //        if (toleranceWarning < Constants.TolerancesMarginsMinimumWarning)
                //        {
                //            toleranceWarning = Constants.TolerancesMarginsMinimumWarning;
                //        }

                //        if (toleranceError < Constants.TolerancesMarginsMinimumError)
                //        {
                //            toleranceError = Constants.TolerancesMarginsMinimumError;
                //        }
                //    }
                //    //TolerancesMarginsMinimum
                //    toleranceLowWarning = directionalTolerance - toleranceWarning;
                //    if (toleranceLowWarning < 0) { toleranceLowWarning = 0; }
                //    toleranceHighWarning = directionalTolerance + toleranceWarning;
                //    toleranceLowError = directionalTolerance - toleranceError;
                //    if (toleranceLowError < 0) { toleranceLowError = 0; }
                //    toleranceHighError = directionalTolerance + toleranceError;
                //}
                //------------------------------------------------

                //debug and comment
                string tempdebug = "";
                string result_comment = "";
                string debugMarginVsTemplate = "";

                tempdebug = "-- Margins " + marginDirection + " --" + Environment.NewLine + "meanToleranceExistDirectional: " + meanToleranceExistDirectional;

                //Check margins High
                string checkMarginVsTemplateHigh = Constants.Ok; //set temporary status.
                if (toleranceHighError != -1 || toleranceHighWarning != -1)
                {
                    ///Check High Error
                    if (toleranceHighError != -1)//If tolerance exists
                    {
                        checkMarginVsTemplateHigh = CheckPointExtension.CheckResultVsTemplate(directionalMeanMargin.ToString(), toleranceHighError.ToString(), Constants.Error, "numerisk", s, "<="); //equal is ok
                    }

                    ///Check High Warning
                    if (checkMarginVsTemplateHigh != Constants.Error)
                    {
                        if (toleranceLowError != -1)//If tolerance exists
                        {
                            checkMarginVsTemplateHigh = CheckPointExtension.CheckResultVsTemplate(directionalMeanMargin.ToString(), toleranceHighWarning.ToString(), Constants.Warning, "numerisk", s, "<="); //= is ok
                        }

                    }

                    //Set result
                    if (checkMarginVsTemplateHigh == Constants.Error)
                    {
                        marginResult.WarningMarginsHigh = GeneralExtension.AddStringWithSeparatorIfNotEmpty(marginResult.WarningMarginsHigh, marginDirection);
                        debugMarginVsTemplate = debugMarginVsTemplate + marginDirection + " margins larger than template. ";
                        //result_comment = result_comment + marginDirection + " margins larger than template. ";
                    }

                    if (checkMarginVsTemplateHigh == Constants.Warning)
                    {
                        marginResult.WarningMarginsHigh = GeneralExtension.AddStringWithSeparatorIfNotEmpty(marginResult.WarningMarginsHigh, marginDirection);
                        debugMarginVsTemplate = debugMarginVsTemplate + marginDirection + " margins slightly larger than template. ";
                        //result_comment = result_comment + marginDirection + " margins slightly larger than template. ";
                    }

                }
                else
                {
                    marginResult.WarningMarginsHigh = Constants.Ok;
                }


                //Check margins Low
                string checkMarginVsTemplateLow = Constants.Ok;
                if (toleranceLowError != -1 || toleranceLowWarning != -1)
                {
                    ///Check Low Error
                    if (toleranceLowError != -1)//If tolerance exists
                    {
                        checkMarginVsTemplateLow = CheckPointExtension.CheckResultVsTemplate(directionalMeanMargin.ToString(), toleranceLowError.ToString(), Constants.Error, "numerisk", s, ">="); //= is ok
                    }

                    ///Check Low Warning
                    if (checkMarginVsTemplateLow != Constants.Error)
                    {
                        if (toleranceLowWarning != -1) //If tolerance exists
                        {
                            checkMarginVsTemplateLow = CheckPointExtension.CheckResultVsTemplate(directionalMeanMargin.ToString(), toleranceLowWarning.ToString(), Constants.Warning, "numerisk", s, ">="); //= is ok
                        }

                    }

                    //Set result
                    if (checkMarginVsTemplateLow == Constants.Error)
                    {
                        marginResult.WarningMarginsLow = GeneralExtension.AddStringWithSeparatorIfNotEmpty(marginResult.WarningMarginsLow, marginDirection);
                        debugMarginVsTemplate = debugMarginVsTemplate + marginDirection + " margins smaller than template. ";
                        //result_comment = result_comment + marginDirection + " margins smaller than template. ";
                    }
                    if (checkMarginVsTemplateLow == Constants.Warning)
                    {
                        marginResult.WarningMarginsLow = GeneralExtension.AddStringWithSeparatorIfNotEmpty(marginResult.WarningMarginsLow, marginDirection);
                        debugMarginVsTemplate = debugMarginVsTemplate + marginDirection + " margins slightly smaller than template. ";
                        //result_comment = result_comment + marginDirection + " margins slightly smaller than template. ";
                    }

                }
                else
                {
                    marginResult.WarningMarginsLow = Constants.Ok;
                }


                //tempdebug = tempdebug + debugMarginVsTemplate + Environment.NewLine + " status: high: " + checkMarginVsTemplateHigh + Environment.NewLine + " status: low: " + checkMarginVsTemplateLow;
                //MessageBox.Show(tempdebug);


                //Final Status
                if (marginResult.OnlyPrintTolerance == Constants.True)
                {
                    //Only print tolerances
                    if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error) //Dont override other warnings and errors found
                    {
                        marginResult.Status = Constants.Info;
                    }
                }
                else //Check status
                {
                    if (checkMarginVsTemplateLow == Constants.Error || checkMarginVsTemplateHigh == Constants.Error)
                    {
                        marginResult.Status = Constants.Error;
                    }
                    if ((checkMarginVsTemplateLow == Constants.Warning || checkMarginVsTemplateHigh == Constants.Warning) && (marginResult.Status != Constants.Error))
                    {
                        marginResult.Status = Constants.Warning;
                    }
                    if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error && marginResult.Status != Constants.Info && (meanToleranceExistDirectional))
                    {
                        marginResult.Status = Constants.Ok;
                    }//marginResult.Status = Constants.Info;
                    if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error && (!meanToleranceExistDirectional))
                    {
                        marginResult.Status = Constants.Info;
                    }
                }




                //Result:
                marginResult.Debug = marginResult.Debug + debugMarginVsTemplate;
                if (marginResult.Comment != "" && marginResult.Comment != null && result_comment != "")
                {
                    marginResult.Comment = marginResult.Comment + Environment.NewLine;
                }
                marginResult.Comment = marginResult.Comment + result_comment;
            }


            return marginResult;
        }


        //Also handle Traffic light!! Either send it to this function or handle it outside. Should it be warning or Error. Could pass the whole checkpoint!
        public static Margins GenerateMarginWarning(List<MarginList> listOfMarginLists, Margins marginResult, CheckPoint s, StructureSet structureSet, string bodyID, PatientContext patientContext)
        {

            string result_output = "";
            string result_comment = "";
            //string tempdebug = "";
            //Set structures
            Structure smallStructure = structureSet.Structures.FirstOrDefault(x => x.Id == marginResult.SmallStructureID); //Will cause error if not smallstructureID or no structure match.
            Structure largeStructure = structureSet.Structures.FirstOrDefault(x => x.Id == marginResult.LargeStructureID);
            string smallStructureID = smallStructure.Id;
            string largeStructureID = largeStructure.Id;


            ////-------------------------
            ////Find negative margin - basic check //This check is too primitive and is no longer in use.
            ////-------------------------
            //marginResult = BasicCheckNegativeMargin(marginResult, smallStructureID, largeStructureID);

            //--------------------------------

            //--------------------------------
            //Run more advanced check:
            // -------------------------------
            Structure body;
            body = structureSet.Structures.Where(x => x.Id == bodyID).FirstOrDefault();
            marginResult = CheckIfStructureIsOutsideStructureWhereNotCroppedToBody(marginResult, smallStructure, largeStructure, body, structureSet, patientContext, s); //Want to return debug information also.

            if (marginResult.IsSmallStructureWithinLargeStructure == Constants.False) // if (marginList.ListOfMargins.ElementAt(iterator).IsSmallStructureWithinLargeStructure == Constants.Warning)
            {
                //result_output = result_output + "*" + smallStructureID + " utenfor " + largeStructureID + Environment.NewLine;
                marginResult.Debug = marginResult.Debug + "*" + smallStructureID + " utenfor " + largeStructureID + " (nøyaktig sjekk punkt for punkt)" + Environment.NewLine;
            }
            //-------------------------------

            //Warnings
            bool meanToleranceExist = (marginResult.ExpectedMeanMargin != -1);
            string tolerance_percentage_comment = "";

            if ((marginResult.IsSmallStructureWithinLargeStructure == Constants.False) || (marginResult.AreStructureOriginsClose == Constants.False) || (marginResult.BasicCheckNegativMarginDetected == Constants.Warning))
            {
                //negativMargin
                if (marginResult.AdvancedCheckNegativMarginDetected == Constants.Warning && marginResult.IsSmallStructureWithinLargeStructure == Constants.True)
                {
                    result_comment = result_comment + "*Negativ margin, men ok siden det kun er i cropping mot body (" + marginResult.SmallStructureStartWith + " < " + Constants.ExceptionDistanceCTVToBodyInStructureInsideStructureCheckMm + "mm fra body). Antall målepunkter hvor " + marginResult.SmallStructureStartWith + " er utenfor " + marginResult.LargeStructureStartWith + " nær Body: " + marginResult.NumberOfPointsWhereStructureOutsideStructureButCloseToBody + "/" + marginResult.NumberOfPointsTotal + ")";
                    //marginResult.Status = Constants.Info;
                }
                //Todo: -> Change status from warning back to Ok or OBS in this case, unless there are other reasons there should be a warning.
                else if (marginResult.IsSmallStructureWithinLargeStructure == Constants.False)
                {
                    //set actual tolerance
                    double actualTolerancePercentagePointsOutsideLargeStructure = Constants.TolerancePercentagePointsOutsideLargeStructure;
                    if (meanToleranceExist)
                    {
                        try
                        {
                            //increase tolerance if zero margin expected.
                            if (marginResult.ExpectedMeanMargin < Constants.CloseToZeroMargin)
                            {
                                actualTolerancePercentagePointsOutsideLargeStructure = Constants.TolerancePercentagePointsOutsideLargeStructureIfZeroMarginExpected; //0.5
                                //result_comment = result_comment + " (tol: " + actualTolerancePercentagePointsOutsideLargeStructure * 100 + "% når forventet margin er " + marginResult.ExpectedMeanMargin + "mm)";
                                tolerance_percentage_comment = tolerance_percentage_comment + " (tol: " + actualTolerancePercentagePointsOutsideLargeStructure * 100 + "%, når forventet margin er " + marginResult.ExpectedMeanMargin + "mm)";
                            }
                            else
                            {
                                tolerance_percentage_comment = tolerance_percentage_comment + " (tol: " + actualTolerancePercentagePointsOutsideLargeStructure * 100 + "%)";
                            }
                        }
                        catch { }
                    }



                    //print info, men warning settes kun om utenfor toleranser
                    result_comment = result_comment + "*" + marginResult.PercentagePointsWhereStructureOutsideStructureAndNoExcuses * 100 + "% målepunkter (" + marginResult.NumberOfPointsWhereStructureOutsideStructureAndNoExcuses + "/" + marginResult.NumberOfPointsTotal + ") av " + marginResult.SmallStructureStartWith + " er utenfor " + marginResult.LargeStructureStartWith ;
                    result_comment = result_comment + tolerance_percentage_comment;
                    //If small structur outside large structure by a certain amount, add comment:
                    if (marginResult.AverageDistanceOutsideLargeStructure > Constants.ToleranceAverageDistanceOutsideLargeStructure)
                    {
                        result_comment = result_comment + Environment.NewLine;
                        result_comment = result_comment + "Gj.snitt avstand utenfor: " + marginResult.AverageDistanceOutsideLargeStructure + "mm, se feks: " + marginResult.ExceptionMaxDistanceSmallStructureToLargeStructureWhereSmallStructureOutsideDicomCoordinates + " (tol: " + Constants.ToleranceAverageDistanceOutsideLargeStructure + "mm)";
                    }

                 

                    //Change status
                    if (marginResult.PercentagePointsWhereStructureOutsideStructureAndNoExcuses > actualTolerancePercentagePointsOutsideLargeStructure || marginResult.AverageDistanceOutsideLargeStructure > Constants.ToleranceAverageDistanceOutsideLargeStructure)
                    {
                        //marginResult.PercentageBadResolutionPoints
                        marginResult.Status = Constants.Warning;
                    }
                    else
                    {
                        //marginResult.Status = Constants.Warning;
                    }
                }
                //{ result_output = result_output + Environment.NewLine + "*CTV utenfor PTV! "; }
                if (marginResult.AdvancedCheckNegativMarginDetected == Constants.Warning && marginResult.IsSmallStructureWithinLargeStructure == Constants.False)
                {
                    result_comment = result_comment + Environment.NewLine + "*Negativ margin!";
                }
                if (marginResult.AreStructureOriginsClose == Constants.False)
                {
                    result_output = result_output + "*Struktursenter " + marginResult.SmallStructureStartWith + " og " + marginResult.LargeStructureStartWith + " > " + Constants.ToleranceTargetStructureMatchOriginDistanceCm + "fra hverandre! ";
                    result_comment = result_comment + Environment.NewLine;
                    marginResult.Status = Constants.Warning;
                }



            }
            else
            {
                //marginResult.Status = Constants.Ok;
            }

            //set booleans (now only check if at least one such tolerance exists, earlier it demanded all to exist)
            bool meanToleranceExistHigh = (marginResult.MeanMarginHighError != -1 || marginResult.MeanMarginHighWarning != -1);
            bool meanToleranceExistLow = (marginResult.MeanMarginLowError != -1 || marginResult.MeanMarginLowWarning != -1);
            //bool meanToleranceExist = (marginResult.ExpectedMeanMargin != -1);
            bool meanToleranceExistDirectional = (marginResult.X_Minus_Margin_tolerance != -1 && marginResult.X_Pluss_Margin_tolerance != -1 && marginResult.Y_Minus_Margin_tolerance != -1 && marginResult.Y_Pluss_Margin_tolerance != -1 && marginResult.Z_Minus_Margin_tolerance != -1 && marginResult.Z_Pluss_Margin_tolerance != -1);
            bool meanToleranceExistDirectionalUpperAndLower =
                (marginResult.X_Minus_Margin_HighError != -1 || marginResult.X_Minus_Margin_HighWarning != -1 || marginResult.X_Minus_Margin_LowError != -1 || marginResult.X_Minus_Margin_LowWarning != -1
                || marginResult.X_Pluss_Margin_HighError != -1 || marginResult.X_Pluss_Margin_HighWarning != -1 || marginResult.X_Pluss_Margin_LowError != -1 || marginResult.X_Pluss_Margin_LowWarning != -1
                || marginResult.Y_Minus_Margin_HighError != -1 || marginResult.Y_Minus_Margin_HighWarning != -1 | marginResult.Y_Minus_Margin_LowError != -1 || marginResult.Y_Minus_Margin_LowWarning != -1
                || marginResult.Y_Pluss_Margin_HighError != -1 || marginResult.Y_Pluss_Margin_HighWarning != -1 || marginResult.Y_Pluss_Margin_LowError != -1 || marginResult.Y_Pluss_Margin_LowWarning != -1
                || marginResult.Z_Minus_Margin_HighError != -1 || marginResult.Z_Minus_Margin_HighWarning != -1 || marginResult.Z_Minus_Margin_LowError != -1 || marginResult.Z_Minus_Margin_LowWarning != -1
                || marginResult.Z_Pluss_Margin_HighError != -1 || marginResult.Z_Pluss_Margin_HighWarning != -1 || marginResult.Z_Pluss_Margin_LowError != -1 || marginResult.Z_Pluss_Margin_LowWarning != -1); //If any exist
                                                                                                                                                                                                                //        bool meanToleranceExistDirectionalUpperAndLower =
                                                                                                                                                                                                                //(marginResult.X_Minus_Margin_HighError != -1 && marginResult.X_Minus_Margin_HighWarning != -1 && marginResult.X_Minus_Margin_LowError != -1 && marginResult.X_Minus_Margin_LowWarning != -1
                                                                                                                                                                                                                //&& marginResult.X_Pluss_Margin_HighError != -1 && marginResult.X_Pluss_Margin_HighWarning != -1 && marginResult.X_Pluss_Margin_LowError != -1 && marginResult.X_Pluss_Margin_LowWarning != -1
                                                                                                                                                                                                                //&& marginResult.Y_Minus_Margin_HighError != -1 && marginResult.Y_Minus_Margin_HighWarning != -1 && marginResult.Y_Minus_Margin_LowError != -1 && marginResult.Y_Minus_Margin_LowWarning != -1
                                                                                                                                                                                                                //&& marginResult.Y_Pluss_Margin_HighError != -1 && marginResult.Y_Pluss_Margin_HighWarning != -1 && marginResult.Y_Pluss_Margin_LowError != -1 && marginResult.Y_Pluss_Margin_LowWarning != -1
                                                                                                                                                                                                                //&& marginResult.Z_Minus_Margin_HighError != -1 && marginResult.Z_Minus_Margin_HighWarning != -1 && marginResult.Z_Minus_Margin_LowError != -1 && marginResult.Z_Minus_Margin_LowWarning != -1
                                                                                                                                                                                                                //&& marginResult.Z_Pluss_Margin_HighError != -1 && marginResult.Z_Pluss_Margin_HighWarning != -1 && marginResult.Z_Pluss_Margin_LowError != -1 && marginResult.Z_Pluss_Margin_LowWarning != -1); //If all exist


            //Dont updates statuses if Template says "PrintOnly"!! Must be implemented! Must also check against patient orientetion.

            //Update statuses all directions (if OnlyPrintTolerances is True, then the status "Info" will be used instead of Warnings and Errors:
            marginResult = UpdateMeanMarginStatus(marginResult, meanToleranceExistHigh, meanToleranceExistLow, "Mean margin", s);

            marginResult = UpdateDirectionalMarginStatus(marginResult, marginResult.X_Pluss_Mean_Margin, meanToleranceExistDirectional, meanToleranceExistDirectionalUpperAndLower,
                marginResult.X_Pluss_Margin_tolerance, marginResult.X_Pluss_Margin_HighError, marginResult.X_Pluss_Margin_HighWarning, marginResult.X_Pluss_Margin_LowError, marginResult.X_Pluss_Margin_LowWarning, " X pluss ", s);
            marginResult = UpdateDirectionalMarginStatus(marginResult, marginResult.X_Minus_Mean_Margin, meanToleranceExistDirectional, meanToleranceExistDirectionalUpperAndLower,
                marginResult.X_Minus_Margin_tolerance, marginResult.X_Minus_Margin_HighError, marginResult.X_Minus_Margin_HighWarning, marginResult.X_Minus_Margin_LowError, marginResult.X_Minus_Margin_LowWarning, " X minus ", s);
            marginResult = UpdateDirectionalMarginStatus(marginResult, marginResult.Y_Pluss_Mean_Margin, meanToleranceExistDirectional, meanToleranceExistDirectionalUpperAndLower,
                marginResult.Y_Pluss_Margin_tolerance, marginResult.Y_Pluss_Margin_HighError, marginResult.Y_Pluss_Margin_HighWarning, marginResult.Y_Pluss_Margin_LowError, marginResult.Y_Pluss_Margin_LowWarning, " Y pluss ", s);
            marginResult = UpdateDirectionalMarginStatus(marginResult, marginResult.Y_Minus_Mean_Margin, meanToleranceExistDirectional, meanToleranceExistDirectionalUpperAndLower,
                marginResult.Y_Minus_Margin_tolerance, marginResult.Y_Minus_Margin_HighError, marginResult.Y_Minus_Margin_HighWarning, marginResult.Y_Minus_Margin_LowError, marginResult.Y_Minus_Margin_LowWarning, " Y minus ", s);
            marginResult = UpdateDirectionalMarginStatus(marginResult, marginResult.Z_Pluss_Mean_Margin, meanToleranceExistDirectional, meanToleranceExistDirectionalUpperAndLower,
                marginResult.Z_Pluss_Margin_tolerance, marginResult.Z_Pluss_Margin_HighError, marginResult.Z_Pluss_Margin_HighWarning, marginResult.Z_Pluss_Margin_LowError, marginResult.Z_Pluss_Margin_LowWarning, " Z pluss ", s);
            marginResult = UpdateDirectionalMarginStatus(marginResult, marginResult.Z_Minus_Mean_Margin, meanToleranceExistDirectional, meanToleranceExistDirectionalUpperAndLower,
                marginResult.Z_Minus_Margin_tolerance, marginResult.Z_Minus_Margin_HighError, marginResult.Z_Minus_Margin_HighWarning, marginResult.Z_Minus_Margin_LowError, marginResult.Z_Minus_Margin_LowWarning, " Z minus ", s);

            //Add comment about directional margins:
            if (marginResult.WarningMarginsHigh != "")
            {
                string marginCommentHigh = "Margins larger than template: " + marginResult.WarningMarginsHigh;
                marginResult.Comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(marginResult.Comment, marginCommentHigh);
            }
            if (marginResult.WarningMarginsLow != "")
            {
                string marginCommentLow = "Margins smaller than template: " + marginResult.WarningMarginsLow;
                marginResult.Comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(marginResult.Comment, marginCommentLow);
            }

            //Set main status:
            if (meanToleranceExistHigh == false && meanToleranceExistLow == false && meanToleranceExist == false && meanToleranceExistDirectional == false)
            {
                //Set status to Info if no warning or errors, and also no tolerances
                if (marginResult.Status != Constants.Warning && marginResult.Status != Constants.Error)
                {
                    marginResult.Status = Constants.Info;
                }

            }


            //info
            if (marginResult.ExistCroppingAgainstBody == Constants.True) //&& marginResult.NumberOfPointsWhereStructureOutsideStructureButCloseToBody > 0
            {
                if (result_comment != "") { result_comment = result_comment + Environment.NewLine; }
                result_comment = result_comment + "*Cropping mot Body."; //+ Environment.NewLine;
                if (marginResult.NumberOfPointsWhereStructureOutsideStructureButCloseToBody > 0)
                {
                    double CTVOutsidePTVPercent = Math.Round(marginResult.NumberOfPointsWhereStructureOutsideStructureButCloseToBody / marginResult.NumberOfPointsTotal * 100, 0);
                    string smallStruct = marginResult.SmallStructureStartWith;
                    string largeStruct = marginResult.LargeStructureStartWith;
                    result_comment = result_comment + " Antall punkter "  + smallStruct + " utenfor " + largeStruct + ":" + CTVOutsidePTVPercent + "% (" + marginResult.NumberOfPointsWhereStructureOutsideStructureButCloseToBody + " / " + marginResult.NumberOfPointsTotal + ")";
                }
            }

            //if (tolerances does not exist)
            //{
            //    marginResult.Status = Constants.Info;
            //}

            //Headers margins          
            result_output = result_output + GeneralExtension.FormatString(-15, -9,
                "Retning:" + Constants.StringSeparator
                //+ "RawValue" + Constants.StringSeparator 
                + "Alle" + Constants.StringSeparator
                + "x-" + Constants.StringSeparator
                + "x+" + Constants.StringSeparator
                + "y-" + Constants.StringSeparator
                + "y+" + Constants.StringSeparator
                + "z-" + Constants.StringSeparator
                + "z+") + Environment.NewLine;
            //Marginer output
            result_output = result_output + GeneralExtension.FormatString(-15, -9,
                "Sn. margin:" + Constants.StringSeparator
                //+ marginResult.MeanMargin + Constants.StringSeparator 
                + marginResult.MeanMarginNotCroppedToBody.ToString() + Constants.StringSeparator
                + marginResult.X_Minus_Mean_Margin.ToString() + Constants.StringSeparator
                + marginResult.X_Pluss_Mean_Margin.ToString() + Constants.StringSeparator
                + marginResult.Y_Minus_Mean_Margin.ToString() + Constants.StringSeparator
                + marginResult.Y_Pluss_Mean_Margin.ToString() + Constants.StringSeparator
                + marginResult.Z_Minus_Mean_Margin.ToString() + Constants.StringSeparator
                + marginResult.Z_Pluss_Mean_Margin.ToString()) + Environment.NewLine;



            //Marginer output basic


            //--------------------------
            //Prepare to print tolerances:
            // --------------------------
            string mean_tolerance = "-";
            string mean_tolerance_Warning = "-";
            string mean_tolerance_Error = "-";

            string X_Minus_tolerance = "-";
            string X_Minus_Warning_tolerance = "";
            string X_Minus_Error_tolerance = "";
            string Y_Minus_tolerance = "-";
            string Y_Minus_Warning_tolerance = "";
            string Y_Minus_Error_tolerance = "";
            string Z_Minus_tolerance = "-";
            string Z_Minus_Warning_tolerance = "";
            string Z_Minus_Error_tolerance = "";
            string X_Pluss_tolerance = "-";
            string X_Pluss_Warning_tolerance = "";
            string X_Pluss_Error_tolerance = "";
            string Y_Pluss_tolerance = "-";
            string Y_Pluss_Warning_tolerance = "";
            string Y_Pluss_Error_tolerance = "";
            string Z_Pluss_tolerance = "-";
            string Z_Pluss_Warning_tolerance = "";
            string Z_Pluss_Error_tolerance = "";

            if (marginResult.ExpectedMeanMargin != -1)
            { mean_tolerance = marginResult.ExpectedMeanMargin.ToString(); }

            if (meanToleranceExistHigh && meanToleranceExistLow)
            {
                mean_tolerance_Warning = marginResult.MeanMarginLowWarning + "-" + marginResult.MeanMarginHighWarning;
                mean_tolerance_Error = marginResult.MeanMarginLowError + "-" + marginResult.MeanMarginHighError;
            }

            if (marginResult.X_Minus_Margin_tolerance != -1)
            { X_Minus_tolerance = marginResult.X_Minus_Margin_tolerance.ToString(); }
            if (marginResult.X_Minus_Margin_LowWarning != -1 && marginResult.X_Minus_Margin_HighWarning != -1)
            { X_Minus_Warning_tolerance = marginResult.X_Minus_Margin_LowWarning.ToString() + "-" + marginResult.X_Minus_Margin_HighWarning.ToString(); }
            if (marginResult.X_Minus_Margin_LowError != -1 && marginResult.X_Minus_Margin_HighError != -1)
            { X_Minus_Error_tolerance = marginResult.X_Minus_Margin_LowError.ToString() + "-" + marginResult.X_Minus_Margin_HighError.ToString(); }

            if (marginResult.X_Pluss_Margin_tolerance != -1)
            { X_Pluss_tolerance = marginResult.X_Pluss_Margin_tolerance.ToString(); }
            if (marginResult.X_Pluss_Margin_LowWarning != -1 && marginResult.X_Pluss_Margin_HighWarning != -1)
            { X_Pluss_Warning_tolerance = marginResult.X_Pluss_Margin_LowWarning.ToString() + "-" + marginResult.X_Pluss_Margin_HighWarning.ToString(); }
            if (marginResult.X_Pluss_Margin_LowError != -1 && marginResult.X_Pluss_Margin_HighError != -1)
            { X_Pluss_Error_tolerance = marginResult.X_Pluss_Margin_LowError.ToString() + "-" + marginResult.X_Pluss_Margin_HighError.ToString(); }

            if (marginResult.Y_Minus_Margin_tolerance != -1)
            { Y_Minus_tolerance = marginResult.Y_Minus_Margin_tolerance.ToString(); }
            if (marginResult.Y_Minus_Margin_LowWarning != -1 && marginResult.Y_Minus_Margin_HighWarning != -1)
            { Y_Minus_Warning_tolerance = marginResult.Y_Minus_Margin_LowWarning.ToString() + "-" + marginResult.Y_Minus_Margin_HighWarning.ToString(); }
            if (marginResult.Y_Minus_Margin_LowError != -1 && marginResult.Y_Minus_Margin_HighError != -1)
            { Y_Minus_Error_tolerance = marginResult.Y_Minus_Margin_LowError.ToString() + "-" + marginResult.Y_Minus_Margin_HighError.ToString(); }

            if (marginResult.Y_Pluss_Margin_tolerance != -1)
            { Y_Pluss_tolerance = marginResult.Y_Pluss_Margin_tolerance.ToString(); }
            if (marginResult.Y_Pluss_Margin_LowWarning != -1 && marginResult.Y_Pluss_Margin_HighWarning != -1)
            { Y_Pluss_Warning_tolerance = marginResult.Y_Pluss_Margin_LowWarning.ToString() + "-" + marginResult.Y_Pluss_Margin_HighWarning.ToString(); }
            if (marginResult.Y_Pluss_Margin_LowError != -1 && marginResult.Y_Pluss_Margin_HighError != -1)
            { Y_Pluss_Error_tolerance = marginResult.Y_Pluss_Margin_LowError.ToString() + "-" + marginResult.Y_Pluss_Margin_HighError.ToString(); }

            if (marginResult.Z_Minus_Margin_tolerance != -1)
            { Z_Minus_tolerance = marginResult.Z_Minus_Margin_tolerance.ToString(); }
            if (marginResult.Z_Minus_Margin_LowWarning != -1 && marginResult.Z_Minus_Margin_HighWarning != -1)
            { Z_Minus_Warning_tolerance = marginResult.Z_Minus_Margin_LowWarning.ToString() + "-" + marginResult.Z_Minus_Margin_HighWarning.ToString(); }
            if (marginResult.Z_Minus_Margin_LowError != -1 && marginResult.Z_Minus_Margin_HighError != -1)
            { Z_Minus_Error_tolerance = marginResult.Z_Minus_Margin_LowError.ToString() + "-" + marginResult.Z_Minus_Margin_HighError.ToString(); }

            if (marginResult.Z_Pluss_Margin_tolerance != -1)
            { Z_Pluss_tolerance = marginResult.Z_Pluss_Margin_tolerance.ToString(); }
            if (marginResult.Z_Pluss_Margin_LowWarning != -1 && marginResult.Z_Pluss_Margin_HighWarning != -1)
            { Z_Pluss_Warning_tolerance = marginResult.Z_Pluss_Margin_LowWarning.ToString() + "-" + marginResult.Z_Pluss_Margin_HighWarning.ToString(); }
            if (marginResult.Z_Pluss_Margin_LowError != -1 && marginResult.Z_Pluss_Margin_HighError != -1)
            { Z_Pluss_Error_tolerance = marginResult.Z_Pluss_Margin_LowError.ToString() + "-" + marginResult.Z_Pluss_Margin_HighError.ToString(); }


            //----------------
            //Print tolerances
            //----------------

            //Expected margin
            result_output = result_output + GeneralExtension.FormatString(-15, -9,
                "Forventet:" + Constants.StringSeparator
                //+ " - " + Constants.StringSeparator 
                + mean_tolerance + Constants.StringSeparator
                + X_Minus_tolerance + Constants.StringSeparator
                + X_Pluss_tolerance + Constants.StringSeparator
                + Y_Minus_tolerance + Constants.StringSeparator
                + Y_Pluss_tolerance + Constants.StringSeparator
                + Z_Minus_tolerance + Constants.StringSeparator
                + Z_Pluss_tolerance) + Environment.NewLine;

            //Marginer toleranse warning
            result_output = result_output + GeneralExtension.FormatString(-15, -9,
                "Toleranse Adv:" + Constants.StringSeparator
                //+ " - " + Constants.StringSeparator
                + mean_tolerance_Warning + " " + Constants.StringSeparator
                + X_Minus_Warning_tolerance + Constants.StringSeparator
                + X_Pluss_Warning_tolerance + Constants.StringSeparator
                + Y_Minus_Warning_tolerance + Constants.StringSeparator
                + Y_Pluss_Warning_tolerance + Constants.StringSeparator
                + Z_Minus_Warning_tolerance + Constants.StringSeparator
                + Z_Pluss_Warning_tolerance) + Environment.NewLine;

            //Marginer toleranse Error
            result_output = result_output + GeneralExtension.FormatString(-15, -9,
                "Toleranse Err:" + Constants.StringSeparator
                //+ " - " + Constants.StringSeparator
                + mean_tolerance_Error + Constants.StringSeparator
                + X_Minus_Error_tolerance + Constants.StringSeparator
                + X_Pluss_Error_tolerance + Constants.StringSeparator
                + Y_Minus_Error_tolerance + Constants.StringSeparator
                + Y_Pluss_Error_tolerance + Constants.StringSeparator
                + Z_Minus_Error_tolerance + Constants.StringSeparator
                + Z_Pluss_Error_tolerance); // + Environment.NewLine;

            //print tolerance margins - old    
            //result_output = result_output + "Tolerances:" + Environment.NewLine;
            //result_output = result_output + GeneralExtension.GenerateTableLine(3, 4, X_Minus_tolerance + Constants.StringSeparator + X_Pluss_tolerance + Constants.StringSeparator + Y_Minus_tolerance + Constants.StringSeparator + Y_Pluss_tolerance + Constants.StringSeparator + Z_Minus_tolerance + Constants.StringSeparator + Z_Pluss_tolerance + Constants.StringSeparator + mean_tolerance + Constants.StringSeparator + mean_tolerance); // + Environment.NewLine;

            marginResult.Output = result_output;
            if (marginResult.Comment != "" && marginResult.Comment != null && result_comment != "")
            {
                marginResult.Comment = marginResult.Comment + Environment.NewLine;
            }
            if (result_comment != "" && result_comment != null)
            {
                //marginResult.Comment = marginResult.Comment  +"Advarsler!" + Environment.NewLine;
                //marginResult.Comment = marginResult.Comment + Environment.NewLine;
            }
            marginResult.Comment = marginResult.Comment + result_comment;


            //tempdebug = tempdebug + debugMarginVsTemplate + Environment.NewLine + " status: high: " + checkMarginVsTemplateHigh + Environment.NewLine + " status: low: " + checkMarginVsTemplateLow;
            //MessageBox.Show(tempdebug);
            //MarginsExtension.PrintMarginTemplate(marginResult);


            return marginResult;
        }

        //Not in use yet:
        public static MarginList GenerateMarginsWarnings(MarginList marginList) // structureBody needed
        {

            ////-----------------------------------------------------
            ////Generate warnings
            ////-----------------------------------------------------
            //int numberOfMargins = marginList.ListOfMargins.Count;
            ////Iterate over margins
            //for (int iterator = 1; iterator < numberOfMargins; iterator++)
            //{
            //    //Worsk on a teporary variable marginResult
            //    Margins marginResult = marginList.ListOfMargins.ElementAt(iterator); //Get marginresult

            //    marginResult = GenerateMarginWarning(marginList, marginResult);

            //    iterator++;
            //    //------------------
            //    //Set final modified result:
            //    //-----------------
            //    marginList.ListOfMargins[iterator] = marginResult;
            //}

            return marginList;
        }

        //Improved CheckMargin, with code separated out in seperate methods. Can only run for one type of pairs at a time ("TypeOfMargin"). Run for "CTV-PTV" first. Then must be run seperately for ITV-PTV for instance.
        public static CheckPoint CheckMargins(CheckPoint s, List<MarginList> listOfMarginLists, StructureSet structureSet, string bodyID, PatientContext patientContext)
        {



            //Go through margins and generate warnings, if small structure is inside of large structure etc. Actually a very advanced check demanding much calculations 
            s.Margins = GenerateMarginWarning(listOfMarginLists, s.Margins, s, structureSet, bodyID, patientContext); //Needs body structure, is now embedded in marginList.



            //Marginer output CSV:
            string result_output_csv = "";
          
            result_output_csv  = result_output_csv +//+ Constants.StringSeparator
                //+ marginResult.MeanMargin + Constants.StringSeparator 
                s.Margins.MeanMarginNotCroppedToBody.ToString() + ":" +
                s.Margins.X_Minus_Mean_Margin.ToString() + ":" +
                s.Margins.X_Pluss_Mean_Margin.ToString() + ":" +
                s.Margins.Y_Minus_Mean_Margin.ToString() + ":" +
                s.Margins.Y_Pluss_Mean_Margin.ToString() + ":" +
                s.Margins.Z_Minus_Mean_Margin.ToString() + ":" +
                s.Margins.Z_Pluss_Mean_Margin.ToString();

            s.CheckResultValueCSV = result_output_csv;
            //MessageBox.Show(result_output_csv);
            //Transfer result from Margin to CheckPoint:

            //s.CheckDebug = s.CheckDebug + Environment.NewLine;   //Removed debug as it clutters up the ToolTip
            //s.CheckDebug = s.CheckDebug + "-----  Generate Warnings -----";
            //s.CheckDebug = s.CheckDebug + Environment.NewLine+ s.Margins.Debug;
            s.CheckStatus = s.Margins.Status;
            s.CheckResultValue = s.Margins.Output;
            s.CheckComment = s.Margins.Comment;

            return s;
        }


        public static void PrintMarginTemplate(Margins margins)
        {
            MessageBox.Show(PlanTemplateExtension.MarginsTemplateToString(margins));
        }

        public static MarginList UpdateMarginTolerances(MarginList marginList, List<Margins> marginsTemplates)
        {

            int iterator = 0;


            //Update marginResult with marginTemplate values
            foreach (Margins marginResult in marginList.ListOfMargins)
            {
                int subiterator = 0;
                //Go through the list of margins we have identified so far
                foreach (Margins marginTemplate in marginsTemplates)
                {
                    //Check them against all margins that exist in template with same templatename (for instance "Prostata")

                    //Validate input
                    string largeStructureIDTemplate = marginTemplate.LargeStructureID;
                    string smallStructureIDTemplate = marginTemplate.SmallStructureID;

                    string largeStructureIDResult = marginResult.LargeStructureID;
                    string smallStructureIDResult = marginResult.SmallStructureID;

                    if (!string.IsNullOrEmpty(largeStructureIDTemplate)) { largeStructureIDTemplate = largeStructureIDTemplate.ToLower(); } else { largeStructureIDTemplate = ""; }
                    if (!string.IsNullOrEmpty(smallStructureIDTemplate)) { smallStructureIDTemplate = smallStructureIDTemplate.ToLower(); } else { smallStructureIDTemplate = ""; }

                    if (!string.IsNullOrEmpty(largeStructureIDResult)) { largeStructureIDResult = largeStructureIDResult.ToLower(); } else { largeStructureIDResult = ""; }
                    if (!string.IsNullOrEmpty(smallStructureIDResult)) { smallStructureIDResult = smallStructureIDResult.ToLower(); } else { smallStructureIDResult = ""; }

                    bool match;
                    match = false;
                    //Attempt to find match in template on match of small and large structure
                    if(largeStructureIDTemplate !="" && largeStructureIDResult != "" && smallStructureIDTemplate != "" && smallStructureIDResult != "")
                    {
                        string stringToRemove = "_art";
                        string modifiedLargeStructureIDResult = largeStructureIDResult.ToLower().Replace(stringToRemove, "");
                        string modifiedSmallStructureIDResult = smallStructureIDResult.ToLower().Replace(stringToRemove, "");
                        match = ((marginTemplate.LargeStructureID.ToLower() == modifiedLargeStructureIDResult) && (marginTemplate.SmallStructureID.ToLower() == modifiedSmallStructureIDResult)); //match = ((marginTemplate.LargeStructureID.ToLower() == marginResult.LargeStructureID.ToLower()) && (marginTemplate.SmallStructureID.ToLower() == marginResult.SmallStructureID.ToLower()));
                        //||  Accept (loads template values) also mach on "_art"


                    }
                    //Earlier: Direct match on at least one name is enough for now. This way if say the samller structure a deviation in name, we still catch with the other larger one
                    //Now: want perfect match on both.

                    if (match)
                    {
                        //write margins
                        //if (marginsTemplates[subiterator].ExpectedMeanMargin != -1)
                        //{
                        marginList.ListOfMargins[iterator].ExpectedMeanMargin = marginsTemplates[subiterator].ExpectedMeanMargin;

                        //}
                        //if (marginsTemplates[subiterator].MeanNotCroppedMarginToleranceLowWarning != -1)
                        //{
                        marginList.ListOfMargins[iterator].MeanMarginLowWarning = marginsTemplates[subiterator].MeanMarginLowWarning;
                        //}
                        //if (marginsTemplates[subiterator].MeanNotCroppedMarginToleranceHighWarning != -1)
                        //{
                        marginList.ListOfMargins[iterator].MeanMarginHighWarning = marginsTemplates[subiterator].MeanMarginHighWarning;
                        //}
                        //if (marginsTemplates[subiterator].MeanNotCroppedMarginToleranceLowError != -1)
                        //{
                        marginList.ListOfMargins[iterator].MeanMarginLowError = marginsTemplates[subiterator].MeanMarginLowError;
                        //}
                        //if (marginsTemplates[subiterator].MeanNotCroppedMarginToleranceHighError != -1)
                        //{
                        marginList.ListOfMargins[iterator].MeanMarginHighError = marginsTemplates[subiterator].MeanMarginHighError;
                        //}
                        //if (marginsTemplates[subiterator].X_Pluss_Margin_tolerance != -1)
                        //{
                        marginList.ListOfMargins[iterator].X_Pluss_Margin_tolerance = marginsTemplates[subiterator].X_Pluss_Margin_tolerance;
                        marginList.ListOfMargins[iterator].X_Pluss_Margin_HighError = marginsTemplates[subiterator].X_Pluss_Margin_HighError;
                        marginList.ListOfMargins[iterator].X_Pluss_Margin_HighWarning = marginsTemplates[subiterator].X_Pluss_Margin_HighWarning;
                        marginList.ListOfMargins[iterator].X_Pluss_Margin_LowError = marginsTemplates[subiterator].X_Pluss_Margin_LowError;
                        marginList.ListOfMargins[iterator].X_Pluss_Margin_LowWarning = marginsTemplates[subiterator].X_Pluss_Margin_LowWarning;
                        //}
                        //if (marginsTemplates[subiterator].X_Minus_Margin_tolerance != -1)
                        //{
                        marginList.ListOfMargins[iterator].X_Minus_Margin_tolerance = marginsTemplates[subiterator].X_Minus_Margin_tolerance;
                        marginList.ListOfMargins[iterator].X_Minus_Margin_HighError = marginsTemplates[subiterator].X_Minus_Margin_HighError;
                        marginList.ListOfMargins[iterator].X_Minus_Margin_HighWarning = marginsTemplates[subiterator].X_Minus_Margin_HighWarning;
                        marginList.ListOfMargins[iterator].X_Minus_Margin_LowError = marginsTemplates[subiterator].X_Minus_Margin_LowError;
                        marginList.ListOfMargins[iterator].X_Minus_Margin_LowWarning = marginsTemplates[subiterator].X_Minus_Margin_LowWarning;
                        //}
                        //if (marginsTemplates[subiterator].Y_Pluss_Margin_tolerance != -1)
                        //{
                        marginList.ListOfMargins[iterator].Y_Pluss_Margin_tolerance = marginsTemplates[subiterator].Y_Pluss_Margin_tolerance;
                        marginList.ListOfMargins[iterator].Y_Pluss_Margin_HighError = marginsTemplates[subiterator].Y_Pluss_Margin_HighError;
                        marginList.ListOfMargins[iterator].Y_Pluss_Margin_HighWarning = marginsTemplates[subiterator].Y_Pluss_Margin_HighWarning;
                        marginList.ListOfMargins[iterator].Y_Pluss_Margin_LowError = marginsTemplates[subiterator].Y_Pluss_Margin_LowError;
                        marginList.ListOfMargins[iterator].Y_Pluss_Margin_LowWarning = marginsTemplates[subiterator].Y_Pluss_Margin_LowWarning;
                        //}
                        //if (marginsTemplates[subiterator].Y_Minus_Margin_tolerance != -1)
                        //{
                        marginList.ListOfMargins[iterator].Y_Minus_Margin_tolerance = marginsTemplates[subiterator].Y_Minus_Margin_tolerance;
                        marginList.ListOfMargins[iterator].Y_Minus_Margin_HighError = marginsTemplates[subiterator].Y_Minus_Margin_HighError;
                        marginList.ListOfMargins[iterator].Y_Minus_Margin_HighWarning = marginsTemplates[subiterator].Y_Minus_Margin_HighWarning;
                        marginList.ListOfMargins[iterator].Y_Minus_Margin_LowError = marginsTemplates[subiterator].Y_Minus_Margin_LowError;
                        marginList.ListOfMargins[iterator].Y_Minus_Margin_LowWarning = marginsTemplates[subiterator].Y_Minus_Margin_LowWarning;
                        //}
                        //if (marginsTemplates[subiterator].Z_Pluss_Margin_tolerance != -1)
                        //{
                        marginList.ListOfMargins[iterator].Z_Pluss_Margin_tolerance = marginsTemplates[subiterator].Z_Pluss_Margin_tolerance;
                        marginList.ListOfMargins[iterator].Z_Pluss_Margin_HighError = marginsTemplates[subiterator].Z_Pluss_Margin_HighError;
                        marginList.ListOfMargins[iterator].Z_Pluss_Margin_HighWarning = marginsTemplates[subiterator].Z_Pluss_Margin_HighWarning;
                        marginList.ListOfMargins[iterator].Z_Pluss_Margin_LowError = marginsTemplates[subiterator].Z_Pluss_Margin_LowError;
                        marginList.ListOfMargins[iterator].Z_Pluss_Margin_LowWarning = marginsTemplates[subiterator].Z_Pluss_Margin_LowWarning;
                        //}
                        //if (marginsTemplates[subiterator].Z_Minus_Margin_tolerance != -1)
                        //{
                        marginList.ListOfMargins[iterator].Z_Minus_Margin_tolerance = marginsTemplates[subiterator].Z_Minus_Margin_tolerance;
                        marginList.ListOfMargins[iterator].Z_Minus_Margin_HighError = marginsTemplates[subiterator].Z_Minus_Margin_HighError;
                        marginList.ListOfMargins[iterator].Z_Minus_Margin_HighWarning = marginsTemplates[subiterator].Z_Minus_Margin_HighWarning;
                        marginList.ListOfMargins[iterator].Z_Minus_Margin_LowError = marginsTemplates[subiterator].Z_Minus_Margin_LowError;
                        marginList.ListOfMargins[iterator].Z_Minus_Margin_LowWarning = marginsTemplates[subiterator].Z_Minus_Margin_LowWarning;
                        //}

                        marginList.ListOfMargins[iterator].ValidPatientOrientation = marginsTemplates[subiterator].ValidPatientOrientation;
                        marginList.ListOfMargins[iterator].OnlyPrintTolerance = marginsTemplates[subiterator].OnlyPrintTolerance;
                    }
                    subiterator++;
                }
                iterator++;
            }
            //MessageBox.Show("UpdateMarginTOlerance");
            //foreach (Margins margin in marginList.ListOfMargins)
            //{
            //    PrintMarginTemplate(margin);
            //}

            return marginList;
        }

        //This method has been rewritten to be more abstract, maybe it could be made into a method for all loading of templates from csv-file, not just margins? Must add class object as input paramter then.
        public static List<Margins> LoadMarginsTemplates(string filePathTemplates, string EclipsePlanTemplateName)
        {
            //patientContext not required yet here, but could be used to skip loading uneccesary parts of templates?

            //Create empty list
            List<Margins> marginsTemplatesList = new List<Margins>(); // list of margins

            //Get all properties from class
            PropertyInfo[] properties = typeof(Margins).GetProperties();


            string line = "";
            int linesCount = 0;
            int columnsCount = 0;
            int lastcolumnsCount = 0;
            double outputIfFail = -1; //If there is nothing written, write -1, as a number is required. 

            IEnumerable<string> lines = File.ReadLines(filePathTemplates);
            linesCount = lines.Count();

            //Split headers into array:
            string[] headersArray = lines.ElementAt(0).Split(';');

            //Iterate over lines. Start from 1 to skip the headers.
            for (int i = 1; i < lines.Count(); i++)
            {
                line = lines.ElementAt(i); //One line is a template
                //MessageBox.Show(line);



                //Split templates into array:
                string[] lineArray = line.Split(';');  // List<char> lineList = line.ToList();

                //Any validation we need to add here??
                //MessageBox.Show(line);
                columnsCount = lineArray.Length;

                //Validate input
                if ((columnsCount != lastcolumnsCount) && (lastcolumnsCount != 0))
                {
                    //Check if one template has wrong number of columns and warn user
                    MessageBox.Show("One line in a template csv-file has different number of columns. This could be because of using characters (like ';') similar to separator used in csv-file, thus causing an extra column. Columns current template:" + columnsCount.ToString() + " . Columns last template checked: " + lastcolumnsCount);
                }
                lastcolumnsCount = columnsCount;


                //Check if line has correct template Name
                if (lineArray[0].ToLower() == EclipsePlanTemplateName.ToLower()) //If it is the correct template name
                {
                    //MessageBox.Show("Match on template: " + line);


                    //Create Margin
                    Margins margin = CreateDefaultMargins();

                    //-----------
                    //Modify Margin - Iterate through all properties and match fields with line-input based on header
                    //-----------
                    string debugPropertiesSet = "";

                    foreach (PropertyInfo property in properties) //Must have exception for certain fields if we do not want to override.
                    {
                        string PropertyName = property.Name;                        
                        int index = Array.FindIndex(headersArray, header => header == PropertyName && header != ""); //Get index where there is match on header and property Name.
                        //If property name matches csv header name:

                        if (index != -1)
                        {
                            //debug:
                            string debugTypeOfIntegerOrDouble = (property.PropertyType == typeof(int) || property.PropertyType == typeof(double)).ToString();
                            debugPropertiesSet = debugPropertiesSet + "Header: " + headersArray[index] + "  ValueParsed:" + TryParseDouble(lineArray[index], outputIfFail).ToString() + "  GetType: " + property.PropertyType.ToString() + " Bool: " + debugTypeOfIntegerOrDouble + Environment.NewLine;

                            //Set numbers
                            if (property.PropertyType == typeof(int) || property.PropertyType == typeof(double))
                            { 
                                try
                                {  //try to set value, number
                                    property.SetValue(margin, TryParseDouble(lineArray[index], outputIfFail));
                                }
                                catch
                                {
                                        property.SetValue(margin, -1); // If no value or illegal value;
                                }
                            }
                            //Set strings
                            if (property.PropertyType == typeof(string))
                            {
                                try
                                {  //try to set value, string
                                    property.SetValue(margin, lineArray[index]);
                                }
                                catch
                                {
                                    property.SetValue(margin, "-1"); // If no value or illegal value;
                                }
                            }
                        }
                    }
                    //MessageBox.Show(debugPropertiesSet);
                    //-------------------------------


                    //Create Margin
                    //Margins margin = new Margins()
                    //{
                    //    SmallerStructureName = lineArray[1],
                    //    LargerStructureName = lineArray[2],
                    //    ExpectedMeanMargin = TryParseDouble(lineArray[3], outputIfFail),
                    //    MeanNotCroppedMarginToleranceHighWarning = TryParseDouble(lineArray[4], outputIfFail),
                    //    MeanNotCroppedMarginToleranceHighError = TryParseDouble(lineArray[5], outputIfFail),
                    //    MeanNotCroppedMarginToleranceLowWarning = TryParseDouble(lineArray[6], outputIfFail),
                    //    MeanNotCroppedMarginToleranceLowError = TryParseDouble(lineArray[7], outputIfFail),
                    //    X_Pluss_Margin_tolerance = TryParseDouble(lineArray[8], outputIfFail),
                    //    X_Minus_Margin_tolerance = TryParseDouble(lineArray[9], outputIfFail),
                    //    Y_Pluss_Margin_tolerance = TryParseDouble(lineArray[10], outputIfFail),
                    //    Y_Minus_Margin_tolerance = TryParseDouble(lineArray[11], outputIfFail),
                    //    Z_Pluss_Margin_tolerance = TryParseDouble(lineArray[12], outputIfFail),
                    //    Z_Minus_Margin_tolerance = TryParseDouble(lineArray[13], outputIfFail),

                    //};

                    //--------------------
                    //set booleans
                    //--------------------
                    bool meanMarginToleranceExpectedExist = (margin.ExpectedMeanMargin != -1);
                    bool meanMarginToleranceExistHigh = (margin.MeanMarginHighError != -1 || margin.MeanMarginHighWarning != -1); //||
                    bool meanMarginToleranceExistLow = (margin.MeanMarginLowError != -1 || margin.MeanMarginLowWarning != -1);  //||
                    //As long as just one diretional tolerance exist, meanMarginToleranceExistDirectional will be true:
                    bool meanMarginToleranceExistDirectional = (margin.X_Minus_Margin_tolerance != -1 || margin.X_Pluss_Margin_tolerance != -1 || margin.Y_Minus_Margin_tolerance != -1 || margin.Y_Pluss_Margin_tolerance != -1 || margin.Z_Minus_Margin_tolerance != -1 || margin.Z_Pluss_Margin_tolerance != -1);
                    //As long as just one diretional High or Low, Warning or Error tolerance exist for EVERY direction, meanMarginToleranceExistDirectionalUpperAndLower will be true:
                    bool meanMarginToleranceExistDirectionalUpperAndLower =
                        (margin.X_Minus_Margin_HighError != -1 || margin.X_Minus_Margin_HighWarning != -1 || margin.X_Minus_Margin_LowError != -1 || margin.X_Minus_Margin_LowWarning != -1
                        && margin.X_Pluss_Margin_tolerance != -1 || margin.X_Minus_Margin_HighWarning != -1 || margin.X_Minus_Margin_LowError != -1 || margin.X_Minus_Margin_LowWarning != -1
                        && margin.Y_Minus_Margin_tolerance != -1 || margin.Y_Minus_Margin_HighWarning != -1 || margin.Y_Minus_Margin_LowError != -1 || margin.Y_Minus_Margin_LowWarning != -1
                        && margin.Y_Pluss_Margin_tolerance != -1 || margin.Y_Pluss_Margin_HighWarning != -1 || margin.Y_Pluss_Margin_LowError != -1 || margin.Y_Pluss_Margin_LowWarning != -1
                        && margin.Z_Minus_Margin_tolerance != -1 || margin.Z_Minus_Margin_HighWarning != -1 || margin.Z_Minus_Margin_LowError != -1 || margin.Z_Minus_Margin_LowWarning != -1
                        && margin.Z_Pluss_Margin_tolerance != -1 || margin.Z_Pluss_Margin_HighWarning != -1 || margin.Z_Pluss_Margin_LowError != -1 || margin.Z_Pluss_Margin_LowWarning != -1);
                    //The last one is not really used much anymore, only debug. Every directional High and Low Error and Warning is evaluated individually if they should use default or explicit margins...
                    //-------------------


                    //Set status if tolerances exist based on boolean:
                    if (meanMarginToleranceExpectedExist) { margin.MeanExpectedToleranceExplicitlySet = Constants.True; }
                    if (meanMarginToleranceExistHigh && meanMarginToleranceExistLow) { margin.MeanUpperLowerToleranceExplicitlySet = Constants.True; }
                    if (meanMarginToleranceExistDirectional) { margin.MeanExpectedDirectionlToleranceExplicitlySet = Constants.True; }
                    if (meanMarginToleranceExistDirectionalUpperAndLower) { margin.MeanUpperLowerDirectionlToleranceExplicitlySet = Constants.True; }

                    //-------------------------------
                    //Modify mean margins if necessary
                    //-------------------------------

                    //Expected mean margin
                    double meanExpectedMargin = margin.ExpectedMeanMargin;
                    //if (meanMarginToleranceExpectedExist) {meanMarginToleranceExpectedExist = true;}

                    //Override tolerances high and low mean tolerance if they do not exist.
                    //LOW
                    if (margin.MeanMarginLowWarning == -1 && meanMarginToleranceExpectedExist)
                    { margin.MeanMarginLowWarning = meanExpectedMargin - Math.Round(meanExpectedMargin * Constants.TolerancesMarginsPercentageWarning, 1);
                        margin.MeanUpperLowerToleranceExplicitlySet = Constants.True;
                    }
                    if (margin.MeanMarginLowError == -1 && meanMarginToleranceExpectedExist)
                    {
                        margin.MeanMarginLowError = meanExpectedMargin - Math.Round(meanExpectedMargin * Constants.TolerancesMarginsPercentageError, 1);
                        margin.MeanUpperLowerToleranceExplicitlySet = Constants.True;
                    }
                    //HIGH
                    if (margin.MeanMarginHighWarning == -1 && meanMarginToleranceExpectedExist)
                    { margin.MeanMarginHighWarning = meanExpectedMargin + Math.Round(meanExpectedMargin * Constants.TolerancesMarginsPercentageWarning, 1);
                        margin.MeanUpperLowerToleranceExplicitlySet = Constants.True;
                    }
                    if (margin.MeanMarginHighError == -1 && meanMarginToleranceExpectedExist)
                    { margin.MeanMarginHighError = meanExpectedMargin + Math.Round(meanExpectedMargin * Constants.TolerancesMarginsPercentageError, 1);
                        margin.MeanUpperLowerToleranceExplicitlySet = Constants.True;
                    }
                    //-------------------------------                                                                                                                          //-------------------------------                                                                                                                                     //---------------------------------

                    //-------------------------------
                    //Modify directional margins if necessary
                    //-------------------------------
                    if (meanMarginToleranceExistDirectional == true) // && meanMarginToleranceExistDirectionalUpperAndLower == false) //There may be some directional tolerances defined, while some others are not. Script should now handle that :) Earlier it demanded either all be set, or none would be.
                    { //Create generic directional warning and error tolerances, high and low:

                        //-----------------------
                        // -- ONLY adding default calculated tolerances for those that do not have explicitly set tolerances
                        //-----------------------

                        //X Minus
                        MarginsDirectionalTolerances marginsDirectionlTolerances = new MarginsDirectionalTolerances
                        {
                            Directional_Mean_Margin = margin.X_Minus_Margin,
                            Margin_tolerance = margin.X_Minus_Margin_tolerance,
                            Margin_HighError = -1,
                            Margin_HighWarning = -1,
                            Margin_LowError = -1,
                            Margin_LowWarning = -1,
                        };

                        marginsDirectionlTolerances = SetDirectionalDefaultMargins(margin, marginsDirectionlTolerances); //Calculate default High and Low Errors and Warnings, as long as we have a "Directional Margin tolerance" to calculate it from.
                        if (margin.X_Minus_Margin_HighError == -1) { margin.X_Minus_Margin_HighError = marginsDirectionlTolerances.Margin_HighError; }; //Use them if they dont already exist
                        if (margin.X_Minus_Margin_HighWarning == -1) { margin.X_Minus_Margin_HighWarning = marginsDirectionlTolerances.Margin_HighWarning; } //Use them if they dont already exist
                        if (margin.X_Minus_Margin_LowError == -1) { margin.X_Minus_Margin_LowError = marginsDirectionlTolerances.Margin_LowError; } //Use them if they dont already exist
                        if (margin.X_Minus_Margin_LowWarning == -1) { margin.X_Minus_Margin_LowWarning = marginsDirectionlTolerances.Margin_LowWarning; } //Use them if they dont already exist

                        //X Pluss
                        marginsDirectionlTolerances = new MarginsDirectionalTolerances
                        {
                            Directional_Mean_Margin = margin.X_Pluss_Margin,
                            Margin_tolerance = margin.X_Pluss_Margin_tolerance,
                            Margin_HighError = -1,
                            Margin_HighWarning = -1,
                            Margin_LowError = -1,
                            Margin_LowWarning = -1,
                        };

                        marginsDirectionlTolerances = SetDirectionalDefaultMargins(margin, marginsDirectionlTolerances);
                        if (margin.X_Pluss_Margin_HighError == -1) { margin.X_Pluss_Margin_HighError = marginsDirectionlTolerances.Margin_HighError; }
                        if (margin.X_Pluss_Margin_HighWarning == -1) { margin.X_Pluss_Margin_HighWarning = marginsDirectionlTolerances.Margin_HighWarning; }
                        if (margin.X_Pluss_Margin_LowError == -1) { margin.X_Pluss_Margin_LowError = marginsDirectionlTolerances.Margin_LowError; }
                        if (margin.X_Pluss_Margin_LowWarning == -1) { margin.X_Pluss_Margin_LowWarning = marginsDirectionlTolerances.Margin_LowWarning; }

                        //Y Minus
                        marginsDirectionlTolerances = new MarginsDirectionalTolerances
                        {
                            Directional_Mean_Margin = margin.Y_Minus_Margin,
                            Margin_tolerance = margin.Y_Minus_Margin_tolerance,
                            Margin_HighError = -1,
                            Margin_HighWarning = -1,
                            Margin_LowError = -1,
                            Margin_LowWarning = -1,
                        };

                        marginsDirectionlTolerances = SetDirectionalDefaultMargins(margin, marginsDirectionlTolerances);
                        if (margin.Y_Minus_Margin_HighError == -1) { margin.Y_Minus_Margin_HighError = marginsDirectionlTolerances.Margin_HighError; }
                        if (margin.Y_Minus_Margin_HighWarning == -1) { margin.Y_Minus_Margin_HighWarning = marginsDirectionlTolerances.Margin_HighWarning; }
                        if (margin.Y_Minus_Margin_LowError == -1) { margin.Y_Minus_Margin_LowError = marginsDirectionlTolerances.Margin_LowError; }
                        if (margin.Y_Minus_Margin_LowWarning == -1) { margin.Y_Minus_Margin_LowWarning = marginsDirectionlTolerances.Margin_LowWarning; }

                        //Y Pluss
                        marginsDirectionlTolerances = new MarginsDirectionalTolerances
                        {
                            Directional_Mean_Margin = margin.Y_Pluss_Margin,
                            Margin_tolerance = margin.Y_Pluss_Margin_tolerance,
                            Margin_HighError = -1,
                            Margin_HighWarning = -1,
                            Margin_LowError = -1,
                            Margin_LowWarning = -1,
                        };

                        marginsDirectionlTolerances = SetDirectionalDefaultMargins(margin, marginsDirectionlTolerances);
                        if (margin.Y_Pluss_Margin_HighError == -1) { margin.Y_Pluss_Margin_HighError = marginsDirectionlTolerances.Margin_HighError; }
                        if (margin.Y_Pluss_Margin_HighWarning == -1) { margin.Y_Pluss_Margin_HighWarning = marginsDirectionlTolerances.Margin_HighWarning; }
                        if (margin.Y_Pluss_Margin_LowError == -1) { margin.Y_Pluss_Margin_LowError = marginsDirectionlTolerances.Margin_LowError; }
                        if (margin.Y_Pluss_Margin_LowWarning == -1) { margin.Y_Pluss_Margin_LowWarning = marginsDirectionlTolerances.Margin_LowWarning; }

                        //Z Minus
                        marginsDirectionlTolerances = new MarginsDirectionalTolerances
                        {
                            Directional_Mean_Margin = margin.Z_Minus_Margin,
                            Margin_tolerance = margin.Z_Minus_Margin_tolerance,
                            Margin_HighError = -1,
                            Margin_HighWarning = -1,
                            Margin_LowError = -1,
                            Margin_LowWarning = -1,
                        };

                        marginsDirectionlTolerances = SetDirectionalDefaultMargins(margin, marginsDirectionlTolerances);
                        if (margin.Z_Minus_Margin_HighError == -1) { margin.Z_Minus_Margin_HighError = marginsDirectionlTolerances.Margin_HighError; }
                        if (margin.Z_Minus_Margin_HighWarning == -1) { margin.Z_Minus_Margin_HighWarning = marginsDirectionlTolerances.Margin_HighWarning; }
                        if (margin.Z_Minus_Margin_LowError == -1) { margin.Z_Minus_Margin_LowError = marginsDirectionlTolerances.Margin_LowError; }
                        if (margin.Z_Minus_Margin_LowWarning == -1) { margin.Z_Minus_Margin_LowWarning = marginsDirectionlTolerances.Margin_LowWarning; }

                        //Z Pluss
                        marginsDirectionlTolerances = new MarginsDirectionalTolerances
                        {
                            Directional_Mean_Margin = margin.Z_Pluss_Margin,
                            Margin_tolerance = margin.Z_Pluss_Margin_tolerance,
                            Margin_HighError = -1,
                            Margin_HighWarning = -1,
                            Margin_LowError = -1,
                            Margin_LowWarning = -1,
                        };

                        marginsDirectionlTolerances = SetDirectionalDefaultMargins(margin, marginsDirectionlTolerances);
                        if (margin.Z_Pluss_Margin_HighError == -1) { margin.Z_Pluss_Margin_HighError = marginsDirectionlTolerances.Margin_HighError; }
                        if (margin.Z_Pluss_Margin_HighWarning == -1) { margin.Z_Pluss_Margin_HighWarning = marginsDirectionlTolerances.Margin_HighWarning; }
                        if (margin.Z_Pluss_Margin_LowError == -1) { margin.Z_Pluss_Margin_LowError = marginsDirectionlTolerances.Margin_LowError; }
                        if (margin.Z_Pluss_Margin_LowWarning == -1) { margin.Z_Pluss_Margin_LowWarning = marginsDirectionlTolerances.Margin_LowWarning; }

                    }
                    //-------------------------------


                    //Add to class
                    marginsTemplatesList.Add(margin);

                    //MessageBox.Show("LoadMarginsTemplates");
                    //PrintMarginTemplate(margin);


                }


            }
            //}
            //catch
            //{
            //    ErrorHandlingExtension.ErrorDog("Kan ikke laste inn templater. Kontroller filen " + filePathTemplates + Environment.NewLine + "Siste linje lest foer feilen oppstod: " + line + Environment.NewLine + "Returnerer tom templatliste.");

            //}


            return marginsTemplatesList;
        }

        public static Margins CalculateMargins(Margins marginsResult, string StructureName_small, string StructureName_large, StructureSet structureSet, PatientContext patientContext)  //public static Margins CalculateMargins(string StructureName_small, string StructureName_large, StructureSet structureSet)
        {
            string IsStruktureWithinStructure = Constants.False;
            string warning = "";


            //--------------
            //Logikksjekker
            //--------------

            //sjekker om den ene strukturen er innenfor den andre:
            IsStruktureWithinStructure = StructureWithinStructureBasic(StructureName_small, StructureName_large, structureSet, marginsResult);
            if (IsStruktureWithinStructure == Constants.False)
            {
                warning = "Strukturen " + StructureName_small + " er ikke innenfor " + StructureName_large + ".";
                marginsResult.Warning = (marginsResult.Warning == "") ? warning : marginsResult.Warning + Environment.NewLine + warning;

            }
            marginsResult.IsSmallStructureWithinLargeStructure = IsStruktureWithinStructure;

            //Sjekker om senter av strukturene er naer hverandre:
            Structure Structure_large = structureSet.Structures.Where(x => x.Id == StructureName_large).FirstOrDefault();
            Structure Structure_small = structureSet.Structures.Where(x => x.Id == StructureName_small).FirstOrDefault();
            string bodyName = StructureExtension.GetBodyId(structureSet);
            Structure Structure_Body = structureSet.Structures.Where(x => x.Id == bodyName).FirstOrDefault();
            double ctv_ptv_x_avstand = Math.Abs((Structure_small.CenterPoint.x - Structure_large.CenterPoint.x) / 10);
            double ctv_ptv_y_avstand = Math.Abs((Structure_small.CenterPoint.y - Structure_large.CenterPoint.y) / 10);
            double ctv_ptv_z_avstand = Math.Abs((Structure_small.CenterPoint.z - Structure_large.CenterPoint.z) / 10);
            if (ctv_ptv_x_avstand < Constants.ToleranceTargetStructureMatchOriginDistanceCm && ctv_ptv_y_avstand < Constants.ToleranceTargetStructureMatchOriginDistanceCm && ctv_ptv_z_avstand < Constants.ToleranceTargetStructureMatchOriginDistanceCm) //hvis ctv origin er neart ptv origin (innen 5 cm)
            {
                marginsResult.AreStructureOriginsClose = Constants.True;
                marginsResult.Debug = marginsResult.Debug + "AreStructureOriginsClose: " + Environment.NewLine + Constants.True + " (avstander: " + Math.Round(ctv_ptv_x_avstand, 5) + ", " + Math.Round(ctv_ptv_y_avstand, 5) + "," + Math.Round(ctv_ptv_z_avstand) + ")";
            }
            else { marginsResult.AreStructureOriginsClose = Constants.False; }

            //Add size and origin:
            marginsResult = CalculateStructureOriginAndSizeAndMargins(StructureName_small, StructureName_large, structureSet, marginsResult);

            //--------------
            //Logikksjekker End
            //--------------

            //--------------
            //Kalkulerer mean margins, og sjekker om cropping mot Body eksisterer
            //--------------

            marginsResult.MeanMargin = CalculateMeanClosestDistance(Structure_large.MeshGeometry.Positions.ToList(), Structure_small.MeshGeometry.Positions.ToList()); // Structure_small.MeshGeometry.Positions.Select(e => new VVector(e.X, e.Y, e.Z))

            marginsResult = CalculateMeanClosestDistanceExceptWhenCroppedToBody(Structure_large, Structure_small, Structure_Body, marginsResult, patientContext);


            //--------------

            //Korrigerer koordinater for orientering:
            //MarginsResult.X_origin_diff = Hjelpefunksjoner.CorrectCoordinateSystemToPatientOrientation(plan, "x", MarginsResult.X_origin_diff, MarginsResult.Y_origin_diff, MarginsResult.Z_origin_diff);
            //MarginsResult.Y_origin_diff = Hjelpefunksjoner.CorrectCoordinateSystemToPatientOrientation(plan, "y", MarginsResult.X_origin_diff, MarginsResult.Y_origin_diff, MarginsResult.Z_origin_diff);
            //MarginsResult.Z_origin_diff = Hjelpefunksjoner.CorrectCoordinateSystemToPatientOrientation(plan, "z", MarginsResult.X_origin_diff, MarginsResult.Y_origin_diff, MarginsResult.Z_origin_diff);


            //Margin = "x: " + CalculateStructureOriginAndSize_Directional(StructureName_small, StructureName_large, "x", plan, MarginsResult);
            //Margin = Margin + Environment.NewLine + "y: " + CalculateStructureOriginAndSize_Directional(StructureName_small, StructureName_large, "y", plan, MarginsResult);
            //Margin = Margin + Environment.NewLine + "z: " + CalculateStructureOriginAndSize_Directional(StructureName_small, StructureName_large, "z", plan, MarginsResult);

            string marginscomment =
            "PTV || CTV || Direction || sizediff || origindiff || margin - || margin + ||:" + Environment.NewLine +
                StructureName_large + " || " + StructureName_small + " || X ||" + marginsResult.X_size_diff + " || " + marginsResult.X_origin_diff + " || " + marginsResult.X_Minus_Margin + " || " + marginsResult.X_Pluss_Margin + Environment.NewLine +
                StructureName_large + " || " + StructureName_small + " || Y ||" + marginsResult.Y_size_diff + " || " + marginsResult.Y_origin_diff + " || " + marginsResult.Y_Minus_Margin + " || " + marginsResult.Y_Pluss_Margin + Environment.NewLine +
                StructureName_large + " || " + StructureName_small + " || Z ||" + marginsResult.Z_size_diff + " || " + marginsResult.Z_origin_diff + " || " + marginsResult.Z_Minus_Margin + " || " + marginsResult.Z_Pluss_Margin + Environment.NewLine +
                "--------------" + Environment.NewLine +
                "PTV Origin X;Y;Z: " + marginsResult.Origin_XYZ_LargeStructure + Environment.NewLine +
                "CTV Origin X;Y;Z: " + marginsResult.Origin_XYZ_SmallStructure + Environment.NewLine +
                "Warnings: " + Environment.NewLine + marginsResult.Warning;

            marginsResult.Debug = marginsResult.Debug + Environment.NewLine + marginscomment;

            //MessageBox.Show(marginscomment);


            return marginsResult;
        }



        public static Margins CalculateStructureOriginAndSizeAndMargins(string StructureName_small, string StructureName_large, StructureSet structureSet, Margins MarginsResult)
        {
            string IsStruktureWithinStructureBasic = Constants.False;
            double diffOriginX = 0;
            double diffOriginY = 0;
            double diffOriginZ = 0;
            double diffSizeX = 0;
            double diffSizeY = 0;
            double diffSizeZ = 0;
            string warning = "";

            //Logikksjekk
            //sjekker om den ene strukturen er innenfor den andre:
            IsStruktureWithinStructureBasic = StructureWithinStructureBasic(StructureName_small, StructureName_large, structureSet, MarginsResult);
            if (IsStruktureWithinStructureBasic == Constants.False)
            {
                warning = "Strukturen " + StructureName_small + " er ikke innenfor strukturen " + StructureName_large + " i funksjonen StructureWithinStructure. Sjekk at dette stemmer. Kjorer likevel ferdig funksjonen CalculateMargins.";
                //MessageBox.Show(warning);
                MarginsResult.Warning = (MarginsResult.Warning == "") ? warning : MarginsResult.Warning + Environment.NewLine + warning;
            }

            //Size and Origin Difference

            //Finner XYZ origin av storste organ:
            MarginsResult.Origin_XYZ_LargeStructure = Math.Round(FindStructureRect3D_origin(StructureName_large, "x", structureSet), 2).ToString() +
                Constants.StringSeparator + Math.Round(FindStructureRect3D_origin(StructureName_large, "y", structureSet), 2).ToString() +
                Constants.StringSeparator + Math.Round(FindStructureRect3D_origin(StructureName_large, "z", structureSet), 2).ToString();

            //Finner XYZ origin av minste organ:
            MarginsResult.Origin_XYZ_SmallStructure = Math.Round(FindStructureRect3D_origin(StructureName_small, "x", structureSet), 2).ToString() +
                Constants.StringSeparator + Math.Round(FindStructureRect3D_origin(StructureName_small, "y", structureSet), 2).ToString() +
                Constants.StringSeparator + Math.Round(FindStructureRect3D_origin(StructureName_small, "z", structureSet), 2).ToString();

            //Kjorer funksjoner for aa finne forskjell i storrelsen paa rect3d rundt hver struktur og forskjell i midtpunktet av rekt3d for hver struktur.
            diffOriginX = CompareStructureRect3D_origin(StructureName_small, StructureName_large, "x", structureSet);
            MarginsResult.X_origin_diff = diffOriginX;
            diffOriginY = CompareStructureRect3D_origin(StructureName_small, StructureName_large, "y", structureSet);
            MarginsResult.Y_origin_diff = diffOriginY;
            diffOriginZ = CompareStructureRect3D_origin(StructureName_small, StructureName_large, "z", structureSet);
            MarginsResult.Z_origin_diff = diffOriginZ;

            diffSizeX = CompareStructureRect3D_size(StructureName_small, StructureName_large, "x", structureSet);
            MarginsResult.X_size_diff = diffSizeX;
            diffSizeY = CompareStructureRect3D_size(StructureName_small, StructureName_large, "y", structureSet);
            MarginsResult.Y_size_diff = diffSizeY;
            diffSizeZ = CompareStructureRect3D_size(StructureName_small, StructureName_large, "z", structureSet);
            MarginsResult.Z_size_diff = diffSizeZ;

            MarginsResult = CalculateDirectionalMargins(diffOriginX, diffSizeX, "x", structureSet, MarginsResult);
            MarginsResult = CalculateDirectionalMargins(diffOriginY, diffSizeY, "y", structureSet, MarginsResult);
            MarginsResult = CalculateDirectionalMargins(diffOriginZ, diffSizeZ, "z", structureSet, MarginsResult);


            //Justerer resultatene slik at de faar 1 desimal
            MarginsResult.X_Minus_Margin = Math.Round(MarginsResult.X_Minus_Margin, 1);
            MarginsResult.X_Pluss_Margin = Math.Round(MarginsResult.X_Pluss_Margin, 1);
            MarginsResult.Y_Minus_Margin = Math.Round(MarginsResult.Y_Minus_Margin, 1);
            MarginsResult.Y_Pluss_Margin = Math.Round(MarginsResult.Y_Pluss_Margin, 1);
            MarginsResult.Z_Minus_Margin = Math.Round(MarginsResult.Z_Minus_Margin, 1);
            MarginsResult.Z_Pluss_Margin = Math.Round(MarginsResult.Z_Pluss_Margin, 1);
            MarginsResult.X_origin_diff = Math.Round(MarginsResult.X_origin_diff, 1);
            MarginsResult.Y_origin_diff = Math.Round(MarginsResult.Y_origin_diff, 1);
            MarginsResult.Z_origin_diff = Math.Round(MarginsResult.Z_origin_diff, 1);
            MarginsResult.X_size_diff = Math.Round(MarginsResult.X_size_diff, 1);
            MarginsResult.Y_size_diff = Math.Round(MarginsResult.Y_size_diff, 1);
            MarginsResult.Z_size_diff = Math.Round(MarginsResult.Z_size_diff, 1);




            //MessageBox.Show("direction: " + direction + Environment.NewLine + "DiffOrigin: " + diffOrigin + Environment.NewLine + "DiffSize: " + diffSize);


            //MessageBox.Show(Margin);

            return MarginsResult;
        }


        public static double FindStructureRect3D_size(string StructureName, string direction, StructureSet structureSet)
        {
            double Rect3Dsize = 0;
            Structure structure_Rect3D = structureSet.Structures.FirstOrDefault(x => x.Id == StructureName);
            Rect3D bounds_Rect3d;
            //Validering
            if (structure_Rect3D != null)
            {
                bounds_Rect3d = structure_Rect3D.MeshGeometry.Bounds;
                //Setter size
                if (direction == "x")
                {
                    Rect3Dsize = bounds_Rect3d.SizeX;
                }
                else if (direction == "y")
                {
                    Rect3Dsize = bounds_Rect3d.SizeY;
                }
                else if (direction == "z")
                {
                    Rect3Dsize = bounds_Rect3d.SizeZ;
                }
            }
            else
            { //Maa legge inn noe bedre feilhandtering
                //MessageBox.Show("Fant ikke Rect3D size for strukturen " + StructureName + " i retning " + direction + ". Husk at retning maa veare i liten bokstav. Returnerer verdien 0.");
            }


            return Rect3Dsize;
        }

        public static double CompareStructureRect3D_size(string StructureName_small, string StructureName_large, string direction, StructureSet structureSet)
        {
            double MarginSize = 0;
            double Rect3D_largeStructure_size = 0;
            double Rect3D_smallStructure_size = 0;

            Rect3D_largeStructure_size = FindStructureRect3D_size(StructureName_large, direction, structureSet);
            Rect3D_smallStructure_size = FindStructureRect3D_size(StructureName_small, direction, structureSet);
            //Legg inn validering
            MarginSize = Rect3D_largeStructure_size - Rect3D_smallStructure_size;

            return MarginSize;
        }


        public static double FindStructureRect3D_origin(string StructureName, string direction, StructureSet structureSet)
        {
            //Finner origin til strukturens Rect3D. I motsetning til hva jeg trodde ligger ikke origin i senter av Rect3D.
            //Origin ligger overst til venstre i strukturens rect3d. Modifiserte koden til aa legge til "size/2" for aa finne senter av Rect3D.

            double Rect3D_origin = 0;
            Structure structure_Rect3D = structureSet.Structures.FirstOrDefault(x => x.Id == StructureName);
            Rect3D bounds_Rect3d;

            //Validering
            if (structure_Rect3D != null)
            {
                bounds_Rect3d = structure_Rect3D.MeshGeometry.Bounds;
                //setter origin
                if (direction == "x")
                {
                    Rect3D_origin = bounds_Rect3d.Location.X + (bounds_Rect3d.SizeX / 2);
                }
                else if (direction == "y")
                {
                    Rect3D_origin = bounds_Rect3d.Location.Y + (bounds_Rect3d.SizeY / 2);
                }
                else if (direction == "z")
                {
                    Rect3D_origin = bounds_Rect3d.Location.Z + (bounds_Rect3d.SizeZ / 2);
                }
            }
            else
            { //Maa legge inn noe bedre feilhandtering
                //MessageBox.Show("Fant ikke Rect3D size for strukturen " + StructureName + " i retning " + direction + ". Husk at retning maa veare i liten bokstav. Returnerer verdien 0.");
            }


            return Rect3D_origin;
        }



        public static double CompareStructureRect3D_origin(string StructureName_small, string StructureName_large, string direction, StructureSet structureSet)
        {
            //Hvis differanse i origin er null, er marginene lik i begge retninger, feks for z direction: da er marginene lik kranielt/kaudalt
            double DifferenceOrigin = 0;
            double Rect3D_largeStructure_size = 0;
            double Rect3D_smallStructure_size = 0;

            Rect3D_largeStructure_size = FindStructureRect3D_origin(StructureName_large, direction, structureSet);
            Rect3D_smallStructure_size = FindStructureRect3D_origin(StructureName_small, direction, structureSet);
            //Legg inn validering
            DifferenceOrigin = Rect3D_largeStructure_size - Rect3D_smallStructure_size;


            return DifferenceOrigin;
        }


        public static string StructureWithinStructureBasic(string StructureName_small, string StructureName_large, StructureSet structureSet, Margins MarginsResult)
        {
            string Result_StructureWithinStructure = Constants.False;
            Structure structure_large = structureSet.Structures.FirstOrDefault(x => x.Id == StructureName_large);
            Structure structure_small = structureSet.Structures.FirstOrDefault(x => x.Id == StructureName_small);
            Rect3D bounds_Rect3d_large;
            Rect3D bounds_Rect3d_small;
            string warning = "";
            //validering


            if (structure_large != null && structure_small != null)
            {
                if (structure_large.HasSegment && structure_small.HasSegment)
                {
                    bounds_Rect3d_large = structure_large.MeshGeometry.Bounds;
                    bounds_Rect3d_small = structure_small.MeshGeometry.Bounds;

                    if (bounds_Rect3d_large.Contains(bounds_Rect3d_small)) //funksjonen maa kontrolleres
                    {
                        Result_StructureWithinStructure = Constants.True;
                    }
                    else
                    {
                        Result_StructureWithinStructure = Constants.False;
                    }

                }
                else
                {
                    warning = "Ingen segmentering for strukturene " + StructureName_small + " og " + StructureName_large + " i funksjonen StructureWithinStructure. Returnerer verdien False.";
                    // MessageBox.Show(warning);
                    MarginsResult.Warning = (MarginsResult.Warning == "") ? warning : MarginsResult.Warning + Environment.NewLine + warning;
                }

            }
            else
            {
                warning = "Finner ikke begge strukturene " + StructureName_small + " og " + StructureName_large + " i funksjonen StructureWithinStructure. Returnerer verdien False.";
                //MessageBox.Show(warning);
                MarginsResult.Warning = (MarginsResult.Warning == "") ? warning : MarginsResult.Warning + Environment.NewLine + warning;
            }

            return Result_StructureWithinStructure;
        }

        public static Margins CalculateDirectionalMargins(double diffOrigin, double diffSize, string direction, StructureSet structureSet, Margins MarginsResult)
        {

            double tempMargin = 0;
            double asymmetryMargin = 0;
            double Margin_asym1 = 0;
            double Margin_asym2 = 0;

            //Kalkulerer marginer i pluss og minus retning
            if (diffOrigin == 0)
            {
                tempMargin = diffSize / 2;
                //Margin = tempMargin.ToString() + Constants.StringSeparator + tempMargin.ToString();
                Margin_asym1 = tempMargin;
                Margin_asym2 = tempMargin;
            }
            else if (diffOrigin > 0) //asymmetri - mer margin i ene siden
            {
                asymmetryMargin = diffOrigin * 2;
                Margin_asym1 = (diffSize - asymmetryMargin) / 2 + asymmetryMargin; //marginen til den ene siden 
                Margin_asym2 = (diffSize - asymmetryMargin) / 2; //resterende margin paa andre siden
            }
            else if (diffOrigin < 0) //asymmetri - mer margin i andre siden
            {
                asymmetryMargin = diffOrigin * 2;
                Margin_asym1 = (diffSize + asymmetryMargin) / 2; //marginen til den ene siden   //X: venstre side ved standard pasientorientering.
                Margin_asym2 = (diffSize + asymmetryMargin) / 2 - asymmetryMargin; //resterende margin paa andre siden   //X: høyre side ved standard pasientorientering.
            }

            //sender resultat tilbake, avh. av retning. //Ikke kontrollert
            if (direction == "x")
            {
                MarginsResult.X_Minus_Margin = Margin_asym2;
                MarginsResult.X_Pluss_Margin = Margin_asym1;

            }
            else if (direction == "y")
            {
                MarginsResult.Y_Minus_Margin = Margin_asym2;
                MarginsResult.Y_Pluss_Margin = Margin_asym1;
            }
            else if (direction == "z")
            {
                MarginsResult.Z_Minus_Margin = Margin_asym2;
                MarginsResult.Z_Pluss_Margin = Margin_asym1;
            }


            return MarginsResult;
        }


        static double CalculateMeanClosestDistance(List<Point3D> set1, List<Point3D> set2)
        {
            double totalDistance = 0;
            string minDistanceDebug = ""; //Debug
            int count = 0;
            int skipCount = 0;
            int countTotal = 0;
            double numberOfPoints = set1.Count();

            int skipMeasurmentUntilNumberReached = 4;
            //CHange how many points of large structure to look at since it takes more time the larger the structure // Add instead based on number of points?
            if (numberOfPoints > 100 && numberOfPoints <= 200)
            {
                skipMeasurmentUntilNumberReached = 6;
            }
            if (numberOfPoints > 200 && numberOfPoints <= 400)
            {
                skipMeasurmentUntilNumberReached = 7;
            }
            else if (numberOfPoints > 400 && numberOfPoints <= 600)
            {
                skipMeasurmentUntilNumberReached = 8;
            }
            else if (numberOfPoints > 600 && numberOfPoints <= 1000)
            {
                skipMeasurmentUntilNumberReached = 10;
            }
            else if (numberOfPoints > 1000 && numberOfPoints <= 3000)
            {
                skipMeasurmentUntilNumberReached = 12;
            }
            else if (numberOfPoints > 3000 && numberOfPoints <= 6000)
            {
                skipMeasurmentUntilNumberReached = 15;
            }
            else if (numberOfPoints > 6000 && numberOfPoints <= 9000)
            {
                skipMeasurmentUntilNumberReached = 20;
            }
            else if (numberOfPoints > 9000 && numberOfPoints <= 12000)
            {
                skipMeasurmentUntilNumberReached = 30;
            }
            else
            {
                skipMeasurmentUntilNumberReached = 40;
            }

            foreach (var p1 in set1)
            {
                countTotal++;
                //Beregner bare hvert 3 punkt for aa spare kalkuleringstid
                if (skipCount < skipMeasurmentUntilNumberReached)
                { skipCount++; }
                else if (skipCount >= skipMeasurmentUntilNumberReached)
                {
                    //-------------------------------
                    //Beregner mean total distance
                    //-------------------------------
                    double minDistance = Math.Sqrt(set2.Min(p2 => DistanceSquared(p1, p2)));
                    minDistanceDebug = minDistanceDebug + Math.Round(minDistance, 2).ToString() + " // "; //Kun debug
                    totalDistance += minDistance;
                    count++;
                    //-------------------------------

                    //resetter
                    skipCount = 0;
                }
            }
            //MessageBox.Show("CountTotal:" + countTotal + Environment.NewLine + "Count:" + count + Environment.NewLine + "PTV-CTV Distance:" + minDistanceDebug);  //Debug
            return Math.Round(totalDistance / count, 1);

        }

        //Idea: Change to  "ValidateTargetStructureMatch". THEN _LATER_ run "CalculateMargins" with the following line:  marginsResult = CalculateMargins(..) So that we can possibly do a Delayed run.
        public static MarginList ValidateTargetStructureMatchAndCalculateMargins(MarginList marginList, Structure smallStructure, Structure largeStructure, string smallStructureID, string largeStructureID, string debugDescription, PatientContext patientContext)
        {

            //Kun hvis ptv er segmentert og ctv eksisterer
            if (smallStructure != null && largeStructure.HasSegment)
            {
                //sjekker om ctv er segmentert
                if (smallStructure.HasSegment)
                {

                    //Er origin neart hverandre?
                    double smallStructureToLargeStructureDistance_X = Math.Abs((smallStructure.CenterPoint.x - largeStructure.CenterPoint.x) / 10);
                    double smallStructureTOLargeStructureDistance_Y = Math.Abs((smallStructure.CenterPoint.y - largeStructure.CenterPoint.y) / 10);
                    double smallStructureTOLargeStructureDistance_z = Math.Abs((smallStructure.CenterPoint.z - largeStructure.CenterPoint.z) / 10);

                    //hvis ctv origin er neart ptv origin (innen 2.5 cm)
                    if (smallStructureToLargeStructureDistance_X < Constants.ToleranceTargetStructureMatchOriginDistanceCm && smallStructureTOLargeStructureDistance_Y < Constants.ToleranceTargetStructureMatchOriginDistanceCm && smallStructureTOLargeStructureDistance_z < Constants.ToleranceTargetStructureMatchOriginDistanceCm)
                    {
                        //Oppretter ny tom MarginResult
                        Margins marginsResult = CreateDefaultMargins();
                        marginsResult.LargeStructureID = largeStructureID;
                        marginsResult.SmallStructureID = smallStructureID;
                        marginsResult.LargeStructureStartWith = marginList.LargeStructureStartWith;
                        marginsResult.SmallStructureStartWith = marginList.SmallStructureStartWith;


                        //Beregner marginer - denne kan vi fjerne fra presjekken og legge inn i selve sjekken, så presjekken ikke bruker så lang tid.
                        marginsResult = CalculateMargins(marginsResult, smallStructureID, largeStructureID, marginList.StructureSet, patientContext);

                        //-------------------------
                        //Find negative margin basic check
                        //-------------------------
                        marginsResult = BasicCheckNegativeMargin(marginsResult, smallStructureID, largeStructureID);

                        //Legger til i Margin-liste
                        marginList.ListOfMargins.Add(marginsResult);

                        //Debug print
                        string debug_LS_List = "";
                        for (int i = 0; i < marginList.LargeTargetStructureList.Count() - 1; i++)
                        {
                            debug_LS_List = debug_LS_List + ", " + marginList.LargeTargetStructureList[i].TargetStructureId;
                        }
                        string debug_SS_List = "";
                        for (int i = 0; i < marginList.SmallTargetStructureList.Count() - 1; i++)
                        {
                            debug_SS_List = debug_SS_List + ", " + marginList.SmallTargetStructureList[i].TargetStructureId;
                        }
                        //MessageBox.Show("Large Str. list:" + Environment.NewLine + debug_LS_List + Environment.NewLine + "Small Str. list:" + Environment.NewLine + debug_SS_List);

                        //Remove from PTV- og CTV-liste so that they cannot be used several times.
                        var itemToRemove = marginList.LargeTargetStructureList.Single(r => r.TargetStructureId == largeStructureID);
                        //Sender til debug
                        if (marginList.Debug != "") { marginList.Debug = marginList.Debug + Environment.NewLine; }
                        marginList.Debug = marginList.Debug + debugDescription + " Remove from list: " + Environment.NewLine + itemToRemove.TargetStructureId;
                        marginList.LargeTargetStructureList.Remove(itemToRemove);

                        //Warning if two structures with same name in list
                        if (marginList.SmallTargetStructureList.Count(r => r.TargetStructureId == smallStructureID) > 1)
                        {
                            marginList.Debug = marginList.Debug + Environment.NewLine + "ERROR! Code attempts to remove two SmallStructureList items. Could only remove one of them." + Environment.NewLine + "Large Str. list:" + Environment.NewLine + debug_LS_List + Environment.NewLine + "Small Str. list:" + Environment.NewLine + debug_SS_List;
                        }
                        itemToRemove = marginList.SmallTargetStructureList.FirstOrDefault(r => r.TargetStructureId == smallStructureID); //Earlier marginList.SmallTargetStructureList.Single, but would crash if more than one match.
                        //Sender til debug
                        marginList.Debug = marginList.Debug + " / " + itemToRemove.TargetStructureId;
                        marginList.SmallTargetStructureList.Remove(itemToRemove);


                    }
                    else
                    {
                        //Sender til debug
                        if (marginList.Debug != "") { marginList.Debug = marginList.Debug + Environment.NewLine; }
                        marginList.Debug = marginList.Debug + debugDescription + " Forkastet match pga. origin senter: " + largeStructureID + " / " + smallStructureID;

                    }
                }
            }
            else { }

            return marginList;
        }

        public static MarginsDirectionalTolerances SetDirectionalDefaultMargins(Margins marginResult, MarginsDirectionalTolerances marginsDirectionlTolerances)
        {
        //MarginsDirectionalTolerances marginsDirectionlTolerances = new MarginsDirectionalTolerances { };

        //if (marginResult.MeanUpperLowerDirectionlToleranceExplicitlySet == Constants.False)
        //{ 
            //Create warning and error tolerances, high and low:
            //Default if no tolerances. Prevent crash
            double toleranceLowWarning = -1;
            double toleranceHighWarning = -1;
            double toleranceLowError = -1;
            double toleranceHighError = -1;
            double toleranceWarning = 1;
            double toleranceError = 1;

            if(marginsDirectionlTolerances.Margin_tolerance != -1) // if a tolerance exists, calculate low and high warnings and errors            if(marginsDirectionlTolerances.Margin_tolerance == -1)
            {
                double directionalTolerance = marginsDirectionlTolerances.Margin_tolerance;


                //set standard tolerances based on Constants
                //if (marginResult.MeanUpperLowerDirectionlToleranceExplicitlySet == Constants.False)
                //{
                toleranceWarning = Math.Round(directionalTolerance * Constants.TolerancesMarginsPercentageWarning, 1);
                toleranceError = Math.Round(directionalTolerance * Constants.TolerancesMarginsPercentageError, 1);
                if (marginsDirectionlTolerances.Directional_Mean_Margin > Constants.TolerancesMarginsMinimumError * 2) // Only add minimum margin if margin is higher than 2 time minimum margin tolerance
                {
                    if (toleranceWarning < Constants.TolerancesMarginsMinimumWarning)
                    {
                        toleranceWarning = Constants.TolerancesMarginsMinimumWarning;
                    }

                    if (toleranceError < Constants.TolerancesMarginsMinimumError)
                    {
                        toleranceError = Constants.TolerancesMarginsMinimumError;
                    }
                }
                //TolerancesMarginsMinimum
                toleranceLowWarning = directionalTolerance - toleranceWarning;
                if (toleranceLowWarning < 0) { toleranceLowWarning = 0; }
                toleranceHighWarning = directionalTolerance + toleranceWarning;
                toleranceLowError = directionalTolerance - toleranceError;
                if (toleranceLowError < 0) { toleranceLowError = 0; }
                toleranceHighError = directionalTolerance + toleranceError;

                marginsDirectionlTolerances.Margin_HighError = toleranceHighError;
                marginsDirectionlTolerances.Margin_HighWarning = toleranceHighWarning;
                marginsDirectionlTolerances.Margin_LowError = toleranceLowError;
                marginsDirectionlTolerances.Margin_LowWarning = toleranceLowWarning;
            }
            //}
        //}

            return marginsDirectionlTolerances;

        }


        static double CalculateDirectionPlussMarginCoordinate(double origin, double size, double percentageDiscarded)
        {
            double plussCoordinate = origin + size / 2 * percentageDiscarded;
            return plussCoordinate;
        }
        static double CalculateDirectionMinusMarginCoordinate(double origin, double size, double percentageDiscarded)
        {
            double plussCoordinate = origin - size / 2 * percentageDiscarded;
            return plussCoordinate;
        }

        static Margins CalculateMeanClosestDistanceExceptWhenCroppedToBody(Structure Structure_large, Structure Structure_small, Structure Structure_Body, Margins MarginsResult, PatientContext patientContext) //set1=PTV, set2=CTV, set3=Body
        {

            int sign = 1;

            List<Point3D> set1 = Structure_large.MeshGeometry.Positions.ToList(); //Sort them some way? .Sort()
            List<Point3D> set2 = Structure_small.MeshGeometry.Positions.ToList();
            List<Point3D> set3 = Structure_Body.MeshGeometry.Positions.ToList();

            MeshGeometry3D Structure_large_mesh = Structure_large.MeshGeometry;

            //Calculate Size and Origins of structure (hopefully all these paramateres are in same units... mm/cm?)
            MarginsResult.Size_LargeStructure_X = Structure_large_mesh.Bounds.SizeX;
            MarginsResult.Size_LargeStructure_Y = Structure_large_mesh.Bounds.SizeY;
            MarginsResult.Size_LargeStructure_Z = Structure_large_mesh.Bounds.SizeZ;
            //--
            MarginsResult.Origin_LargeStructure_X = Structure_large.CenterPoint.x;
            MarginsResult.Origin_LargeStructure_Y = Structure_large.CenterPoint.y;
            MarginsResult.Origin_LargeStructure_Z = Structure_large.CenterPoint.z;

            //Calculate minimum and maximum distances for directional margins. They are used to split up a structure into "zones" which are call "X pluss" / "X minus" / "Y plus" etc., so we can retrieve asymmetric margins.
            //Define Direction Minimum and Maximum Coordinates
            double Z_Pluss_Direction_Intermediate_Current_Coordinate = CalculateDirectionPlussMarginCoordinate(MarginsResult.Origin_LargeStructure_Z, MarginsResult.Size_LargeStructure_Z, Constants.DirectionalMarginPercentageDiscardedPointsCurrentDirection);
            double X_Pluss_Direction_Intermediate_Current_Coordinate = CalculateDirectionPlussMarginCoordinate(MarginsResult.Origin_LargeStructure_X, MarginsResult.Size_LargeStructure_X, Constants.DirectionalMarginPercentageDiscardedPointsCurrentDirection);
            double Y_Pluss_Direction_Intermediate_Current_Coordinate = CalculateDirectionPlussMarginCoordinate(MarginsResult.Origin_LargeStructure_Y, MarginsResult.Size_LargeStructure_Y, Constants.DirectionalMarginPercentageDiscardedPointsCurrentDirection);
            double Z_Minus_Direction_Intermediate_Current_Coordinate = CalculateDirectionMinusMarginCoordinate(MarginsResult.Origin_LargeStructure_Z, MarginsResult.Size_LargeStructure_Z, Constants.DirectionalMarginPercentageDiscardedPointsCurrentDirection);
            double X_Minus_Direction_Intermediate_Current_Coordinate = CalculateDirectionMinusMarginCoordinate(MarginsResult.Origin_LargeStructure_X, MarginsResult.Size_LargeStructure_X, Constants.DirectionalMarginPercentageDiscardedPointsCurrentDirection);
            double Y_Minus_Direction_Intermediate_Current_Coordinate = CalculateDirectionMinusMarginCoordinate(MarginsResult.Origin_LargeStructure_Y, MarginsResult.Size_LargeStructure_Y, Constants.DirectionalMarginPercentageDiscardedPointsCurrentDirection);

            double Z_Pluss_Direction_Intermediate_Other_Coordinate = CalculateDirectionPlussMarginCoordinate(MarginsResult.Origin_LargeStructure_Z, MarginsResult.Size_LargeStructure_Z, Constants.DirectionalMarginPercentageKeptPointsOtherDirections);
            double X_Pluss_Direction_Intermediate_Other_Coordinate = CalculateDirectionPlussMarginCoordinate(MarginsResult.Origin_LargeStructure_X, MarginsResult.Size_LargeStructure_X, Constants.DirectionalMarginPercentageKeptPointsOtherDirections);
            double Y_Pluss_Direction_Intermediate_Other_Coordinate = CalculateDirectionPlussMarginCoordinate(MarginsResult.Origin_LargeStructure_Y, MarginsResult.Size_LargeStructure_Y, Constants.DirectionalMarginPercentageKeptPointsOtherDirections);
            double Z_Minus_Direction_Intermediate_Other_Coordinate = CalculateDirectionMinusMarginCoordinate(MarginsResult.Origin_LargeStructure_Z, MarginsResult.Size_LargeStructure_Z, Constants.DirectionalMarginPercentageKeptPointsOtherDirections);
            double X_Minus_Direction_Intermediate_Other_Coordinate = CalculateDirectionMinusMarginCoordinate(MarginsResult.Origin_LargeStructure_X, MarginsResult.Size_LargeStructure_X, Constants.DirectionalMarginPercentageKeptPointsOtherDirections);
            double Y_Minus_Direction_Intermediate_Other_Coordinate = CalculateDirectionMinusMarginCoordinate(MarginsResult.Origin_LargeStructure_Y, MarginsResult.Size_LargeStructure_Y, Constants.DirectionalMarginPercentageKeptPointsOtherDirections);

            //DirectionalMarginPercentageKeptPointsOtherDirections

            MarginsResult.Z_Minus_Maximum_Coordinate = Z_Minus_Direction_Intermediate_Current_Coordinate;
            MarginsResult.X_Minus_Maximum_Coordinate = X_Minus_Direction_Intermediate_Current_Coordinate;
            MarginsResult.Y_Minus_Maximum_Coordinate = Y_Minus_Direction_Intermediate_Current_Coordinate;
            MarginsResult.Z_Pluss_Minimum_Coordinate = Z_Pluss_Direction_Intermediate_Current_Coordinate;
            MarginsResult.X_Pluss_Minimum_Coordinate = X_Pluss_Direction_Intermediate_Current_Coordinate;
            MarginsResult.Y_Pluss_Minimum_Coordinate = Y_Pluss_Direction_Intermediate_Current_Coordinate;

            double total_distance_Z_Minus = 0;
            double total_distance_X_Minus = 0;
            double total_distance_Y_Minus = 0;
            double total_distance_Z_Pluss = 0;
            double total_distance_X_Pluss = 0;
            double total_distance_Y_Pluss = 0;

            double count_Z_Minus = 0;
            double count_X_Minus = 0;
            double count_Y_Minus = 0;
            double count_Z_Pluss = 0;
            double count_X_Pluss = 0;
            double count_Y_Pluss = 0;

            double count_Z_Minus_No_Margin = 0;
            double count_X_Minus_No_Margin = 0;
            double count_Y_Minus_No_Margin = 0;
            double count_Z_Pluss_No_Margin = 0;
            double count_X_Pluss_No_Margin = 0;
            double count_Y_Pluss_No_Margin = 0;

            double count_Z_Minus_Negativ_Margin = 0;
            double count_X_Minus_Negativ_Margin = 0;
            double count_Y_Minus_Negativ_Margin = 0;
            double count_Z_Pluss_Negativ_Margin = 0;
            double count_X_Pluss_Negativ_Margin = 0;
            double count_Y_Pluss_Negativ_Margin = 0;


            double totalDistance = 0;
            int countNotCropped = 0;
            int countTotal = 0;
            int countCroppedAndExcluded = 0;
            int skipCount = 0;
            int countNotInsideStructure = 0;

            //string bodyDistanceDebug = ""; //Debug
            string existCroppingAgainstBody = Constants.False;
            string debugMargins = "";

            string insideLargestStructureNotCropped = Constants.True;

            // Set volume
            double structure1Volume = 0;
            if (!Structure_large.IsEmpty)
            {
                structure1Volume = Structure_large.Volume;
            }
            double structure2Volume = 0;
            if (!Structure_small.IsEmpty)
            {
                structure2Volume = Structure_small.Volume;
            }

            int skipMeasurmentUntilNumberReached = 3; //2
                                                      //CHange how many points of large structure to look at since it takes more time the larger the structure
            if (structure1Volume > 200 && structure1Volume <= 400)
            {
                skipMeasurmentUntilNumberReached = 6;
            }
            else if (structure1Volume > 400 && structure1Volume <= 600)
            {
                skipMeasurmentUntilNumberReached = 8;
            }
            else if (structure1Volume > 600 && structure1Volume <= 1000)
            {
                skipMeasurmentUntilNumberReached = 10;
            }
            else if (structure1Volume > 1000 && structure1Volume <= 3000)
            {
                skipMeasurmentUntilNumberReached = 20;
            }
            else //Unreasonably large structures - we dont need to calculate all points. It would take minutes. Not tested if it actually reduces calculation time ....
            {
                skipMeasurmentUntilNumberReached = 40;
            }

            double distanceSet1_Set3 = 0;
            double distanceSet1_Set2 = 0;
            double distanceSet2_Set3 = 0;

            double maxDistanceSet1_Set2_SmallStructureOutsideLargeStructure = 0;
            string maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureCoordinates = "";
            string maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureStrings = "";

            Point3D point3 = new Point3D { X = 0, Y = 0, Z = 0 };
            Point3D point2 = new Point3D { X = 0, Y = 0, Z = 0 };


            //int totalPoints = set1.Count;

            foreach (var p1 in set1)
            {
                countTotal++;
                //Beregner bare noen punkter for aa spare kalkuleringstid, skipper resten
                if (skipCount < skipMeasurmentUntilNumberReached)
                { skipCount++; continue; }
                else if (skipCount >= skipMeasurmentUntilNumberReached)
                {
                    //Tidligere kode:
                    //double minBodyDistance = set3.Min(p3 => Distance(p1, p3));

                    //-------------------------------
                    //Look for closest point from point 1 in set1 (PTV) to set3 (Body):
                    //-------------------------------
                    distanceSet1_Set3 = double.MaxValue; //9999;
                    //double tempLastBodyDistance = 0;
                    int countbody = set3.Count();
                    for (int i = 0; i < countbody -1; i++) //  (var p3 in set3)
                    {
                        //if (tempLastBodyDistance > Constants.BodyDistanceHigherThanThisSkipFurtherAhead_LargeSkip)
                        //{
                        //    if (i + Constants.BodyDistanceNumberOfPointsToSkip_LargeSkip < countbody -1) { i = i + Constants.BodyDistanceNumberOfPointsToSkip_LargeSkip; } //Skips ahead some further points if distance is too big, saves time.
                        //}
                        //else if((tempLastBodyDistance > Constants.BodyDistanceHigherThanThisSkipFurtherAhead_SmallSkip))
                        //{
                        //    if (i + Constants.BodyDistanceNumberOfPointsToSkip_LargeSkip < countbody -1) { i = i + Constants.BodyDistanceNumberOfPointsToSkip_SmallSkip; } //Skips ahead some further points if distance is too big, saves time.
                        //}

                        var p3 = set3[i];
                        double tempdistance = DistanceSquared(p1, p3);
                        //tempLastBodyDistance = tempdistance;
                        if (tempdistance < distanceSet1_Set3)
                        {
                            distanceSet1_Set3 = tempdistance;
                            point3 = p3;
                        }
                    }
                    distanceSet1_Set3 = Math.Sqrt(distanceSet1_Set3);

                    //-------------------------------
                    //Look for closest point from point1 in set1 (PTV) to set2 (CTV):
                    //-------------------------------
                    //double tempLastSmallStructureDistance = 0;
                    int countSmallStructure = set2.Count();
                    distanceSet1_Set2 = double.MaxValue; // 9999;
                    for (int i = 0; i < countSmallStructure-1; i++)  //foreach (var p2 in set2)
                    {
                        //if (tempLastSmallStructureDistance > Constants.SmallStructureDistanceHigherThanThisSkipFurtherAhead)
                        //{
                        //    if (i + Constants.SmallStructureDistanceNumberOfPointsToSkip < countSmallStructure - 1) { i = i + Constants.SmallStructureDistanceNumberOfPointsToSkip; } //Skips ahead some further points if distance is too big, saves time.
                        //}

                        var p2 = set2[i];
                        double tempdistance = DistanceSquared(p1, p2);
                        //tempLastSmallStructureDistance = tempdistance;
                        if (tempdistance < distanceSet1_Set2)
                        {
                            distanceSet1_Set2 = tempdistance;
                            point2 = p2;
                        }

                    }
                    distanceSet1_Set2 = Math.Sqrt(distanceSet1_Set2);

                    //-------------------------------
                    //Distance from Set2 (CTV) to Set3 (Body) 
                    //-------------------------------
                    distanceSet2_Set3 = Distance(point3, point2);

                    //Debug
                    //bodyDistanceDebug = bodyDistanceDebug + "-" + Math.Round(distanceSet1_Set3,1) + "-" + Math.Round(distanceSet1_Set2,1) + "-" + Math.Round(distanceSet2_Set3,1) + " // ";  //Kun debug

                    //Only count if  structure 2 (CTV) and structure 1 (PTV) is not too close to structure 3 (Body). Thus removing all areas cropped against skin from margin calculation. 
                    if (distanceSet1_Set3 > Constants.ExceptionDistancePTVToBodyInMarginCalculationMm && distanceSet2_Set3 > Constants.ExceptionDistanceCTVToBodyInMarginCalculationMm) // if (minBodyDistance > Konstanter.ExceptionDistanceStructureToBodyInMarginCalculation) 
                    {
                        //Inside structure? Separate check done simultaniously
                        VVector contours = new VVector(point2.X, point2.Y, point2.Z); //Point in Smallest Structure (point1) that is closest to Largest Structure point. Langt fra perfekt, men tilnearming for aa ikke faa mange falske positive near Body.
                        if (Structure_large.IsPointInsideSegment(contours) == false)
                        {
                            insideLargestStructureNotCropped = Constants.False;
                            countNotInsideStructure++;

                            sign = -1;

                            if (distanceSet1_Set2 > maxDistanceSet1_Set2_SmallStructureOutsideLargeStructure)
                            {

                                maxDistanceSet1_Set2_SmallStructureOutsideLargeStructure = Math.Round(distanceSet1_Set2, 3);
                                VVector dicomToUservVector = Convert3DPointToVvector(point2);
                                dicomToUservVector = ConvertVvectorToUserCoordinates(dicomToUservVector, patientContext);
                                maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureCoordinates = PrintVvectorCoordinates(dicomToUservVector);
                                maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureStrings = maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureStrings + maxDistanceSet1_Set2_SmallStructureOutsideLargeStructure + ",";
                            }
                        }
                        else
                        {
                            sign = 1;
                        }



                        //-------------------------------
                        //Calculate mean total distance
                        //-------------------------------
                        double minDistanceAbsolute = distanceSet1_Set2;
                        double minDistance = sign * distanceSet1_Set2; // set1.Min(p2 => Distance(p1, p2));

                        totalDistance += minDistance;
                        countNotCropped++;
                        //-------------------------------

                        //-------------------------------
                        //Calculate directional mean distance!
                        //-------------------------------

                        //X_Pluss
                        if ((p1.X > X_Pluss_Direction_Intermediate_Current_Coordinate) && (p1.Z < Z_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Z > Z_Minus_Direction_Intermediate_Other_Coordinate) && (p1.Y < Y_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Y > Y_Minus_Direction_Intermediate_Other_Coordinate))
                        {
                            total_distance_X_Pluss += minDistance;
                            count_X_Pluss++;
                            if (minDistanceAbsolute < Constants.CloseToZeroMargin)
                            {
                                count_X_Pluss_No_Margin++; //Close to no margin
                            }
                            if (minDistance < 0)
                            {
                                count_X_Pluss_Negativ_Margin++; //Negativ margin
                            }
                        }
                        //X_Minus
                        if ((p1.X < X_Minus_Direction_Intermediate_Current_Coordinate) && (p1.Z < Z_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Z > Z_Minus_Direction_Intermediate_Other_Coordinate) && (p1.Y < Y_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Y > Y_Minus_Direction_Intermediate_Other_Coordinate))
                        {
                            total_distance_X_Minus += minDistance;
                            count_X_Minus++;
                            if (minDistanceAbsolute < Constants.CloseToZeroMargin)
                            {
                                count_X_Minus_No_Margin++;
                            }
                            if (minDistance < 0)
                            {
                                count_X_Minus_Negativ_Margin++; //Negativ margin
                            }
                        }
                        //Z_Pluss
                        if ((p1.Z > Z_Pluss_Direction_Intermediate_Current_Coordinate) && (p1.X < X_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.X > X_Minus_Direction_Intermediate_Other_Coordinate) && (p1.Y < Y_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Y > Y_Minus_Direction_Intermediate_Other_Coordinate))
                        {
                            total_distance_Z_Pluss += minDistance;
                            count_Z_Pluss++;
                            if (minDistanceAbsolute < Constants.CloseToZeroMargin)
                            {
                                count_Z_Pluss_No_Margin++;
                            }
                            if (minDistance < 0)
                            {
                                count_Z_Pluss_Negativ_Margin++; //Negativ margin
                            }
                        }
                        //Z_Minus
                        if ((p1.Z < Z_Minus_Direction_Intermediate_Current_Coordinate) && (p1.X < X_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.X > X_Minus_Direction_Intermediate_Other_Coordinate) && (p1.Y < Y_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Y > Y_Minus_Direction_Intermediate_Other_Coordinate))
                        {
                            total_distance_Z_Minus += minDistance;
                            count_Z_Minus++;
                            if (minDistanceAbsolute < Constants.CloseToZeroMargin)
                            {
                                count_Z_Minus_No_Margin++;
                            }
                            if (minDistance < 0)
                            {
                                count_Z_Minus_Negativ_Margin++; //Negativ margin
                            }
                        }
                        //Y_Pluss
                        if ((p1.Y > Y_Pluss_Direction_Intermediate_Current_Coordinate) && (p1.X < X_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.X > X_Minus_Direction_Intermediate_Other_Coordinate) && (p1.Z < Z_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Z > Z_Minus_Direction_Intermediate_Other_Coordinate))
                        {
                            total_distance_Y_Pluss += minDistance;
                            count_Y_Pluss++;
                            if (minDistanceAbsolute < Constants.CloseToZeroMargin)
                            {
                                count_Y_Pluss_No_Margin++;
                            }
                            if (minDistance < 0)
                            {
                                count_Y_Pluss_Negativ_Margin++; //Negativ margin
                            }
                        }
                        //Y_Minus
                        if ((p1.Y < Y_Minus_Direction_Intermediate_Current_Coordinate) && (p1.X < X_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.X > X_Minus_Direction_Intermediate_Other_Coordinate) && (p1.Z < Z_Pluss_Direction_Intermediate_Other_Coordinate) && (p1.Z > Z_Minus_Direction_Intermediate_Other_Coordinate))
                        {
                            total_distance_Y_Minus += minDistance;
                            count_Y_Minus++;
                            if (minDistanceAbsolute < Constants.CloseToZeroMargin)
                            {
                                count_Y_Minus_No_Margin++;
                            }
                            if (minDistance < 0)
                            {
                                count_Y_Minus_Negativ_Margin++; //Negativ margin
                            }
                        }



                        //-------------------------------
                        //-------------------------------



                        //reset skipCount
                        skipCount = 0;
                    }
                    else
                    {
                        countCroppedAndExcluded++;
                        skipCount++;
                        if (distanceSet1_Set2 < Constants.DefinitionCroppingPTVToCTVDistanceMarginCalculationMm) //Neart Body + Avstand PTV til CTV er liten -> defineres som cropping
                        {
                            existCroppingAgainstBody = Constants.True;
                        }


                    }
                }
            }
            MarginsResult.MeanMarginNotCroppedToBody = Math.Round(totalDistance / countNotCropped, 1);




            MarginsResult.X_Pluss_Mean_Count = count_X_Pluss;
            MarginsResult.Y_Pluss_Mean_Count = count_Y_Pluss;
            MarginsResult.Z_Pluss_Mean_Count = count_Z_Pluss;
            MarginsResult.X_Minus_Mean_Count = count_X_Minus;
            MarginsResult.Y_Minus_Mean_Count = count_Y_Minus;
            MarginsResult.Z_Minus_Mean_Count = count_Z_Minus;

            MarginsResult.X_Pluss_Negativ_Margin_Count = count_X_Pluss_Negativ_Margin;
            MarginsResult.X_Minus_Negativ_Margin_Count = count_X_Minus_Negativ_Margin;
            MarginsResult.Y_Pluss_Negativ_Margin_Count = count_Y_Pluss_Negativ_Margin;
            MarginsResult.Y_Minus_Negativ_Margin_Count = count_Y_Minus_Negativ_Margin;
            MarginsResult.Z_Pluss_Negativ_Margin_Count = count_Z_Pluss_Negativ_Margin;
            MarginsResult.Z_Minus_Negativ_Margin_Count = count_Z_Minus_Negativ_Margin;

            //Set directional margin, if there are valid measuringpoints, otherwise use basic calculation.

            if (count_X_Pluss > 0) { MarginsResult.X_Pluss_Mean_Margin = Math.Round(total_distance_X_Pluss / count_X_Pluss, 1); } else { MarginsResult.X_Pluss_Mean_Margin = MarginsResult.X_Pluss_Margin; }

            if (count_X_Minus > 0) { MarginsResult.X_Minus_Mean_Margin = Math.Round(total_distance_X_Minus / count_X_Minus, 1); } else { MarginsResult.X_Minus_Mean_Margin = MarginsResult.X_Minus_Margin; }

            if (count_Z_Pluss > 0) { MarginsResult.Z_Pluss_Mean_Margin = Math.Round(total_distance_Z_Pluss / count_Z_Pluss, 1); } else { MarginsResult.Z_Pluss_Mean_Margin = MarginsResult.Z_Pluss_Margin; }

            if (count_Z_Minus > 0) { MarginsResult.Z_Minus_Mean_Margin = Math.Round(total_distance_Z_Minus / count_Z_Minus, 1); } else { MarginsResult.Z_Minus_Mean_Margin = MarginsResult.Z_Minus_Margin; }

            if (count_Y_Pluss > 0) { MarginsResult.Y_Pluss_Mean_Margin = Math.Round(total_distance_Y_Pluss / count_Y_Pluss, 1); } else { MarginsResult.Y_Pluss_Mean_Margin = MarginsResult.Y_Pluss_Margin; }

            if (count_Y_Minus > 0) { MarginsResult.Y_Minus_Mean_Margin = Math.Round(total_distance_Y_Minus / count_Y_Minus, 1); } else { MarginsResult.Y_Minus_Mean_Margin = MarginsResult.Y_Minus_Margin; }

            //If negativ avarage margin in any direction
            if ((total_distance_X_Pluss / count_X_Pluss < 0) || (total_distance_X_Minus / count_X_Minus < 0) || (total_distance_Z_Pluss / count_Z_Pluss < 0) || (total_distance_Z_Minus / count_Z_Minus < 0) || (total_distance_Y_Pluss / count_Y_Pluss < 0) || (total_distance_Y_Minus / count_Y_Minus < 0))
            {

                MarginsResult.AdvancedCheckNegativMarginDetected = Constants.Warning;
            }
            else
            {
                MarginsResult.AdvancedCheckNegativMarginDetected = Constants.Ok;
            }

            //if margin is mostly very small and also basic check shows no margin - override to basic margin.
            if (count_X_Pluss_No_Margin > Constants.CloseToZeroMarginPercentage * count_X_Pluss)
            {
                if (MarginsResult.X_Pluss_Margin < Constants.CloseToZeroMargin)
                {
                    MarginsResult.X_Pluss_Mean_Margin = MarginsResult.X_Pluss_Margin;
                }

            }
            if (count_X_Minus_No_Margin > Constants.CloseToZeroMarginPercentage * count_X_Minus)
            {
                if (MarginsResult.X_Minus_Margin < Constants.CloseToZeroMargin)
                {
                    MarginsResult.X_Minus_Mean_Margin = MarginsResult.X_Minus_Margin;
                }

            }
            if (count_Y_Pluss_No_Margin > Constants.CloseToZeroMarginPercentage * count_Y_Pluss)
            {
                if (MarginsResult.Y_Pluss_Margin < Constants.CloseToZeroMargin)
                {
                    MarginsResult.Y_Pluss_Mean_Margin = MarginsResult.Y_Pluss_Margin;
                }

            }
            if (count_Y_Minus_No_Margin > Constants.CloseToZeroMarginPercentage * count_Y_Minus)
            {
                if (MarginsResult.Y_Minus_Margin < Constants.CloseToZeroMargin)
                {
                    MarginsResult.Y_Minus_Mean_Margin = MarginsResult.Y_Minus_Margin;
                }

            }
            if (count_Z_Pluss_No_Margin > Constants.CloseToZeroMarginPercentage * count_Z_Pluss)
            {
                if (MarginsResult.Z_Pluss_Margin < Constants.CloseToZeroMargin)
                {
                    MarginsResult.Z_Pluss_Mean_Margin = MarginsResult.Z_Pluss_Margin;
                }

            }
            if (count_Y_Minus_No_Margin > Constants.CloseToZeroMarginPercentage * count_Z_Minus)
            {
                if (MarginsResult.Z_Minus_Margin < Constants.CloseToZeroMargin)
                {
                    MarginsResult.Z_Minus_Mean_Margin = MarginsResult.Z_Minus_Margin;
                }

            }


            debugMargins = Environment.NewLine + "CountTotalPoints: " + countTotal + Environment.NewLine
                + "Count used: " + countNotCropped + Environment.NewLine
                + "Count excluded because CTV or PTV close to Body: " + countCroppedAndExcluded + Environment.NewLine
                + "maxDistanceSet1_Set2_SmallStructureOutsideLargeStructure: " + maxDistanceSet1_Set2_SmallStructureOutsideLargeStructure + Environment.NewLine
                + "maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureCoordinates: " + maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureCoordinates + Environment.NewLine//maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureStrings 
                + "maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureStrings: " + maxDistanceSet1_Set2_SmallStructureOutsideLargeStructureStrings;

            //+ Environment.NewLine + "CTV-Body Distance: " + bodyDistanceDebug);;
            MarginsResult.Debug = MarginsResult.Debug + debugMargins;

            MarginsResult.ExistCroppingAgainstBody = existCroppingAgainstBody;
            if (existCroppingAgainstBody == Constants.True)
            {
                if (MarginsResult.Warning != "") { MarginsResult.Warning = MarginsResult.Warning + Environment.NewLine; }
                MarginsResult.Warning = MarginsResult.Warning + MarginsResult.LargeStructureID + " croppet mot Body!";
            }


            if (insideLargestStructureNotCropped == Constants.False)
            {
                if (MarginsResult.Warning != "") { MarginsResult.Warning = MarginsResult.Warning + Environment.NewLine; }
                MarginsResult.Warning = MarginsResult.Warning + MarginsResult.SmallStructureID + " ikke innenfor " + MarginsResult.LargeStructureID + "! " + " Points outside: " + countNotInsideStructure + " (not all points checked, so underestimation!)";
            }


            return MarginsResult;
        }

        public static double TryParseDouble(string input, double output)
        {
            if (input == "")
            {
                input = "-1";
            }

            Double.TryParse(input.Replace(",", "."), out output);

            return output;
        }


    }
}
