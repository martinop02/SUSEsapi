﻿using System;
using System.Collections.Generic;
using System.Data; //Lagt inn bitj
using System.Diagnostics;
using System.Globalization;
//using Image = VMS.TPS.Common.Model.API.Image;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
//Endre strukturer til transluce:

//Slipper eksplisitt referere til Helpers

namespace EclipsePlanCheck.Helpers
{
    public static class PlanExtension
    {
        //----------------------
        //SUS checkpoints
        //----------------------
        public static IEnumerable<Beam> GetFields(ExternalPlanSetup plan)
        {
            return plan.Beams.Where(b => !b.IsSetupField);
        }

        public static int[] GetPlanNumber(ExternalPlanSetup plan)
        {
            string id = plan.Id;

            int[] number = new int[2];


            number[0] = int.Parse(id[2].ToString() + (int.TryParse(id[3].ToString(), out int secondDigit) ? secondDigit.ToString() : ""));

            int digitCount = (int)Math.Floor(Math.Log10(Math.Abs(number[0]))) + 1;

            if (char.IsDigit(id[digitCount + 3]) && (id[digitCount + 2] == '.' || id[digitCount + 2] == ';'))
            {
                number[1] = int.Parse(id[digitCount + 3].ToString());
            }

            return number;
        }

        //----------------------
        //----------------------
        public static bool CheckIfPlanContainsFiF(ExternalPlanSetup plan, PatientContext patientContext)
        {
            bool existFiF = false; //Default
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist)
            {
                foreach (Beam field in patientContext.ChosenPlan.Beams)
                {
                    if (FieldExtension.CheckIfFieldIsFiF(field) || FieldExtension.CheckIfFieldIsIMRT(field))
                    {
                        existFiF = true;
                    }
                }

            }
            return existFiF;
        }

        public static bool CheckIfCourseContainsProtonPlans(ExternalPlanSetup plan, PatientContext patientContext)
        {
            int count = 0;
            bool resultProtonPlans = false;
            foreach(IonPlanSetup ProtonPlanInCourse in plan.Course.IonPlanSetups )
            {
                count = count + 1;
            }

            if(count >0)
            {
                resultProtonPlans = true;
            }


            return resultProtonPlans;
        }

        public static CheckPoint CheckFractionation(CheckPoint s, ExternalPlanSetup plan)
        {
            string fractionation = PlanExtension.GetFractionation(plan);
            s.CheckResultValue = fractionation;
            s.CheckResultValueCSV = fractionation;
            //Justerer sjekkpunktet i egen funksjon
            s = CheckPointExtension.CheckFractionationVsTemplate(fractionation, s.CheckTemplateValue, s);
            return s;
        }


        public static string GetFractionation(ExternalPlanSetup planen)
        {
            string fraksjonering = planen.DosePerFraction.ValueAsString + planen.DosePerFraction.UnitAsString + " x " + planen.NumberOfFractions + " = " + planen.TotalDose.ValueAsString + planen.TotalDose.UnitAsString;
            return fraksjonering;
        }


        public static CheckPoint CheckEnergies(ExternalPlanSetup plan, CheckPoint s)
        {
            string energyList = "";
            string _energy = "";
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {
                    _energy = felt.EnergyModeDisplayName;
                    if (!energyList.Contains(_energy))
                    {
                        if (energyList != "") { energyList = energyList + Constants.StringSeparator; }
                        energyList = energyList + _energy;
                    }
                }
            }
            s.CheckResultValue = energyList;
            s.CheckResultValueCSV = energyList;

            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(s.CheckResultValue, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);

            return s;
        }

        public static string GetMachineType (List <Field> fieldList)
        {

            string machineType = "";
            bool match_Halcyon = CheckIfHalcyonMachine(fieldList);
            bool match_Ethos = CheckIfEthosMachine(fieldList);
            bool match_TrueBeam = CheckIfTrueBeamMachine(fieldList);

            //Check Type machine, if TB-list is emtpy, sets to TrueBeam
            if (match_TrueBeam || Constants.MachinesTB == "")
            {
                machineType = Constants.TB;
            }
            if (match_Halcyon)
            {
                machineType = Constants.Halcyon; //Override to Halcyon
            }
            if (match_Ethos)
            {
                machineType = Constants.Ethos; //Override to Ethos
            }
            return machineType;
        }

        // SjekkDoserate
        public static CheckPoint CheckDoserate(ExternalPlanSetup plan, CheckPoint s)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            //Henter total antall MU
            string _energy = "";
            string _maskin = "";
            string _maskintype = "";
            string faktiskDoseRate = "";
            string templatDoseRate = "";
            string bool_sjekk_dr = Constants.True;
            int feltnr = 0;
            //Resultat
            string _resultstring = "";
            string _templatestring = "";
            string resultCSV = "";
            string templateCSV = "";
            string _header = "";

            _header = GeneralExtension.FormatString(12, 12, "Energi:" + Constants.StringSeparator + "DoseRate: ") + Environment.NewLine; //Header

            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {
                    feltnr = feltnr + 1;
                    //henter energi og maskin
                    _energy = felt.EnergyModeDisplayName;
                    _maskin = felt.TreatmentUnit.Id;

                    //Sjekker maskintype kun for forste felt
                    if (feltnr == 1)
                    {
                        //sjekker type maskin i templat, antar kun en type i plan
                        if (Constants.MachinesTB.Contains(_maskin) || Constants.MachinesTB == "")
                        {
                            _maskintype = Constants.TB;
                        }
                        if (Constants.MachinesHalcyon.Contains(_maskin))
                        {
                            _maskintype = Constants.Halcyon;
                        }
                        if (Constants.MachinesEthos.Contains(_maskin))
                        {
                            _maskintype = Constants.Ethos;
                        }
                    }

                    //sjekker korrrekt doserate i templat for hver energi (maa matche maskin og energinavn)
                    List<FieldEnergy> templatEnergi = Constants.Energies.Where(x => x.MachineType == _maskintype && x.EnergyName == _energy).ToList();
                    //Henter doserate fra forste match
                    int count = templatEnergi.Count();
                    // templatDoseRate = templatEnergi != null ? templatEnergi.ToList().First().Doserate : "";
                    if (count > 0)
                    {
                        templatDoseRate = templatEnergi.ToList().FirstOrDefault().DoseRate;
                    }
                    else { templatDoseRate = ""; }

                    //bruker templat
                    if (s.CheckTemplateValue != "")
                    {
                        s.CheckDebug = s.CheckDebug + "Doserate er definert manuelt i templatet. ";
                        //DoseRate allerede definert i templat.
                    }
                    //bruker default doserate om ingen definert
                    else
                    {
                        s.CheckTemplateValue = templatDoseRate != null ? templatDoseRate : ""; //Tom string om ingen templat eksisterer. 
                        s.CheckDebug = s.CheckDebug + "Doserate i templatet er hentet fra maks doserate for maskinen. ";
                    }



                    //faktisk doserate
                    faktiskDoseRate = felt.DoseRate.ToString();

                    //Sjekker
                    if (faktiskDoseRate == templatDoseRate && bool_sjekk_dr != Constants.False)
                    { //OK
                        bool_sjekk_dr = Constants.True;
                    }
                    else if (templatDoseRate == "")
                    {
                        string kommentar = "Finner ikke maskin " + _maskin + ", så kan ikke sjekke hva standard doserate skal være." + templatDoseRate;
                        if (s.CheckComment == "")
                        { s.CheckComment = kommentar; }
                        else { s.CheckComment = s.CheckComment + Environment.NewLine + kommentar; }
                        bool_sjekk_dr = Constants.False;
                    }
                    else if (faktiskDoseRate != templatDoseRate)
                    { //Feil
                        string kommentar = "Feltet " + felt.Id + " har doserate " + faktiskDoseRate + " mens templatet tilsier doserate skal være " + templatDoseRate + ". Maskin: " + _maskin + " (type: " + _maskintype + ")";
                        bool_sjekk_dr = Constants.False;
                        if (s.CheckComment == "")
                        { s.CheckComment = kommentar; }
                        else { s.CheckComment = s.CheckComment + Environment.NewLine + kommentar; }

                    }

                    //Setter resultat per felt
                    if (_resultstring == "")
                    {   //forste felt
                        _resultstring = _resultstring + GeneralExtension.FormatString(12, 12, _energy + Constants.StringSeparator + faktiskDoseRate);
                        _templatestring = _templatestring + GeneralExtension.FormatString(12, 12, _energy + Constants.StringSeparator + templatDoseRate); //GenerateTableLine(4, 4, _energy + Constants.StringSeparator + templatDoseRate);

                        //CSV result
                        if (resultCSV != "")
                        { resultCSV = resultCSV + "|"; } //Add some kind of separator that is not ";".
                        resultCSV = resultCSV + faktiskDoseRate;

                        if (templateCSV != "")
                        { templateCSV = templateCSV + "|"; } //Add some kind of separator that is not ";".
                        templateCSV = templateCSV + templatDoseRate;

                    }
                    else
                    {
                        //oppdaterer resultat med alle energier brukt (fjerner duplikater)
                        string temp = GeneralExtension.FormatString(12, 12, _energy + Constants.StringSeparator + faktiskDoseRate);
                        if (!_resultstring.Contains(temp)) //!_resultstring.Contains(_energy + ":" + templatDoseRate + "")
                        {
                            _resultstring = _resultstring + Environment.NewLine + temp;

                            //CSV result
                            if (resultCSV != "")
                            { resultCSV = resultCSV + "|"; } //Add some kind of separator that is not ";".
                            resultCSV = resultCSV + faktiskDoseRate;

                            if (templateCSV != "")
                            { templateCSV = templateCSV + "|"; } //Add some kind of separator that is not ";".
                            templateCSV = templateCSV + templatDoseRate;
                        }
                        GeneralExtension.FormatString(12, 12, _energy + Constants.StringSeparator + templatDoseRate);
                        // oppdaterer templat kun med energier som ikke allerede er skrevet:
                        if (!_templatestring.Contains(temp) && (temp != null && temp != "")) //Add, prevent adding new line if it is empty.
                        { _templatestring = _templatestring + Environment.NewLine + temp; }
                    }

                }
            }

            //Setter endelig resultat:
            if (bool_sjekk_dr == Constants.True)
            {
                s.CheckStatus = Constants.Ok;
            }
            else
            {
                s.CheckStatus = Constants.Warning;
            }
            s.CheckResultValue = _header + _resultstring;
            s.CheckTemplateValue = _header + _templatestring;
            s.CheckResultValueCSV = resultCSV;
            s.CheckTemplateValueCSV = templateCSV;


            return s; //
        }

        //HentBasePlan

        public static string HentBasePlanString(ExternalPlanSetup plan)
        {
            string result = "";
            PlanningItem basePlan = plan.BaseDosePlanningItem;
            if (basePlan != null)
            {
                result = basePlan.Id;
            }
            else { result = ""; }

            return result;
        }
        public static CheckPoint CheckBasePlan(ExternalPlanSetup plan, CheckPoint s, string baseplanID)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            //string test = plan.PlanType.ToString();
            //MessageBox.Show(test);
            s.CheckResultValue = baseplanID;
            s.CheckResultValueCSV = baseplanID;
            if (baseplanID != "")
            {
                s.CheckStatus = s.CheckTrafficLight;
            }
            else 
            {
                s.CheckDiscardedAtRuntime = Constants.True;
            }
            return s;
        }
        public static CheckPoint CheckBasePlanPercentage(ExternalPlanSetup plan, CheckPoint s, string baseplanID)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            double bp_totdose = 0;
            double prosent_bp = 0;
            string str_prosent = "";
            PlanningItem bp = plan.BaseDosePlanningItem;

            if (baseplanID != "")
            {
                Course bp_Course = bp.Course; //identifiserer korrekt course
                try
                {
                    //Går igjennom alle courser i tilfelle baseplan ligger i annen course
                    //foreach (Course c in plan.Course.Patient.Courses)
                    //{
                    foreach (ExternalPlanSetup p in bp_Course.PlanSetups) // plan.Course.PlanSetups
                    {
                        try //Kan få krasj her. Skipper sjekk hvis det er tilfelle. Fungerte ikke med "if vp.VerifiedPlan != null"
                        {
                            if (p.Id == baseplanID)
                            {
                                bp_totdose = p.TotalDose.Dose;
                                prosent_bp = Math.Round(bp_totdose / plan.TotalDose.Dose, 1) * 100;
                                str_prosent = prosent_bp.ToString();
                                //MessageBox.Show(str_prosent);
                                s.CheckResultValue = str_prosent;
                                s.CheckResultValueCSV = str_prosent;
                                s.CheckDebug = s.CheckDebug + "PlanID: " + baseplanID + ". CourseID: " + bp_Course.Id + ". ";
                            }
                        }
                        catch
                        {
                            s.CheckDebug = "Feil i uthenting av BasePlan-verdier.";
                            s.CheckResultValue = "0";
                            s.CheckResultValueCSV = "0";
                        }
                    }
                    //}
                }
                catch
                {
                    s.CheckDebug = "Feil i uthenting av BasePlan-verdier.";
                    s.CheckResultValue = "0";
                    s.CheckResultValueCSV = "0";
                }

            }
            else
            {
                s.CheckDiscardedAtRuntime = Constants.True;
                s.CheckDebug = "Feil i uthenting av BasePlan-verdier.";
                s.CheckResultValue = "0";
                s.CheckResultValueCSV = "0";
            }
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(s.CheckResultValue, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);

            return s;
        }

        //Test code to find IMRT merged, copied from JawTracking checkpoint
        public static CheckPoint CheckIMRTMerged(ExternalPlanSetup plan, CheckPoint s, string baseplanID)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            int Feltnnr = 0;
            bool mergedstatus = true;// jaw beveger seg for alle kollimatorer for alle felt i planen
            bool koll_statisk_felt = true; // jaw-tracking paa for alle kollimatorer i feltet

            foreach (Beam felt in plan.Beams)
            {
                //If IMRT or FiF technique (Technique = "STATIC" and MLC = "DoseDynamic)
                if (felt.IsSetupField == false && (felt.Technique.Id.Contains(Constants.Teknikk.IMRT_technique_name_Aria) && felt.MLCPlanType.ToString() == Constants.Teknikk.IMRT_technique_MLCPlanType_name_Aria)) //enten 'ARC' og 'SRS ARC'
                {
                    //Check i main collimators move at all during all controlpoints -> If so, then it is a merged field. If not, then it is not a merged field.

                    Feltnnr = Feltnnr + 1;
                    // til debug:   MessageBox.Show(felt.Id.ToString());
                    int teller = 0;
                    bool x1_statisk, x2_statisk, y1_statisk, y2_statisk; //er kollimatoren statisk gjennom alle kontrollpunkt?
                    int cp_max = felt.ControlPoints.Count;
                    double[,] arrayCP = new double[4, cp_max];

                    foreach (ControlPoint cp in felt.ControlPoints)
                    {
                        arrayCP[0, teller] = cp.JawPositions.X1;
                        arrayCP[1, teller] = cp.JawPositions.X2;
                        arrayCP[2, teller] = cp.JawPositions.Y1;
                        arrayCP[3, teller] = cp.JawPositions.Y2;
                        if (teller > 0)
                        {
                            x1_statisk = arrayCP[0, 0].Equals(arrayCP[0, teller]);
                            x2_statisk = arrayCP[1, 0].Equals(arrayCP[1, teller]);
                            y1_statisk = arrayCP[2, 0].Equals(arrayCP[2, teller]);
                            y2_statisk = arrayCP[3, 0].Equals(arrayCP[3, teller]);
                            // til debug:  if (teller == 1 || teller == 45 || teller == 75) { MessageBox.Show("cp x1,x2,y1,y2 " + teller + ": "+x1_statisk.ToString() + " " + x2_statisk.ToString() + " " + y1_statisk.ToString() + " " + y2_statisk.ToString()); }
                            if (x1_statisk == true && x2_statisk == true && y1_statisk == true && y2_statisk == true)
                            {
                                //koll_statisk_felt = true; //endrer aldri tilbake til true
                            }
                            else
                            {
                                koll_statisk_felt = false; //kan legge inn skippe til neste felt hvis false?
                            }
                            //til debug:  if (teller == 1 || teller == 75) { MessageBox.Show("koll_statisk_felt cp " + teller + ": " + koll_statisk_felt.ToString()); }
                        }
                        teller = teller + 1;
                    }


                    //---- //skrive ut array til en messagebox for debugging:
                    for (int i = 0; i < arrayCP.GetLength(0); i++)
                    {
                        string teststr = "";
                        for (int j = 0; j < arrayCP.GetLength(1); j++)
                        {
                            teststr = teststr + ", " + arrayCP[i, j];
                        }
                        //til debug:  MessageBox.Show(teststr);
                    }
                    //--------------------------------------------------------

                    //hvis det er ingen kontrollpunkter settes statusen til false.
                    if (GeneralExtension.ArrayIsNullOrEmpty(arrayCP)) { mergedstatus = false; }
                }
                //endelig status - hvis bare en kollimator paa ett felt ikke beveger seg, vild den si at jaw-tracking er false.
                if (koll_statisk_felt == true)
                {
                    mergedstatus = false;
                }
                else
                {
                    //jawtrackingstatus = true; //endrer aldri tilbake til true
                }
                //hvis det er ingen imrt felt overhode maa status settes til false igjen:
                if (Feltnnr == 0) { mergedstatus = false; }
            }




            //Setter
            //endelig resultat:
            if (mergedstatus == true)
            {
                s.CheckStatus = s.CheckTrafficLight;
                s.CheckResultValue = "IMRT-felt merged.";
                s.CheckComment = "IMRT-felt er merged.";
            }
            else
            {
                
                s.CheckStatus = Constants.Ok;
                s.CheckResultValue = "IMRT-felt ikke merged";
                s.CheckDiscardedAtRuntime = Constants.True;
            }
            return s;
        }

        public static CheckPoint CheckMobius(ExternalPlanSetup plan, CheckPoint s)
        {

           //DateTime latestTime = new DateTime(1066, 1, 1);

            string ID_pas = plan.Course.Patient.Id.ToString();
            DateTime crt = (DateTime)plan.CreationDateTime;
            string path = Constants.MobiusPath;


            //Generate expected PlanId in pdf name in Mobius
            string korr_planID = plan.Id;
            korr_planID = korr_planID.Replace("ø", "_");
            korr_planID = korr_planID.Replace("æ", "_");
            korr_planID = korr_planID.Replace("å", "_");
            korr_planID = korr_planID.Replace("Ø", "_");
            korr_planID = korr_planID.Replace("Æ", "_");
            korr_planID = korr_planID.Replace("Å", "_");
            korr_planID = korr_planID.Replace(" ", "_");
            korr_planID = korr_planID.Replace(":", "_"); // Plan revisjon
            korr_planID = korr_planID.Replace("#", "_"); // 
            korr_planID = korr_planID.Replace("-", "_"); //

            //string searchTerm = "*" + ID_pas + "*";
            string searchTerm = ID_pas; //contains
            string debugTime = "";
            if (Directory.Exists(path))
            {
                var stopwatch1 = Stopwatch.StartNew();
                path = FindDirectoryWithFile(path, searchTerm);
                stopwatch1.Stop();
                debugTime = debugTime + "(Debugging runtime info: FindDirectoryWithFile = " + stopwatch1.ElapsedMilliseconds.ToString() + "ms. " ;
                if (path == null) { path = ""; } // if file does not exist, return empty directory

                //search first top directory, only if not found there, search all directories. Modify checkpoint with answer:
                var stopwatch2 = Stopwatch.StartNew();
                s = SearchDirectoryForMobiusFile(path, crt, searchTerm, ID_pas, s, korr_planID, false); //s = SearchDirectoryForMobiusFile(path, crt, latestTime, searchTerm, ID_pas, s, korr_planID, false);
                stopwatch2.Stop();
                debugTime = debugTime + "SearchDirectoryForMobiusFile = " + stopwatch2.ElapsedMilliseconds.ToString() + "ms.)";
                s.CheckComment = s.CheckComment + Environment.NewLine + debugTime;
            }
            else 
            { //Inactivate checkpoint
                s.CheckDiscardedAtRuntime = Constants.True; //Change. We want to see that Mobius is not  done!
                s.CheckResultRawValue = "";
                s.CheckDebug = s.CheckDebug + Environment.NewLine + "'CheckMobius' deaktivert fordi den ikke fant folderen med Mobius-pdfer."; //This is not visible in Debug??
            }
            s.CheckResultValueCSV = s.CheckResultValue;
            return s;
        }


        //returns the directory that cointains at least one file with search term
        public static string FindDirectoryWithFile(string rootPath, string searchTerm)
        {

            var stack = new Stack<string>();
            stack.Push(rootPath);

            while (stack.Count > 0) //while any directoryis still in stack
            {
                //retrieve and remove current directory
                var dir = stack.Pop();



                var files = Directory.EnumerateFiles(dir);
                    //.OrderByDescending(File.GetLastWriteTimeUtc);

                //Check current directory
                foreach (var file in files)
                {
                    if (Path.GetFileName(file).Contains(searchTerm))
                        //MessageBox.Show("dir: " + dir + Environment.NewLine + "file: " + file);
                        return dir;
                }

                //2. Add subdirectories if avaliable - newest first, so it is always the newst folder we return with patient
                var dirs = Directory.EnumerateDirectories(dir)
                .OrderByDescending(Directory.GetLastWriteTimeUtc);

                foreach (var subDir in dirs)
                {
                    stack.Push(subDir); // newest pushed first = processed first
                }
            }

            return null;
        }


        public static CheckPoint SearchDirectoryForMobiusFile(string path, DateTime crt,  string searchTerm, string ID_pas, CheckPoint s, string korr_planID, bool ID_Found) //DateTime latestTime,
        {

            //directories
            //bool ID_found = false;
            int numberOfFilesMatching = 0; // in this directory
            int numberOfFilesContainsSearchTerm = 0; // in this directory
            int numberOfFilesAlmostMatching = 0;
            string tempCommentNotMatchingPlan = "";
            DateTime latestTime = new DateTime(1066, 1, 1);
            string latestFile = "";
            string fileName = "";

            //MessageBox.Show("path: " + path);
            if (path != "")
            {

                // 1. Search directory
                foreach (var file in Directory.EnumerateFiles(path))
                {
                    //----------------------------------------------
                    //If we found correct ID
                    //----------------------------------------------
                    string tempfileName = Path.GetFileName(file);
                    if (tempfileName.Contains(searchTerm))
                    {
                        numberOfFilesContainsSearchTerm = numberOfFilesContainsSearchTerm + 1;


                        if (tempfileName.Contains("Plan_Check"))
                        {


                            //Extract data from this file and modify CheckPoint
                            fileName = tempfileName;

                            //----------------------------------------------
                            //Extract data
                            //-----------------------------------------------

                            string temp_dat = "";
                            string temp_planID = "";

                            //if (fileName.Contains("Plan_Check")) //Then only those that are "Plan_Check" files
                            //{
                            if (s.CheckDebug != "") { s.CheckDebug = s.CheckDebug + Environment.NewLine; }
                            s.CheckDebug = s.CheckDebug + fileName; //Til kommentar hvis ingen perfekt match

                            //Dato fra fil-skaperdato.
                            DateTime dt = File.GetCreationTime(file);
                            temp_dat = dt.ToString();
                            var diffDato = dt - crt;
                            int diffDays = diffDato.Days;

                            //MV-navn p navn
                            int pFrom = file.IndexOf(ID_pas) + ID_pas.Length;
                            int pTo = file.LastIndexOf("--Plan_Check");

                            temp_planID = file.Substring(pFrom, pTo - pFrom);



                            if (temp_planID.Contains(korr_planID))
                            {
                                if (dt >= latestTime)
                                {
                                    latestTime = dt;
                                    latestFile = file;

                                }

                                numberOfFilesMatching = numberOfFilesMatching + 1;
                                s.CheckResultValue = Constants.True;
                                s.CheckStatus = Constants.Ok;
                                if (s.CheckComment != "" && s.CheckComment != null) { s.CheckComment = s.CheckComment + Environment.NewLine; }
                                s.CheckComment = s.CheckComment + "PlanID: " + korr_planID + "    Dato: " + temp_dat + " (" + diffDays + " døgn etter plan ble skapt). ";
                                s.CheckDebug = s.CheckDebug + "Temp_planID: " + temp_planID + ".";

                                if (diffDays > 30 || diffDays < -30)
                                {//Skriver dato
                                    s.CheckComment = s.CheckComment + "Advarsel: over 30 dager forskjell mellom når Mobius-fil er generert og plan skapt.";
                                }
                            }
                            else if (s.CheckResultValue != Constants.True)
                            {
                                numberOfFilesAlmostMatching = numberOfFilesAlmostMatching + 1;
                                s.CheckResultValue = Constants.False;
                                s.CheckStatus = Constants.Warning;
                                if (numberOfFilesAlmostMatching > 1) { tempCommentNotMatchingPlan = tempCommentNotMatchingPlan + Environment.NewLine; }
                                tempCommentNotMatchingPlan = tempCommentNotMatchingPlan + fileName;
                            }
                            //------------------------------------------------
                            ID_Found = true;// stop search in further folders
                        }

                    }
                }
            }
           

            ////----------------------------------------------
            //// 2. Only search subdirectories if not found in the last one.
            ////----------------------------------------------
            //int directoryNumber = 0;
            //int numDirectories = 0;
            //if (ID_Found == false)
            //{
                
            //    numDirectories = Directory.EnumerateDirectories(path).Count();
            //    foreach (var dir in Directory.EnumerateDirectories(path))
            //    {
            //        directoryNumber = directoryNumber + 1;
            //        //continue to sub directory
            //        s = SearchDirectoryForMobiusFile(dir, crt, searchTerm, ID_pas, s, korr_planID, ID_Found); //restart search in new folder.
            //    }
            //}
            //else
            //{}
            
            //Set final status:

                s = SetFinalMobiusStatus(s, numberOfFilesMatching, numberOfFilesContainsSearchTerm, numberOfFilesAlmostMatching, tempCommentNotMatchingPlan); //Dependant of number of matches
                //Debug:
                //MessageBox.Show("ID_pas:" + ID_pas + Environment.NewLine + "searchTerm:" + searchTerm + Environment.NewLine + "numberOfFilesContainsSearchTerm:" + numberOfFilesContainsSearchTerm + Environment.NewLine + "last fileName match:" + fileName + Environment.NewLine + "latestTime:" + latestTime.ToShortDateString() + Environment.NewLine + "path:" + path + Environment.NewLine + "numberOfFilesMatching:" + numberOfFilesMatching + Environment.NewLine + "s.CheckComment:" + s.CheckComment + Environment.NewLine + "s.CheckDebug:" + Environment.NewLine + s.CheckDebug);
  


            return s;
        }

        //Extract data from singe Mobius pdf file:
        public static CheckPoint ExtractMobiusData(CheckPoint s, string file, string fileName, DateTime crt, string ID_pas, string korr_planID)
        {

            //string latestFile = "";

            int ant = 0;
            string temp_dat = "";
            string temp_planID = "";

            //if (fileName.Contains("Plan_Check")) //Then only those that are "Plan_Check" files
            //{
                if (s.CheckDebug != "") { s.CheckDebug = s.CheckDebug + Environment.NewLine; }
                s.CheckDebug = s.CheckDebug + fileName; //Til kommentar hvis ingen perfekt match
                //s.CheckDebug = s.CheckDebug + fileName + Environment.NewLine;
                //DATO fra filnavnet
                //var sbStr = filename.Substring(filename.LastIndexOf("--") + 1);
                //if (sbStr == filename) //Hvis den feiler er stringene like
                //{
                //    s.SjekkDebug = s.SjekkDebug + "Fant ikke StrDate i filnavnet på Mobius folder. ";
                //}
                //temp_dat = sbStr; //fra dette året til ".pdf"

                //Dato fra fil-skaperdato.
                DateTime dt = File.GetCreationTime(file);
                temp_dat = dt.ToString(); //dt.Date.ToString() + " " + dt.Hour.ToString() + ":" + dt.Minute.ToString();
                var diffDato = dt - crt;
                int diffDays = diffDato.Days;

                //MV-navn p navn
                int pFrom = file.IndexOf(ID_pas) + ID_pas.Length;
                int pTo = file.LastIndexOf("--Plan_Check");

                temp_planID = file.Substring(pFrom, pTo - pFrom);



                if (temp_planID.Contains(korr_planID))
                {
                    //if (dt >= latestTime)
                    //{
                    //    latestTime = dt;
                    //    latestFile = file;

                    //}

                    ant = ant + 1;
                    s.CheckResultValue = Constants.True;
                    s.CheckStatus = Constants.Ok;
                    if (s.CheckComment != "" && s.CheckComment != null) { s.CheckComment = s.CheckComment + Environment.NewLine; }
                    s.CheckComment = s.CheckComment + "PlanID: " + korr_planID + "    Dato: " + temp_dat + " (" + diffDays + " døgn etter plan ble skapt). ";
                    s.CheckDebug = s.CheckDebug + "Temp_planID: " + temp_planID + ".";

                    if (diffDays > 30 || diffDays < -30)
                    {//Skriver dato
                        s.CheckComment = s.CheckComment + "Advarsel: over 30 dager forskjell mellom når Mobius-fil er generert og plan skapt.";
                    }
                }
                else if (s.CheckResultValue != Constants.True)
                {
                    s.CheckResultValue = Constants.False;
                    s.CheckStatus = Constants.Warning;
                    s.CheckComment = s.CheckComment + fileName; //Closest match
                //s.SjekkKommentar = s.SjekkKommentar + "Navn og PlanID (feil):" + temp_planID + Environment.NewLine + "Dato: " + temp_dat;
                 }

            //}

            return s;
        }

        public static CheckPoint SetFinalMobiusStatus(CheckPoint s, int numberOfFilesMatching, int numberOfFilesContainsSearchTerm, int numberOfFilesAlmostMatching, string tempCommentNotMatchingPlan)
        {
           
            if (numberOfFilesMatching == 0)
            {
                s.CheckDebug = s.CheckDebug + " Antall treff = 0. ";
                s.CheckResultValue = Constants.False; //Fail
                s.CheckStatus = Constants.Warning;
                //s.CheckResultRawValue = "";
                s.CheckDebug = s.CheckDebug + "Fant ikke planID i filnavnet.";
                //Flere detaljer hvis vi fant en fil som er nesten korrekt:
                if (tempCommentNotMatchingPlan != "" && tempCommentNotMatchingPlan != null)
                {
                    //Fant noe som nesten stemmer....
                    s.CheckComment = "Fant ikke planrapport for akkurat denne planen i Mobius, men pasienten har " + numberOfFilesAlmostMatching + " andre planrapporter i Mobius." + Environment.NewLine + "PlanID i filnavnet matcher ikke med planID i Eclipse. Disse filene finnes i Mobius: " + Environment.NewLine + tempCommentNotMatchingPlan;
                }
                else
                {
                    s.CheckComment = "Fant ingen planrapport i Mobius på denne pasienten!";
                }
               
            }
            else if (numberOfFilesMatching == 1)
            {
                //s.CheckComment = s.CheckComment + tempKommentar;
                //s.CheckResultRawValue = latestFile;
                //Sjekk ogsaa mot dato og MV
            }
            else //Flere
            {
                s.CheckComment = "OBS! Antall Mobius-sjekker på denne plan: " + numberOfFilesMatching + Environment.NewLine + s.CheckComment;
                s.CheckStatus = Constants.Warning;
                //s.CheckResultRawValue = latestFile;
            }

            return s;
        }

        //if(!Directory.Exists(path))

        public static CheckPoint CheckCollimatorAngle(ExternalPlanSetup plan, CheckPoint s, List<Field> Feltliste)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            bool resultat = true;
            double _collVinkel = 0;
            string _feltoppsummering = "";

            int antallfelt = Feltliste.Count();
            int i = 0;

            _feltoppsummering = GeneralExtension.FormatString(18, 18, "Felt:" + Constants.StringSeparator + "Kol.vinkel:") + Environment.NewLine; //Header   GeneralExtension.GenerateTableLine(4, 4, "Felt:" + Constants.StringSeparator + "Kol.vinkel:") + Environment.NewLine; //Header
                                                                                                                                                     // _feltoppsummering = "Feltnavn: " + "\t\t" + "Kollimatorvinkel:" + Environment.NewLine;

            foreach (Field f in Feltliste)
            {
                //Only relevant for IMRTs/ARCs
                if(f.FieldTechniqueName == Constants.Teknikk.Arc_technique_forklaring || f.FieldTechniqueName == Constants.Teknikk.FiF_technique_forklaring || f.FieldTechniqueName == Constants.Teknikk.IMRT_Hybrid_technique_forklaring || f.FieldTechniqueName == Constants.Teknikk.IMRT_technique_forklaring || f.FieldTechniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring || f.FieldTechniqueName == Constants.Teknikk.TotalBody_technique_forklaring )
                {

                
                    i = i + 1;
                    bool test = false;
                    test = Double.TryParse(f.FieldCollimatorAngle, NumberStyles.Number, CultureInfo.InvariantCulture, out _collVinkel);
                    if (test == true)
                    {
                        if (_collVinkel >= 2 && _collVinkel <= 358)
                        {
                            if (resultat != false)
                            {
                                resultat = true;
                            }
                            else
                            {
                                s.CheckComment = s.CheckComment + "Kollimatorvinkel <2° for " + f.FieldID + "(Kollimator:" + f.FieldCollimatorAngle + "°). ";
                            }
                        }
                        else
                        {
                            resultat = false;
                        }
                        //_tempfeltoppsum = f.FeltID + "(" + f.Collimatorvinkel + ")";
                        //if (_feltoppsummering == "")
                        //{
                        //}  
                        _feltoppsummering = _feltoppsummering + GeneralExtension.FormatString(18, 18, f.FieldID + Constants.StringSeparator + f.FieldCollimatorAngle + "°");  //Data
                        s.CheckResultValueCSV = s.CheckResultValueCSV + f.FieldCollimatorAngle + Constants.StringSeparator; //Kun kollimatorverdiene.
                        if (i < antallfelt) { _feltoppsummering = _feltoppsummering + Environment.NewLine; } //Legger til new line etter så lenge ikke siste felt i listen.
                    }
                }
            }
            if (resultat == false)
            {
                s.CheckStatus = s.CheckTrafficLight;
            }
            else
            {
                s.CheckStatus = Constants.Ok;
            }
            s.CheckResultValue = _feltoppsummering;

            return s;
        }

        public static CheckPoint CheckWedge(ExternalPlanSetup plan, CheckPoint s, List<Field> Feltliste)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            string _mu = "";
            double _mu_dbl = 0;
            string _kile = "";
            string _feltID = "";
            string _feltoppsummering = "";
            string _statusKile = Constants.Ok;
            string _kommentar = "";
            string resultatCSV = "";
            bool test = false;

            _feltoppsummering = GeneralExtension.FormatString(20, 20, "Feltnavn: " + Constants.StringSeparator + "Kile: " + Constants.StringSeparator + "MU: "); //Header
            //_feltoppsummering = Hjelpefunksjoner.GenerateTableLine(15, 1, "Feltnavn: " + Constants.StringSeparator + "Kile: " + Constants.StringSeparator + "MU: "); //Header
            //Sjekker alle kilefelt
            foreach (Field f in Feltliste.Where(x => x.FieldWedge != ""))
            {

                _feltID = f.FieldID;
                _mu = f.FieldMU; //Ikke enhet
                _kile = f.FieldWedge;
                test = double.TryParse(_mu, out _mu_dbl);
                if (test == true)
                {
                    _mu = Math.Round(_mu_dbl, 1).ToString(); //redigerer til kun 1 desimal.
                }
                //resultat

                //-----  Data ------
                _feltoppsummering = _feltoppsummering + Environment.NewLine + GeneralExtension.FormatString(20, 20, _feltID + Constants.StringSeparator + _kile + Constants.StringSeparator + _mu);  //Data
                if(resultatCSV != "") { resultatCSV = resultatCSV + "|"; }
                resultatCSV = resultatCSV + _mu;
                //_feltoppsummering = _feltoppsummering + Environment.NewLine + Hjelpefunksjoner.GenerateTableLine(15, 1, _feltID + Constants.StringSeparator + _kile + Constants.StringSeparator + _mu);

                //_mu_dbl = Convert.ToDouble(_mu);
                if (test == true)
                {
                    if (_mu_dbl >= Constants.Tolerance_Minimum_MU_Wedge)
                    {
                        _statusKile = Constants.Ok;
                    }
                    else
                    {
                        _statusKile = s.CheckTrafficLight;
                        _kommentar = _kommentar = "Felt " + _feltID + " (" + _kile + ") har MU < " + Constants.Tolerance_Minimum_MU_Wedge + "! MU = " + _mu + "MU. ";
                    }
                }

            }

            //sende resultat
            s.CheckResultValue = _feltoppsummering;
            s.CheckStatus = _statusKile;
            s.CheckComment = _kommentar;
            s.CheckResultValueCSV = resultatCSV;
            return s;
        }



        public static List<Fractionation> ConvertStringToFractionationClass(string fraksj)
        {
            string frD = "";
            string nFr = "";
            string totD = "";
            int pFrom;
            int pTo;
            char[] separators = new char[] { Constants.CharSeparator };

            List<string> _FrListeStr = fraksj.Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
            List<Fractionation> _FrListe = new List<Fractionation>();

            //Sjekker listen av fraksjoneringener.
            foreach (string fr in _FrListeStr)
            {
                try
                {
                    frD = fr.Substring(0, fr.IndexOf("Gy x")); //This will crash if there is no "Gy x" !
                }
                catch 
                {
                    MessageBox.Show("Feil i fraksjoneringen i templatet. Ingen fraksjonsdose: " + fr + ". Setter fraksjonsdose til 0.");
                    frD = "0";
                 }

                //MessageBox.Show(frD);
                //frD = fr.Substring(0, 5);

                try
                {
                    pFrom = fr.IndexOf("Gy x ") + "Gy x ".Length;
                    pTo = fr.LastIndexOf(" = ");
                    int length = pTo - pFrom;
                    if (length < 0) 
                    { length = 0;
                        MessageBox.Show("Failed to convert fractionation string to fractionation class when loading template. Skips this fractionation in loading. Format required: 'XGy x Y = ZGy'. Please review template for incorrect input here: " + fraksj);
                    }
                    nFr = fr.Substring(pFrom, pTo - pFrom);
                    // MessageBox.Show(nFr);
                    //nFr = fr.Substring(11, 2);

                    //pFrom = fr.IndexOf(" = ") + " = ".Length;
                    //pTo = fr.Length;
                    //totD = fr.Substring(pFrom, pTo - pFrom);

                    string temp = fr.Replace("Gy", "");
                    var n = temp.LastIndexOf("= ");
                    totD = temp.Substring(n + 1);
                    //MessageBox.Show(totD);

                    _FrListe.Add(new Fractionation()
                    {
                        DosePerFraction = frD,
                        TotalDose = totD,
                        NumberOfFractions = nFr,
                    });
                }
                catch{ MessageBox.Show("Failed to convert fractionation string when loading template. Skips this fractionation. Please check template for incorrect input: " + fraksj); }


            }

            return _FrListe;
        }
        //StringTilFraksjonering

        public static CheckPoint CheckNormalizationMethod( CheckPoint s, ExternalPlanSetup plan)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            //To do: ELEKTRONER
            // different normalization.

            string normalizationMethod = PlanExtension.NormalizationMethod(plan);
            s.CheckResultValue = normalizationMethod;
            s.CheckResultValueCSV = normalizationMethod;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(normalizationMethod, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            return s;
        }

        public static string NormalizationMethod(ExternalPlanSetup plan)
        {
            string normalisering = plan.PlanNormalizationMethod.ToString();
            return normalisering;

        }
        public static string NormaliseringsIkkeSatt(ExternalPlanSetup planen)
        {
            bool _normaliseringIkkeSatt = false;
            string normalisering = planen.PlanNormalizationMethod.ToString();
            if (normalisering.Contains("No plan normalization") | normalisering.Contains("Plan Normalization Value"))
            {
                _normaliseringIkkeSatt = true;
            }

            return _normaliseringIkkeSatt.ToString();
        }
        public static string NormaliseringsUnormal(ExternalPlanSetup planen, string TeknikkForklaring, string MaskinID)
        {
            bool _normaliseringUnormal = false;
            string normalisering = planen.PlanNormalizationMethod.ToString();

            if (!normalisering.Contains("100.00% covers 50.00% of Target Structure") && !(TeknikkForklaring == "SRS VA"))
            {//om ikke 100.00% covers 50.00% of Target Structure og det ikke er stereotaksi
                _normaliseringUnormal = true;
            }

            if (normalisering.Contains("100.00% covers 50.00% of Target Structure") && (TeknikkForklaring == "SRS VA"))
            {//om 100.00% covers 50.00% of Target Structure og det er stereotaksi
                _normaliseringUnormal = true;
            }

            //Om ikke 100.00% covers 95.00% of Target Structure og det er stereotaksi
            if ((!(normalisering.Contains("100.00% covers 95.00% of Target Structure")) && (TeknikkForklaring == "SRS VA")))
            {
                _normaliseringUnormal = true;
            }

            if (NormaliseringsIkkeSatt(planen) == "true")
            {
                _normaliseringUnormal = true;
            }

            return _normaliseringUnormal.ToString();
        }

        public static string NormaliseringsUnormalForklaring(ExternalPlanSetup planen, string TeknikkForklaring, string MaskinID)
        {
            string _normaliseringUnormalForklaring = "";
            string normalisering = planen.PlanNormalizationMethod.ToString();

            if (!normalisering.Contains("100.00% covers 50.00% of Target Structure") && !(TeknikkForklaring == "SRS VA"))
            {//om ikke 100.00% covers 50.00% of Target Structure og det ikke er stereotaksi
                _normaliseringUnormalForklaring = "Normalisering er ikke 100%=50%!";
            }

            if (normalisering.Contains("100.00% covers 50.00% of Target Structure") && (TeknikkForklaring == "SRS VA"))
            {//om 100.00% covers 50.00% of Target Structure og det er stereotaksi
                _normaliseringUnormalForklaring = "Normalisering er 100%=50% for SRS teknikk!";
            }

            //Om ikke 100.00% covers 95.00% of Target Structure og det er stereotaksi
            if ((!(normalisering.Contains("100.00% covers 95.00% of Target Structure")) && (TeknikkForklaring == "SRS VA")))
            {
                _normaliseringUnormalForklaring = "Normalisering er ikke 100%=95% for SRS teknikk!";
            }

            return _normaliseringUnormalForklaring;
        }

        public static CheckPoint CheckCalculationAlgorithm(CheckPoint s, ExternalPlanSetup plan, string technique)
        {
            string calculationAlgorithm = PlanExtension.CalculationAlgorithm(plan, technique);
            if (calculationAlgorithm == "")
            { s.CheckComment = "Klarer ikke detektere beregningsalgoritme!"; }
            s.CheckResultValue = calculationAlgorithm;
            s.CheckResultValueCSV = calculationAlgorithm;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(calculationAlgorithm, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            return s;
        }

        public static string CalculationAlgorithm(ExternalPlanSetup plan, string technique)
        {
            string algo = "";

            //string _teknikk = SjekkTeknikk(plan); //Trengs for aa skille elektronplan og fotonplan

            //Forbedring: Her maa vi handtere om det er en protonplan paa bedre maate enn try - catch.
            if (technique == Constants.Teknikk.Electron_technique_forklaring)
            {   //Elektroner
                algo = plan.ElectronCalculationModel.ToString();
            }
            else
            {   //Fotoner
                try
                {
                    algo = plan.PhotonCalculationModel.ToString();
                    //string test = plan.PhotonCalculationOptions["CalculationGridSizeInCM"];
                }
                catch
                {
                    //Protoner 
                    try
                    {
                        algo = plan.ProtonCalculationModel.ToString(); //This requires plan to be a class "IonPlanSetup", which it is currently not. Will not work now.
                    }
                    catch //Enything else to think about? 
                    {
                    }
                }
            }
            return algo;
        }


        public static string GetOptimizationApertureShapeControllerLevel(ExternalPlanSetup plan)
        {
            //Only for VMAT optimation - should there be som validation here?
            string calculation_model = plan.GetCalculationModel(CalculationType.PhotonVMATOptimization);
            plan.GetCalculationOption(calculation_model, "ApertureShapeController", out string apertureShapeController);
            //string _teknikk = SjekkTeknikk(plan); //Trengs for aa skille elektronplan og fotonplan


            return apertureShapeController;
        }

        public static CheckPoint CheckCalculationResultion(CheckPoint s, ExternalPlanSetup plan, string technique)
        {
            string calculatinResuloution = PlanExtension.CalculationResultion(plan, technique); //trenger ikke sende teknikk som parameter
            if (calculatinResuloution == "")
            { s.CheckComment = "Klarer ikke detektere kalkuleringsoppløsning!"; }
            s.CheckResultValue = calculatinResuloution;
            s.CheckResultValueCSV = calculatinResuloution;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(calculatinResuloution, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            return s;
        }

        public static string CalculationResultion(ExternalPlanSetup plan, string _teknikk)
        {
            string resolution = "";
            //Alternativ:   resolution = plan.PhotonCalculationOptions["CalculationGridSizeInCM"];  //Men da må man håndtere spesifikt hvilken type kalkulering det er. Fotoner vs elektroner etc.
            resolution = (plan.Dose.XRes / 10).ToString(); //Oppløsning i cm. Bedre losning
            return resolution;
        }

        public static string PrintClinicalGoals(ExternalPlanSetup plan) //Just testing, for fun
        {
            string clinicalGoalsResult = "";
            List<ClinicalGoal> clinicalGoals = plan.GetClinicalGoals();
            foreach (ClinicalGoal clinicalGoal in clinicalGoals)
            {
                //clinicalGoalsResult = clinicalGoalsResult + clinicalGoal.StructureId + " " + clinicalGoal.MeasureType + " " +  clinicalGoal.Objective.ToString() + " "  + clinicalGoal.VariationAcceptable.ToString() + Environment.NewLine; //etc.

            }

            return clinicalGoalsResult;
        }

        public static bool Does180DegreeStaticFieldExist(string teknikk, List<Field> feltliste)
        {
            List<Field> f180 = (List<Field>)feltliste.Where(x => x.FieldGantryAngle.Contains("180")).ToList();
            int count = f180.Count();
            bool eksisterer_180_felt = (count > 0);

            bool teknikk_statiske_felt = (teknikk == Constants.Teknikk.FiF_technique_forklaring) || (teknikk == Constants.Teknikk.IMRT_technique_forklaring) || (teknikk == Constants.Teknikk.IMRT_Hybrid_technique_forklaring) || (teknikk == Constants.Teknikk.Static_technique_forklaring);

            return (eksisterer_180_felt) && (teknikk_statiske_felt);
        }
        public static FieldsAnalysis AnalyzeFields(string teknikk, List<Field> feltliste, ExternalPlanSetup plan)
        {
            List<Field> f180 = (List<Field>)feltliste.Where(x => x.FieldGantryAngle.Contains("180")).ToList();
            int count = f180.Count();
            bool eksisterer_180_felt = (count > 0);
            bool teknikk_statiske_felt = (teknikk == Constants.Teknikk.FiF_technique_forklaring) || (teknikk == Constants.Teknikk.IMRT_technique_forklaring) || (teknikk == Constants.Teknikk.IMRT_Hybrid_technique_forklaring) || (teknikk == Constants.Teknikk.Static_technique_forklaring);
            bool gantryvinkel_konvertert = false;
            string gantryvinkel_vekting_res = "";
            double gantryvinkelscore = 0;
            string extended_status_felt = "";
            string lat = "";
            string uthentet_verdi = "";

            string optimal_extended_status = "";
            string beamExtendedAnalysis = "";
            string beamExtendedAnalysisCSV = "";
            string utdypning = "";


            //-------------------------------------
            //Create FieldAnalysis
            //-------------------------------------
            var f_analyse = new FieldsAnalysis
            {
                GantryWeight = "",
                Extended_180_field = "",
                PlanLaterality = "",
                PlanLaterality_cm = "",
                PatientOrientation = "",
                ExtractedValue = "",
                ExtractedValueCSV = "",
                Elaboration = "",
                OptimalExtendedStatusFromGantryWeight = "",
                OptimalExtendedStatusFromLaterality = "",
            };


            //-------------------------------------
            //Pasientorientering:
            //-------------------------------------
            string pasorient = PlanExtension.GetPlanPatientOrientation(plan).ToString();
            // uthentet_verdi = uthentet_verdi + Environment.NewLine + "Pas.Orient: " + pasorient;

            //-------------------------------------
            //henter isosenter og lateralitet:
            //-------------------------------------
            Beam felt = plan.Beams.Where(x => !x.IsSetupField).OrderBy(x => x.BeamNumber).FirstOrDefault();
            if(felt == null)
            {
                felt = plan.Beams.Where(x => x.IsSetupField).OrderBy(x => x.BeamNumber).FirstOrDefault();
            }
            if(felt == null)
            {

            }
            string iso_x = PlanExtension.GetIsosenter(plan, "x", felt);
            string iso_y = PlanExtension.GetIsosenter(plan, "y", felt);
            string iso_z = PlanExtension.GetIsosenter(plan, "z", felt);
            string multipleIsosenter = PlanExtension.MultipleIsosenter(plan); //er det multiple isosenter? true/false.
            var isosenter = new Isosenter
            {
                Iso_x = iso_x,
                Iso_y = iso_y,
                Iso_z = iso_z,
                FieldsHaveSameIsosenter = multipleIsosenter
            };
            //Laterality
            double x_double = GetIsosenter_Double(plan, "x", felt);  //Use different function! Get difference between Isosenter and center of Patient (Either defined as senter of image, or, if Body Exist, midway between Body entry and exit). UserOrigin can be placed in strange places.
            if (x_double > 2.2) //postitiv x = høyre
            {
                lat = Constants.Venstre; ;
            }
            else if (x_double < -2.2) //negativ x = venstre
            { 
                lat = Constants.Hoyre; 
            }
            else { lat = Constants.Medial; }

            lat = CorrectLateralityToPatientOrientation(plan.TreatmentOrientation, lat); //Correcting for a couple of known patient orientations. /image.ImagingOrientation //plan.TreatmentOrientation
                                                                                         //TODO: SHOULD ALSO REFUSE TO CALCULATE IF "WEIRD" PATIENT ORIENTATION!
            utdypning = utdypning + "Lateralitet: " + lat;


            if (eksisterer_180_felt && teknikk_statiske_felt)
            {
                double vekting_270 = 0;
                double vekting_90 = 0;
                string gantryvinkel_string = "";
                double gantryvinkel_double = 0;

                int ant_ext = 0;
                int ant_ikke_ext = 0;

                //-------------------------------------
                //Henter hovedvektingen av feltvinkler
                //-------------------------------------
                foreach (Field f2 in feltliste)
                {
                    gantryvinkel_string = f2.FieldGantryAngle;
                    gantryvinkel_konvertert = Double.TryParse(gantryvinkel_string, out gantryvinkel_double);
                    if (gantryvinkel_konvertert)
                    {
                        if (gantryvinkel_double > 180 && gantryvinkel_double <= 360)
                        {
                            vekting_270 = vekting_270 - gantryvinkel_double + 360; //legger til tall fra 1-179, hoyere desto nearmerere nedenfra.
                        }
                        else if (gantryvinkel_double >= 0 && gantryvinkel_double < 180)
                        {
                            vekting_90 = vekting_90 + gantryvinkel_double; //legger til tall fra 1-179, hoyere desto nearmerere nedenfra.
                        }
                    }
                    else { MessageBox.Show("Klarer ikke konv gantryvinkel " + gantryvinkel_string + "til double."); }
                }
                //sjekker hvilken side vektingen er av felt er hoyest - gantry 90 grader eller 270 grader.
                //Hvis forksjellen er over 20 grader, gir varsel
                if (vekting_270 >= vekting_90 + 20)
                {
                    gantryvinkel_vekting_res = "270";
                    gantryvinkelscore = vekting_270 - vekting_90;
                    optimal_extended_status = "Extended";
                }
                else if (vekting_90 >= vekting_270 + 20)
                {
                    gantryvinkel_vekting_res = "90";
                    gantryvinkelscore = vekting_90 - vekting_270;
                    optimal_extended_status = "ikke Extended";
                }
                else
                {
                    gantryvinkel_vekting_res = "0";
                    gantryvinkelscore = (vekting_90 >= vekting_270) ? vekting_90 - vekting_270 : vekting_270 - vekting_90;
                    optimal_extended_status = "ingen";
                }
                f_analyse.OptimalExtendedStatusFromGantryWeight = optimal_extended_status;

                //-------------------------------------
                //Henter total extendedstatus 180-felt 
                //-------------------------------------


                //Data
                foreach (Field f1 in f180)
                {
                    if (beamExtendedAnalysisCSV != "" && beamExtendedAnalysisCSV != null) { beamExtendedAnalysisCSV = beamExtendedAnalysisCSV + Constants.StringSeparator; }
                    if (f1.FieldExtended == Constants.True)
                    {
                        ant_ext = ant_ext + 1;
                    }
                    else
                    {
                        ant_ikke_ext = ant_ikke_ext + 1;
                    }

                }

                //Extended status
                if ((ant_ext > 0) && (ant_ikke_ext == 0))
                { extended_status_felt = Constants.True; }
                else if ((ant_ikke_ext > 0) && (ant_ext == 0))
                { extended_status_felt = Constants.False; }
                else
                { extended_status_felt = "Mix"; }



                ////gantryvinkel_vekting_res = "90";
                //utdypning = utdypning + Environment.NewLine + "Feltene er vinklet mest mot: " + gantryvinkel_vekting_res + " gantry-retning."; //Should be editet
                //utdypning = utdypning + Environment.NewLine + "Optimal extended-status mtp. feltvinkler: " + optimal_extended_status + ".";

            }



            //-------------------------------------
            //sender resultat tilbake
            //-------------------------------------
            //var f_analyse = new FieldsAnalysis
            //{
            f_analyse.GantryWeightScore = gantryvinkelscore;
            f_analyse.GantryWeight = gantryvinkel_vekting_res;
            f_analyse.Exist_180_field = eksisterer_180_felt;
            f_analyse.Extended_180_field = extended_status_felt;
            f_analyse.PlanIsosenter = isosenter;
            f_analyse.PlanLaterality = lat;
            f_analyse.PlanLaterality_cm = x_double.ToString();
            f_analyse.PatientOrientation = pasorient;
            f_analyse.ExtractedValue = uthentet_verdi;
            f_analyse.ExtractedValueCSV = beamExtendedAnalysisCSV;
            f_analyse.Elaboration = utdypning;
            //};

            //Analyserer videre resultatet, setter kommentar og warning
            f_analyse = PlanExtension.AnalyzeGantryAngleWeighting(f_analyse);

            if(f_analyse.OptimalExtendedStatusFromLaterality == "Extended")
            {
                f_analyse.OptimalExtendedStatus = "Extended";
            }
            else if(f_analyse.OptimalExtendedStatusFromLaterality == "ikke Extended")
            {
                f_analyse.OptimalExtendedStatus = "ikke Extended";
            }

            if (eksisterer_180_felt && teknikk_statiske_felt)
            {

                //-------------------------------------
                //Printer tabell:
                //-------------------------------------

                //Header
                beamExtendedAnalysis = GeneralExtension.FormatString(20, 18, "Feltnavn: " + Constants.StringSeparator + "Status: " + Constants.StringSeparator + "Opt. feltvekting:" + Constants.StringSeparator + "Opt. lateralitet:"); //Header

                //Data
                foreach (Field f1 in f180)
                {
                    if (beamExtendedAnalysisCSV != "" && beamExtendedAnalysisCSV != null) { beamExtendedAnalysisCSV = beamExtendedAnalysisCSV + Constants.StringSeparator; }
                    if (f1.FieldExtended == Constants.True)
                    {
                        beamExtendedAnalysis = beamExtendedAnalysis + Environment.NewLine + GeneralExtension.FormatString(20, 18, f1.FieldID + Constants.StringSeparator + "Extended" + Constants.StringSeparator + f_analyse.OptimalExtendedStatusFromGantryWeight + "  " + Constants.StringSeparator + f_analyse.OptimalExtendedStatusFromLaterality + "  " );  //Data

                        beamExtendedAnalysisCSV = beamExtendedAnalysisCSV + "Extended" + ":" + f_analyse.OptimalExtendedStatusFromGantryWeight + ":" + f_analyse.OptimalExtendedStatusFromLaterality; //+ Constants.StringSeparator
                    }
                    else
                    {
                        beamExtendedAnalysis = beamExtendedAnalysis + Environment.NewLine + GeneralExtension.FormatString(20, 18, f1.FieldID + Constants.StringSeparator + "Ikke Extended" + Constants.StringSeparator + f_analyse.OptimalExtendedStatusFromGantryWeight + "  " + Constants.StringSeparator + f_analyse.OptimalExtendedStatusFromLaterality + "  " );  //Data

                        beamExtendedAnalysisCSV = beamExtendedAnalysisCSV + "Ikke Extended" + ":" + f_analyse.OptimalExtendedStatusFromGantryWeight + ":" + f_analyse.OptimalExtendedStatusFromLaterality; //+ Constants.StringSeparator
                    }

                }
                //setter feltnavn:
                uthentet_verdi = beamExtendedAnalysis;
                f_analyse.ExtractedValue = uthentet_verdi;



                utdypning = utdypning + Environment.NewLine + "Feltene er vinklet mest mot: " + f_analyse.GantryWeight + " gantry-retning."; //Should be editet
                utdypning = utdypning + Environment.NewLine + "Optimal extended-status mtp. feltvinkler: " + f_analyse.OptimalExtendedStatusFromGantryWeight + ".";
            }



                return f_analyse;

        }
        public static FieldsAnalysis AnalyzeGantryAngleWeighting(FieldsAnalysis f_analyse)
        {
            string gantryvinkelKommentar = "";
            string latKommentar = "";
            string ExtendedWarning = "";
            string lat = f_analyse.PlanLaterality;
            string pasorient = f_analyse.PatientOrientation;
            string HFS = PatientOrientation.HeadFirstSupine.ToString();
            string utdypning = f_analyse.Elaboration;


            if (f_analyse.Exist_180_field)
            {

                //gantryvinkelvekting analyse
                if ((f_analyse.GantryWeight == "90") && (f_analyse.Extended_180_field == Constants.False))
                {
                    //vektet paa 90 side, men ikke extended - ok
                    ExtendedWarning = Constants.False;

                }
                else if ((f_analyse.GantryWeight == "270") && (f_analyse.Extended_180_field == Constants.True))
                {
                    //vektet paa 270 side, men extended - ok
                    ExtendedWarning = Constants.False;
                }
                else if ((f_analyse.GantryWeight == "0"))
                {
                    //vektet likt - alt ok
                    ExtendedWarning = Constants.False;
                }
                else if ((f_analyse.GantryWeight == "270") && (f_analyse.Extended_180_field == Constants.False))
                {
                    //vektet paa 270 side, men ikke extended - warning

                    gantryvinkelKommentar = "Gantryvinklene er vektet mot " + f_analyse.GantryWeight + "-siden, mens bakfrafelt er ikke satt til Extended. Kan være mer optimalt med Extended?";
                    ExtendedWarning = Constants.True;
                    f_analyse.OptimalExtendedStatusFromGantryWeight = "Extended";

                }
                else if ((f_analyse.GantryWeight == "90") && (f_analyse.Extended_180_field == Constants.True))
                {
                    //vektet paa 90 side, men extended - warning
                    gantryvinkelKommentar = "Gantryvinklene er vektet mot " + f_analyse.GantryWeight + "-siden, mens bakfrafelt er satt til Extended. Kan være mer optimalt uten Extended?";
                    ExtendedWarning = Constants.True;
                    f_analyse.OptimalExtendedStatusFromGantryWeight = "ikke Extended";

                }
                else if (f_analyse.Extended_180_field == "Mix")
                {
                    //flere bakfrafelt med forskjellig status paa extended - warning
                    gantryvinkelKommentar = "Bakfrafelt har vekslende Extended-status.";
                    if (f_analyse.GantryWeight == "90")
                    { }
                    else if (f_analyse.GantryWeight == "270")
                    { }
                    else if (f_analyse.GantryWeight == "0")
                    { }
                    ExtendedWarning = Constants.True;


                }

                //Lateralitet (+ pasientorientering) og Extended - analyse:
                if ((f_analyse.Exist_180_field) && (lat == Constants.Hoyre) && (pasorient == HFS)) //Endret fra hardkodet "hoyre", 27.11.2024 breped
                {
                    //Warning - høyresidig bestråling bakfra brude ha Extended
                    if (f_analyse.Extended_180_field == Constants.False)
                    {
                        latKommentar = "Lateralitet er " + lat + ", men bakfrafelt er ikke satt til 'Extended'. Kan medføre krasj.";
                        utdypning = utdypning + Environment.NewLine + "Optimal extended-status mtp. lateralitet: Extended.";
                        ExtendedWarning = Constants.True;
                        f_analyse.OptimalExtendedStatusFromLaterality = "Extended";
                    }
                    //Ok - høyresidig bestråling bakfra brude ha Extended
                    if (f_analyse.Extended_180_field == Constants.True)
                    {
                        utdypning = utdypning + Environment.NewLine + "Optimal extended-status mtp. lateralitet: Extended.";
                        //uthentet_verdi = uthentet_verdi + Environment.NewLine + "Optimal extended-status mtp. øvrige feltvinkler: Extended.";
                        //latKommentar = "Lateralitet er " + lat + " og bakfrafelt er satt til 'Extended'.";
                        ExtendedWarning = Constants.False;
                        f_analyse.OptimalExtendedStatusFromLaterality = "Extended";
                    }


                }
                if ((f_analyse.Exist_180_field) && (lat == Constants.Venstre) && (pasorient == HFS)) //Endret fra hardkodet "venstre", 27.11.2024 breped
                {
                    //Warning - høyresidig bestråling bakfra brude ikke ha Extended
                    if (f_analyse.Extended_180_field == Constants.True)
                    {
                        latKommentar = "Lateralitet er " + lat + ", men bakfrafelt er satt til 'Extended'. Kan medføre krasj.";
                        utdypning = utdypning + Environment.NewLine + "Optimal extended-status mtp. lateralitet: ikke Extended.";
                        f_analyse.OptimalExtendedStatusFromLaterality = "ikke Extended";
                        ExtendedWarning = Constants.True;
                    }
                    //Ok - høyresidig bestråling bakfra brude ikke ha Extended
                    if (f_analyse.Extended_180_field == Constants.False)
                    {
                        //latKommentar = "Lateralitet er " + lat + " og bakfrafelt er ikke satt til 'Extended'.";
                        utdypning = utdypning + Environment.NewLine + "Optimal extended-status mtp. lateralitet: ikke Extended.";
                        ExtendedWarning = Constants.False;
                        f_analyse.OptimalExtendedStatusFromLaterality = "ikke Extended";
                    }


                }

            }
            //Oppdaterer
            f_analyse.Elaboration = utdypning;
            f_analyse.AngleWarning = ExtendedWarning;
            f_analyse.AngleComment = gantryvinkelKommentar + latKommentar;


            return f_analyse;
        }



        //lat_iso kan ha lateralitet: 1) Medial 2) Høyre 3) Venstre. 
        //lat_MV_navn og lat_targetvolume kan ha lateralitet: 1) Ukjent 2) Høyre 3) Venstre
        public static CheckPoint CheckLaterality(FieldsAnalysis f_analyse, string StrListePTV_Templat, string MVListe_Templat, CheckPoint s, ExternalPlanSetup plan)
        {
            string lat_iso = f_analyse.PlanLaterality;
            string lat_MV_navn = "";
            string lat_targetvolume = "";
            //string lat_strukturer = "";
            string trafikklys = s.CheckTrafficLight;
            string planID = plan.Id;
            string strukturliste_L = "";
            string strukturliste_R = "";
            string struktur_hoved = "";
            string _tempUtdyping = "";
            string _tempKommentar = "";
            string _tempResultat = "";
            string _tempStatus = "";
            string planID_red = "";

            //fjerner ev. revisjonsnummer fra planID. Endrer "01g HyBrst_L:1" til "01g HyBrst_L"
            int index = planID.LastIndexOf(":");
            if (index >= 0) { planID_red = planID.Substring(0, index); }
            else { planID_red = planID; }

            s.CheckDebug = s.CheckDebug + "Isosenter lateralitet er " + f_analyse.PlanLaterality_cm + "cm";

            _tempUtdyping = "Isosenterplasering indikerer lateralitet: " + lat_iso;

            //Sjekker PlanID for generisk benevnelse Hoyre og Venstre


            if (planID.Contains(Constants.PlanID_Template_Laterality_Right_Contains_String) || planID.ToLower().Contains(" hø ") || planID_red.EndsWith(Constants.PlanID_Template_Laterality_Right_EndsWith_String)  || planID_red.ToLower().EndsWith("ho") || planID_red.ToLower().EndsWith("hø")) //include norwegian string
            {
                lat_MV_navn = Constants.Hoyre;
            }
            else if (planID.Contains(Constants.PlanID_Template_Laterality_Left_Contains_String) || planID.ToLower().Contains(" ve ") || planID_red.EndsWith(Constants.PlanID_Template_Laterality_Left_EndsWith_String) || planID_red.ToLower().EndsWith("ve"))  //include norwegian string
            {
                lat_MV_navn = Constants.Venstre;
            }
            else
            {
                lat_MV_navn = Constants.Unknown;
            }
            _tempUtdyping = _tempUtdyping + Environment.NewLine + "PlanId indikerer laterlitet: " + lat_MV_navn + ".";


            //Sjekker Target Volume ved lateralitet
            struktur_hoved = plan.TargetVolumeID;
            //Sjekker andre PTV strukturer med lateralitet
            if (struktur_hoved.Contains(Constants.PTV_StartWith) && (struktur_hoved.Contains(Constants.Structures_Template_Laterality_Left_Contains_String) || struktur_hoved.EndsWith(Constants.Structures_Template_Laterality_Left_EndsWith_String) || struktur_hoved.ToLower().EndsWith("ve")))
            {//Venstre
                lat_targetvolume = Constants.Venstre;
            }
            if (struktur_hoved.Contains(Constants.PTV_StartWith) && (struktur_hoved.Contains(Constants.Structures_Template_Laterality_Right_Contains_String) || struktur_hoved.EndsWith(Constants.Structures_Template_Laterality_Right_EndsWith_String) ||  struktur_hoved.ToLower().EndsWith("ho") || struktur_hoved.ToLower().EndsWith("hø")))
            {//Hoyre
                lat_targetvolume = Constants.Hoyre;
            }
            if (lat_targetvolume != Constants.Venstre && lat_targetvolume != Constants.Hoyre)
            { //Hverken Hoyre eller Venstre
                lat_targetvolume = Constants.Unknown;
            }
            _tempUtdyping = _tempUtdyping + Environment.NewLine + "Target Volume ID indikerer lateralitet: " + lat_targetvolume;

            //Henter ut strukturer som inneholder "PTV" og "_L" eller "_R" i navn.
            List<Structure> str_L = plan.StructureSet.Structures.Where(str => str.Id.Contains(Constants.PTV_StartWith) && str.Id.Contains(Constants.Structures_Template_Laterality_Left_EndsWith_String)).ToList();
            List<Structure> str_R = plan.StructureSet.Structures.Where(str => str.Id.Contains(Constants.PTV_StartWith) && str.Id.Contains(Constants.Structures_Template_Laterality_Right_EndsWith_String)).ToList();
            strukturliste_L = string.Join(Constants.StringSeparator, str_L);
            strukturliste_R = string.Join(Constants.StringSeparator, str_R);
            //MessageBox.Show("strukturlister:" + Environment.NewLine + strukturliste_L + Environment.NewLine + strukturliste_R);




            //Det er lateralitet i iso og enten targetvolume eller plannavn har lateralitet. Sjekker om det er samsvar mellom lateralitet.
            if (lat_iso != Constants.Medial && (lat_targetvolume != Constants.Unknown || lat_MV_navn != Constants.Unknown))
            {
                //Det finnes lateralitet i iso, men den er ikke rett etter targetvol eller planid
                if (lat_iso != lat_targetvolume || lat_iso != lat_MV_navn)
                {   //Avvik

                    //Iso og plannavn ok, men targetvolume kanskje feil
                    if (lat_MV_navn == lat_iso)
                    {
                        //burde det veare noyaktig?
                        //if (s.CheckSettings == Constants.CheckSettingsStrict) // Mamma, skal ha lateralitet i targetvolume ogsaa
                        //{
                        //    //_tempKommentar = "Isosenter og PlanID indikerer lateralitet " + lat_iso + ", mens TargetVolume ID indikerer lateralitet " + lat_targetvolume + "!";

                        //    if (lat_targetvolume == Constants.Unknown)
                        //    { //target volume ukjent lat.
                        //        _tempKommentar = "TargetVolume ID har ingen lateralitet.";
                        //    }
                        //    else
                        //    {//denne burde vaere umulig :)
                        //        _tempKommentar = "TargetVolume ID indikerer lateralitet " + lat_targetvolume + ".";
                        //    }

                        //    _tempStatus = s.CheckTrafficLight;
                        //    _tempResultat = lat_iso;
                        //}
                        //else  //feks lunge, der targetvolume ikke navnes med lateralitet. Det er altså ikke feil
                        //{
                            _tempStatus = Constants.Ok;
                            _tempResultat = lat_iso;
                        //}

                    }
                    //plannavn og targetvolume samme, men iso forskjellig
                    else if (lat_MV_navn == lat_targetvolume)
                    {

                        _tempKommentar = "Isosenter indikerer lateralitet " + lat_iso + ", mens TargetVolume ID og PlanID indikerer lateralitet " + lat_targetvolume + "!";

                        _tempStatus = s.CheckTrafficLight;
                        _tempResultat = "Inkonsistent.";
                    }
                    else if (lat_iso == lat_targetvolume)
                    {
                        if (lat_MV_navn == Constants.Unknown)
                        { //PlanID ukjent lat.
                            _tempKommentar = "PlanID har ingen lateralitet.";
                            _tempResultat = lat_iso;
                        }
                        else
                        {//PlanID annen lat.
                            _tempKommentar = "Isosenter og TargetVolume ID indikerer lateralitet " + lat_iso + ", mens PlanID indikerer lateralitet " + lat_MV_navn + "!";
                            _tempResultat = "Inkonsistent.";
                        }
                        _tempStatus = s.CheckTrafficLight;

                    }
                    else
                    {
                        _tempKommentar = "Isosenter indikerer lateralitet " + lat_iso + ", TargetVolume ID indikerer lateralitet " + lat_targetvolume + " og PlanID indikerer " + lat_MV_navn + "!";
                        _tempStatus = s.CheckTrafficLight;
                        _tempResultat = lat_iso;
                    }
                }
                //Det finnes lateralitet i iso, og den er rett
                else  //OK
                {
                    _tempStatus = Constants.Ok;
                    _tempResultat = lat_iso;
                }
            }
            //Det finnes ikke lateralitet i iso, og det er rett
            else if (lat_iso == Constants.Medial && lat_targetvolume == Constants.Unknown && lat_MV_navn == Constants.Unknown)
            {
                _tempStatus = Constants.Ok;
                _tempResultat = lat_iso + " (iso x: " + f_analyse.PlanLaterality_cm + "cm)";

            }
            //Det finnes ikke lateralitet i iso, men det er lateralitet i targetvolume ID eller plan ID
            else if (lat_iso == Constants.Medial && (lat_targetvolume != Constants.Unknown || lat_MV_navn != Constants.Unknown))
            {
                _tempStatus = s.CheckTrafficLight;
                if (lat_iso != Constants.Unknown)
                {
                    _tempResultat = "Isosenter indikerer: " + lat_iso + " (x: " + f_analyse.PlanLaterality_cm + "cm)";
                    _tempKommentar = "Isosenter indikerer lateralitet " + lat_iso + ", TargetVolume ID indikerer lateralitet " + lat_targetvolume + " og PlanID indikerer " + lat_MV_navn + "!";
                }
            }

            //Hvis ingen status er satt:
            if (_tempStatus == "" && (lat_targetvolume == Constants.Unknown && lat_MV_navn == Constants.Unknown))
            {
                //BÅDE PLANID ELLER STURKTURID ER UKJENT
                _tempStatus = Constants.Ok;
                _tempResultat = lat_iso;

            }


            s.CheckComment = _tempKommentar;
            s.CheckResultValue = _tempResultat;
            s.CheckResultValueCSV = _tempResultat;
            s.CheckElaboration = _tempUtdyping;
            s.CheckStatus = _tempStatus;

            return s;
        }

        public static CheckPoint CheckExtendedFieldStatus(CheckPoint s, ExternalPlanSetup plan, FieldsAnalysis fieldsAnalysis)
        {
            string statusExtendedFieldStatus = "";
            if (fieldsAnalysis.AngleWarning == Constants.True)
            {
                statusExtendedFieldStatus = s.CheckTrafficLight;
                s.CheckComment = fieldsAnalysis.AngleComment;
            }
            else { statusExtendedFieldStatus = Constants.Ok; }
            s.CheckStatus = statusExtendedFieldStatus;
            s.CheckResultValue = fieldsAnalysis.ExtractedValue;
            s.CheckResultValueCSV = fieldsAnalysis.ExtractedValueCSV;
            s.CheckElaboration = fieldsAnalysis.Elaboration;

            return s;
        }


        public static bool SequentialPlanExist(PatientContext patientContext)
        {
            bool sekvplanExisterer = false;
            string felles_ref_pkt = "";
            string sekv_planer = "";

            if (patientContext.SanityLevel > Constants.SanityLevelPlanExist)
            {
                foreach (ExternalPlanSetup temp_plan in patientContext.ChosenCourse.ExternalPlanSetups)
                {
                    bool tempsekvplanExisterer = false; //tempstatus - resetter variabel for hver plan som testes.
                                                        //hvis tempplanen ikke er rejected og ikke allerede sjekket plan
                    if (temp_plan.ApprovalStatus != PlanSetupApprovalStatus.Rejected && temp_plan.Id != patientContext.ChosenPlan.Id && !temp_plan.Id.ToLower().Contains("plan sum"))
                    {

                        //itererer gjennom alle referansepunkt i hovedplan
                        foreach (var refpkt in patientContext.ChosenPlan.ReferencePoints)
                        {
                            //hvis noen av referansepktene matcher mellom templplan og hovedplan, skriver dem til variabel
                            if (temp_plan.ReferencePoints.Any(x => x.Id.Contains(refpkt.Id)))
                            {
                                tempsekvplanExisterer = true; //eksisterer boostplan med felles referansepunkt
                                sekvplanExisterer = true;
                                if (felles_ref_pkt != "") { felles_ref_pkt = felles_ref_pkt + Constants.StringSeparator; }
                                felles_ref_pkt = felles_ref_pkt + temp_plan.ReferencePoints.FirstOrDefault(x => x.Id.Contains(refpkt.Id));
                            }
                        }
                    }
                    if (tempsekvplanExisterer == true)
                    {   //Legger inn plannavnene.
                        if (sekv_planer != "") { sekv_planer = sekv_planer + Constants.StringSeparator; }
                        sekv_planer = sekv_planer + temp_plan.Id;

                        //harMammaBoost = true; //Brukes til å modifisere andre sjekker om det finnes boost.
                    }
                }
            }


            return sekvplanExisterer;
        }

        public static CheckPoint SequentialPlanExist(CheckPoint s, PatientContext patientContext)
        {
            bool sekvplanExisterer = false;
            string felles_ref_pkt = "";
            string sekv_planer = "";

            if (patientContext.SanityLevel >= s.CheckSanityLevelRequired)
            {
                foreach (ExternalPlanSetup temp_plan in patientContext.ChosenCourse.ExternalPlanSetups)
                {
                    bool tempsekvplanExisterer = false; //tempstatus - resetter variabel for hver plan som testes.
                                                        //hvis tempplanen ikke er rejected og ikke allerede sjekket plan
                    if (temp_plan.ApprovalStatus != PlanSetupApprovalStatus.Rejected && temp_plan.Id != patientContext.ChosenPlan.Id && !temp_plan.Id.ToLower().Contains("plan sum"))
                    {

                        //itererer gjennom alle referansepunkt i hovedplan
                        foreach (var refpkt in patientContext.ChosenPlan.ReferencePoints)
                        {
                            //hvis noen av referansepktene matcher mellom templplan og hovedplan, skriver dem til variabel
                            if (temp_plan.ReferencePoints.Any(x => x.Id.Contains(refpkt.Id)))
                            {
                                tempsekvplanExisterer = true; //eksisterer boostplan med felles referansepunkt
                                sekvplanExisterer = true;
                                if (felles_ref_pkt != "") { felles_ref_pkt = felles_ref_pkt + Constants.StringSeparator; }
                                felles_ref_pkt = felles_ref_pkt + temp_plan.ReferencePoints.FirstOrDefault(x => x.Id.Contains(refpkt.Id));
                            }
                        }
                    }
                    if (tempsekvplanExisterer == true)
                    {   //Legger inn plannavnene.
                        if (sekv_planer != "") { sekv_planer = sekv_planer + Constants.StringSeparator; }
                        sekv_planer = sekv_planer + temp_plan.Id;

                        //harMammaBoost = true; //Brukes til å modifisere andre sjekker om det finnes boost.
                    }
                }
            }

            if (sekvplanExisterer == true)
            {
                s.CheckDiscardedAtRuntime = Constants.False;
                s.CheckResultValue = Constants.True;
                s.CheckResultValueCSV = Constants.True;
                s.CheckStatus = s.CheckTrafficLight;
                s.CheckComment = "Andre planer som bidrar til samme referansepunkt: " + sekv_planer + Environment.NewLine + "Felles referansepunkt: " + felles_ref_pkt;
            }
            else
            {
                s.CheckDiscardedAtRuntime = Constants.True;
                s.CheckResultValue = Constants.False;
                s.CheckResultValueCSV = Constants.False;
                s.CheckStatus = s.CheckTrafficLight; //does not matter - discarded anyway
            }


            return s;
        }



        // Implementerer Wildcard i sok: "*" and "?"
        private static String WildCardToRegular(String value)
        {
            return "^" + Regex.Escape(value).Replace("\\?", ".").Replace("\\*", ".*") + "$";
        }

        //Compares strings , including wildcards
        public static string CompareStringArrays(string resultatverdi, string templatverdi, string trafikklys)
        {

            string boolSjekk = ""; //"Error";

            //if (Constants.AllStringComparisonCaseSensitive == false)
            //{ //If case insensitive search
            //    resultatverdi = resultatverdi.ToLower();
            //    templatverdi = templatverdi.ToLower();
            //}


            //String til array, hvis flere uthentinger eller flere templatverdier:
            string[] resultStringsToCompareArray = resultatverdi.Split(Constants.CharSeparator);
            string[] templateStringsToCompareAgainstArray = templatverdi.Split(Constants.CharSeparator);

            // ---- Stringsjekk ----

            //Tomt templat
            if (templatverdi == "")
            { boolSjekk = Constants.Unknown; }
            //Templat som godtar alt
            else if (templatverdi == "*")
            { boolSjekk = Constants.Ok; }
            //Ikke tomt templat
            else
            {
                //Sjekker hvert uthentet resultat, om flere. Alle uthentede verdier maa stemme med minst en templatverdi.
                foreach (string resultStringToCompare in resultStringsToCompareArray)
                {

                    string temp_boolSjekk = Constants.Error;
                    //sjekker mot alle potensielle verdier i templatet, trenger bare en match
                    foreach (string templateStringToCompareAgainst in templateStringsToCompareAgainstArray)
                    {
                        if (Regex.IsMatch(resultStringToCompare, WildCardToRegular(templateStringToCompareAgainst.Trim()))) //Sjekken godtar også wildcards i templat "*"  //if (r == t)
                        { temp_boolSjekk = Constants.Ok; } //hvis det finnes en eneste match blir denne satt OK
                        else if (temp_boolSjekk != Constants.Ok) //Hvis ikke match sett til trafikklys (= warning).
                        { temp_boolSjekk = trafikklys; }
                    }
                    //setter endelig status
                    if (boolSjekk != trafikklys) //status kan aldri settes fra feil til ok igjen, bare andre veien.
                    { boolSjekk = temp_boolSjekk; } //Setter status til warning basert på at denne 'r' mislyktes.
                }
            }
            return boolSjekk;
        }


        public static string ApprovalHistoryList(ExternalPlanSetup plan)
        {
            //Forbedring: returnere en klasse/struct med history-elementene og binde den til en list-view i stede for som en stor string...
            string st1 = "";
            string tid1 = "";
            string user1 = "";
            string hist = "";
            foreach (ApprovalHistoryEntry apphist2 in plan.ApprovalHistory)
            {
                st1 = apphist2.ApprovalStatus.ToString();
                tid1 = apphist2.ApprovalDateTime.ToString();
                user1 = apphist2.UserId.ToString();
                hist = hist + st1 + " " + user1 + " " + tid1 + System.Environment.NewLine;
            }
            return hist;
        }




        //Hent Gating
        public static string HentGating(ExternalPlanSetup plan)
        {
            string _gating = "";
            if (plan.UseGating.ToString().ToLower() == "false")
            {
                _gating = "False";

            }
            else if (plan.UseGating.ToString().ToLower() == "true")
            {
                _gating = "True";
            }
            return _gating;
        }
        //Hent gating-protokoll?



        public static double HentMUPerGy(ExternalPlanSetup plan)  //Ide: Hent ut MetersetPerGy direkte for hvert felt istedenfor totalt (felt.MetersetPerGy) og finn feltet med maks MaksFeltMetersetPerGy.
        {
            //Henter total antall MU
            double AntallMU = 0;
            int Antall_felt = 0;
            foreach (Beam felt in plan.Beams)
            {

                if (felt.IsSetupField == false)
                {
                    Antall_felt = Antall_felt + 1;
                    AntallMU = AntallMU + felt.Meterset.Value;
                }
            }
            //Henter antall Gy    
            double DosePerFraksjon = plan.PlannedDosePerFraction.Dose;
            return AntallMU / DosePerFraksjon; //MU per Gy
        }

        public static double HentTotMU(ExternalPlanSetup plan)
        {
            //Henter total antall MU
            double AntallMU = 0;
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {
                    AntallMU = AntallMU + felt.Meterset.Value;
                }
            }
            return AntallMU;
        }



        //-------------------------------------
        //Fluence:
        //-------------------------------------
        public static float[,] HentFluenceTilArray(Beam felt)
        {
            float[,] optflu;
            Fluence fl = felt.GetOptimalFluence();
            if (fl != null)
            {
                optflu = felt.GetOptimalFluence().GetPixels();
            }
            else
            {//Returnerer tom array
                optflu = new float[0, 0];
            }

            return optflu;
        }
        public static string FluenceTilString(float[,] optflu)
        {//Console.WriteLine("[{0}]", string.Join(", ", optflu));
            string result = string.Join("\n", optflu);
            //MessageBox.Show(result);
            return result;
        }
        public static Fluence GenererFluenceTest(Beam felt)
        {
            var beam = felt;


            float[,] flu = new float[100, 100];

            for (int i = 0; i < 100; i++)
            {
                for (int j = 0; j < 100; j++)
                {
                    if (j > 50)
                    {
                        flu[i, j] = (float)0.5;
                    }
                    else
                    {
                        flu[i, j] = 1;
                    }
                }
            }
            Fluence fluence = new Fluence(flu, -125, 125);
            //beam.SetOptimalFluence(fluence);

            return fluence;
        }

        public static float HentMaxFluenceFelt(Beam felt)
        {
            string flMax = "0";
            string fluencearraystring = "";
            float maxvalue = 0;

            Fluence fl = felt.GetOptimalFluence();
            if (fl != null)
            {
                float[,] optflu;
                optflu = HentFluenceTilArray(felt);
                fluencearraystring = FluenceTilString(optflu); //Test
                maxvalue = optflu.Cast<float>().Max();
                flMax = maxvalue.ToString();
            }

            return maxvalue;
        }
        public static CheckPoint CheckSmallestMaxFluencePlan(ExternalPlanSetup plan, CheckPoint s, string hasFluence)
        {
            string flMax = "";
            double Minste_maxvalue = 9999;
            double value = 0;
            string feltnavn = "";
            s.CheckComment = "";

            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField != true)
                {
                    //teknikken, kun IMRT, ikke statisk:
                    if (FieldExtension.CheckIfFieldIsIMRT(felt))
                    {
                        feltnavn = felt.Id;
                        value = HentMaxFluenceFelt(felt);

                        //Setter minste max_fluence verdi:
                        if ((value < Minste_maxvalue) && (value != 0)) { Minste_maxvalue = value; }
                        //Sjekker om maxverdi er for lav
                        if (value < Constants.ToleranceSmallestFluenceMaxVAlue)
                        {
                            if (s.CheckComment != "") { s.CheckComment = s.CheckComment + Environment.NewLine; }
                            s.CheckComment = s.CheckComment + "Feltet '" + feltnavn + "' har fluens < " + Constants.ToleranceSmallestFluenceMaxVAlue + ".";
                            s.CheckStatus = s.CheckTrafficLight;
                        }
                    }
                }
            }
            //Setter status
            if (s.CheckStatus != s.CheckTrafficLight)
            {
                s.CheckStatus = Constants.Ok;
            }

            s.CheckResultValue = Math.Round(Minste_maxvalue, 4).ToString();
            s.CheckResultValueCSV = Math.Round(Minste_maxvalue, 4).ToString();
            s.CheckElaboration = s.CheckElaboration + flMax;

            if (hasFluence != Constants.True)
            {

                s.CheckDiscardedAtRuntime = Constants.True;
            }


                return s;
        }

        public static CheckPoint CheckMaxFluenceMatrixPlan(ExternalPlanSetup plan, CheckPoint s, string hasFluence)
        {
            string flMax = "";
            string flMaxCSV = "";
            float value = 9999;
            string feltnavn = "";
            s.CheckComment = "";

            flMax = GeneralExtension.GenerateTableLine(5, 4, "Felt: |Max Fluence: ");
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField != true)
                {
                    //teknikken, kun IMRT, ikke statisk:
                    if (FieldExtension.CheckIfFieldIsIMRT(felt))
                    {
                        feltnavn = felt.Id;
                        value = HentMaxFluenceFelt(felt);
                        flMax = flMax + Environment.NewLine + GeneralExtension.GenerateTableLine(5, 4, feltnavn + Constants.StringSeparator + value.ToString());
                        if (flMaxCSV != "") { flMaxCSV = flMaxCSV + Constants.StringSeparator; }
                        flMaxCSV = flMaxCSV + feltnavn + ":"+ Math.Round(value,4).ToString();
                    }
                }
            }
            //Setter status
            s.CheckStatus = s.CheckTrafficLight;
            s.CheckResultValue = flMax;
            s.CheckResultValueCSV = flMaxCSV;


            if (hasFluence != Constants.True)
            {
                s.CheckDiscardedAtRuntime = Constants.True;
            }

            return s;
        }


        public static string PlanHasFluence(ExternalPlanSetup plan)
        {
            string result = Constants.False;
            float maxvalue = 0;
            float value = 0;

            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField != true)
                {
                    //LEGG INN: sjekk teknikken, kun IMRT, ikke statisk:
                    if (FieldExtension.CheckIfFieldIsIMRT(felt))
                    {

                        value = HentMaxFluenceFelt(felt);
                        if (value > maxvalue) { maxvalue = value; }
                    }
                }
            }
            if (maxvalue == 0) { result = Constants.False; }
            else { result = Constants.True; }


            return result;
        }

        //-------------------------------------
        //End Fluence
        //-------------------------------------





        public static int NumberOfIsoFields(ExternalPlanSetup plan, bool bolusfelt)
        {
            //Henter total antall MU
            int AntallFelt = 0;
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == true)
                {
                    //Legge inn unntak for bolusfelt...
                    if (bolusfelt == true)
                    {
                        if (felt.Id.ToLower().Contains("bolus")) //kun telle hvis den inneholder bolus
                        {
                            AntallFelt = AntallFelt + 1;
                        }
                    }
                    else
                    {
                        if (!felt.Id.ToLower().Contains("bolus")) //kun telle hvis den IKKE inneholder bolus
                        {
                            AntallFelt = AntallFelt + 1;
                        }
                    }
                }
            }
            return AntallFelt;
        }

        public static CheckPoint CheckNumberOfSetupFields( CheckPoint s, ExternalPlanSetup plan)
        {
            int numberOfISOFields = PlanExtension.NumberOfIsoFields(plan, false);
            s.CheckResultValue = numberOfISOFields.ToString();
            s.CheckResultValueCSV = numberOfISOFields.ToString();

            //IF no tolerance in template, set tolerance temporarily to a constant decided in settings:
            double double_templateverdi = Constants.AbsoluteToleranceMinimumNumberOfSetupFields;
            bool validDouble = double.TryParse(s.CheckTemplateValue,
        NumberStyles.Any, CultureInfo.InvariantCulture,
        out double_templateverdi);

            if (validDouble != true) { s.CheckDebug = s.CheckDebug + "Ingen templatverdi. Bruker default templatverdi på 4 setupfelt. "; }

            //Sjekker antall Setupfelt
            if (numberOfISOFields < double_templateverdi) //4 hvis ingen templat
            {
                s.CheckStatus = s.CheckTrafficLight; //Endrer fra rod til gult  varsel, da det tydeligvis finnes unntak (total hjerne, Halcyon, ethos etc). Grønt ved 1 hvis Halcyon/Ethos 13.02.2024 BP

                s.CheckStatus = s.CheckTrafficLight;
                //Less than Abolute minimum tolerance -> Error:
                if (numberOfISOFields < Constants.AbsoluteToleranceMinimumNumberOfSetupFields)
                {
                        s.CheckStatus = Constants.Error;
                        s.CheckDebug = s.CheckDebug + " Krever minst " + Constants.AbsoluteToleranceMinimumNumberOfSetupFields + " antall setupfelt! ";
                        s.CheckComment = s.CheckComment + " Krever minst " + Constants.AbsoluteToleranceMinimumNumberOfSetupFields + " antall setupfelt! ";
                }

            }
            else
            {
                s.CheckStatus = Constants.Ok;
            }

            return s;
        }

        public static CheckPoint CheckNumberOfBolusSetupFields(CheckPoint s, ExternalPlanSetup plan, List<StructureCheck> boluser, string technique)
        {
            //bolusstatuses
            bool bolusAttached = false;
            bool bolusUnattached = false;
            bool bolus3D = false;
            bool ElectronTechnique = false;

            //Check that it is not electron technique (exception):
            if (technique == Constants.Teknikk.Electron_technique_forklaring)
            {
                ElectronTechnique = true;
            }

            //Sjekker om det finnes attached boluser til feltene. 
            if (boluser.Count > 0 )
            {
                s.CheckDebug = s.CheckDebug + Environment.NewLine + "Antall boluser: " + boluser.Count + " (>0)." + Environment.NewLine + "Teknikk: " + technique + " (!= Elektroner).";
                foreach (StructureCheck bolus in boluser)
                {
                    if (bolus.AttachedFields != "" && bolus.AttachedFields != null)
                    {       //Minst en bolus er attached
                        s.CheckDebug = s.CheckDebug + Environment.NewLine + "For bolus '" + bolus.StructureID + "' - minst èn bolus attached til felt?: " + bolusAttached;
                        bolusAttached = true;
                    }
                    if(bolus.StructureID.ToLower().Contains("3d"))
                    {
                        bolus3D = true;
                    }
                }
                //There exists boluses Unattached (so-called "structure" boluses or 3D-boluses) (Legge inn krav om bolusfelt ved bolus-strukturer ogsaa - altsaa ikke attached to field?)
                if ( bolusAttached == false)
                {
                    bolusUnattached = true;
                }

            }

            //Debug if 3d-bolus
            if (bolus3D == true)
            {
                s.CheckDebug = s.CheckDebug + Environment.NewLine + "3D-bolus exist.";
            }
            //Exception regarding electron technique
            if (ElectronTechnique == true)
            {
                //if not 3d-bolus, then maybe we need bolus-field after all.
                if (bolus3D != true)
                {
                    s.CheckDiscardedAtRuntime = Constants.True;
                }
            }

            //If no boluses, remove checkpoint
            if (bolusAttached == false && bolusUnattached == false && bolus3D == false)
            {   //fjerner punkt
                s.CheckDiscardedAtRuntime = Constants.True; //completeCheckPointList.RemoveAt(i);
            }
            else
            {//Go through with checkpoint

                int numberOfBolusFields = PlanExtension.NumberOfIsoFields(plan, true);
                s.CheckResultValue = numberOfBolusFields.ToString();
                s.CheckResultValueCSV = numberOfBolusFields.ToString();
                s = PlanExtension.SetStatusNumberOFBolusFieldsCheck(plan, numberOfBolusFields, s);


            }
            return s;
        }


        //CheckNumberOfBolusSetupFields
        public static CheckPoint CheckInvalidCharactersInID(CheckPoint s, ExternalPlanSetup plan)
        {
            string resultValue = "";
            //string resultValueCSV = "";
            string status = Constants.Unknown;
            bool existInvalidId = false;
            int numberOfInvalidIDs = 0;
            

            //------
            //Iterate over the beams, remember to also check DRRs, isosenters (where there is multiples), plan Id, course ID, structures and referencepoints.
            //------
            foreach (Beam beam in plan.Beams)
            {
                //Make method: StringContainsInvalidCharacters(), returns true or false.
                if(beam.Id.Contains("°") || beam.Id.Contains("\u00B0")) //unsure which method is best. To do: Define instead a string list with many invalid characters to check agains.  "°|$|£|" etc. 
                {
                    //Write outout if all fields with error
                    if (resultValue != "") { resultValue = resultValue + Environment.NewLine; }
                    resultValue = resultValue + "Felt: " + beam.Id;
                    numberOfInvalidIDs = numberOfInvalidIDs + 1;

                    //Set status
                    existInvalidId = true;
                    status = s.CheckTrafficLight;
                }

                //-----
                //Also check DRR if it exists:
                //-----
                string DRR_ID = "";
                //retrieve DRR_ID if it exists
                try
                {
                    DRR_ID = beam.ReferenceImage.Id;  //if (felt.ReferenceImage.Id == null) {} did not work, crashes...
                }
                catch{}
                if (DRR_ID != "")  //An alternative to this is to look through all images for Degree signs, in same sereies and study...
                {
                    //Check for invalid characters
                    if (DRR_ID.Contains("°") || DRR_ID.Contains("\u00B0")) //unsure which method is best
                    {
                        //Write outout if all fields with error
                        if (resultValue != "") 
                        { resultValue = resultValue + Environment.NewLine;
                        }
                        resultValue = resultValue + "DRR: " + DRR_ID;
                        numberOfInvalidIDs = numberOfInvalidIDs + 1;

                        //Set status
                        existInvalidId = true;
                        status = s.CheckTrafficLight;
                    }
                }
                //-----
                //-----


            }
            //------
            //------

            //Check plan ID
                //Check for invalid characters
            if (plan.Id.Contains("°") || plan.Id.Contains("\u00B0")) //unsure which method is best
            {
                //Write outout if all fields with error
                if (resultValue != "")
                {
                    resultValue = resultValue + Environment.NewLine;
                }
                resultValue = resultValue + "Plan: " + plan.Id;
                numberOfInvalidIDs = numberOfInvalidIDs + 1;

                //Set status
                existInvalidId = true;
                status = s.CheckTrafficLight;
            }

            //Check course ID
                //Check for invalid characters
            if (plan.Course.Id.Contains("°") || plan.Course.Id.Contains("\u00B0")) //unsure which method is best
            {
                //Write outout if all fields with error
                if (resultValue != "")
                {
                    resultValue = resultValue + Environment.NewLine;
                }
                resultValue = resultValue + "Course: " + plan.Course.Id;
                numberOfInvalidIDs = numberOfInvalidIDs + 1;

                //Set status
                existInvalidId = true;
                status = s.CheckTrafficLight;
            }

            //ReferencePoints:



            //All relevant things iterated over. Now set final status:
            if (existInvalidId == false)
            {
                status = Constants.Ok;
                resultValue = Constants.False;
                s.CheckResultValueCSV = "Ugyldige tegn i IDer: " + numberOfInvalidIDs.ToString();
                //Modify output for Display:
                s.CheckResultValue = "Ugyldige tegn i IDer: " + numberOfInvalidIDs.ToString() + Environment.NewLine + resultValue;
            }
            else
            {

            }



            //Set CheckPoint values;
            s.CheckStatus = status;
            s.CheckResultValue = resultValue;

            return s;
        }

            public static CheckPoint SetStatusNumberOFBolusFieldsCheck(ExternalPlanSetup plan, int input_antall, CheckPoint s)
        {
            //Sjekker antall Setupfelt
            if (input_antall > 0)
            {
                s.CheckStatus = Constants.Ok;
            }
            else
            {
                s.CheckStatus = s.CheckTrafficLight;
            }
            return s;
        }



        public static string GetGantryAngle(Beam felt, string Teknikk)
        {
            string _gantryangle = "";
            //Vmat teknikk
            if (Teknikk == Constants.Teknikk.Arc_technique_name_Aria || Teknikk == Constants.Teknikk.SRS_Arc_technique_name_Aria)
            {
                _gantryangle = felt.ControlPoints.FirstOrDefault().GantryAngle.ToString() + " - " + felt.ControlPoints.Last().GantryAngle.ToString();
            }
            else //Static
            {
                _gantryangle = felt.ControlPoints.FirstOrDefault().GantryAngle.ToString();
            }

            return _gantryangle;
        }
        public static string GetWedgeID(Beam felt)
        {
            string _wedge = "";
            if (felt.Wedges.Any())
            {
                _wedge = felt.Wedges.FirstOrDefault().Id;
            }
            return _wedge;
        }

        //SjekkElektronTray

        public static CheckPoint GetApplicatorTrayCode(ExternalPlanSetup plan, CheckPoint s)
        {
            string _felt = "";
            string _result = "";
            string resultCSV = "";
            string _appl = "";
            string _tray = "";
            string _code = "";
            string _status = Constants.Ok;
            string _globalstatus = Constants.Ok;//Kan ikke brukes naa, men nyttig naar vi finner en maate aa sjekke CustomCode
            //_result = GeneralExtension.GenerateTableLine(5, 4, "Felt:" + Constants.StringSeparator + "Applikator:" + Constants.StringSeparator + " Tray: " + Constants.StringSeparator + " Status: ");
            _result = GeneralExtension.FormatString(18, 18, "Felt:" + Constants.StringSeparator + "Applikator:" + Constants.StringSeparator + " Tray: " + Constants.StringSeparator + " Status: ");
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {
                    _felt = felt.Id;
                    _appl = GetApplicator(felt);
                    _tray = GetTrayName(felt);
                    _code = GetTray_CustomCode(felt);

                    //Sjekker:
                    if (_appl == "")
                    {
                        _status = Constants.Warning;
                        s.CheckComment = s.CheckComment + "" + _felt + " mangler applikator. ";
                    }
                    if (_tray == "")
                    {
                        _status = Constants.Warning;
                        s.CheckComment = s.CheckComment + "" + _felt + " mangler tray. ";
                    }
                    //if (_code == "")
                    //{
                    //    _status = Konstanter.Warning;
                    //    s.SjekkKommentar = s.SjekkKommentar + "" + _felt + " mangler CustomCode. ";
                    //}
                    //Setter status:
                    if (_status == Constants.Warning)
                    {
                        _globalstatus = Constants.Warning;
                    }
                    //Skriver linje:
                    //_result = _result + Environment.NewLine + GeneralExtension.GenerateTableLine(5, 4, _felt + Constants.StringSeparator + _appl + Constants.StringSeparator + _tray + Constants.StringSeparator + _globalstatus);   // + ";" + _tray + ";" + _code + ";" + _status);   
                    _result = _result + Environment.NewLine + GeneralExtension.FormatString(18, 18, _felt + Constants.StringSeparator + _appl + Constants.StringSeparator + _tray + Constants.StringSeparator + _globalstatus);
                    if (resultCSV != "") { resultCSV = resultCSV + Constants.StringSeparator; } //Add separator
                    resultCSV = resultCSV + _felt + ":" + _appl + ":" + _tray + ":" + _globalstatus;
                }

            }
            s.CheckResultValue = _result;
            s.CheckResultValueCSV = resultCSV;
            s.CheckStatus = Constants.Printout; //_globalstatus Endret til kun Info
            return s;
        }

        public static string GetApplicator(Beam felt)
        {
            string _applicator = "";
            try // I tilfelle app = NULL, hindrer pot. krasj.
            { _applicator = felt.Applicator.Id; }
            catch
            { }//_applicator = "";

            return _applicator;
        }
        public static string GetTrayName(Beam felt)
        {
            string _tray = "";
            //string tray_kode = felt.Blocks.First().Tray.Id.ToString();
            if (felt.Trays.Any())
            {
                _tray = felt.Trays.FirstOrDefault().Name;
            }

            return _tray;
        }
        public static string GetTray_CustomCode(Beam felt)
        {
            //Fungerer ikke, returnerer ID isteden (CustomAddOn3).
            string tray_kode = "";
            if (felt.Blocks.Any())
            {
                tray_kode = "-"; //felt.Blocks.FirstOrDefault().Tray.Id.ToString();
            }

            return tray_kode;
        }
        public static string GetExtendedStatus(Beam felt, string Teknikk)
        {
            string _extended = "";
            //Vmat teknikk
            if (Teknikk == Constants.Teknikk.Arc_technique_name_Aria || Teknikk == Constants.Teknikk.SRS_Arc_technique_name_Aria)
            {
                if (felt.IsGantryExtended || felt.IsGantryExtendedAtStopAngle)
                {
                    _extended = Constants.True;
                }
                else
                {
                    _extended = Constants.False;
                }
            }
            else //Static (unngaa krasj hvis man tester IsGantryExtendedAtStopAngle, da det ikke er Arc?)
            {
                if (felt.IsGantryExtended)
                {
                    _extended = Constants.True;
                }
                else
                {
                    _extended = Constants.False;
                }
            }

            return _extended;
        }
        public static List<Field> CreateFieldList(ExternalPlanSetup plan)
        {
            List<Field> _feltliste = new List<Field>();


            foreach (Beam felt in plan.Beams)
            {
                string id = "";
                string energi = "";
                string doserate = "";
                string kollimatorvinkel = "";
                string gantryangle = "";
                string extended = "";
                string teknikk = "";
                string mu = "";
                string kile = "";
                string tray = "";
                string tray_kode = ""; //Ikke mulig å hente ut via ESAPI.
                string applikator = "";
                string maskin = "";

                //Kun behandlingsfelt:
                if (!felt.IsSetupField)
                {
                    //Setter verdier
                    teknikk = FieldExtension.GetTechniqueFromField(felt);
                    id = felt.Id;
                    energi = felt.EnergyModeDisplayName;
                    doserate = felt.DoseRate.ToString();
                    kollimatorvinkel = felt.ControlPoints.FirstOrDefault().CollimatorAngle.ToString(); //Antar ingen hyperarc!
                    gantryangle = GetGantryAngle(felt, teknikk);
                    extended = GetExtendedStatus(felt, teknikk);
                    try { mu = felt.Meterset.Value.ToString(); } //If dose not calculated, set MU = 0;
                    catch { mu = "0"; }
                     //Ikke enhet
                    
                    kile = GetWedgeID(felt);
                    applikator = GetApplicator(felt);
                    tray = GetTrayName(felt);
                    maskin = felt.TreatmentUnit.Id;
                    //legger til i feltlisten:
                    _feltliste.Add(new Field() { FieldID = id, FieldTechniqueName = teknikk, FieldMachineID = maskin, FieldEnergy = felt.EnergyModeDisplayName, FieldDoseRate = doserate, FieldCollimatorAngle = kollimatorvinkel, FieldGantryAngle = gantryangle, FieldExtended = extended, FieldMU = mu, FieldWedge = kile, FieldApplicator = applikator, FieldTray = tray, FieldTrayCustomCode = tray_kode });

                }

            }

            return _feltliste;
        }



        public static string GetMachineIDsAll(ExternalPlanSetup plan)
        {

            int Feltnnr = 0;
            int antallMaskiner = 0;
            string feltmaskin = "";
            string[] maskiner;
            maskiner = new string[] { "", "", "", "", "" }; //maks 5 

            foreach (Beam felt in plan.Beams)
            {
                Feltnnr = Feltnnr + 1;
                feltmaskin = felt.TreatmentUnit.Id;
                //Finner forste felt
                if (Feltnnr == 1)
                {
                    maskiner[0] = feltmaskin;
                    antallMaskiner = 1;
                }

                //Hvis denne kombinasjon av teknikk og MLC ikke finnes fra for, legg til.
                if (maskiner.Contains(feltmaskin) == false)
                {
                    //if (!(felt.Technique.Id == ForsteFeltTeknikk) || !(mlcType.ToString() == ForsteFeltMLC))
                    antallMaskiner = antallMaskiner + 1;
                    if (antallMaskiner < 6)
                    {
                        maskiner[antallMaskiner] = feltmaskin;
                    }

                }
            }
            return GeneralExtension.ArrayToString(maskiner);
        }
        public static int AntallMaskinID(ExternalPlanSetup plan)
        {

            int Feltnnr = 0;
            int antallMaskiner = 0;
            string feltmaskin = "";
            string[] Maskiner;
            Maskiner = new string[] { "", "", "", "", "" }; //maks 5

            foreach (Beam felt in plan.Beams)
            {
                Feltnnr = Feltnnr + 1;
                feltmaskin = felt.TreatmentUnit.Id;
                //Finner forste felt
                if (Feltnnr == 1)
                {
                    Maskiner[0] = feltmaskin;
                    antallMaskiner = 1;
                }
                //sjekker resten
                if (Maskiner.Contains(feltmaskin) == false)
                {
                    antallMaskiner = antallMaskiner + 1;
                    Maskiner[antallMaskiner] = feltmaskin;
                }
            }
            return antallMaskiner;
        }

        public static string SjekkErrorMaskinID(ExternalPlanSetup plan)
        {
            string maskinID = "";
            string errorMaskinID = Constants.False;
            int antallMaskiner = PlanExtension.AntallMaskinID(plan);
            if (antallMaskiner == 1)
            {
                maskinID = FieldExtension.ForsteFeltMaskin(plan);
                errorMaskinID = Constants.False;
            }
            else
            {
                maskinID = PlanExtension.GetMachineIDsAll(plan);
                errorMaskinID = Constants.True;
            }
            return errorMaskinID;
        }

        public static CheckPoint CheckMachine(ExternalPlanSetup plan, CheckPoint s)
        {
            string debug_string = "";
            bool match = false;
            string tempstring = "";
            int antall_maskinID = AntallMaskinID(plan);
            string maskin = GetMachineIDsAll(plan);
            string forsteMaskin = FieldExtension.ForsteFeltMaskin(plan);
            debug_string = "Antall maskiner: " + antall_maskinID.ToString();
            debug_string = debug_string + Environment.NewLine + "Error: ";
            if (antall_maskinID > 1)
            {
                debug_string = debug_string + Constants.True;
                s.CheckComment = debug_string;
                s.CheckStatus = s.CheckTrafficLight; //Error
            }
            else
            {
                debug_string = debug_string + Constants.False;
                s.CheckStatus = Constants.Printout;
            }

            tempstring = "Maskintype: ";
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesEthos);
            if (match == true) { tempstring = tempstring + "Ethos"; }
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesHalcyon);
            if (match == true) { tempstring = tempstring + "Halcyon"; }
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesTB);
            if (match == true) { tempstring = tempstring + "TrueBeam"; }

            if (tempstring == "Maskintype: ")
            {
                tempstring = "Maskintype: Ingen match på maskin!";
                s.CheckComment = "Finner ikke maskinen '" + forsteMaskin + "' i listen av gyldige maskiner i koden.";
                s.CheckStatus = Constants.Info;
            }

            //Sender resultat
            s.CheckResultValue = maskin + " (" + tempstring + ")";
            s.CheckResultValueCSV = maskin + " (" + tempstring + ")";
            debug_string = debug_string + Environment.NewLine + tempstring;

            //Oppdaterer debug:
            tempstring = "RPM-Gating allowed: ";
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesGatingAllowedRPM);
            debug_string = debug_string + Environment.NewLine + tempstring + match;

            tempstring = "OSMS-Gating allowed: ";
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesGatingAllowedOSMS);
            debug_string = debug_string + Environment.NewLine + tempstring + match;

            tempstring = "Stereotaxy allowed: ";
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesStereotaxyAllowed);
            debug_string = debug_string + Environment.NewLine + tempstring + match;

            tempstring = "Elektrons allowed: ";
            match = CheckMachineProperty(forsteMaskin, Constants.MachinesElectronsAllowed);
            debug_string = debug_string + Environment.NewLine + tempstring + match;

            s.CheckDebug = debug_string;

            return s;
        }




        public static string GetTechniqueMLC(ExternalPlanSetup plan)
        {
            //henter ut begge samtidig fordi det er av og til flere kombinasjoner av Teknikk og MLC i samme plan. 
            int beamNumber = 0;
            int numberOfTechniques = 0;
            string mlcType = "";
            string teknikk = "";
            string[] techniquesUsed;
            techniquesUsed = new string[] { "", "", "", "", "" }; //maks 5 teknikker på samme plan. Finnes ikke flere.
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {
                    beamNumber = beamNumber + 1;
                    mlcType = felt.MLCPlanType.ToString();
                    teknikk = felt.Technique.ToString();
                    //Finner forste felt
                    if (beamNumber == 1)
                    {
                        techniquesUsed[0] = teknikk + "/" + mlcType;
                        numberOfTechniques = 1;
                    }
                    //Sjekker de overige feltene ikke er samme, legger til
                    //Sjekke teknikk:  Arc Therapy, SRS Arc Therapy, SRS static, Static, Total Body Irradiation
                    //Sjekke MLC PlanType. Finnes: ArcDynamic, DoseDynamic (->IMRT), Static, VMAT.

                    //Hvis denne kombinasjon av teknikk og MLC ikke finnes fra for, legg til.
                    if (techniquesUsed.Contains(teknikk + "/" + mlcType) == false)
                    {
                        //if (!(felt.Technique.Id == ForsteFeltTeknikk) || !(mlcType.ToString() == ForsteFeltMLC))
                        numberOfTechniques = numberOfTechniques + 1;
                        if (numberOfTechniques<6)
                        {
                            techniquesUsed[numberOfTechniques] = teknikk + "/" + mlcType;
                        }  
                    }
                }
            }
            return GeneralExtension.ArrayToString(techniquesUsed);
        }

        public static string GetTechniqueExlanation(double antallStFelt, double antallFiFFelt, double antallIntFelt, double antallArcFelt, double antallSRSArcFelt, double antallTotalBodyFelt, double antallElektronFelt)
        {

            string TeknikkForklaring = "";

            if (antallStFelt > 0 && antallIntFelt == 0)
            {
                TeknikkForklaring = Constants.Teknikk.Static_technique_forklaring; //"Statisk";
            }
            else if (antallFiFFelt > 0)
            {
                TeknikkForklaring = Constants.Teknikk.FiF_technique_forklaring; // "FiF";
            }
            else if (antallIntFelt > 0 && antallStFelt == 0)
            {
                TeknikkForklaring = Constants.Teknikk.IMRT_technique_forklaring; //"IMRT";
            }
            else if (antallIntFelt > 0 && antallStFelt > 0)
            {
                TeknikkForklaring = Constants.Teknikk.IMRT_Hybrid_technique_forklaring; //"Hybrid IMRT";
            }
            else if (antallArcFelt > 0)
            {
                TeknikkForklaring = Constants.Teknikk.Arc_technique_forklaring; //"VA";
            }
            else if (antallSRSArcFelt > 0)
            {
                TeknikkForklaring = Constants.Teknikk.SRS_Arc_technique_forklaring; //"SRS VA";
            }
            else if (antallTotalBodyFelt > 0)
            {
                TeknikkForklaring = Constants.Teknikk.TotalBody_technique_forklaring; // "Total Body";
            }
            else if (antallElektronFelt > 0)
            {
                TeknikkForklaring = Constants.Teknikk.Electron_technique_forklaring; // "Total Body";
            }
            else
            {
                TeknikkForklaring = Constants.Teknikk.Unknown_technique_forklaring;
            }



            return TeknikkForklaring;
        }

        public static CheckPoint CheckTolerancetableTreat(CheckPoint s, ExternalPlanSetup plan)
        {
            Toleransetabell t1 = PlanExtension.GetTolerancetable(plan);
            string numberOfTolerances = t1.NumberOfToleranceTables;
            int x1 = 0;
            Int32.TryParse(numberOfTolerances, out x1);
            if (x1 > 1)
            {
                s.CheckComment = "Det er flere forskjellige toleransetabeller for behandlingsfelt!";
            }

            string toleranceTables = t1.Toleransetabeller; //Treat-felt
            s.CheckResultValue = toleranceTables;
            s.CheckResultValueCSV = toleranceTables;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(toleranceTables, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            //Tillater ikke at det ikke eksisterer toleransetabell:
            if (toleranceTables == "") //lagt inn 25.11.2024 som fix. Bedre å skrive om funkjsonen "FinnToleransetabell til å ta imot SjekkPunkt som input og output og gå bort i fra "Toleransetabell"-klassen.
            {
                s.CheckStatus = Constants.Error;
            }
            return s;
        }

        public static CheckPoint CheckTolerancetableSetup(CheckPoint s, ExternalPlanSetup plan)
        {
            Toleransetabell t2 = PlanExtension.GetTolerancetable(plan, "Setup");
            string numberOfTolerances = t2.NumberOfToleranceTables;
            int x2 = 0;
            Int32.TryParse(numberOfTolerances, out x2);
            if (x2 > 1)
            {
                s.CheckComment = "Det er flere forskjellige toleransetabeller for setupfelt!";
            }

            string toleranceTables = t2.Toleransetabeller;
            s.CheckResultValue = toleranceTables;
            s.CheckResultValueCSV = toleranceTables;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(toleranceTables, s.CheckTemplateValue, s.CheckTrafficLight, "string", s, s.CheckTemplateValue);
            if (toleranceTables == "") //lagt inn 25.11.2024 som fix. Bedre å skrive om funkjsonen "FinnToleransetabell til å ta imot SjekkPunkt som input og output og gå bort i fra "Toleransetabell"-klassen.
            {
                s.CheckStatus = Constants.Error;
            }
            return s;
        }

        public static Toleransetabell GetTolerancetable(ExternalPlanSetup plan, string TypeFelt = "Treat")  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc)? Hvis ikke valgt, alle felt utenom setup.
        {
            int Feltnnr = 0;
            int antallToleransetabeller = 0;
            string toleransetabell = "";
            string[] ToleranserBrukt;
            ToleranserBrukt = new string[] { "", "", "", "", "" }; //maks 5 


            foreach (Beam felt in plan.Beams)
            {
                //Henter toleransetabell for behandlingsfeltene 
                if (TypeFelt == "Treat")
                {
                    if (felt.IsSetupField == false)
                    {
                        Feltnnr = Feltnnr + 1;
                        toleransetabell = felt.ToleranceTableLabel.ToString();
                        //Finner forste felt
                        if (Feltnnr == 1)
                        {
                            ToleranserBrukt[0] = toleransetabell;
                            antallToleransetabeller = 1;
                        }
                        if (ToleranserBrukt.Contains(toleransetabell) == false)
                        {
                            antallToleransetabeller = antallToleransetabeller + 1;
                            ToleranserBrukt[antallToleransetabeller] = toleransetabell;
                        }
                    }
                }
                //Henter toleransetabell for setupfeltene
                else if (TypeFelt == "Setup")
                {
                    if (felt.IsSetupField == true)
                    {
                        Feltnnr = Feltnnr + 1;
                        toleransetabell = felt.ToleranceTableLabel.ToString();
                        //Finner forste felt
                        if (Feltnnr == 1)
                        {
                            ToleranserBrukt[0] = toleransetabell;
                            antallToleransetabeller = 1;
                        }
                        if (ToleranserBrukt.Contains(toleransetabell) == false)
                        {
                            antallToleransetabeller = antallToleransetabeller + 1;
                            ToleranserBrukt[antallToleransetabeller] = toleransetabell;
                        }
                    }
                }

            }
            var t = new Toleransetabell
            {
                Toleransetabeller = GeneralExtension.ArrayToString(ToleranserBrukt),
                NumberOfToleranceTables = antallToleransetabeller.ToString()

            };

            return t;
        }

        public static int NumberOfToleranceTables(ExternalPlanSetup plan)
        {
            int Feltnnr = 0;
            int antallToleransetabeller = 0;
            string toleransetabell = "";
            string[] ToleranserBrukt;
            ToleranserBrukt = new string[] { "", "", "", "", "" }; //maks 5
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false)
                {
                    Feltnnr = Feltnnr + 1;
                    toleransetabell = felt.ToleranceTableLabel.ToString();
                    //Finner forste felt
                    if (Feltnnr == 1)
                    {
                        ToleranserBrukt[0] = toleransetabell;
                        antallToleransetabeller = 1;
                    }
                    if (ToleranserBrukt.Contains(toleransetabell) == false)
                    {
                        antallToleransetabeller = antallToleransetabeller + 1;
                        ToleranserBrukt[antallToleransetabeller] = toleransetabell;
                    }
                }
            }
            return antallToleransetabeller;
        }


        //Fungerer ikke:
        //JawTrackingbool = felt.Plan.OptimizationSetup.UseJawTracking;

        public static CheckPoint CheckJawTrackingStatusOld(ExternalPlanSetup plan, CheckPoint s)
        {
            int Feltnnr = 0;
            bool jawtrackingstatus = true;// jaw beveger seg for alle kollimatorer for alle felt i planen
            bool koll_statisk_felt = true; // jaw-tracking paa for alle kollimatorer i feltet
            foreach (Beam felt in plan.Beams)
            {
                //If not setupfield and is some kind of Arc.
                if (felt.IsSetupField == false && (felt.Technique.Id.Contains(Constants.Teknikk.Arc_technique_name_Aria) || felt.Technique.Id.Contains(Constants.Teknikk.SRS_Arc_technique_name_Aria) || felt.Technique.Id.Contains(Constants.Teknikk.TotalBody_technique_name_Aria))) //enten 'ARC' og 'SRS ARC'
                {
                    Feltnnr = Feltnnr + 1;
                    // til debug:   MessageBox.Show(felt.Id.ToString());
                    int teller = 0;
                    bool x1_statisk, x2_statisk, y1_statisk, y2_statisk; //er kollimatoren statisk gjennom alle kontrollpunkt?
                    int cp_max = felt.ControlPoints.Count;
                    double[,] arrayCP = new double[4, cp_max];

                    //For each control point
                    foreach (ControlPoint cp in felt.ControlPoints)
                    {
                        arrayCP[0, teller] = cp.JawPositions.X1; //Note down the jaw positions
                        arrayCP[1, teller] = cp.JawPositions.X2;
                        arrayCP[2, teller] = cp.JawPositions.Y1;
                        arrayCP[3, teller] = cp.JawPositions.Y2;
                        if (teller > 0)
                        {
                            x1_statisk = arrayCP[0, 0].Equals(arrayCP[0, teller]); //Compare to first jaw position
                            x2_statisk = arrayCP[1, 0].Equals(arrayCP[1, teller]);
                            y1_statisk = arrayCP[2, 0].Equals(arrayCP[2, teller]);
                            y2_statisk = arrayCP[3, 0].Equals(arrayCP[3, teller]);
                            // til debug:  if (teller == 1 || teller == 45 || teller == 75) { MessageBox.Show("cp x1,x2,y1,y2 " + teller + ": "+x1_statisk.ToString() + " " + x2_statisk.ToString() + " " + y1_statisk.ToString() + " " + y2_statisk.ToString()); }
                            if (x1_statisk == true && x2_statisk == true && y1_statisk == true && y2_statisk == true)
                            {
                                //koll_statisk_felt = true; //endrer aldri tilbake til true
                                MessageBox.Show("cp, index, x1,x2,y1,y2 " + teller + "|" + cp.Index +": " + x1_statisk.ToString() + " " + x2_statisk.ToString() + " " + y1_statisk.ToString() + " " + y2_statisk.ToString());
                            }
                            else
                            {
                                koll_statisk_felt = false; //kan legge inn skippe til neste felt hvis false?
                            }
                            //til debug:  if (teller == 1 || teller == 75) { MessageBox.Show("koll_statisk_felt cp " + teller + ": " + koll_statisk_felt.ToString()); }
                        }
                        teller = teller + 1;
                    }


                    //---- //skrive ut array til en messagebox for debugging:
                    for (int i = 0; i < arrayCP.GetLength(0); i++)
                    {
                        string teststr = "";
                        for (int j = 0; j < arrayCP.GetLength(1); j++)
                        {
                            teststr = teststr + ", " + arrayCP[i, j];
                        }
                        //til debug:
                        MessageBox.Show(teststr);
                    }
                    //--------------------------------------------------------

                    //hvis det er ingen kontrollpunkter settes statusen til false.
                    if (GeneralExtension.ArrayIsNullOrEmpty(arrayCP)) { jawtrackingstatus = false; }
                }
                //endelig status - hvis bare en kollimator paa ett felt ikke beveger seg, vild den si at jaw-tracking er false.
                if (koll_statisk_felt == true)
                {
                    jawtrackingstatus = false;
                }
                else
                {
                    //jawtrackingstatus = true; //endrer aldri tilbake til true
                }
                //hvis det er ingen arcs overhode maa status settes til false igjen:
                if (Feltnnr == 0) { jawtrackingstatus = false; }
            }


            //Setter
            //endelig resultat:
            if (jawtrackingstatus == true)
            {
                s.CheckStatus = Constants.Ok;
                s.CheckResultValue = "På";
                s.CheckResultValueCSV = "På";
                s.CheckStatus = Constants.Ok;
            }
            else
            {
                s.CheckStatus = s.CheckTrafficLight;
                s.CheckResultValue = "Av";
                s.CheckResultValueCSV = "Av";
                s.CheckStatus = s.CheckTrafficLight;
                s.CheckComment = "Jaw Tracking ikke slått på.";
            }
            return s;
        }

        public static CheckPoint CheckJawTrackingStatus(ExternalPlanSetup plan, CheckPoint s)
        {
            int Feltnnr = 0;
            bool jawtrackingstatus = true;// jaw beveger seg for alle kollimatorer for alle felt i planen
            bool koll_statisk_felt = true; // jaw-tracking paa for alle kollimatorer i feltet
            foreach (Beam felt in plan.Beams)
            {
                //If not setupfield and is some kind of Arc.
                if (felt.IsSetupField == false && (felt.Technique.Id.Contains(Constants.Teknikk.Arc_technique_name_Aria) || felt.Technique.Id.Contains(Constants.Teknikk.SRS_Arc_technique_name_Aria) || felt.Technique.Id.Contains(Constants.Teknikk.TotalBody_technique_name_Aria))) //enten 'ARC' og 'SRS ARC'
                {
                    Feltnnr = Feltnnr + 1;
                    // til debug:   MessageBox.Show(felt.Id.ToString());
                    int teller = 0;
                    bool x1_statisk, x2_statisk, y1_statisk, y2_statisk; //er kollimatoren statisk gjennom alle kontrollpunkt?
                    int cp_max = felt.ControlPoints.Count;
                    double[,] arrayCP = new double[4, cp_max];

                    //For each control point
                    foreach (ControlPoint cp in felt.ControlPoints)
                    {
                        arrayCP[0, teller] = cp.JawPositions.X1; //Note down the jaw positions
                        arrayCP[1, teller] = cp.JawPositions.X2;
                        arrayCP[2, teller] = cp.JawPositions.Y1;
                        arrayCP[3, teller] = cp.JawPositions.Y2;
                        if (teller > 0)
                        {
                            x1_statisk = arrayCP[0, 0].Equals(arrayCP[0, teller]); //Compare to first jaw position
                            x2_statisk = arrayCP[1, 0].Equals(arrayCP[1, teller]);
                            y1_statisk = arrayCP[2, 0].Equals(arrayCP[2, teller]);
                            y2_statisk = arrayCP[3, 0].Equals(arrayCP[3, teller]);
                            // til debug:
                            //if (teller == 1 || teller == 45 || teller == 75) { MessageBox.Show("cp x1,x2,y1,y2 " + teller + ": "+x1_statisk.ToString() + " " + x2_statisk.ToString() + " " + y1_statisk.ToString() + " " + y2_statisk.ToString()); }
                            if (x1_statisk == true && x2_statisk == true && y1_statisk == true && y2_statisk == true)
                            {
                                //koll_statisk_felt = true; //endrer aldri tilbake til true
                                //MessageBox.Show("cp, index, x1,x2,y1,y2 " + teller + "|" + cp.Index + ": " + x1_statisk.ToString() + " " + x2_statisk.ToString() + " " + y1_statisk.ToString() + " " + y2_statisk.ToString());
                            }
                            else
                            {
                                koll_statisk_felt = false; //kan legge inn skippe til neste felt hvis false?
                            }
                            //til debug:
                            //if (teller == 1 || teller == 75) { MessageBox.Show("koll_statisk_felt cp " + teller + ": " + koll_statisk_felt.ToString()); }
                        }
                        teller = teller + 1;
                    }


                    //---- //skrive ut array til en messagebox for debugging:
                    for (int i = 0; i < arrayCP.GetLength(0); i++)
                    {
                        string teststr = "";
                        for (int j = 0; j < arrayCP.GetLength(1); j++)
                        {
                            teststr = teststr + ", " + arrayCP[i, j];
                        }
                        //til debug:
                        //MessageBox.Show(teststr);
                    }
                    //--------------------------------------------------------

                    //hvis det er ingen kontrollpunkter settes statusen til false.
                    //MessageBox.Show("koll_statisk_felt cp beforeArrayISNull" + ": " + koll_statisk_felt.ToString());
                    if (GeneralExtension.ArrayIsNullOrEmpty(arrayCP)) { jawtrackingstatus = false; }
                    //MessageBox.Show("koll_statisk_felt cp afterArrayISNull" + ": " + koll_statisk_felt.ToString());
                }

            }

            //endelig status - hvis bare en kollimator beveger seg en plass blant alle cp vil det si det er jawtracking
            if (koll_statisk_felt == true)
            {
                jawtrackingstatus = false;
            }
            else
            {
                //jawtrackingstatus = true; //endrer aldri tilbake til true
            }
            //hvis det er ingen arcs overhode maa status settes til false igjen:
            if (Feltnnr == 0) { jawtrackingstatus = false; }


            //Setter
            //endelig resultat:
            if (jawtrackingstatus == true)
            {
                s.CheckStatus = Constants.Ok;
                s.CheckResultValue = "På";
                s.CheckResultValueCSV = "På";
                s.CheckStatus = Constants.Ok;
            }
            else
            {
                s.CheckStatus = s.CheckTrafficLight;
                s.CheckResultValue = "Av";
                s.CheckResultValueCSV = "Av";
                s.CheckComment = "Jaw Tracking ikke slått på.";
            }
            return s;
        }



        public static CheckPoint CheckCouchvinkel(ExternalPlanSetup plan, CheckPoint s)
        {
            s.CheckResultValue = Constants.False;//Default
            s.CheckResultValueCSV = Constants.False;
            foreach (Beam beam in plan.Beams)
            {
                string ps_angle = beam.PatientSupportAngleToUser(beam.ControlPoints.FirstOrDefault().PatientSupportAngle).ToString(); //Added PatientSupportAngleToUser-method, so that 330 degrees is not mixed with 30 degrees for instance.
                if (ps_angle != "0")
                {
                    s.CheckResultValue = Constants.True;
                    s.CheckResultValueCSV = Constants.True;
                    if (s.CheckComment != "") { s.CheckComment = s.CheckComment + Environment.NewLine; }
                    s.CheckComment = GeneralExtension.GenerateTableLine(5, 4, beam.Id + Constants.StringSeparator + ps_angle);
                    s.CheckStatus = s.CheckTrafficLight;
                }
            }

            if (s.CheckResultValue == Constants.False) //Remove if irrelevant
            {
                s.CheckDiscardedAtRuntime = Constants.True;
            }

            return s;
        }

        public static CheckPoint CheckAvoidance(ExternalPlanSetup plan, CheckPoint s)
        {
            int Feltnnr = 0;
            string Totavoidancestatus = Constants.False;// Avoidance maa egentlig sjekkes per felt, men dette er statusen er paa plan-nivaa
            //returnerer ogsaa en string med feltnavn + vinklene med jawtracking
            string VinklerAvoidance = ""; //string hvor vinklene skrives til info
            int antfelt = plan.Beams.Where(x => x.IsSetupField == false && (x.Technique.Id.Contains(Constants.Teknikk.Arc_technique_name_Aria) || x.Technique.Id.Contains(Constants.Teknikk.SRS_Arc_technique_name_Aria))).Count();
            foreach (Beam felt in plan.Beams)
            {
                if (felt.IsSetupField == false && (felt.Technique.Id.Contains(Constants.Teknikk.Arc_technique_name_Aria) || felt.Technique.Id.Contains(Constants.Teknikk.SRS_Arc_technique_name_Aria))) //enten 'ARC' og 'SRS ARC'
                {

                    Feltnnr = Feltnnr + 1;
                    // til debug:   MessageBox.Show(felt.Id.ToString());
                    int teller = 0; //Feltnummer. itererer gjennom felt som oppfyller kriteriene.
                    bool Meterset_statisk; //er metersetweight statisk gjennom flere kontrollpunkt i samme felt? (akkumulert vekt av feltet som er straalt)

                    int cp_max = felt.ControlPoints.Count;
                    double[,] arrayCP = new double[2, cp_max];
                    bool avoidancestatus = false;// Avoidance status satt paa feltnivaa. False i utgangspunktet, saa gjores sjekken.

                    foreach (ControlPoint cp in felt.ControlPoints) //Itererer gjennom alle CP
                    {

                        arrayCP[0, teller] = cp.MetersetWeight;
                        arrayCP[1, teller] = cp.GantryAngle;
                        if (teller > 0)
                        {
                            //MetersetWeight inneholder akkumulert vekt av feltet opp til controlpunktet (cp). Hvis det ikke straales paa et cp/en vinkel vil MetersetWeight ikke endre seg, ellers vil tallet alltid bli storre.
                            //Altsaa hvis Meterset er statisk fra et punkt til et annet er det null doserate og dermed avoidance.
                            Meterset_statisk = arrayCP[0, teller].Equals(arrayCP[0, teller - 1]);


                            // til debug:  if (teller == 1 || teller == 45 || teller == 75) { MessageBox.Show(""); }
                            if (Meterset_statisk == true)
                            {
                                //Hvis avoidance status ikke er satt tidligere
                                if (avoidancestatus == false)
                                {
                                    //Skriver resultatstring og setter status

                                    if (VinklerAvoidance == "") { VinklerAvoidance = GeneralExtension.FormatString(20, 20, "Feltnavn: " + Constants.StringSeparator + " Avoidancevinkler:") + Environment.NewLine; } //Header
                                    // { VinklerAvoidance = "Feltnavn: " + "\t\t" + "Avoidancevinkler:" + Environment.NewLine; } //Forste felt med avvoidance faar header. Characters: 10 (3 tabs) + 8 (2 tabs) + X
                                    VinklerAvoidance = VinklerAvoidance + GeneralExtension.FormatString(20, 20, felt.Id + Constants.StringSeparator + arrayCP[1, teller].ToString().Trim());  //Data
                                    //VinklerAvoidance = VinklerAvoidance + felt.Id + tabs + arrayCP[1, teller]; //skriver vinkel start
                                    avoidancestatus = true; //paa feltnivaa - endrer aldri status tilbake til false paa feltnivaa
                                    Totavoidancestatus = Constants.True; //paa plannivaa - endrer aldri status tilbake til false paa plannivaa
                                }
                                //Kun forste gang det skifter  til statisk meterset. Else ingenting

                            }
                            else //meterset_statisk = false
                            {
                                if (avoidancestatus == true) //paa feltnivaa. 
                                { // Naar vi gaar fra statisk meterset til okende meterset igjen: noterer ned sluttvinkelen for avoidance.
                                    VinklerAvoidance = VinklerAvoidance + "-" + arrayCP[1, teller - 1] + "°";
                                    if (Feltnnr < antfelt) { VinklerAvoidance = VinklerAvoidance + Environment.NewLine; } //skriver vinkel slutt
                                    avoidancestatus = false; //setter til false for a kun hente sluttvinkelen en gang. Totavoidancestatus er satt, som er det viktige.
                                }
                            }
                            //til debug:  if (teller == 1 || teller == 75) { MessageBox.Show(""); }
                        }
                        teller = teller + 1;
                    }// end controlpoint iterasjon


                    //---- //skrive ut array til en messagebox - kun for debugging:
                    for (int i = 0; i < arrayCP.GetLength(0); i++)
                    {
                        string teststr = "";
                        for (int j = 0; j < arrayCP.GetLength(1); j++)
                        {
                            teststr = teststr + ", " + arrayCP[i, j];
                        }
                        //til debug:  MessageBox.Show(teststr);
                    }
                    //--------------------------------------------------------

                    //hvis det er ingen kontrollpunkter settes statusen til false.
                    if (GeneralExtension.ArrayIsNullOrEmpty(arrayCP)) { avoidancestatus = false; }
                } // end feltiterasjon

                //hvis det er ingen arcs overhode maa status settes til false igjen:
                if (Feltnnr == 0) { Totavoidancestatus = Constants.False; }
            }
            s.CheckResultValueCSV = Totavoidancestatus;
            s.CheckResultValue = Totavoidancestatus;
            s.CheckComment = VinklerAvoidance;
            s.CheckStatus = Constants.Info;

            //Remove checkpoint if no comment exist
            if (s.CheckComment == "")
            {
                s.CheckDiscardedAtRuntime = Constants.True;
            }


            return s;
        }



        //AntallBehandlinger
        public static string NumberOFTreatmentsScheduled(ExternalPlanSetup plan)
        {
            int teller = 0;
            teller = plan.TreatmentSessions.Count();
            return teller.ToString();
        }


        //Henter ut isosenter som stirng i cm. 
        public static string GetIsosenter(ExternalPlanSetup plan, string xyz, Beam felt)
        {

            string iso_xyz = "";
            iso_xyz = GetIsosenter_Double(plan, xyz, felt).ToString();
            if (GetIsosenter_Double(plan, xyz, felt).ToString() == "-999")
            {
                iso_xyz = "";
            }


            return iso_xyz;
        }

        public static CheckPoint CheckPlanPatientOrientation(CheckPoint s, ExternalPlanSetup plan)
        {
            //Get generic status
            string patientPlanOrientationPlan = PlanExtension.GetPlanPatientOrientation(plan).ToString(); //retrieve Plan value.
            string patientOrientationImage = GetImagePatientOrientation(plan.StructureSet); //Image patient orientation
            s.CheckResultValue = patientPlanOrientationPlan;
            s.CheckResultValueCSV = patientPlanOrientationPlan;//Set result. Add image orientation alsi?
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(patientPlanOrientationPlan, s.CheckTemplateValue, s.CheckTrafficLight, "string", s); //Se status
            
            //--------------
            //Modify status
            //--------------
            //if no template exist and it is not standard orientation (force user to doublecheck that it is correct):
            if (patientPlanOrientationPlan != "HeadFirstSupine" && s.CheckStatus == Constants.Unknown) //&& patientPlanOrientation != "FeetFirstSupine" 
            {
                s.CheckStatus = Constants.Printout;
                s.CheckComment = s.CheckComment  + "OBS! Ikke HeadFirstSupine. Vurder!"; //Comment
            }
            //Differente patient orientation in plan and Image? Not good!(?)
            if(patientPlanOrientationPlan != patientOrientationImage)
            {
                //Endre status
                if(s.CheckStatus != Constants.Warning && s.CheckStatus != Constants.Warning2 && s.CheckStatus != Constants.Error) 
                {
                    s.CheckStatus = Constants.Warning;
                }
                if (s.CheckComment != "") { s.CheckComment = s.CheckComment + Environment.NewLine; }
                s.CheckComment = s.CheckComment + "OBS! CT-bildene sin PatientOrientation er forskjellig fra planen sin PatientOrientation!"; //Comment
            }

            
            return s;
        }

        public static string GetPlanPatientOrientation(ExternalPlanSetup plan)
        {
            string pasOrient = "";
            pasOrient = plan.TreatmentOrientation.ToString();
            return pasOrient;
        }
        public static string GetImagePatientOrientation(StructureSet structureSet)
        {
            Image image = structureSet.Image;
            
            string pasOrient = "";
            pasOrient = image.ImagingOrientation.ToString();
            return pasOrient;
        }
        public static string GetImageCreationDate(StructureSet structureSet)
        {
            Image image = structureSet.Image;
            string imageDate = image.CreationDateTime.ToString(); //.Series.Study.CreationDateTime
            return imageDate;
        }

        //Henter ut isosenter som  double i cm. Gir ut -999 ved error.
        public static double GetIsosenter_Double(ExternalPlanSetup plan, string xyz, Beam felt)
        {

            double iso_xyz = -999;
            double iso_xyz_test = -999;
            var uo = plan.StructureSet.Image.UserOrigin; // 
            //plan.StructureSet.Image.DicomToUser(plan.StructureSet.Image.Origin, plan).x.ToString();
            //plan.StructureSet.Image.DicomToUser(plan.Beams.FirstOrDefault().IsocenterPosition, plan).x.ToString();
            //-----------------------------------------------------------
            //fortegn for beregning avhengig av orientering paa pasient?
            //-----------------------------------------------------------
            bool BytteXogY = false; //skal koordinatene byttes pga pasientorientering?
            double fortegnx = 1;
            double fortegny = 1;
            double fortegnz = 1;
            PatientOrientation orientering = plan.TreatmentOrientation;

            if (orientering == PatientOrientation.HeadFirstSupine)
            {
                fortegnx = 1;
                fortegny = 1;
                fortegnz = 1;
            }
            if (orientering == PatientOrientation.HeadFirstProne)
            {
                fortegnx = -1;
                fortegny = -1;
                fortegnz = 1;
            }
            if (orientering == PatientOrientation.FeetFirstProne)
            {
                fortegnx = 1;
                fortegny = -1;
                fortegnz = -1;
            }
            if (orientering == PatientOrientation.FeetFirstSupine)
            {
                fortegnx = -1;
                fortegny = 1;
                fortegnz = -1;
            }
            if (orientering == PatientOrientation.FeetFirstDecubitusLeft)
            {
                BytteXogY = true;
                fortegnx = 1;
                fortegny = 1;
                fortegnz = -1;
            }
            if (orientering == PatientOrientation.FeetFirstDecubitusRight)
            {
                BytteXogY = true;
                fortegnx = -1;
                fortegny = -1;
                fortegnz = -1;
            }
            if (orientering == PatientOrientation.HeadFirstDecubitusLeft)
            {
                BytteXogY = true;
                fortegnx = -1;
                fortegny = 1;
                fortegnz = 1;
            }
            if (orientering == PatientOrientation.HeadFirstDecubitusRight)
            {
                BytteXogY = true;
                fortegnx = 1;
                fortegny = -1;
                fortegnz = 1;
            }

            //Regner ut posisjonenen, bruker fortegn og bytter om koordinater basert paa pasientorientering
            if (xyz == "x")
            {
                iso_xyz_test = Math.Round(plan.StructureSet.Image.DicomToUser(plan.Beams.FirstOrDefault().IsocenterPosition, plan).x / 10, 2);
                if (BytteXogY == true)
                {
                    iso_xyz = Math.Round(fortegnx * (felt.IsocenterPosition.y - uo.y) / 10, 2);
                }
                else
                {
                    iso_xyz = Math.Round(fortegnx * (felt.IsocenterPosition.x - uo.x) / 10, 2);
                }
            }
            else if (xyz == "y")
            {
                iso_xyz_test = Math.Round(plan.StructureSet.Image.DicomToUser(plan.Beams.FirstOrDefault().IsocenterPosition, plan).y / 10, 2);

                if (BytteXogY == true)
                {
                    iso_xyz = Math.Round(fortegny * (felt.IsocenterPosition.x - uo.x) / 10, 2);
                }
                else
                {
                    iso_xyz = Math.Round(fortegny * (felt.IsocenterPosition.y - uo.y) / 10, 2);
                }
            }
            else if (xyz == "z")
            {
                iso_xyz_test = Math.Round(plan.StructureSet.Image.DicomToUser(plan.Beams.FirstOrDefault().IsocenterPosition, plan).z / 10, 2);
                iso_xyz = Math.Round(fortegnz * (felt.IsocenterPosition.z - uo.z) / 10, 2);
            }
            else
            {
                MessageBox.Show("Feil input i funksjonen 'GetIsosenter_Double(). Isosenter som kommer ut blir feil.");
            }


            return iso_xyz;
        }

        public static double IsosenterCorrectedToUserCoordinateSystem(ExternalPlanSetup plan, string xyz, double x, double y, double z)
        {

            double corrected_xyz = -999;
            var isosenter = plan.Beams.FirstOrDefault().IsocenterPosition;
            Image image = plan.StructureSet.Image;


            //Use function that exist in Image.DicomToUser
            if (xyz == "x")
            {
                corrected_xyz = Math.Round(image.DicomToUser(isosenter, plan).x, 3);
            }
            else if (xyz == "y")
            {
                corrected_xyz = Math.Round(image.DicomToUser(isosenter, plan).y, 3);
            }
            else if (xyz == "z")
            {
                corrected_xyz = Math.Round(image.DicomToUser(isosenter, plan).z, 3);
            }
            else
            {
                MessageBox.Show("Feil input i funksjonen 'IsosenterCorrectedToUserCoordinateSystem(). Isosenter som kommer ut blir feil.");
            }
            return corrected_xyz;
        }

        public static double ImageOriginCorrectedToUserCoordinateSystem(ExternalPlanSetup plan, string xyz, double x, double y, double z)
        {

            double corrected_xyz = -999;
            var uo = plan.StructureSet.Image.Origin;
            Image image = plan.StructureSet.Image;


            //Use function that exist in Image.DicomToUser
            if (xyz == "x")
            {
                corrected_xyz = Math.Round(image.DicomToUser(uo, plan).x, 3);
            }
            else if (xyz == "y")
            {
                corrected_xyz = Math.Round(image.DicomToUser(uo, plan).y, 3);
            }
            else if (xyz == "z")
            {
                corrected_xyz = Math.Round(image.DicomToUser(uo, plan).z, 3);
            }
            else
            {
                MessageBox.Show("Feil input i funksjonen 'ImageOriginCorrectedToUserCoordinateSystem(). Origin som kommer ut blir feil.");
            }
            return corrected_xyz;
        }
        public static string CorrectLateralityToPatientOrientation(PatientOrientation patientOrientation, string laterality)
        {
            bool InverseValue = false; //Right is Right
            //bool ChangeXandY = false; //Should we look at y or x to find "Right or "Left" //Not implemented
            string new_laterality = laterality;

            if (patientOrientation == PatientOrientation.HeadFirstSupine)
            {
                InverseValue = false;
            }
            if (patientOrientation == PatientOrientation.HeadFirstProne)
            {
                InverseValue = true;
            }
            if (patientOrientation == PatientOrientation.FeetFirstProne)
            {
                InverseValue = false;
            }
            if (patientOrientation == PatientOrientation.FeetFirstSupine)
            {
                InverseValue = true; //InverseValue = true;
            }
            //Suggestion: for all other patient orientations, set laterality to unknown!
            //if (patientOrientation == PatientOrientation.FeetFirstDecubitusLeft)
            //{
            //    ChangeXandY = true;
            //    InverseValue = false;
            //}
            //if (patientOrientation == PatientOrientation.FeetFirstDecubitusRight)
            //{
            //    ChangeXandY = true;
            //    InverseValue = true;
            //}
            //if (patientOrientation == PatientOrientation.HeadFirstDecubitusLeft)
            //{
            //    ChangeXandY = true;
            //    InverseValue = false;
            //}
            //if (patientOrientation == PatientOrientation.HeadFirstDecubitusRight)
            //{
            //    ChangeXandY = true;
            //    InverseValue = true;
            //}

            //Set value

            if (InverseValue == false)
            {
                if (laterality == Constants.Hoyre )
                {
                    new_laterality = Constants.Hoyre;
                }
                else if(laterality == Constants.Venstre)
                {
                    new_laterality = Constants.Venstre;
                }

            }
            else if (InverseValue == true)
            {
                if (laterality == Constants.Venstre)
                {
                    new_laterality = Constants.Hoyre;
                }
                else if (laterality == Constants.Hoyre)
                {
                    new_laterality = Constants.Venstre;
                }

            }


            return new_laterality;
        }


            public static string MultipleIsosenter(ExternalPlanSetup plan)
        {
            string multipleIsoResultat = Constants.False;

            string x = "";
            string y = "";
            string z = "";

            string _x = "";
            string _y = "";
            string _z = "";

            int teller = 0;

            foreach (Beam felt in plan.Beams)
            {
                teller = teller + 1;

                if (teller == 1)
                {
                    x = felt.IsocenterPosition.x.ToString();
                    y = felt.IsocenterPosition.y.ToString();
                    z = felt.IsocenterPosition.z.ToString();
                }
                else
                {
                    _x = felt.IsocenterPosition.x.ToString();
                    _y = felt.IsocenterPosition.y.ToString();
                    _z = felt.IsocenterPosition.z.ToString();


                    if (x != _x || y != _y || z != _z)
                    {
                        multipleIsoResultat = Constants.True;
                    }
                }

            }

            return multipleIsoResultat;
        }

        public static bool SjekkOmHeltall(double x)
        {
            //true hvos heltall
            return Math.Abs(x % 1) <= (Double.Epsilon * 100);
        }

        public static string IsosenterHeltall(ExternalPlanSetup plan, string xyz = "xyz")
        {
            string IsosenterHeltall = Constants.True;
            bool _testbool = true;
            double x;
            double y;
            double z;

            foreach (Beam felt in plan.Beams)
            {
                x = GetIsosenter_Double(plan, "x", felt);
                y = GetIsosenter_Double(plan, "y", felt);
                z = GetIsosenter_Double(plan, "z", felt);

                //tester om enten x,y eller z spesifikt er heltall, evt om alle er heltall.
                if (_testbool == true)
                {
                    if (xyz == "x")
                    {
                        _testbool = (SjekkOmHeltall(x) == true);
                    }
                    if (xyz == "y")
                    {
                        _testbool = (SjekkOmHeltall(y) == true);
                    }
                    if (xyz == "z")
                    {
                        _testbool = (SjekkOmHeltall(z) == true);
                    }
                    else //"xyz"
                    {
                        _testbool = (SjekkOmHeltall(x) == true && SjekkOmHeltall(y) == true && SjekkOmHeltall(z) == true);
                    }

                    if (_testbool == false)
                    {
                        IsosenterHeltall = Constants.False;
                    }
                }
            }
            return IsosenterHeltall;
        }

        // DOSE

        public static double[,,] GetDoseMatrix(this PlanningItem pi, DoseValue.DoseUnit unit)
        {
            var oldPresentation = pi.DoseValuePresentation;
            pi.DoseValuePresentation = DoseValuePresentation.Absolute;
            double factor = 1.0;
            if (unit == DoseValue.DoseUnit.Percent)
            {
                factor = 100 * pi.Dose.VoxelToDoseValue(int.MaxValue).Dose / TotalDoseGy(pi);   //);
                factor /= (double)int.MaxValue;
            }
            else if (unit != DoseValue.DoseUnit.Unknown)
                factor = pi.Dose.VoxelToDoseValue(int.MaxValue).Dose / (double)int.MaxValue;
            pi.DoseValuePresentation = oldPresentation;

            int nx = pi.Dose.XSize;
            int ny = pi.Dose.YSize;
            int nz = pi.Dose.ZSize;
            double[,,] dose = new double[nx, ny, nz];
            int[,] slice = new int[nx, ny];

            for (int kz = 0; kz < nz; kz++)
            {
                pi.Dose.GetVoxels(kz, slice);
                for (int ix = 0; ix < nx; ix++)
                    for (int jy = 0; jy < ny; jy++)
                        dose[ix, jy, kz] = factor * slice[ix, jy];
            }

            return dose;
        }

        public static double TotalDoseGy(this PlanningItem pi)
        {
            Func<PlanSetup, double> getDoseFromRx = ps => { return ps.TotalDose.Dose; };

            //Dose is prescription based

            if (pi is PlanSetup)
            {
                var plan = pi as PlanSetup;
                return getDoseFromRx(plan);
            }
            //Plan Sum
            var sum = pi as PlanSum;
            var totalDose = 0.0;
            foreach (var plan in sum.PlanSetups)
                totalDose += getDoseFromRx(plan);
            return totalDose;
        }



        // -------------------------------------------
        // ----------     Utdatert          ----------
        // -------------------------------------------

        public static bool CheckMachineProperty(string machine, string machine_list)
        {
            bool _match_Res = false;
            bool match = false;
            foreach (string m in machine_list.Split(Constants.CharSeparator).ToList())
            {
                match = (m == machine);
                //Setter status globalt _match=true om det er match paa en av maskinene i listen
                if (match != false)
                { _match_Res = true; }
            }
            return _match_Res;
        }

        public static bool CheckIfHalcyonMachine(List<Field> feltliste)
        {
            bool _match_Hal = false;
            var match = new Field();
            foreach (string m in Constants.MachinesHalcyon.Split(Constants.CharSeparator).ToList())
            {
                match = feltliste.FirstOrDefault(stringToCheck => stringToCheck.FieldMachineID == m);
                //Setter status globalt _match=true om det er match paa en av maskinene i listen
                if (match != null)
                { _match_Hal = true; }
            }
            return _match_Hal;
        }
        public static bool CheckIfEthosMachine(List<Field> feltliste) 
        {
            var match = new Field();
            bool _match_Eth = false;
            foreach (string m in Constants.MachinesEthos.Split(Constants.CharSeparator).ToList())
            {
                match = feltliste.FirstOrDefault(stringToCheck => stringToCheck.FieldMachineID == m);
                //Setter status globalt _match=true om det er match paa en av maskinene i listen
                if (match != null)
                { _match_Eth = true; }
            }
            return _match_Eth;
        }

        public static bool CheckIfTrueBeamMachine(List<Field> feltliste)
        {
            bool _match_TB = false;
            var match = new Field();
            foreach (string m in Constants.MachinesTB.Split(Constants.CharSeparator).ToList())
            {
                match = feltliste.FirstOrDefault(stringToCheck => stringToCheck.FieldMachineID == m);
                //Setter status globalt _match=true om det er match paa en av maskinene i listen
                if (match != null)
                { _match_TB = true; }
            }
            return _match_TB;
        }
        public static CheckPoint CheckIsosenterWarningHalcyonEthos(ExternalPlanSetup plan, CheckPoint s)
        {
            string resultat = Constants.Ok;
            string resultat_info = "";
            string str_iso_z = "";
            Double neg_toleranse_isoZ_Halcyon = -30;
            Double pos_toleranse_isoZ_Halcyon = 17;

            //Antatt pa forhaand at det er Ethos eller Halcyon maskin! Samme sjekk, saa de er slaatt sammen.
            //Antatt kun ett isosenter, eller vil bare siste komme ut.
            foreach (Beam felt in plan.Beams)
            {

                Double iso_z = GetIsosenter_Double(plan, "z", felt);
                str_iso_z = iso_z.ToString();

                if ((iso_z < neg_toleranse_isoZ_Halcyon || iso_z > pos_toleranse_isoZ_Halcyon) && resultat == Constants.Ok)
                {
                    resultat = Constants.Error; //onsker kun aa gi feilmelding en gang.
                    resultat_info = "ERROR: Plan kan ikke leveres på Ethos eller Halcyon! Z = " + iso_z.ToString() + ". Kan ikke ha z < " + neg_toleranse_isoZ_Halcyon + " eller z > " + pos_toleranse_isoZ_Halcyon + ".";
                }
            }

            s.CheckResultValue = "z = " + str_iso_z;
            s.CheckResultValueCSV = "z = " + str_iso_z;
            s.CheckTemplateValue = " z > " + neg_toleranse_isoZ_Halcyon + "; z < " + pos_toleranse_isoZ_Halcyon + ".";
            s.CheckComment = resultat_info;
            s.CheckStatus = resultat;

            return s;
        }






    }
}
