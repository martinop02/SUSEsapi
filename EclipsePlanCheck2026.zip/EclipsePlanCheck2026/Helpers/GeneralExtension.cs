﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

using System.Windows.Media.Media3D;
//Endre strukturer til transluce:
using System.Drawing;

//Slipper eksplisitt referere til Helpers
using EclipsePlanCheck.Helpers;

using System.Reflection;
using System.Collections;
using System.Diagnostics;


namespace EclipsePlanCheck
{
    public static class GeneralExtension
    {

        public class ParsedFieldInfo
        {
            public string FieldId { get; set; }
            public string FieldNumberString { get; set; }
            public int? FieldNumberInteger { get; set; }
            public string FieldDegreeString { get; set; }
            public int? FieldDegreeInteger { get; set; }

            public string AfterFieldDegreeRemainingString { get; set; }
            public string AfterFieldDegreeEnergy { get; set; }

            public string AfterDegreeCouchAngleString { get; set; }
            public int? AfterDegreeCouchAngleInteger { get; set; }


        }



        //Extract the two first characters if they are digits as integer.
        //Can be used to find field number, plan number and course number
        //Assume we never go aboe 99.

        public static List<int> ExtractAndConvertFirstTwoDigits(List<string> inputStrings)
        {
            List<int> resultDigits = new List<int>();
            Regex regex = new Regex(@"^\d{2}"); // Matches exactly two digits at the beginning of the string

            foreach (string str in inputStrings)
            {
                Match match = regex.Match(str);
                if (match.Success)
                {
                    // Extract the matched string (the two digits)
                    string digitString = match.Value;

                    // Convert the extracted string to an integer
                    if (int.TryParse(digitString, out int parsedDigit))
                    {
                        resultDigits.Add(parsedDigit);
                    }
                }
            }
            return resultDigits;
        }

        /// <summary>
        /// Checks if a list of integer digits contains no multiple of the same digit
        /// and no missing digit between the minimum and maximum values.
        /// </summary>
        /// <param name="digits">The list of integer digits to check.</param>
        /// <returns>True if the conditions are met, false otherwise.</returns>
        public static bool CheckDigitsForMultipleAndHoles(List<int> digits)
        {
            if (digits == null || !digits.Any())
            {
                // An empty or null list cannot satisfy the conditions.
                return false;
            }

            // 1. Check for multiple occurrences of the same digit (no duplicates).
            // Convert to a HashSet to efficiently check for duplicates.
            HashSet<int> distinctDigits = new HashSet<int>(digits);
            if (distinctDigits.Count != digits.Count)
            {
                // Duplicates found.
                return false;
            }

            // 2. Check for missing digits between the minimum and maximum values.
            int minDigit = digits.Min();
            int maxDigit = digits.Max();

            // Iterate from minDigit to maxDigit and ensure each digit is present.
            for (int i = minDigit; i <= maxDigit; i++)
            {
                if (!distinctDigits.Contains(i))
                {
                    // A digit is missing in the sequence.
                    return false;
                }
            }

            // All conditions are met.
            return true;
        }

        // should contain No Multiples, no Holes and should contain one with 1.
        public static bool ValidateDigitList(List<int> digits)
        {
            // 1. Check for at least one '1'
            if (!digits.Contains(1))
            {
                return false;
            }

            // 2. Check for no multiple of the same digit
            if (digits.Distinct().Count() != digits.Count)
            {
                return false; //handle different cases where this can be allowed for fields
            }

            // 3. Check for no missing digits between the min and max
            if (digits.Count > 1) // Only relevant if there's more than one digit
            {
                int minDigit = digits.Min();
                int maxDigit = digits.Max();

                // Create a reference sequence from min to max
                var expectedSequence = Enumerable.Range(minDigit, maxDigit - minDigit + 1);

                // Check if the input digits contain all expected digits and no others
                if (!expectedSequence.All(expectedDigit => digits.Contains(expectedDigit)) ||
                    !digits.All(inputDigit => expectedSequence.Contains(inputDigit)))
                {
                    return false;
                }
            }

            return true; // All conditions are met.
        }

        public static List<string> ExtractAfterFieldDegreeCharacters(List<string> inputStrings)
        {
            List<string> extractedParts = inputStrings
                .Select(s =>
                {
                    int degreeIndex = s.IndexOf('°');
                    if (degreeIndex != -1 && degreeIndex < s.Length - 1)
                    {
                        return s.Substring(degreeIndex + 1);
                    }
                    return null; // Or string.Empty, depending on desired behavior for strings without a degree char or with degree char at the end
            })
                .Where(s => s != null) // Filter out nulls if you returned null for non-matches
                .ToList();

            return extractedParts;
        }
        public static bool FieldDegreeMatchesStaticField(string input)
        {
            // Regex pattern:
            // ^          - Start of the string
            // \d+        - One or more digits
            // \u00B0     - The Unicode character for the degree sign
            // (?!-|\s-)  - Negative lookahead: asserts that the following characters are NOT
            //              a minus sign OR a space followed by a minus sign
            // $          - End of the string
            string pattern = @"^\d+\u00B0(?!-|\s-)$";
            return Regex.IsMatch(input, pattern);
        }

        //Extract degree number (from a field)
        public static string ExtractFieldDegreeNumber(string input) //Will only work for static fields! What about VMAT with two degrees with one "-" between.
        {
            // Regex pattern:
            // (\d+) captures one or more digits.
            // (?=°) is a positive lookahead asserting that the captured digits are followed by a degree symbol.
            string pattern = @"(\d+)(?=°)";
            Match match = Regex.Match(input, pattern);

            if (match.Success)
            {
                return match.Groups[1].Value; // Return the captured digits
            }
            else
            {
                return string.Empty; // No match found
            }
        }


        //   Two numbers: Represented by \d{2}.
        //  Then a space: Represented by \s.
        //  Then one or more digits: Represented by \d+.
        //  Then a degree sign: Represented by \u00B0 (the Unicode representation of the degree symbol).
        //  Then not a minus sign or a space and minus sign after that: This is a negative lookahead assertion, (?!-|\s -). This ensures that the degree sign is not immediately followed by a hyphen or by a space and then a hyphen.
        //  Then any number of characters or number or special characters: Represented by .*. This matches any character (except newline) zero or more times.
        public static bool FieldDegreesMatchesStaticField(string input)
        {
            // The regex pattern
            string pattern = @"^\d{2}\s\d+\u00B0(?!-|\s-).*$";

            // Use Regex.IsMatch to check if the input string matches the pattern
            return Regex.IsMatch(input, pattern);
        }
        public static void ExtractFieldDegreeDigitsFromStaticField(string input)
        {
            string pattern = @"^\d{2}\s(?<digitsBeforeDegree>\d+)°(?!-).*$";
            Match match = Regex.Match(input, pattern);

            if (match.Success)
            {
                string extractedDigits = match.Groups["digitsBeforeDegree"].Value;
                Console.WriteLine($"'{input}' matches. Extracted digits before degree sign: {extractedDigits}");
            }
            else
            {
                Console.WriteLine($"'{input}' does not match the required format.");
            }

            //string input1 = "12 345°abc"; // Matches
            //string input2 = "99 1°Xyz";    // Matches
            //string input3 = "01 23°-def";  // Does not match (has '-' after degree sign)
            //string input4 = "ab 123°ghi";  // Does not match (not two digits at start)
            //string input5 = "12 34°";      // Matches
            //string input6 = "12 345-abc";  // Does not match (no degree sign)
        }

        public static bool FieldDegreesMatchesArcField(string input)
        {
            // The pattern:
            // ^          - Start of the string
            // \d{2}      -  Two numbers
            //  ` `       -  Then a space
            // \d+        - One or more digits
            // \u00B0     - The Unicode character for the degree sign (°)
            // -          - A literal minus sign
            // \d+        - One or more digits
            // \u00B0     - The Unicode character for the degree sign (°)
            // $          - End of the string
            // .*         - Then any number of characters or numbers or special characters: .*
            string pattern = @"^\d{2} \d+\u00B0-\d+\u00B0.*$";
            return Regex.IsMatch(input, pattern);

            //Test:

            //string validString = "12 345°-67°Some_text_here!";
            //string invalidString1 = "1 345°-67°"; // Not two initial digits
            //string invalidString2 = "12 345-67°"; // Missing first degree sign
            //string invalidString3 = "12 345°-67"; // Missing second degree sign
        }

        public static List<int> ExtractFieldDegreeDigitsFromArc(string input)
        {
            // Regex pattern explanation:
            // ^\d{2}            - Matches exactly two digits at the beginning of the string.
            // \s               - Matches a single whitespace character.
            // (\d+)            - Captures one or more digits (Group 1 - first set of digits before degree sign).
            // °                - Matches the degree sign character.
            // -                - Matches a literal minus sign.
            // (\d+)            - Captures one or more digits (Group 2 - second set of digits before degree sign).
            // °                - Matches the degree sign character.
            // .*               - Matches any character (except newline) zero or more times.
            // $                - Matches the end of the string.
            string pattern = @"^\d{2}\s(\d+)°-?(\d+)°.*$";

            Match match = Regex.Match(input, pattern);

            if (match.Success)
            {
                List<int> digits = new List<int>();
                digits.Add(int.Parse(match.Groups[1].Value)); // First captured group
                digits.Add(int.Parse(match.Groups[2].Value)); // Second captured group
                return digits;
            }
            else
            {
                return null; // Format not matched
            }

            //string input1 = "12 34° -56° Some text here";
            //string input2 = "99 123° -4567° Another example!";
            //string input3 = "Invalid string";
        }

        public static List<int> ExtractNumbersBeforeDegree(List<string> inputStrings)
        {
            List<int> extractedNumbers = new List<int>();
            // The regex pattern looks for one or more digits (\d+) followed by a degree symbol (°)
            // The parentheses around \d+ create a capturing group for the digits.
            string pattern = @"(\d+)°";

            foreach (string input in inputStrings)
            {
                MatchCollection matches = Regex.Matches(input, pattern);

                foreach (Match match in matches)
                {
                    // The captured group (index 1) contains the digits
                    if (int.TryParse(match.Groups[1].Value, out int number))
                    {
                        extractedNumbers.Add(number);
                    }
                }
            }
            return extractedNumbers;
        }


        public static int? FirstTwoCharactersAsIntegerOrNull(string inputId)
        {
            int? firstTwoCharacters = null;

            string pattern = @"^(\d{2})";
            Match match = Regex.Match(inputId, pattern);
            if (match.Success)
            {
                string extractedDigits = match.Groups[1].Value;
                if (int.TryParse(extractedDigits, out int result))
                {
                    firstTwoCharacters = result;
                    //Console.WriteLine($"Input: \"{inputId}\" -> Extracted: \"{extractedDigits}\", Converted Integer: {result}");
                }
                else
                {
                    //Console.WriteLine($"Input: \"{inputId}\" -> Error converting \"{extractedDigits}\" to integer.");
                }
            }
            else
            {
                //Console.WriteLine($"Input: \"{inputId}\" -> First two characters are not digits or string is too short.");
            }

            return firstTwoCharacters; //integer or null
        }

        public static void PrintObject(object inputObject)
        {
            MessageBox.Show(ClassToString(inputObject));
        }
        public static string ClassToString(object inputObject)
        {
            string resultPrintObject = "";

            Type objectType = inputObject.GetType();

            //Get all properties from class
            PropertyInfo[] properties = objectType.GetProperties();
            //Iterate through all properties 
            foreach (PropertyInfo property in properties) //Must have exception for certain fields we do not want to override.
            {
                string value = "";
                //If property value not empty
                try
                {
                    value = property.GetValue(inputObject).ToString();
                }
                catch
                {
                    value = "Unable to retrieve value from template. ";
                }
                string EclipseCheckTemplate = property.Name;

                if (resultPrintObject == "") { resultPrintObject = EclipseCheckTemplate + ": " + value; }
                else { resultPrintObject = resultPrintObject + Environment.NewLine + EclipseCheckTemplate + ": " + value; }
            }

            return resultPrintObject;
        }
        public static string ToBitString(this BitArray bits)
        {
            var sb = new StringBuilder();

            for (int i = 0; i < bits.Count; i++)
            {
                char c = bits[i] ? '1' : '0';
                sb.Append(c);
            }
            return sb.ToString();
        }

        public static string AddStringWithNewLineIfNotEmpty(string mainString, string addString) //Empty or null
        {
            string addStringWithNewLine = (mainString == "" || mainString == null) ? addString : mainString + Environment.NewLine + addString;
            return addStringWithNewLine;
        }
        public static string AddStringWithSeparatorIfNotEmpty(string mainString, string addString) //Empty or null
        {
            string addStringWithNewLine = (mainString == "" || mainString == null) ? addString : mainString + ", " + addString;
            return addStringWithNewLine;
        }

        public static bool NumberIsInteger(double input)
        {
            return Math.Abs(input % 1) <= (Double.Epsilon * 100);
        }

        public static int NumberOfTabsInString(string s = "", int tabdef = 4)
        {
            int res_int = 0;
            int s_int = s.Length;

            double nbOfVisualTabs = Math.Ceiling((double)s_int / tabdef); //ikke Round, Ceiling runder opp, altsaa om det er 11 characters trenger man 3 tabs med 4 characters (=12 characters)
            //---Korreksjoner---
            //Hvis lengden er under 4, må legge til ekstra tab.
            if (s_int < tabdef) { res_int = 1; }
            //Hvis nøyaktig x*tabdef (8 eller 16 characters feks), må legge inn ekstra tab.
            if (NumberIsInteger((double)s_int / tabdef)) { res_int = res_int + 1; }

            res_int = res_int + (int)nbOfVisualTabs;

            //Sender resultat
            return res_int;
        }

        public static string GenerateTabs(int n)
        {
            return new string('\t', n);
        }

        // --- Brukes til aa formatere en linje i en tabell korrekt ----
        //antallTabs = antall tabs fra en kolonne til den neste, avgjøres av hva man tror er maks characters eller tabs man kan faa i input
        //tabdef = antall characters i en tab, ofte 4
        //input er det som skal legges i hver kolonne, så justeres antall tabs etter det. Teksstring med Constants.CharSeparator for å skille hver kolonne. Kan vaere header- eller data-linje


        public static string Align(string key, int width)
        {
            string newKey = "";
            string[] keyElements = key.Split('|');

            if (keyElements.Length == 1)
            {
                newKey += key;
            }
            else if (keyElements.Length == 2)
            {
                //left align the first chunk
                newKey += keyElements[0];
                //insert blank spaces so the entire line length will be a multiple of width
                newKey += new string('.', width - ((key.Length - 1) % width));
                //insert the last chunk
                newKey += keyElements[1];
            }
            else if (keyElements.Length == 3)
            {
                if (keyElements[0] != "")
                {
                    //left align the first chunk 
                    newKey += keyElements[0];
                    //and pad the rest of the line
                    newKey += new string('.', width - (keyElements[0].Length % width));
                }
                //pad the left, center the second chunk and pad the right
                double sidePadding = width - (keyElements[1].Length % width);
                int leftPadding = (int)Math.Floor(sidePadding / 2);
                int rightPadding = (int)Math.Ceiling(sidePadding / 2);
                newKey += new string('.', leftPadding) + keyElements[1] + new string('.', rightPadding);

                if (keyElements[2] != "")
                {
                    //pad the line
                    newKey += new string('.', width - (keyElements[2].Length % width));
                    //and right align the last chunk
                    newKey += keyElements[2];
                }
            }

            return newKey;
        }

        public static string Wrap(string key, int width)
        {
            return Regex.Replace(key, ".{" + width + "}", "$0" + Environment.NewLine);
        }

        //numberOfSpacesFirst: Max number of spaces accepted in first column. numberOfSpacesRest: Max number of spaces accepted in all other columns. Negative means left aligned, positiv is right aligned.
        public static string FormatString(int numberOfSpacesFirst, int numberOfSpacesRest, string KolInput)
        {

            string resultstring = "";
            string spaces = "";
            //string content = "";
            string[] inputArr = KolInput.Split(Constants.CharSeparator);
            int totant = inputArr.Count();
            int i = 0;
            //string[] newArray = new string[inputArr.Count()];
            //Create format string
            foreach (string s in inputArr)
            {
                if (i ==0)
                {
                    spaces = spaces + "{" + i + "," + numberOfSpacesFirst + "}  ";     //{0,20}{1,15}{2,15}
                    //newArray[i] = Align(s, numberOfSpacesFirst);
                }
                else
                {
                    spaces = spaces + "| {" + i + "," + numberOfSpacesRest + "}";     //{0,20}{1,15}{2,15}
                    //newArray[i] = Align(s, numberOfSpacesRest);
                }
                i = i + 1;
            }
            //Create table:
            resultstring = string.Format(spaces, inputArr); //newArray

            return resultstring;
        }


        //Ubrukelig
        public static string GenerateTabelLineSpaces (int numberOfSpacesFirst, int numberOfSpacesRest, string KolInput)
        {

            string resultstring = "";
            string[] inputArr = KolInput.Split(Constants.CharSeparator);
            int totant = inputArr.Count();
            int i = 0;

            
            foreach (string s in inputArr)
            {
                i = i + 1;
                if ( i ==1 )
                {
                    resultstring = resultstring  + s.PadRight(numberOfSpacesFirst) + "|";
                }
                else
                {
                    resultstring = resultstring  + s.PadRight(numberOfSpacesRest) + "|";
                }
                
            }

            //string.Format("{0,20}{1,15}{2,15}", resultstring, resultstring, resultstring);

            return resultstring;
        }

        public static string Generatestringwithformat(int numberOfSpacesFirst, int numberOfSpacesRest, string KolInput)
        {

            string resultstring = "";
            string[] inputArr = KolInput.Split(Constants.CharSeparator);
            int totant = inputArr.Count();
            int i = 0;


            foreach (string s in inputArr)
            {
                i = i + 1;
                if (i == 1)
                {
                    resultstring = resultstring + s.PadRight(numberOfSpacesFirst) + "|";
                }
                else
                {
                    resultstring = resultstring + s.PadRight(numberOfSpacesRest) + "|";
                }

            }

            return resultstring;
        }

        public static void PrintTxtDocument(string documentation)
        {
            DateTime dateTime = DateTime.Now;
            string fileName = "EclipsePlanCheck_Documentation" + dateTime.ToString("yyyy_MM_dd_HH_mm") + ".txt";
            string pathWithName = "";
            try
            {
                //Temp path
                string path = System.IO.Path.GetTempPath();
                pathWithName = path + fileName; // + @"/"

                // Create a new file and write the content to it
                File.WriteAllText(pathWithName, documentation);
                //Console.WriteLine($"Document '{fileName}' created successfully.");

                // Open the document with the default application
                Process.Start(pathWithName);
                //Console.WriteLine($"Document '{fileName}' opened.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Feilmelding i forsøk på å generere dokumentasjon: {ex.Message}" + Environment.NewLine + "Forsøkte lagre fil på sti:" + pathWithName);
                //Console.WriteLine($"An error occurred: {ex.Message}");
            }

        }


        public static string GenerateDocumentation(PatientContext patientContext, CheckScenarioResult checkScenarioResultat)
        {
            string documentation = "";
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "       CheckPoint Documentation");
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");

            //remember old template:
            string chosentemplate = checkScenarioResultat.TemplateChosen.TemplateName; //Why is this necessary, checkScenarioResultat is not passed back! Find out later how to avoid, so we dont end up changing something we should not.

            CheckScenarioResult tempcheckScenarioResultat = new CheckScenarioResult();
            tempcheckScenarioResultat = checkScenarioResultat; //Alle templaters resultat
            //string templateChosen = "zzDocumentation";
            //Temporary set template name:
            tempcheckScenarioResultat.TemplateChosen.TemplateName = "zzDocumentation";


            List<CheckPoint> tempcheckPointList = new List<CheckPoint>();

            //Need to add certain fake data in order to create certain checks:

            //Create fake bolus:
            List<StructureCheck> boluser = new List<StructureCheck>();
            boluser.Add(new StructureCheck() { StructureID = "Bolus", StructureHU = "-300", StructureType = "eclipsebolus", AttachedFields = "", Explanation = "", Status = Constants.Ok, ColorSet = "Cyan" });

            //Create fake list of margins:
            List<MarginList> listOfMarginLists = new List<MarginList>();

            //Create CheckPointList:
            tempcheckPointList = CreateCheckPoint.CreateCheckPointList(patientContext, tempcheckScenarioResultat, listOfMarginLists); //boluser

            //Create empty checkpoint for Structure.
            CheckPoint checkpoint = new CheckPoint()
            {
                CheckListCategory = "CT og strukturer",
                CheckNumber = "2.6",
                CheckCategory = "Strukturer",
                CheckName = "Marginer: " + Environment.NewLine + "CTV" + " -> " + Environment.NewLine + "PTV", // + Environment.NewLine +
                CheckTemplateValue = "", 
                CheckVerification = "",
                CheckComment = "",
                CheckType = Constants.Check,
                CheckExplanation = "Sjekker om marginene er innenfor toleranse. Hvis ingen toleranser oppgitt, vises bare marginene til info.",
                CheckTrafficLight = Constants.Warning + "/" + Constants.Info,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInactivated = Constants.False,
                CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist,
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckStatus = "",
                CheckDebug = "", 
                CheckResultValue = "",
            }; ;

            tempcheckPointList.Add(checkpoint);

            //Splitt sjekkpunkt-listen i flere lister gruppert etter SjekkListeKategori.

            List<CheckPoint> sjekkpunktlisteCourse = new List<CheckPoint>(tempcheckPointList.FindAll(a => a.CheckListCategory == "Course"));
            List<CheckPoint> sjekkpunktlisteStruktur = new List<CheckPoint>(tempcheckPointList.FindAll(a => a.CheckListCategory == "CT og strukturer"));
            List<CheckPoint> sjekkpunktlistePlan = new List<CheckPoint>(tempcheckPointList.FindAll(a => a.CheckListCategory == "Plan"));
            List<CheckPoint> sjekkpunktlisteTeknikk = new List<CheckPoint>(tempcheckPointList.FindAll(a => a.CheckListCategory == "Teknikk"));
            List<CheckPoint> sjekkpunktlisteRefpkt = new List<CheckPoint>(tempcheckPointList.FindAll(a => a.CheckListCategory == "Refpkt"));
            List<CheckPoint> sjekkpunktlisteDVH = new List<CheckPoint>(tempcheckPointList.FindAll(a => a.CheckListCategory == "DVH"));

            documentation = documentation + Environment.NewLine + Environment.NewLine + AddCheckPointListToDocumentation(sjekkpunktlisteCourse, "Course");
            documentation = documentation + Environment.NewLine + Environment.NewLine + AddCheckPointListToDocumentation(sjekkpunktlisteStruktur, "CT og strukturer");
            documentation = documentation + Environment.NewLine + Environment.NewLine + AddCheckPointListToDocumentation(sjekkpunktlistePlan, "Plan");
            documentation = documentation + Environment.NewLine + Environment.NewLine + AddCheckPointListToDocumentation(sjekkpunktlisteTeknikk, "Teknikk");
            documentation = documentation + Environment.NewLine + Environment.NewLine + AddCheckPointListToDocumentation(sjekkpunktlisteRefpkt, "Refpkt");
            documentation = documentation + Environment.NewLine + Environment.NewLine + AddCheckPointListToDocumentation(sjekkpunktlisteDVH, "DVH");

            //MessageBox.Show(result);

            //reset name
            tempcheckScenarioResultat.TemplateChosen.TemplateName = chosentemplate;

            return documentation;
        }

        public static string GenerateLastChanges()
        {
            string lastChange = "";
            lastChange = AddStringWithNewLineIfNotEmpty(lastChange, "v1.1.15-16: småbugs, tidsoptimering");
            lastChange = AddStringWithNewLineIfNotEmpty(lastChange, "-Referansepunktliste m/ toleransedoser vises nå ikke for kontrolltypen 'Doseplan'.");
            lastChange = AddStringWithNewLineIfNotEmpty(lastChange, "-Kollisjonssjekken går ca 6-7x raskere.");
            lastChange = AddStringWithNewLineIfNotEmpty(lastChange, " Tidsbruk VMAT gikk fra 40s -> 6s. IMRT-plan fra 26s -> 4s.");

            return lastChange;

        }

        public static string GenerateChangeLog()
        {
            string changes = "";
            changes = AddStringWithNewLineIfNotEmpty(changes, "|------------------------------------|");
            changes = AddStringWithNewLineIfNotEmpty(changes, "|------------------------------------|");
            changes = AddStringWithNewLineIfNotEmpty(changes, "           ChangeLog");
            changes = AddStringWithNewLineIfNotEmpty(changes, "|------------------------------------|");
            changes = AddStringWithNewLineIfNotEmpty(changes, "|------------------------------------|");
            changes = changes + Environment.NewLine;
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.16:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Forbedret hastighet på søk etter Mobius fil. Folderen er 159GB og inneholder ca 250 000 filer... ");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.15:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Kollisjonssjekken går ca 6-7x raskere. VMAT: 40s -> 6s. IMRT-plan: 26s -> 4s.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Referansepunktliste m/ toleransedoser vises nå ikke for kontrolltypen 'Doseplan'.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.14:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Kollisjonsjekk kjører nå ikke for Halcyon.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-UserOrigin: Endret praksis for blymarkører. Derfor midlertidig deaktivert sjekk etter markører på høyre");
            changes = AddStringWithNewLineIfNotEmpty(changes, " og venstre side. Skal etterhvert modifisere sjekken til å se etter markør sentralt istedet. Nå sjekker den");
            changes = AddStringWithNewLineIfNotEmpty(changes, " bare at UserOrigin er flyttet bort i fra default posisjonen. Den sjekker ikke mot markør.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.13:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Fikset bug der jawtracking kan gi falske advarsler.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Modifisert Couch-sjekk så den godtar alt ved wildcard ('*') i templatet.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.12:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Lagt inn SB6-maskin som Halcyon.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Modifisert kollisjonsmodell.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-fikset små bugs.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.11:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Lagt inn sjekkpunt for grader-tegn i felt-ID-er.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.10:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-UserOrigin kan også sjekkes med en struktur 'zMarker'(relevant for fotonplan som sammenlignes med protonplan).");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Noen korrigeringer i bordsjekken og kollisjonsjekken.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.9:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Færre advarsler på Margin-sjekk (feks på PTV_72, med 0mm margin).");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Sjekker om 'BodyFreeBreathing'-struktur eksisterer i Fripust-CT for Mamma.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Modifisert bordsjekken så den sjekker alle bordstrukturer.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Halvert kalkuleringstiden på Marginsjekk og UserOrigin.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Lagt inn Export-knapp som skal brukes av studentene.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.8:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Fixed bug in Secondary referencepoints checkpoint (5.2) showed up even if is not relevant.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Changed so all Template Values are displayed with line breaks from the start so GUI window is not so wide.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Fixed bug in HighResolution CheckPoint (2.6) where it would crash if an empty PTV exists. Edited formatting of output.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.6 & v1.1.7:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Collimator angle check also run for IMRT fields, not just VMAT.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-UI update and multithreading. Checks are now run in a background operation. Code details below:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "     -Running UI on separate thread (UI thread). ESAPI-code is run on main thread (ESAPI thread) via dispatcher.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "     -Reorganized buisiness code, more methods in Model. Can now run code from UI with 'Commands' from View via ViewModel and then to Model. ");
            changes = AddStringWithNewLineIfNotEmpty(changes, "     -View is now generated instantly, empty display at first. UI is updated continually via 'Commands' that run on separate UI-thread.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "     -Checkpoints are split into 'late' and 'quick'. All 'quick' checkpoints are run first so we can see them at once. Then the late ones are run. ");
            changes = AddStringWithNewLineIfNotEmpty(changes, "     -Added progressbar so we know it is working on something. Because ESAPI-code is run on separate thread with dispather, I have not found way to set mouse to Cursor.Wait.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Added CollisionCheck and a seperate a visualization for it. Valid only for 'HeadFirstSupine' and not for electrons technique.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Merging code changes done at HUS and SUS concurrently.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.5:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-SUS checkpoints added");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-DelayedCalculation functionality added.");
            changes = AddStringWithNewLineIfNotEmpty(changes,"v1.1.4:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Fixed bug in documentation code. Earlier did not display generated documentation for reference points and DVH check point.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Changed checknumber of new checkpoint 'Check HR structures' as it was duplicate number.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Changed template override for electron treatments. Allows 0 setup fields etc.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Changed formatting of electron aperture checkpoint.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Added code to transform couch angle to user coordinate system.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.3:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Fixed bug in UserOrigin Check. Code could search for pixels 1 pixel outside of CT if marker is close to CT border, instead of keeping inside the CT matrix like sensible code does.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.2:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Changed code for checking if newest version of project is being run.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1.1:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "New checkpoints, altered checkpoints, and some visual changes:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Updated Margin Check. Changed algorithm to match structures that have margins (CTV to PTV, GTV to CTV etc). Added csv-template file to check against tolerances.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Added UserOrigin Check");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Added documentation button. Now documentation is generated from the code. Not the most pleasent format for now, just basic txt-file. Hopefully it will at least be easier to keep documentation documents up to date.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Added custom hospital button.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Changed all text in checkpoint to Monospaced Fonts as it makes it easier to format in tables.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Now PlanCheckTemplatesMachineOverride.csv (used to ovverride template values in certain cases) can also be used for technique-based overrides, not just Machine-based ovverrides. Earlier was only used to override templates if a Halcyon and Ethos machine is used as a 'Prostate' plan for instance have different energies etc. and different template demands if it on a ring machine vs on a TB. Now it also overrides if there is electron treatment technique also.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.1:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "Large update of EclipsePlanCheck from v 1.0 Many changes in the code behind without necessarily changing how the user sees it. Less hard coded, and more things put out in external templates and constants for instance. Attemting to change checkpoints and code so other hospitals can more easily adapt it.");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Added Margin Check. Does not check against tolerances yet, only informs of the margins. Only handles CTV to PTV");
            changes = AddStringWithNewLineIfNotEmpty(changes, "-Moved templates out of code and into csv files for easier editing.");

            changes = AddStringWithNewLineIfNotEmpty(changes, "v1.0:");
            changes = AddStringWithNewLineIfNotEmpty(changes, "------");
            changes = AddStringWithNewLineIfNotEmpty(changes, "The original project. A document was created to describe it when it was created. Not updated with newer changes yet.");
            changes = changes + Environment.NewLine + Environment.NewLine;

            return changes;
        }


        public static string AddCheckPointListToDocumentation(List<CheckPoint> checkPointList, string title)
        {
            string documentation = "";
            string lineToAdd = "";
            string lineToAddFormatted = "";

            //add title
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");
            if (title != "") { documentation = AddStringWithNewLineIfNotEmpty(documentation, title ); } else { documentation = AddStringWithNewLineIfNotEmpty(documentation, "Kategori uten tittel:"); }
            //Add headers
            documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");
            lineToAdd = "SJEKKNUMMER|SJEKKNAVN|TYPE SJEKK|TYPE TASKER|TRAFIKKLYS|INAKTIVERT|USYNLIG";
            lineToAddFormatted = FormatString(-25, -25, lineToAdd);
            documentation = AddStringWithNewLineIfNotEmpty(documentation, lineToAddFormatted);

            //string formattedCheckType = "";
            //string formattedCheckName = "";
            //string formattedCheckTaskName = "";

            foreach (CheckPoint s in checkPointList)
            {
                lineToAdd = s.CheckNumber.Replace("|", "/").Replace(Environment.NewLine, " ") + "|" + s.CheckName.Replace("|", "/").Replace(Environment.NewLine, " ") + "|" + s.CheckType.Replace("|", "/").Replace(Environment.NewLine, " ") + "|" + s.CheckTaskName.Replace("|", "/").Replace(Environment.NewLine, " ") + "|" + s.CheckTrafficLight.Replace(Environment.NewLine, " ") + "|" + s.CheckInactivated.Replace(Environment.NewLine, " ") + "|" + s.CheckInvisibleUnlessWarningOrError.Replace(Environment.NewLine, " ");
                lineToAddFormatted = FormatString(-25, -25, lineToAdd);
                documentation = AddStringWithNewLineIfNotEmpty(documentation, lineToAddFormatted);
                documentation = AddStringWithNewLineIfNotEmpty(documentation, "Forklaring:");
                documentation = AddStringWithNewLineIfNotEmpty(documentation, s.CheckExplanation.Replace(Environment.NewLine, " ") + Environment.NewLine);
            }
            //documentation = AddStringWithNewLineIfNotEmpty(documentation, "|------------------------------------|");
            return documentation;
        }
        public static void ExportResultAsCSV(EclipseCheckModel eclipseCheckResult, PatientContext patCon, CheckScenarioResult chScRes) //MainViewModel viewModel
        {


            //Save as TWO files. 
            //One with context (patient and plan)
            //One with CheckPoint results
            //---------
            //File ONE
            //---------

            //user info

            string user = patCon.UserId.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;

            //Get Sanity info
            string sanityLevel = patCon.SanityLevel.ToString() ?? string.Empty;   //viewModel.Context.SanityLevel.ToString(); 
            string sanityDescription = patCon.SanityDescription.ToString().Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty; //viewModel.Context.SanityDescription.ToString();

            //Patient info (prevent anyone sending csv-unfirendly input)
            string PatientID = patCon.ChosenPatient.Id.ToString().Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty; //viewModel.Context.ChosenPatient.Id.ToString();
            string courseID = patCon.ChosenCourse.Id.ToString().Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty; //viewModel.Context.ChosenCourse.Id.ToString();
            string planID = patCon.ChosenPlan.Id.ToString().Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty; //viewModel.Context.ChosenPlan.Id.ToString();
            //eclipseCheckResult.ChosenControlTask;
            //eclipseCheckResult.SanityLevel
            //eclipseCheckResult.SanityLevelDescription

            //Get template info
            EclipseCheckTemplate templateChosen = chScRes.TemplateChosen; //viewModel.ScenarioResult.TemplateChosen; //eclipseCheckModel.TemplateName
            string score = templateChosen.TemplateScore.ToString();
            string templateName = templateChosen.TemplateName; //eclipseCheckModel.TemplateName; //templateChosen.TemplateName;
            List<EclipseCheckTemplate> templatelistModified = chScRes.EclipseCheckTemplateList.Where(x => x.TemplateName != templateName).ToList();
            int secondMaxScore = templatelistModified.Max(x => x.TemplateScore);// max in the modified list
            EclipseCheckTemplate secondTemplate = templatelistModified.FirstOrDefault(x => x.TemplateScore == secondMaxScore);

            string secondTemplateName = secondTemplate.TemplateName ?? string.Empty; ;

            // Headers definitions:
            string headerMargins = "checkNumber;checkName;checkStatus;PatientID;courseID;planID;TimeStamp;Alle;x-;x+;y-;y+;z-;z+;Comment;CalculationTime";
            string headersContext = "PatientID;courseID;planID;Timestamp;sanityLevel;sanityDescription;templateChosen;templateScore;templateSecondMaxScore;templateSecondName;UserId";
            string headersCheckPoints = "checkNumber;checkName;checkStatus;checkResultValueCSV;checkTemplateValue;checkInactivated;checkDiscardedAtRuntime;checkTaskName;PatientID;courseID;planID;Timestamp";

            //---------
            //File TWO
            //---------


            // Create filename and file path, using date and time and plan id
            DateTime now = DateTime.Now;
            string filePath = Constants.PlanCheckTemplateFolderPath + @"Export\";
            string formattedDateTime = now.ToString("yyyyMMdd_HHmmss"); //"ddMMyyyy_HHmmss"
            //string today = now.ToString("ddMMyyyy");
            string filepathAndNameCheckpoints = filePath + "EPC_CheckPoints.csv"; //filePath + "EPC_CheckPoints_" + planID + "_" + formattedDateTime + ".csv";
            string filePathAndNameContext = filePath +  "EPC_Context.csv"; //filePath +  "EPC_Context_" + planID + "_" + formattedDateTime + ".csv";
            string filePathMargins = filePath + "EPC_Margins.csv"; //filePath + "EPC_Margins_" + planID + "_" + formattedDateTime + ".csv";

            var csvBuilder = new StringBuilder();
            string checkName= "";

            bool ContextNeedsHeader = true;
            bool MarginNeedsHeader = true;
            bool CheckPointsNeedsHeader = true;

            //-------------
            //Create files if files do not exist
            //-------------

            //CONTEXT: Creating files and writing headers
            if (!File.Exists(filePathAndNameContext))
            { //File does not exist
                    // The using statement ensures the StreamWriter is correctly disposed of
                    using (StreamWriter sw = new StreamWriter(filePathAndNameContext, false, Encoding.UTF8))
                    {

                        //Header
                        sw.WriteLine(headersContext);
                    }
            }


            //CHECKPOINTS: Creating files and writing headers
            if (!File.Exists(filepathAndNameCheckpoints))
            {//File does not exist
                // The using statement ensures the StreamWriter is correctly disposed of
                using (StreamWriter sw = new StreamWriter(filepathAndNameCheckpoints, false, Encoding.UTF8))
                {
                    //Header
                    sw.WriteLine(headersCheckPoints);
                }
            }

            //MARGINS: Creating files and writing headers
            if (!File.Exists(filePathMargins))
            {//File does not exist
                // The using statement ensures the StreamWriter is correctly disposed of
                using (StreamWriter sw = new StreamWriter(filePathMargins, false, Encoding.UTF8))
                {
                    //Header
                    sw.WriteLine(headerMargins);
                }

            }
            //-------------
            //-------------




            //-------------
            //Check if headers must be written (if the file already existed).
            //-------------
            string debug = "write headers";
            try
            {

                //-------------
                // Headers control
                //-------------

                // CONTEXT: Do we need to add header?
                using (StreamReader sr = new StreamReader(filePathAndNameContext))
                {
                    //Check if file is empty
                    string firstLine = sr.ReadLine();
                    if (!string.IsNullOrWhiteSpace(firstLine))
                    {
                        ContextNeedsHeader = false;
                    }
                }
                // MARGINS: Do we need to add header?
                using (StreamReader sr = new StreamReader(filePathMargins))
                {
                    //Check if file is empty
                    string firstLine = sr.ReadLine();
                    if (!string.IsNullOrWhiteSpace(firstLine))
                    {
                        MarginNeedsHeader = false;
                    }
                }
                // CheckPoints: Do we need to add header?
                using (StreamReader sr = new StreamReader(filepathAndNameCheckpoints))
                {
                    //Check if file is empty
                    string firstLine = sr.ReadLine();
                    if (!string.IsNullOrWhiteSpace(firstLine))
                    {
                        CheckPointsNeedsHeader = false;
                    }
                }
                //-------------
                //-------------


                debug = "Headers check finished. Start writing Context data";

                //-------------
                // CONTEXT
                //-------------
                // Add header?
                if (ContextNeedsHeader == true)
                {
                    using (StreamWriter sw = new StreamWriter(filePathAndNameContext, false, Encoding.UTF8))
                    {
                        //Header
                        sw.WriteLine(headersContext);
                    }

                }

                //Write Context data
                using (StreamWriter sw = new StreamWriter(filePathAndNameContext, true, Encoding.UTF8)) //using (StreamWriter sw = File.AppendText(filePathAndNameContext))
                {
                    //Header
                    //sw.WriteLine("PatientID;courseID;planID;sanityLevel;sanityDescription;templateChosen;templateScore;templateSecondMaxScore;templateSecondName");
                    //Get checkpoint info:

                    sw.WriteLine(PatientID + ";" + courseID + ";" + planID + ";" + formattedDateTime + ";" + sanityLevel + ";" + sanityDescription + ";" + templateName + ";" + score + ";" + secondMaxScore + ";" + secondTemplateName + ";" + user);

                }
                //-------------
                //-------------

                //-------------
                // CHECKPOINTS
                //-------------
                // Add header?
                if (CheckPointsNeedsHeader == true)
                {
                    using (StreamWriter sw = new StreamWriter(filepathAndNameCheckpoints, false, Encoding.UTF8))
                    {
                        //Header
                        sw.WriteLine(headersCheckPoints);
                    }

                }

                //Write CP data
                using (StreamWriter sw = new StreamWriter(filepathAndNameCheckpoints, true, Encoding.UTF8)) //using (StreamWriter sw = File.AppendText(filepathAndNameCheckpoints))
                {

                    
                    //Get checkpoint info:
                    //MUST ALSO GO THROUGH the other checkpointlists, since discarded checkpoints are removed from list.
                    foreach (CheckPoint cp in eclipseCheckResult.CheckPointListAll) //foreach (CheckPoint cp in viewModel.EclipseCheckResult.CheckPointListAll)
                    {
                        debug = "Headers finished. Start writing data. Going throug CP " + cp.CheckName +".";
                        //Set variable or set empty if it fails. Clean away ";" and new lines. And UTF16 symbols
                        string checkStatus = "";
                        //Remove UTF16-symbols
                        if (cp.CheckStatus == Constants.Delayed)
                        {
                            checkStatus = "Delayed";
                        }
                        else if(cp.CheckStatus == Constants.Calculating)
                        {
                            checkStatus = "Calculating";
                        }
                        else
                        {
                            checkStatus = cp.CheckStatus ?? string.Empty; //Standard
                        }


                        //Clean:
                        string checkNumber = cp.CheckNumber ?? string.Empty;
                        checkName = cp.CheckName.Replace(Environment.NewLine, " ") ?? string.Empty; //Remove any new lines from string
                        
                        string CheckResultValueCSV = cp.CheckResultValueCSV.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;
                        string checkTemplateValue = cp.CheckTemplateValue.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty; //Should already be CSV compatible as it was loaded from CSV from the start.
                        if (cp.CheckTemplateValueCSV != "" && cp.CheckTemplateValueCSV != null) { checkTemplateValue = cp.CheckTemplateValueCSV.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty; } //If this is used instead.
                        string checkInactivated  = cp.CheckInactivated ?? string.Empty;
                        string checkDiscardedAtRuntime = cp.CheckDiscardedAtRuntime ?? string.Empty;
                        string checkTaskName = cp.CheckTaskName ?? string.Empty;
                        string calculationTime = cp.CheckTimeElapsed;

                        //Write
                        sw.WriteLine("Nr" + checkNumber + ";" + checkName + ";" + checkStatus + ";" + CheckResultValueCSV + ";" + checkTemplateValue + ";" + checkInactivated + ";" + checkDiscardedAtRuntime + ";" + calculationTime + ";" + checkTaskName + ";" + PatientID + ";" + courseID + ";" + planID + ";" + formattedDateTime); ;
                    }
                }
                debug = "Headers check finished. Start writing data. All checkpoints written. Starting on margins header.";

                //-------------
                //-------------

                //-------------
                // MARGINS
                //-------------

                //Write margins header if needed
                if (MarginNeedsHeader == true)
                {
                    using (StreamWriter sw = new StreamWriter(filePathMargins, false, Encoding.UTF8))
                    {
                        //Header
                        sw.WriteLine(headerMargins);
                    }

                }

                debug = "Headers check finished. Start writing data. All checkpoints written. Starting on writing margins data.";

                //-------------
                //Write margins data
                //-------------

                //It can be several Margins! Must handle it. Send to list
                List<CheckPoint> marginsCheckPointlists = (List<CheckPoint>) eclipseCheckResult.CheckPointListAll.Where(x => x.CheckSwitchCode == "Margins").ToList();

                //For eac margins in list, print result i csv-file
                foreach (CheckPoint checkPoint in marginsCheckPointlists)
                {
                    char[] marginseparator = new char[] { ':' };
                    string[] inputArr = checkPoint.CheckResultValueCSV.Split(marginseparator);
                    int totant = inputArr.Count();
                    //int i = 0;
                    string marginsOutput = "";
                    foreach (string s in inputArr)
                    {
                        marginsOutput = marginsOutput + s.Replace(".",",") + ";";
                    }
                    // marginsOutput should be  "Alle;x-;x+;y-;y+;z-;z+;"

                    string marginsCheckName = checkPoint.CheckName.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;
                    string marginsCheckNumber = "Nr" + checkPoint.CheckNumber.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;
                    string marginsCheckStatus = checkPoint.CheckStatus.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;
                    string marginsCheckComment = checkPoint.CheckComment.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;
                    string marginsTimeElapsed= checkPoint.CheckTimeElapsed.Replace(Environment.NewLine, " ").Replace(";", "") ?? string.Empty;
                    
                    using (StreamWriter sw = new StreamWriter(filePathMargins, true, Encoding.UTF8))
                    {
                        //Header
                        sw.WriteLine(marginsCheckNumber + ";" + marginsCheckName + ";" + marginsCheckStatus + ";" + PatientID + ";" + courseID + ";" + planID + ";" + formattedDateTime + ";" + marginsOutput + marginsCheckComment + ";" + marginsTimeElapsed);
                    }

                }




                //-------------
                //-------------


            }
            catch (Exception e)
            {
                MessageBox.Show("En feil skjedde i eksport. Siste status før krasj: " + debug + Environment.NewLine + "Feilmelding: " +  e.Message);
            }





            //Iterate over checkpoint list and write the following (complex output must be set in quotation marks":
            // CheckLabel ; CheckNumber ; CheckStatus ; CheckResult ; CheckTemplateValue ; CheckInactivated ; CheckDiscardedAtRunTime ; CheckFailedControlType 
            //eclipseCheckResult.CheckPointListAll


            //var properties = typeof(T).GetProperties();

            //var row = 

            //MessageBox.Show("Fullført eksport til CSV!");

        }



            public static string GenerateTableLine(int antallTabsKol, int tabdef, string KolInput)
        {
            int usedTabs = 0;
            int restTabs = 0;
            string tabs = "";
            //int tabs_mod = 0;
            string string_mod = "";

            string resultstring = "";

            string[] inputArr = KolInput.Split(Constants.CharSeparator);
            int totant = inputArr.Count();
            int i = 0;
            foreach (string s in inputArr)
            {
                i = i + 1;
                //Korrigerer:
                if (NumberIsInteger((double)s.Length / tabdef))
                {
                    //tabs_mod = 1; //Ekstra tab
                    string_mod = "  "; //Ekstra space
                } //Ekstra tab
                usedTabs = NumberOfTabsInString(s + string_mod, 4);
                restTabs = (antallTabsKol - usedTabs > 0) ? antallTabsKol - usedTabs : 2;
                tabs = GenerateTabs(restTabs); //Formaterer antall tabs for aa lage tabell uten forskyvninger mellom header og tekst
                //Siste element uten ekstra tabs etter
                if (i == totant)
                {
                    resultstring = resultstring + s; //skriver inn verdi i resultatstring, uten tabs
                }
                //Ellers med tabs
                else
                {
                    resultstring = resultstring + s + string_mod + tabs; //skriver inn verdi i resultatstring inkl tabs
                }

            }

            return resultstring;
        }


        public static int MaxLength(String[] arr)
        {
            int len = int.MinValue;
            int N = arr.Length;

            // Traverse the array
            for (int i = 0; i < N; i++)
            {
                // Stores the length
                // of current String
                int l = arr[i].Length;

                // Update maximum length
                if (len < l)
                {
                    len = l;
                }
            }

            // Return the maximum length
            return len;
        }

        // nyttig funksjon for aa gjore en array med strings om til en lang enkeltstring
        public static string ArrayToString(string[] array) //optional input: var separator (feks string " + " evnt. NewLine)
        {
            return string.Join(" + ", array.Where(x => x.Length > 0));  //return string.Join(" + ", array);  //return string.Join(string.Empty, array);
            //string result = string.Join(", ", input.Where(x => x.Length <= 4));
        }
        // <summary>Indicates whether the specified array is null or has a length of zero.</summary>
        // <returns>true if the array parameter is null or has a length of zero; otherwise, false.</returns>
        public static bool ArrayIsNullOrEmpty(this Array array)
        {
            return (array == null || array.Length == 0);
        }

        //GetScriptVersionHandling

        public static ScriptVersionHandling CreateDefaultScriptVersion (ScriptVersionHandling scriptVersionHandling)
        {
            scriptVersionHandling.NewerVersionInfo = "";
            scriptVersionHandling.NewerVersionWarning = "";
            scriptVersionHandling.ScriptName = "";
            scriptVersionHandling.ScriptVersion = "";
            scriptVersionHandling.ScriptNameAndVersion = "";
            scriptVersionHandling.LastChangeDateToDisplay = "";
            scriptVersionHandling.LastChangeInfo = "";
            return scriptVersionHandling;
         }

        public static ScriptVersionHandling GetScriptVersionHandling(ScriptVersionHandling scriptVersionHandling)
        {
            scriptVersionHandling = CreateDefaultScriptVersion(scriptVersionHandling); //Empty strings.
            //Name
            string scriptName = Constants.ScriptName; //System.Reflection.Assembly.GetExecutingAssembly().GetName().Name.Replace(".esapi", "");
            scriptVersionHandling.ScriptName = scriptName;
            //Version
            string scriptVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            scriptVersionHandling.ScriptVersion = scriptVersion;
            //Version and name
            string scriptVersionAndName = scriptName + " v." + scriptVersion;
            scriptVersionHandling.ScriptNameAndVersion = scriptVersionAndName;

            //Find newer versions:
            try
            {
                //Path:
                string fullPath = System.Reflection.Assembly.GetEntryAssembly().Location;
                //newer version exists?
                if (fullPath != "")
                {
                    scriptVersionHandling = GeneralExtension.CheckFolderForNewerFileVersion(Constants.PlanPublishedScriptsFolderPath, scriptName, scriptVersionHandling);
                }
            }
            catch { MessageBox.Show("Failed to check for newer versions of file."); }




            return scriptVersionHandling;
        }


        public static ScriptVersionHandling CheckFolderForNewerFileVersion (string folderPath, string searchName, ScriptVersionHandling scriptVersionHandling)
        {
            //Check if newer file exist - new code, hence wrapped in "try":
            string fileNameAndPathNewVersion = "";

            string tempVersionNumber = ""; 
            string newerVersionNumber = ""; //If it exist
            string debugNewerVersionWarning = "";
            string debugNewerVersionInfo = "|----- Existing versions of script in folder: ---|" + Environment.NewLine;
            string currentVersionName = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            string fileDateCreated = "";
            DateTime lastChangeDate = new DateTime(2025, 11, 03, 7, 41, 0);

            //Current file creation time:
            //Assembly currentAssembly = Assembly.GetEntryAssembly();
            //string executablePath = currentAssembly.Location;
            //FileInfo fileInfo = new FileInfo(executablePath);
            //DateTime currentFileDateCreated = fileInfo.CreationTime;

            // To find files containing 'searchName' anywhere in their name:
            string searchPattern = $"*{searchName}*";


            string[] files = Directory.GetFiles(folderPath, searchPattern);

            //Go through all files in same folder as this file
            foreach (string file in files)
            {

                // Get the file version.
                FileVersionInfo myFileVersionInfo = FileVersionInfo.GetVersionInfo(file); //(@"C:\MyAssembly.dll");
                string myFileName = Path.GetFileName(file); //(@"C:\MyAssembly.dll");
                DateTime fileLastModified = File.GetLastWriteTime(file);

                //New last change date (all files)
                if (fileLastModified > lastChangeDate)
                {
                    lastChangeDate = fileLastModified; //New last change date
                }

                tempVersionNumber = myFileVersionInfo.FileVersion;
                debugNewerVersionInfo = AddStringWithNewLineIfNotEmpty(debugNewerVersionInfo, myFileName + ": " + tempVersionNumber);

                //Check if there is a newer version than currently running?
                if (Version.Parse(tempVersionNumber) > Version.Parse(currentVersionName))
                {
                    if (newerVersionNumber != "")
                    {   
                        //Newer than other in folder too?
                        if (Version.Parse(tempVersionNumber) > Version.Parse(newerVersionNumber))
                        {
                            newerVersionNumber = tempVersionNumber;
                            fileNameAndPathNewVersion = myFileName;
                            fileDateCreated = fileLastModified.ToString();
                            lastChangeDate = fileLastModified;
                        }
                        else { } //Not newer
                    }
                    else //If no newer has been set yet
                    {
                        newerVersionNumber = tempVersionNumber;
                        fileNameAndPathNewVersion = myFileName;
                        fileDateCreated = fileLastModified.ToString();
                        lastChangeDate = fileLastModified;
                    }
                }

            }

            
            if (newerVersionNumber == "")
            {
                scriptVersionHandling.NewerVersionWarning = "";  //"There is no newer version - yet :)";
                                                                 //debugVersionNumber = AddStringWithNewLineIfNotEmpty(debugVersionNumber, "There is no newer version - yet :)");

                //Add latest changes info if changes are within a certain number of days - disappears afterwards:
                try
                { //could happend that there is no lastDateModified, then it would crash - skip this step
                    DateTime today = DateTime.Today;
                    TimeSpan differenceDates = today - lastChangeDate; //currentFileDateEdited lastChangeDate
                    //MessageBox.Show(lastChangeDate.ToString() + Environment.NewLine + differenceDates.TotalDays.ToString());
                    if (differenceDates.TotalDays < Constants.DaysBeforeNotification) //say 15 days
                    {
                        scriptVersionHandling.LastChangeInfo = GenerateLastChanges();
                    }
                }
                finally { }
            }

            //Add latest changes info always:
            //try
            //{ //could happend that there is no lastDateModified, then it would crash - skip this step
            //    DateTime today = DateTime.Today;
            //    TimeSpan differenceDates = today - lastChangeDate;
            //    if (differenceDates.TotalDays < Constants.DaysBeforeNotification) //say 15 days
            //    {
            //        scriptVersionHandling.LastChangeInfo = GenerateLastChanges();
            //    }
            //}
            //finally { }


            //Give warning if there is a newer version:
            if (newerVersionNumber != "")
            {   //Instructions to change script:
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "|---------- Ny scriptversjon tilgjengelig ---------|");
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "En ny skriptversjon er tilgjengelig!");
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "Nyeste filnavn: " + fileNameAndPathNewVersion);
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "Nyeste filversjon: " + newerVersionNumber);
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "Nyeste fil-lokalisasjon: " + folderPath);
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "Nyeste fil endringsdato: " + fileDateCreated);
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "For å kunne bruke nyeste versjon, vennligst lukk 'User Home' og log inn i Aria igjen. Ta et skjermbilde av denne meldingen hvis du ikke husker den :)");
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "I Eclipse, gå til Tools -> Scripts. Velg nåværende skript og under 'Favorites' trykk 'Remove' for å fjerne den gamle versjonen som favoritt.");
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "Sørg for at 'Location' er satt til -> 'System Scripts', velg nyeste versjon av skriptet (se over). Trykk 'Add' under 'Favorites' for å sette som ny favoritt.");
                debugNewerVersionWarning = AddStringWithNewLineIfNotEmpty(debugNewerVersionWarning, "|-------------------------------------------------|");
                scriptVersionHandling.NewerVersionWarning = debugNewerVersionWarning;
                scriptVersionHandling.LastChangeDateToDisplay = fileDateCreated;
                scriptVersionHandling.LastChangeDate = lastChangeDate;
                

                //debugVersionNumber = AddStringWithNewLineIfNotEmpty(debugVersionNumber, "Newest version: " + newerVersionNumber);
            }
            scriptVersionHandling.NewerVersionInfo = debugNewerVersionInfo + Environment.NewLine + "|------------------------------------------------|";

            return scriptVersionHandling;
        }

        public static string CheckStringsVsStrings(string patientData, string templateData)
        {
            string stringMatchResult = "";
            char[] separators = new char[] { Constants.CharSeparator };


            string[] patientDataArray = patientData.Split(separators);
            string[] templateDataArray = templateData.Split(separators);

            string tempPatientData = "";
            string tempTemplateData = "";

            //Iterate over template values (first, because template values are in prioritized order)
            foreach (string chosenTemplateData in templateDataArray)
            {
                //Iterate over chosen patient values
                foreach (string chosenPatientData in patientDataArray)
                {
                    if (Constants.AllStringComparisonCaseSensitive == false)
                    { //If case insensitive search
                        tempPatientData = chosenPatientData.ToLower();
                        tempTemplateData = chosenTemplateData.ToLower();
                    }
                    else
                    { //Case senisitive
                        tempPatientData = chosenPatientData;
                        tempTemplateData = chosenTemplateData;
                    }

                    if (MatchWildcardString(tempTemplateData, tempPatientData) == true) //Only templateData can have wildcard etc.
                    {
                        stringMatchResult = chosenPatientData;
                        return stringMatchResult;
                    }
                }
            }

            return stringMatchResult;
        }

        //Sjekke for match med wildcard * og enkelt ukjent character tillatt:
        public static Boolean MatchWildcardString(String searchPattern, String input)
        {
            String regexPattern = "^";

            foreach (Char c in searchPattern)
            {
                switch (c)
                {
                    case '*':
                        regexPattern += ".*";
                        break;
                    case '?':
                        regexPattern += ".";
                        break;
                    default:
                        regexPattern += "[" + c + "]";
                        break;
                }
            }
            return new Regex(regexPattern + "$").IsMatch(input);
        }

        public static bool SolveBooleanExpression(string op, double? value, double? toleranse, CheckPoint s)
        {
            bool result = false;

            if (value != null && toleranse != null)
            { 
                if (op == ">")
                {
                    result = value > toleranse;
                }
                else if (op == "<")
                {
                    result = value < toleranse;
                }
                else if (op == "<=")
                {
                    result = value <= toleranse;
                }
                else if (op == ">=")
                {
                    result = value >= toleranse;
                }
                else if (op == "==" || op == "=")
                {
                    result = value == toleranse;
                }
                else
                {
                    s.CheckDebug = s.CheckDebug + "Klarte ikke evaluere operatoren: '" + op + "' brukt i uttrykk. Sjekkpunkt: " + s.CheckNumber + " " + s.CheckName;
                    //MessageBox.Show("Klarte ikke evaluere operatoren: '" + op + "' brukt i toleransegrense. Sjekkpunkt: " + s.SjekkNummer + " " + s.SjekkNavn);
                }
            }
            return result;
        }
    } 
}
