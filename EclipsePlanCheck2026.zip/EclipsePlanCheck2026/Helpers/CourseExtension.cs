﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

using System.Windows.Media.Media3D;
//Endre strukturer til transluce:
using System.Drawing;

//Slipper eksplisitt referere til Helpers
using EclipsePlanCheck.Helpers;

namespace EclipsePlanCheck.Helpers
{
    class CourseExtension
    {

        public static CheckPoint CheckDiagnosis(CheckPoint s, Course course)
        {
            string diagnosisAll = CourseExtension.GetAllAttachedDiagnosis(course);
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(diagnosisAll, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            s.CheckResultValue = diagnosisAll;
            s.CheckResultValueCSV = diagnosisAll;
            if (diagnosisAll == "") //Hvis ingen diagnose - ovverrider til error
            {
                s.CheckComment = "Ingen Diagnose attached!";
                s.CheckStatus = Constants.Error;
            }
            else {} //ellers bruker trafikklys
            return s;
        }

        public static String GetAllAttachedDiagnosis(Course c) //alle diagnoser som er på pasient og som er attached til coursen
        {


            //Henter ut alle diagnoser på pasientog sender som som string separert med komma
            String StrDiagnoser = "";
            var Diagnose = c.Diagnoses;
            int antall = Diagnose.Count();
            int teller = 0;
            string primaersekundaer = "";
            string separator = "";
            foreach (Diagnosis d in Diagnose)
            {
                // Type: ESAPI kan ikke hente om primaer eller sekundaer enda..., men kanskje en vakker dag... :(  //d.Type
                primaersekundaer = ""; //(" & d.Type & ")"

                //Separator:
                teller = teller + 1;
                if (teller == 1)
                { 
                    //separator = Constants.StringSeparator;
                    separator = "";
                }  //" (" & d.Type & "),"
                //else if (teller < antall)
                //{
                //    //separator = Constants.StringSeparator;
                //    separator = Constants.StringSeparator; ;
                //}  //" (" & d.Type & "),"
                else
                {
                    separator = Constants.StringSeparator;
                    //separator = "";
                }   //" (" & d.Type & ")"
                StrDiagnoser = StrDiagnoser.Trim() + primaersekundaer + separator + d.Code.Trim();

            }
            return StrDiagnoser;
        }

        public static String GetIntention(Course c) //alle diagnoser som er på pasient og som er attached til coursen
        {
            //Henter ut alle diagnoser på pasientog sender som som string separert med komma
            String Intensjon = "";
            if (c.Intent != null)
            {
                Intensjon = c.Intent;
            }
            return Intensjon;
        }


        public static CheckPoint CheckIntention(CheckPoint s, Course course)
        {
            string intent = CourseExtension.GetIntention(course);
            s.CheckResultValue = intent;
            s.CheckResultValueCSV = intent;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(intent, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);

            //Special cases:
            if (intent == "") //No intention - ovveride to error
            {
                s.CheckComment = "Ingen Intensjon satt!";
                s.CheckStatus = Constants.Error;
            }
            else if (s.CheckStatus != Constants.Ok || s.CheckTemplateValue == "")
            {
                if (intent == "Unknown")
                {
                    s.CheckComment = "'Ukjent' intensjon. Denne skal vel ikke brukes?";
                    if (s.CheckTemplateValue == "") { s.CheckStatus  = Constants.Info; }
                }
                else if (!(intent.Contains("Curative") || (intent.Contains("Palliative"))))
                {
                    s.CheckComment = "Ikke standard intensjon valgt.";
                    if (s.CheckTemplateValue == "") { s.CheckStatus = Constants.Info; }
                }
                else { }//ellers bruker trafikklys som vanlig
            }


            return s;
        }

        //CourseIntensjonWarning generell: ingen intensjon lagt til
        public static String IntentionWarning(Course c) //intensjon
        {
            string IntensjonWarningResultat =Constants.False;
            //Sjekker om standard valg paa intensjon
            String intensjon = c.Intent.Trim();
            if (intensjon != "Curative" && intensjon != "Palliative")
            {
                IntensjonWarningResultat = Constants.True;
            }
            return IntensjonWarningResultat;
        }


    }
}
