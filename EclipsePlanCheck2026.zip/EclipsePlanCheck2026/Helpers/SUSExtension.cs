﻿using EclipsePlanCheck.Helpers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Xml.Schema;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

using EclipseImage = VMS.TPS.Common.Model.API.Image;


namespace EclipsePlanCheck.Helpers
{
    public static class SUSExtension
    {
        public static void CheckPrescription(ExternalPlanSetup plan, CheckPoint checkPoint)
        {


            if (plan.RTPrescription == null)
            {

                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckResultValue = "Ingen rekvisisjon funnet";
                return;
            }

            checkPoint.CheckResultValue = plan.RTPrescription.Status;
            
            if (plan.RTPrescription.Status == "Approved") checkPoint.CheckStatus = Constants.Ok;
            else checkPoint.CheckStatus = Constants.Error;

 
        }



        public static void CheckDoseplanNumber(ExternalPlanSetup plan, CheckPoint checkPoint, IEnumerable<Beam> nonSetupFields)
        {
            /* Doseplannummer er korrekt
             * Rød: Hvis formatering er feil, eller koden ikke er blant de fem brukte
             * Gul: Årstall er ikke likt gjeldende årstall
             * Output: Doseplannummer
             * Notat: Akkurat nå sjekker den ikke om rett kode er til rett type case, burde legges inn (feks at vmat plan faktisk har vmat kode), 
             * legg inn sjekk for om løpenummer er 0000
             *        
             */
            
            List<string> legalDPCodes = new List<string> { "CDP", "CEP", "CRA", "CRP", "CFF", "CVP", "CIB"};
            string dosePlanNumber = plan.Name;
            if (dosePlanNumber == null || dosePlanNumber == "")
            {
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckResultValue = "Doseplannummer er ikke satt";
                return;
            }
            checkPoint.CheckStatus = Constants.Error;


            bool yearIsCorrect = dosePlanNumber.StartsWith(DateTime.Now.Year.ToString());
            bool codeIsLegal = legalDPCodes.Any(code => dosePlanNumber.Contains(code));
            bool fieldsAreCorrect = nonSetupFields.Count().ToString() == dosePlanNumber.Substring(dosePlanNumber.Length - 1, 1);
            bool formattingIsCorrect = Regex.IsMatch(dosePlanNumber, @"^20\d{2}-\d{4}-[A-Z]{3}-\d+$");

            if (codeIsLegal && fieldsAreCorrect && formattingIsCorrect)
            {
                checkPoint.CheckStatus = Constants.Ok;
            }
            if (!yearIsCorrect)
            {
                checkPoint.CheckStatus = Constants.Warning;
                checkPoint.CheckComment = "Årstall i kode er ikke lik gjeldende årstall: " + DateTime.Now.Year.ToString();
            }
            var comment = new List<string>();
            if (!codeIsLegal) comment.Add($"Doseplankoden er ikke en av de gyldige kodene: ({string.Join(", ",legalDPCodes)})");
            if (!fieldsAreCorrect) comment.Add($"Koden inneholder feil mengde felt ({dosePlanNumber.Substring(dosePlanNumber.Length - 1, 1)}). Plan har {nonSetupFields.Count()} felt");
            if (!formattingIsCorrect) comment.Add("Formateringen på nummeret er ikke korrekt i følge standarden: ^20\\d{2}-\\d{4}-[A-Z]{3}-\\d+$");
            if (!yearIsCorrect) comment.Add("Årstall i kode er ikke lik gjeldende årstall: " + DateTime.Now.Year.ToString());


            checkPoint.CheckResultValue = dosePlanNumber;

        }

        public static void CheckPlanAndFieldName(ExternalPlanSetup plan, IEnumerable<ExternalPlanSetup> allPlans, CheckPoint checkPoint)
        {
            // Regex for plan: starter med MV eller IB, deretter tall, eventuelt revisjon med . eller ; + tall
            var planRegex = new Regex(@"^(MV|IB)(\d+)([.;]\d+)?\b.*$");
            var fieldRegex = new Regex(@"^Fe (\d+)([.;]\d+)?\b.*$");


            // --- PLAN SJEKK ---
            var parsedPlans = allPlans
                .Select(p => new { Plan = p, Match = planRegex.Match(p.Id) })
                .ToList();

            // sjekk plan-type i forhold til antall referansepunkter
            bool planTypeCorrect = (plan.ReferencePoints.Count() > 1 ? plan.Id.StartsWith("IB") : plan.Id.StartsWith("MV"));



            

            // trekk ut hovednummer og revisjon
            var planKeys = parsedPlans
                .Select(x =>
                {
                    int number = int.Parse(x.Match.Groups[2].Value);
                    int revision = x.Match.Groups[3].Success ? int.Parse(x.Match.Groups[3].Value.Substring(1)) : 0;
                    return $"{number}.{revision}";
                })
                .ToList();

            bool planNoDuplicates = planKeys.Distinct().Count() == planKeys.Count;
            bool planNumbersContiguous = true;
            {
                // kun sjekk hull i hovednummer (revisjoner er egne versjoner av samme nummer)
                var mainNumbers = parsedPlans.Select(x => int.Parse(x.Match.Groups[2].Value)).Distinct().OrderBy(n => n).ToList();
                planNumbersContiguous = mainNumbers.First() == 1 && mainNumbers.Last() == mainNumbers.Count;
            }

            bool planNameOk = planTypeCorrect && planNoDuplicates && planNumbersContiguous;

            // --- FELT SJEKK ---
            var parsedFields = allPlans
                .SelectMany(p => PlanExtension.GetFields(p))
                .Select(f => new { Field = f, Match = fieldRegex.Match(f.Id) })
                .ToList();

            

            var fieldKeys = parsedFields
                .Select(f =>
                {
                    int number = int.Parse(f.Match.Groups[1].Value);
                    int revision = f.Match.Groups[2].Success ? int.Parse(f.Match.Groups[2].Value.Substring(1)) : 0;
                    return $"{number}.{revision}";
                })
                .ToList();

            bool fieldNoDuplicates = fieldKeys.Distinct().Count() == fieldKeys.Count;
            bool fieldNumbersContiguous = true;
            {
                var mainFieldNumbers = parsedFields.Select(f => int.Parse(f.Match.Groups[1].Value)).Distinct().OrderBy(n => n).ToList();
                fieldNumbersContiguous = mainFieldNumbers.First() == 1 && mainFieldNumbers.Last() == mainFieldNumbers.Count;
            }

            bool fieldsOk = fieldNoDuplicates && fieldNumbersContiguous;

            // --- RESULTAT ---
            if (!fieldsOk)
            {
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment += "Felt-IDer følger ikke gyldig sekvens. Sjekk at alle felt er nummerert uten hull og duplikater.\n";
            }
            if (!planNameOk)
            {
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment += "Plannavn er ikke korrekt. Sjekk at nummerering er korrekt i forhold til tidligere planer, samt om den er IB eller MV.\n";
            }
            if (planNameOk && fieldsOk)
            {
                checkPoint.CheckStatus = Constants.Ok;
            }
            // sjekk om alle planer matcher formatet
            if (parsedPlans.Any(x => !x.Match.Success))
            {
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment += "En eller flere plannavn hos pasienten inneholder ikke gyldig format (må være MVx eller IBx, evt. med revisjon .y eller ;y) \n";
                
            }

            if (parsedFields.Any(f => !f.Match.Success))
            {
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment += "Et eller flere feltnavn hos pasienten inneholder ugyldig format (må være Fe x eller Fe x.y / Fe x;y)\n";
                
            }

            // --- OUTPUT ---
            List<string> fieldNames = new List<string>();
            foreach (ExternalPlanSetup p in allPlans)
            {
                fieldNames.Add(p.Id + (p.Id == plan.Id ? " (gjeldende plan)" : ""));
                foreach (Beam beam in PlanExtension.GetFields(p))
                {
                    fieldNames.Add("    " + beam.Id);
                }
            }
            checkPoint.CheckResultValue = string.Join("\n", fieldNames);
        }

        public static void CheckPortalDose(ExternalPlanSetup plan, IEnumerable<ExternalPlanSetup> allAllPlans, CheckPoint checkPoint, Dictionary<string, bool> planBools)
        {
            /*Plan har portal dose plan lagt til for VMAT/IMRT
             * Rød: Hvis portal dose plan er laagt til men feltnavn er feil
             * Gul: Hvis portal dose plan ikke finnes for VMAT/IMRT
             * Output: Ja / Nei / Plan er ikke VMAT/IMRT
             * Notat:
             */
            if (!planBools["isImrt"] && !planBools["isVmat"])
            {
                checkPoint.CheckStatus = Constants.Ok;
                checkPoint.CheckResultValue = "Plan er ikke VMAT/IMRT";
                return;
            }
            if (allAllPlans.Any(p => p.Id == plan.Id && p.PlanIntent == "VERIFICATION"))
            {
                checkPoint.CheckResultValue = "Ja";
                ExternalPlanSetup pdPlan = allAllPlans.First(p => p.Id == plan.Id && p.PlanIntent == "VERIFICATION");

                bool beamsAreEqual = true;

                var pdBeamIds = pdPlan.Beams.Where(b => !b.IsSetupField).Select(b => b.Id).OrderBy(b=>b);

                var planBeamIds = plan.Beams.Where(b => !b.IsSetupField).Select(b => b.Id).OrderBy(b=>b);


                if (pdBeamIds.Count() != planBeamIds.Count())
                {
                    checkPoint.CheckComment = "PD-plan og original plan har ikke samme mengde behandlingsfelt";
                    checkPoint.CheckStatus = Constants.Error;
                    return;
                }
                


                for (int i = 0; i < planBeamIds.Count(); i++)
                {
                    if (planBeamIds.ElementAt(i) != pdBeamIds.ElementAt(i))
                        beamsAreEqual = false;
                }

                if (!beamsAreEqual)
                {
                    checkPoint.CheckStatus = Constants.Error;
                    checkPoint.CheckComment = "Feltnavn matcher ikke mellom PD og original plan";
                }
                else
                    checkPoint.CheckStatus= Constants.Ok;
            }
            else
            {
                checkPoint.CheckResultValue = "Nei";
                checkPoint.CheckStatus = Constants.Warning;
            }

        }



        public static void CheckPlanApproved(ExternalPlanSetup plan, CheckPoint checkPoint)
        {
            /*Plan er godkjent
             * Rød: Hvis ikke planning approved eller reviewed
             * Gul:
             * Output: Approval status
             * Notat:
             */


            bool planIsReviewed = plan.ApprovalHistory.Any(e => e.ApprovalStatus == PlanSetupApprovalStatus.Reviewed);
            bool planIsPlanningApproved = plan.ApprovalHistory.Any(e => e.ApprovalStatus == PlanSetupApprovalStatus.PlanningApproved);


            if (planIsPlanningApproved && planIsReviewed)
                checkPoint.CheckStatus = Constants.Ok;
                
            else checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment += planIsPlanningApproved ? "" : "Plan er ikke planning approved\n";
                checkPoint.CheckComment += planIsReviewed ? "" : "Plan er ikke reviewed\n";

            checkPoint.CheckResultValue = plan.ApprovalStatus.ToString();
        }

        public static void CheckUnapproved(ExternalPlanSetup plan, CheckPoint checkPoint)
        {
            /* Det er lagt til kommentar om planen er satt til Unapproved etter Reviewed
             * Rød: Hvis plan er satt i unapproved etter reviewed og kommentar er tom
             * Gul: Hvis satt i unapproved etter reviewed men kommentar finnes
             * Grønn: Hvis plan ikke er satt i unapproved etter reviewed
             * Output: Status melding + evt kommentar hvis relevant
             * Notat: Satt inaktiv hvis ikke gul eller rød
             */


            bool foundUnapproved = false;
            


            bool foundReviewedAfterUnapproved = false; //Benevningen er kronologisk motsatt fordi listen går fra nyest -> eldst, ergo eldst kommer etter nyest

            foreach (var element in plan.ApprovalHistory)
            {
                if (element.ApprovalStatus == PlanSetupApprovalStatus.UnApproved)
                    foundUnapproved = true;

                if (element.ApprovalStatus == PlanSetupApprovalStatus.Reviewed && foundUnapproved)
                    foundReviewedAfterUnapproved = true;
            }

            string unapprovedComment;
            

            if (foundReviewedAfterUnapproved && (plan.Comment == ""))
            {
                unapprovedComment = "Plan er satt i unapproved etter reviewed men ingen kommentar!!!!!!!!!!";
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment =  unapprovedComment;
            }
            else if (foundReviewedAfterUnapproved)
            {
                unapprovedComment = "Plan er satt i unapproved etter reviewed, kommentar fra den skyldige:\n" + plan.Comment;
                checkPoint.CheckStatus = Constants.Warning;
                checkPoint.CheckComment = unapprovedComment;
            }
            else
            {
                unapprovedComment = "Nei";
                checkPoint.CheckStatus = Constants.Ok;
                checkPoint.CheckResultValue = unapprovedComment;
            }

            
        }

       

        public static void CheckTreatmentSessions(ExternalPlanSetup plan, CheckPoint checkPoint)
        {
            /* Korrekt antall behandlinger er lagt inn
             * Rød: Hvis fraksjoner ikke matcher behandlinger
             * Gul:
             * Grønn: Hvis fraksjoner matcher behandlinger
             * Output: Antall fraksjoner og antall behandlinger
             * Notat:
             */
            string treatmentSessions = $"Behandlinger: {plan.TreatmentSessions.Count()}\nFraksjoner: {plan.NumberOfFractions}";

            if (plan.TreatmentSessions.Count() != plan.NumberOfFractions)
                checkPoint.CheckStatus = Constants.Error;
            else checkPoint.CheckStatus = Constants.Ok;
            checkPoint.CheckResultValue = treatmentSessions;
            checkPoint.CheckResultValueCSV = plan.TreatmentSessions.Count() + "/" + plan.NumberOfFractions; //CSV
        }


        public static void CheckFieldNames(ExternalPlanSetup plan, IEnumerable<ExternalPlanSetup> allPlans, CheckPoint checkPoint)
        {
            /* Feltnavn/-nummerering er korrekt
             * Rød: Hvis feltnavn ikke følger rett format 
             * Gul:
             * Grønn: Hvis feltnavn følger rett format
             * Output: Alle felt fra alle tidligere planer
             * Notat: IKKE I BRUK
             */

           


            List<string> fieldNames = new List<string>();
            

            foreach (ExternalPlanSetup p in allPlans)
            {
                fieldNames.Add( p.Id + (p.Id == plan.Id ? " (gjeldende plan)" : ""));
                foreach (Beam beam in PlanExtension.GetFields(p))
                {
                    fieldNames.Add("    " + beam.Id);

                }
                
            }

            IEnumerable<string> allFieldIds = allPlans.SelectMany(p => PlanExtension.GetFields(p)).Select(b => b.Id);

            var fieldRegex = new Regex(@"^Fe (\d+)$");

            var fieldNumbers = allFieldIds
                .Select(s => fieldRegex.Match(s))
                .Where(m => m.Success)
                .Select(m => int.Parse(m.Groups[1].Value));

            // Check for valid pattern, no duplicates, and no gaps
            bool allMatch = fieldNumbers.Count() == allFieldIds.Count();
            bool noDuplicates = fieldNumbers.Distinct().Count() == fieldNumbers.Count();
            bool noGaps = fieldNumbers.Min() == 1 && fieldNumbers.Max() == fieldNumbers.Count();

            bool isValidSequence = allMatch && noDuplicates && noGaps;

            if (!isValidSequence)
            {
                checkPoint.CheckStatus = Constants.Error;
                checkPoint.CheckComment = $"Felt-IDer følger ikke gyldig sekvens. Sjekk at alle felt er nummerert fra 1 til {allFieldIds.Count()} uten hull og duplikater.";
            }
            else checkPoint.CheckStatus = Constants.Ok;

            checkPoint.CheckResultValue = string.Join("\n", fieldNames);

        }

        public static void CheckFieldInField(ExternalPlanSetup plan, CheckPoint checkPoint)
        {
            /* Felt er slått sammen field-in-field
             * Rød: Hvis det er felt med helt lik energi, kollimator vinkel, kollimator åpning og gantryvinkel
             * Gul:
             * Grønn: Hvis den ikke er rød
             * Output: Tommelopp/ned
             * Notat: 
             */

            string fieldInField = "";
            

            if (PlanExtension.GetFields(plan)
                .GroupBy(b => new { b.ControlPoints.First().CollimatorAngle, b.ControlPoints.First().GantryAngle, b.ControlPoints.First().JawPositions, b.EnergyModeDisplayName }) // b.EnergyMode })  SUS Uncomment
                .Any(g => g.Count() > 1))
            {
                checkPoint.CheckStatus = Constants.Error;
                fieldInField = "Field-in-field felt er ikke slått sammen.";
                checkPoint.CheckResultValue = "👎";
                checkPoint.CheckResultValueCSV = "Ikke slaatt sammen.";
            }
            else
            {
                checkPoint.CheckStatus = Constants.Ok;
                checkPoint.CheckResultValue = "👍";
                checkPoint.CheckResultValueCSV = "Ok.";
            }

            checkPoint.CheckComment = fieldInField;
        }

        public static void CheckMissingSlices(EclipseImage image, CheckPoint checkPoint)
        {

            /* Sjekk om CT mangler snitt
             * Rød: Hvis antall snitt ikke samsvarer med oppløsning i Z-akse
             * Gul: 
             * Grønn: Hvis ikke rød
             * Output: Antall snitt og oppløsning i Z-akse for CT-en
             * Notat: 
             */
            bool slicesMissing = image.ZSize != image.Series.Images.Where(i => i.UID != null).Count();

            checkPoint.CheckStatus = slicesMissing ? Constants.Error : Constants.Ok;
            checkPoint.CheckResultValue = $"Forventede snitt: {image.ZSize}\nFakstiske snitt: {image.Series.Images.Where(i => i.UID != null).Count()}";
            checkPoint.CheckResultValueCSV =  image.Series.Images.Where(i => i.UID != null).Count() + "/" + image.ZSize;  //CSV 
        }

 

        public static void CheckPlanUncertainties(CheckPoint checkPoint, ExternalPlanSetup plan)
        {
            checkPoint.CheckStatus = checkPoint.CheckTrafficLight; //Constants.Info;
            if (!plan.PlanUncertainties.Any())
            {
                checkPoint.CheckResultValue = "Nei";
                checkPoint.CheckStatus = Constants.Printout; //Lighter color if nothing to see there, breped
            }
            else
            {
                checkPoint.CheckResultValue = "Ja";
                checkPoint.CheckComment = string.Join("\n", plan.PlanUncertainties.Select(pu => pu.DisplayName));
                checkPoint.CheckStatus = Constants.Info; //Heavier color if something here, stands more out breped
            }
            checkPoint.CheckResultValueCSV = checkPoint.CheckResultValue; //CSV
        }

        private static string GetPlanUncertaintyString(PlanUncertainty pu)
        {
            VVector isoShift = pu.IsocenterShift;
            return $"{pu.Id}: X: {isoShift.x}cm Y: {isoShift.y}cm Z: {isoShift.z}cm";
        }
    }
}
