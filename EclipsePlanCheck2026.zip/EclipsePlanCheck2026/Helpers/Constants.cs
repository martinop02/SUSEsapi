﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;

namespace EclipsePlanCheck.Helpers
{
    //-----Konstanter -----

    public class Constants
    {
        public const string Hospital = "HUS";
        public const string ScriptName = "EclipsePlanCheck";

        //SanityLevelCheck Levels
        public const int SanityLevelNoPatient = 0; 
        public const int SanityLevelPatientExist = 1;
        public const int SanityLevelImageExist = 2;
        public const int SanityLevelStructureSetExist = 3;
        public const int SanityLevelCourseExistNotStructureSetOrImage = 4;
        public const int SanityLevelCourseExist = 5;
        public const int SanityLevelPlanExist = 6;

        public const int SanityLevelFractionationExist =7;
        public const int SanityLevelCalculatedDoseExist = 8;
        //public const int SanityLevelTargetStructureExist = 8; //TargetStructureExist is stored in the patientContext class, use that to check.
        public const int SanityLevelAllGood = 9999;


        //Separator to split strings
        public const string StringSeparator = "|";
        public const char CharSeparator = '|'; //Arrays demand Char not string. Should be the same as StringSeparator over.

        //settings:
        public const bool AllStringComparisonCaseSensitive = false;

        //Set paths

#if HUS
        public const string PlanPublishedScriptsFolderPath = @"\\Vir-app5338\va_data$\ProgramData\Vision\PublishedScripts\";
        public const string PlanCheckTemplateFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string PlanCheckTemplateTestFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string PlanCheckTemplateFileName = @"PlanCheckTemplates.csv";
        public const string PlanCheckTemplateTestFileName = @"PlanCheckTemplatesTest.csv";
        public const string PlanCheckTemplateMachineOverideFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string PlanCheckTemplateMachineOverideFileName = @"PlanCheckTemplatesMachineOverride.csv";
        public const string MarginTemplatesFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string MarginTemplatesFileName = @"MarginTemplates.csv";
        public const string CheckPointSettingsFileName = @"CheckPointSettings.csv";
        //public const string DVHTemplateFileName = @"DVH.csv"; //These are put directly in the code now because then you can add custom criteria for them to show up - see CreateCheckPoint.cs
#endif
#if SUS
        public const string PlanPublishedScriptsFolderPath = @"\\10.92.139.197\Sharedfiles\Personlige mapper\Martin\EditSUS-templates\";
        public const string PlanCheckTemplateFolderPath = @"\\10.92.139.197\Sharedfiles\Personlige mapper\Martin\EditSUS-templates\";
        public const string PlanCheckTemplateTestFolderPath = @"\\10.92.139.197\Sharedfiles\Personlige mapper\Martin\EditSUS-templates\";
        public const string PlanCheckTemplateFileName = @"PlanCheckTemplates.csv";
        public const string PlanCheckTemplateTestFileName = @"PlanCheckTemplatesTest.csv";
        public const string PlanCheckTemplateMachineOverideFolderPath = @"\\10.92.139.197\Sharedfiles\Personlige mapper\Martin\EditSUS-templates\";
        public const string PlanCheckTemplateMachineOverideFileName = @"PlanCheckTemplatesMachineOverride.csv";
        public const string MarginTemplatesFolderPath = @"\\10.92.139.197\Sharedfiles\Personlige mapper\Martin\EditSUS-templates\";
        public const string MarginTemplatesFileName = @"MarginTemplates.csv";
        public const string CheckPointSettingsFileName = @"CheckPointSettings.csv";
        //public const string DVHTemplateFileName = @"DVH.csv"; //These are put directly in the code now because then you can add custom criteria for them to show up - see CreateCheckPoint.cs
#endif
#if UNN
        public const string PlanPublishedScriptsFolderPath = @"\\Vir-app5338\va_data$\ProgramData\Vision\PublishedScripts\";
        public const string PlanCheckTemplateFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string PlanCheckTemplateTestFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string PlanCheckTemplateFileName = @"PlanCheckTemplates.csv";
        public const string PlanCheckTemplateTestFileName = @"PlanCheckTemplatesTest.csv";
        public const string PlanCheckTemplateMachineOverideFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string PlanCheckTemplateMachineOverideFileName = @"PlanCheckTemplatesMachineOverride.csv";
        public const string MarginTemplatesFolderPath = @"\\vir-app5338.ihelse.net\va_data$\HIS_Link\EclipsePlanCheck\";
        public const string MarginTemplatesFileName = @"MarginTemplates.csv";
#endif

#if Debug
        //public const bool TestMode = true; //Set to true to run i testmode. 
#endif

#if Clinical
        //public const bool TestMode = false; //Set to true to run i testmode. 
#endif

        //Notify of changes if within certain days:
        public const int DaysBeforeNotification = 35;

        //Traffic light - what should be shown in text
        public const string Ok = "Ok"; //Ok, green ✅ ✔️
        public const string Warning = "Adv."; //Warning minor,  yellow ⚠️ 🔔 📢
        public const string Warning2 = "Adv."; //Warning major, orange //Not used right now now! '⚠️❗'
        public const string Error = "Feil"; //Feil, red ❌ ⛔ ❗🛑✋🏻
        public const string Unknown = "Ukjent"; //Ukjent, grey ❓ 🤔  �

        //Suggestion - make a method: 
        //if status='Ok' replace inteface status output with desired 'OkSymbol'=✅. Always keep constants 'Ok', 'Warning' and 'Error' the same for all versions as they are used in Excelsheets and xaml-code, and only change desired display symbol/text: 'OkSymbol'
        //If status='Warning', replace interface status output with 'WarningSymbol'=⚠️
        //If status='Error', replace interface status output with 'ErrorSymbol'= ❌

        //Other traffic lights of just printing information, colorcoded for how important it is:
        public const string Printout = "Utskrift"; //  Least important (Lavender color) Pure printout   //Til info 
        //Symbols: ℹ️🖨️ 💬 📝 📩 📊 📄 ⎙ 🖨🧾
        public const string Info = "Info"; // Somewhat more important. 'Info' is both a status (Cyan color) and a Type of checkpoint    
        //Symbols: ℹ️ 🛈 𝒊 ⓘ
        public const string OBS = "OBS"; // Most important. (still Cyan color).     
        //Symbols: ℹ️🚩📌🔔📨👋👀👁️‍🗨️😱😨📣


        //Types of CheckPoints:
        //public const string Info = "Info"; //mostly printed information, not necessarily correct or wrong.
        public const string Check = "Sjekk"; //A CheckPoint, oten checked against template value, can have many different statuses (Error / Warning / Ok etc).

        //Calculation statuses
        public const string Calculating = "⌛..."; //Hourglass (Calculating) symbol
        public const string Delayed = "⏯"; //Clock ⏱️ (Delayed) and Hourglass ⌛ (Calculation) symbol? Or use Pause symbol ⏸️ ▐▐ ❚❚⏯. Or stop symbol ⏹️.

        //public const string ReRunCalculation = "🔄"; //"▶" ▶️🔄↺ 

        public const string TemplateEmpty = "Ingen funnet"; //Ingen gyldig templat funnet -> Tomt/generelt temlat


        //Sender ofte all data som tekst til interface, ogsaa booleans. Laster ogsaa booleans inn i fra csv-filer og skriver til dem, derfor bruker vi string. Bruker konstanter for å hindre forskjell smaa/store bokstaver etc.
        //Kan fjernes hvis vi begynner å bruke converters isteden...
        public const string True = "True";
        public const string False = "False";

        //Lateralitet
        public const string Hoyre = "Høyre";
        public const string Venstre = "Venstre";
        public const string Medial = "Medial";

        //Settings - outdated, should be deleted
        public const string CheckSettingsStrict = "Streng";
        public const string SjekkSettingsMedium = "Medium";


        public const string DoNotShowReferencePointsTaskTypes = "Doseplan"; // Used to hide Refpoint list for certain task types //to be handled a different way later?
        public const string DefaultTaskType = "Fysiker"; // zzTest//Fysiker//Used as default chosen TaskType, if no active choice taken. Only have one in the string!
        public const string ControlTaskTypes = "Doseplan|Fysiker|BasicPlanCheck|zzTest";


        //Machine type
        //public enum MachineType
        //{ TrueBeam, Ethos, Halcyon };

        public const string TB = "TrueBeam";
        public const string Halcyon = "Halcyon";
        public const string Ethos = "Ethos";
        //public const string Proton = "Proton"; //? 

        public const int AbsoluteToleranceMinimumNumberOfSetupFields = 1;

        //Energier
        public static List<FieldEnergy> Energies = new List<FieldEnergy>
        {
            new FieldEnergy() { EnergyName = "6X-FFF", DoseRate = "1400", MachineType = Constants.TB},
            new FieldEnergy() { EnergyName = "10X-FFF", DoseRate = "2400", MachineType = Constants.TB},
            new FieldEnergy() { EnergyName = "6X-FFF", DoseRate = "800", MachineType = Constants.Ethos},
            new FieldEnergy() { EnergyName = "6X-FFF", DoseRate = "800", MachineType = Constants.Halcyon},
            new FieldEnergy() { EnergyName = "6X", DoseRate = "600", MachineType = Constants.TB },
            new FieldEnergy() { EnergyName = "15X", DoseRate = "600", MachineType = Constants.TB },
            //Elektroner
            new FieldEnergy() { EnergyName = "6E", DoseRate = "1000", MachineType = Constants.TB },
            new FieldEnergy() { EnergyName = "9E", DoseRate = "1000", MachineType = Constants.TB },
            new FieldEnergy() { EnergyName = "12E", DoseRate = "1000", MachineType = Constants.TB },
            new FieldEnergy() { EnergyName = "15E", DoseRate = "1000", MachineType = Constants.TB },
        };

        //Machines (SUS values from the NY version)
        public const string MachinesGatingAllowedRPM = ""; //Empty = always allowed
        public const string MachinesGatingAllowedOSMS = ""; //Empty = always allowed
        public const string MachinesStereotaxyAllowed = ""; //Empty = always allowed
        public const string MachinesElectronsAllowed = ""; //Empty = always allowed

        //Need to keep track of ring-machines vs TB at certain hospitals
        public const string MachinesEthos = ""; //Leave Empty if none
        public const string MachinesHalcyon = ""; //Leave Empty if none
        public const string MachinesTB = "SBH_1|SBH_2|SBH_3|SBH1_2025|SBH2_2025|SBH3_2021"; //Empty = always TB

        //Mobius
        public const string MobiusPath = @"\\vir-app5338\va_data$\Mobius\Reports\";

        //Limits for smalles fieldssizw
        public const int ToleranceFieldsize_x = 3;
        public const int ToleranceFieldsize_y = 3;
        public const int ToleranceFieldsize_xy = 9; //x*y
        //Mu/Gy Limits for choosing PD
        public const int IMRT_PD_MUperGy = 1000; //600
        public const int VMAT_PD_MUperGy = 500; //300

        //
        public const int DefinitionLessThanThisNumberOfControlPointsToBeFiFTechnique = 31; //Otherwis it will be IMRT

        //Grenser for Fluence
        public const double ToleranceSmallestFluenceMaxVAlue = 0.03;

        //CROPPING Definition:
        //Minste distanse (i mm ) mellom en struktur og Body for aa ekskludere maalepunkt i strukturen fra kalkulering av margin:
        public const double ExceptionDistancePTVToBodyInMarginCalculationMm = 6.5; //PTV must be within this distance from Body to be considered cropped. Cropped points are skipped in calculating MeanMarginNotCropped
        public const double ExceptionDistanceCTVToBodyInMarginCalculationMm = 9; //CTV must be within this distance from Body to be considered cropped. Cropped points are skipped in calculating MeanMarginNotCropped.
        public const double DefinitionCroppingPTVToCTVDistanceMarginCalculationMm = 1.6; //CTV must be within this distance from PTV to be considered cropped. Cropped points are skipped in calculating MeanMarginNotCropped
        //-> Both CTV distance to body and ptv distance to body must be inside this limit to be considered in cropped area!
        //public const double BodyDistanceHigherThanThisSkipFurtherAhead_LargeSkip = 150;  //Save time in calculations //These attemts caused major issues. Do not try this again, unless you can sort all 3DPoints by distance first, and the the whole point is gone, no time to save...
        //public const int BodyDistanceNumberOfPointsToSkip_LargeSkip = 3;
        //public const double BodyDistanceHigherThanThisSkipFurtherAhead_SmallSkip = 75;
        //public const int BodyDistanceNumberOfPointsToSkip_SmallSkip = 2;
        //public const double SmallStructureDistanceHigherThanThisSkipFurtherAhead = 75;
        //public const int SmallStructureDistanceNumberOfPointsToSkip = 2;

        //INSIDE STRUCTURE?
        public const double ExceptionDistanceCTVToBodyInStructureInsideStructureCheckMm = 12; //If CTV is outside PTV (normally gives error) in a region within this distance from Body, then it will not considered it an error. (there is still a comment made about it). "IsStructureWithinStructure" is the function it is used in. 
        public const double ExceptionDistanceCTVToPTVIsEqualInStructureInsideStructureCheckMm = 0.5; //in mm //IF CTV is never outside PTV with more then this amount of mm, then check assumes CTV=PTV not not actually outside //earlier 0.1mm
        public const double ToleranceTargetStructureMatchOriginDistanceCm = 2.5; // For instance if 2.5: center point of PTV has to be within 2.5cm of center point of CTV origin in order for the CTV-PTV match to be accepted.

        //Bad resolution structure points?
        public const double ToleranceBadResolutionMm = 4.5;
        public const double TolerancePercentagePointsBadResolutionWarning = 0.25; //If too many points have bad resolution, give headsup: "Code will discard many measurements because large structure has bad resolution. Mean resolution:

        //Small structure outside large structure tolerances:
        public const double TolerancePercentagePointsOutsideLargeStructure = 0.1; //How many measurement points can be outside large structure before there is a warning.
        public const double TolerancePercentagePointsOutsideLargeStructureIfZeroMarginExpected = 0.5; //Higher. if there is zero margin expected, there is much more likely to be random points of CTV outside PTV for instance. More tolerance.
        public const double ToleranceAverageDistanceOutsideLargeStructure = 3; //3mm

        //Defining directional sectors of a structure. Could at later point be replaced with using normal vectors on structure and finding all point with a certain normal direction.
        public const double DirectionalMarginPercentageDiscardedPointsCurrentDirection = 0.6; //If finding margin in X directions, if the structure goes from say coordinates X=-20 to X=+20, and this factor is 0.8 (80%), then margins in X directions will be measured from X=+16 to X=+20 and X=-16 to X=-20 respectively.
        public const double DirectionalMarginPercentageKeptPointsOtherDirections = 0.95;  //When checking marings in a structure in say X-direction, how far (relative to structure lengrh) should it check this in y and z directions. If it is 0.95 (95%), it will discard the 5% of the edges in y and z direction.

        //StandardMargin
        //public const double StandardMarginIfNoTemplateValue = 5; //in mm. Not used now. Instead it only displays as information.
        //Default warnings (hvis ingen spesifisert)
        public const double TolerancesMarginsPercentageWarning = 0.25; //if 0.2 it means it tolerate up to 20% deviation before warning
        public const double TolerancesMarginsPercentageError = 0.4; //if 0.4 it means it tolerate up to 40% deviation before error
        public const double TolerancesMarginsMinimumWarning = 0.5; //Should always tolerate 0.5 mm deviation
        public const double TolerancesMarginsMinimumError = 0.8; //Should always tolerate 0.8 mm deviation
        public const double CloseToZeroMargin = 1; //Define area "close to zero margin". If too many measurments are in directional margin is smaller than this factor, we override to zero margin if mesh geometries show 0 margin. There is no point using mean margin then.
        public const double CloseToZeroMarginPercentage = 0.5; //0.5 means 50% measurements must be close to zero in directional margin check in order to conclude that there is 0 margin. There is no point using mean marign then.

        //Bolus standard HU
        public const string BolusStandardHU = "0";  //"0|100|200" if you want more standard bolus HU values. Add a table with different types of bolus? 3D: 0 | Standard: 0 | Salve: 0 | PLA: 300 | TPU : 200 etc.


        public static List<StructureCheck> BolusTemplates = new List<StructureCheck>
        {
            new StructureCheck() { StructureID = "*bolus*cs*", StructureHU = "0"},
            new StructureCheck() { StructureID = "*bolus*tpu*", StructureHU = "0"},
            new StructureCheck() { StructureID = "*bolus*pla*", StructureHU = "300"},
            new StructureCheck() { StructureID = "*bolus*salve*", StructureHU = "0"},
            new StructureCheck() { StructureID = "*bolus*elastogel*", StructureHU = "200"},
            new StructureCheck() { StructureID = "*bolus*vanne*", StructureHU = "*"}, //Ingen grense
            new StructureCheck() { StructureID = "*bolus*bind*", StructureHU = "*"}, //Ingen grense

        };


        //Grenser for feltstorrelse
        public const int Tolerance_Minimum_MU_Wedge = 20;

        //Settings for search for markers around User Origin
        public const int NumberOfPixelsOutsideBodySearch = 50; //Searches from body to 20 pixels outside body in x-direction //Can be on mask outside patient body
        public const int NumberOfPixelsInsideBodySearch = 4; //Searches from body to this number of pixels inside body in x-direction //Should not search to far into body because we might hit bone!
        public const int MarkerFoundCriteriaHUValue = 700; //If value is > this HU value in this area, then it consider it that marker is found. //Earlier: 780
        public const int NumberOfPixelsInSearch_Y = 15; //How many slices in y direction should we search for marker
        public const int NumberOfSlizesInSearch = 5;  //How many slices in z direction should we search for slices
        public const int ReducedSearchThisDistanceFromUserOrigin = 3; //Only do reduced search when this far away from user origin, definition. Stated in pixels, both for Y and Z directions
        public const int ReducedNumberOfPixelsInSearch = 3; //when reduced search as defined by ReducedYSearchThisDistanceFromUserOrigin, only go this many pixels in the other direction
        public const double ToleranceMarkerPositionDifferenceMm = 5; //if total difference from
        //public const int ExpectedNumberOfMarkersDetected = 2; //Lower than this gives a warning.

        //Tykkelse på standard couch, i cm:
        public const double ThicknessOfCouch_CM = 6.3; // i cm. Brukes fordi noen bord har ekstra fikseringsutstyr inkludert i strukturen, slik at da er ikke posisjon til toppen av couch er nyttig. Finner heller bunn av couch og legger til denne verdien.
                                                       //Kompromiss mellom:   //Standardbordtykkelse: 6.27cm.   //mammabordtykkelse: 6.34cm.
                                                       //Couch-til-isosenter-avstand toleranse i cm:
        public const double ToleranseAvstandBordTilIsosenterCm = 28; //cm //27
        public const string CouchExcactIDs = "CouchSurface|CouchMamSurface|BosSurface|Couch surface"; //Searches for direct match on these ids and choses first match found, can contain wildcards
        public const string CouchIDContainsStandardPhrase = "*Couch*Surface*|*Couch*surface*|*Surface*|*Couch*|*bos*"; //If no direct match, searches for this phrase(s), prioritized order, can contain wildcards

        //Collision check tolerances warnings in cm
        public const double CollisionDistanceError = 3.0;
        public const double CollisionDistanceWarning = 4.0;


        public const string UnionPTV = "PTVu"; //If no direct match on target structure, searches for this phrase/these phrases, prioritized order, can contain wildcards

        //Algoritmer - gyldig versjon.
        public const string AAA_algo = "AAA_16.1.0"; //Default AAA //Outdated since it is now written in the Template                                       
        public const string Acuros_algo = "AXB_16.1.0"; //default Acuros //Outdated since it is now written in the Template                                               
        public const string Electron_algo = "EMC16.1.0"; //default Elektron //Outdated since it is now written in the Template  



        //Normaliseringer: //"100.00% covers 50.00% of Target Structure"  "100.00% covers 95.00% of Target Structure"
        public const string Normalisering_100c50_standard = "100.00% covers 50.00% of Target Structure";
        public const string Normalisering_stereotaksi = "100.00% covers 95.00% of Target Structure";

        //PTV name:
        public const string PTV_StartWith = "PTV"; //"GTV-CTV|GTV-IGTV|IGTV-CTV|CTV-ITV|CTV-PTV|ITV-PTV"
        public const string CTV_StartWith = "CTV";
        public const string ITV_StartWith = "ITV";
        public const string GTV_StartWith = "GTV";
        public const string IGTV_StartWith = "IGTV";

        //HighResolution settings:
        public const int HighResolutionStructureIfDistanceLessThanCm = 3;
        public const double HighResolutionStructureDistanceStopSearchCm = HighResolutionStructureIfDistanceLessThanCm * 0.1; //Stops searching if structure is closer to another structure since it is already very close.  Saves time.
        public const double ShouldNotBeHighResolutionStructureIfVolumeHigherThanCm3 = 500;
        public const double ShouldNotBeHighResolutionStructureShortDistanceFromTargetIfVolumeHigherThanCm3 = 35;
        //public const string MandatoryHighResolutionStructures = "";

        //Laterality
        public const string LateralityTemplateString = "$$";

        //When templates include laterality in structureIDs and planIDs, add "$$" where laterality would be positioned in the string. A function will replace this with correct laterality string.
        //Where "$$" is written, it will check for these strings in that location, depending on laterality. Can have severel possibilities seperated by Constants.StringSeparator. See PlanTemplateExtention.
        public const string Structures_Template_Laterality_Left_Contains_String = "_L_";
        public const string Structures_Template_Laterality_Left_EndsWith_String = "_L";
        public const string Structures_Template_Laterality_Right_Contains_String = "_R_";
        public const string Structures_Template_Laterality_Right_EndsWith_String = "_R";

        public const string PlanID_Template_Laterality_Left_Contains_String = "_L_"; 
        public const string PlanID_Template_Laterality_Left_EndsWith_String = "_L"; //Ve  //RSF is notation for Left mamma with Skin Flash, used at HUS
        public const string PlanID_Template_Laterality_Right_Contains_String = "_R_";  
        public const string PlanID_Template_Laterality_Right_EndsWith_String = "_R"; //Ho //Hø  //RSF is notation for Right mamma with Skin Flash, used at HUS



        //When searching for laterality in structures and planIDs, when the string contains this, it assumes this means its laterality. Is checked against isosenter laterality.
        public const string Structures_Search_Laterality_Left_Contains_String = "_L_";
        public const string Structures_Search_Laterality_Left_EndsWith_String = "_L";
        public const string Structures_Search_Laterality_Right_Contains_String = "_R_";
        public const string Structures_Search_Laterality_Right_EndsWith_String = "_R";

        public const string PlanID_Search_Laterality_Left_Contains_String = "_L_|LNL|LN_L|_LSF"; //LNR = Lymph Nodes Left in mammae plans used at HUS //LSF is notation for Left mamma with Skin Flash, used at HUS
        public const string PlanID_Search_Laterality_Left_EndsWith_String = "_L|_Ve"; 
        public const string PlanID_Search_Laterality_Right_Contains_String = "_R_|LNR|LN_R|_RSF"; //LNR = Lymph Nodes Right im mammae plans used at HUS //RSF is notation for Right mamma with Skin Flash, used at HUS
        public const string PlanID_Search_Laterality_Right_EndsWith_String = "_R|_Ho|_Hø";

        //public const char[] ArraySeparators = { ';' };  //Det er ikke mulig aa lage konstanter som er arrays :(  Det maa erkleares der det brukes

        public const string DefaultTemplat = "Default";
        public const string DefaultTemplatColor = "Cyan";

        //Score for templater
        //Default konstanter
        public const int MatchScoreDiagnosis = 3;
        public const int MatchScoreCourse = 5;
        public const int MatchScoreStruktSet = 1;
        public const int MatchScorePlanID = 10;
        public const int MatchScorePTV = 2;
        public const int MatchScoreCTV = 2;
        public const int MatchScoreOAR = 1;
        public const int MatchScoreStructure = 3;
        public const int MatchScoreNumberOfFractions = 1;
        public const int MatchScoreDosePerFraction = 1;
        public const int MatchScoreFractionation = 3;
        public const int MatchScoreTechnique = 3;
        public const int MatchScoreSRSTechnique = 8;

        public const int MinimumScoreToChooseATemplate = 17; //A template must get this score or higher than this score to be autoselected. Otherwise the default template is selected. //(Check out method "ChangeColorByScore" if this value is set < 11.)

        //Teknikknavn
        //SRS RA, RA, Static, FiF, TotalBody
        public static class Teknikk
        {
            //Statisk felt definisjoner Aria
            public const string Static_technique_name_Aria = "STATIC"; //Definert i Aria
            public const string Static_technique_MLCPlanType_name_Aria = "Static"; //Definert i Aria
            public const string Static_technique_forklaring = "Statisk"; //Output fra skriptet

            //IMRT definisjoner Aria
            public const string IMRT_technique_name_Aria = "STATIC"; //Definert i Aria
            public const string IMRT_technique_MLCPlanType_name_Aria = "DoseDynamic"; //Definert i Aria
            public const string IMRT_technique_forklaring = "IMRT"; //Output fra skriptet

            public const string IMRT_Hybrid_technique_forklaring = "Hybrid IMRT"; //Output fra skriptet

            //Field-in-field definisjoner Aria
            public const string FiF_technique_name_Aria = "STATIC"; //Definert i Aria
            public const string FiF_technique_MLCPlanType_name_Aria = "DoseDynamic"; //Definert i Aria
            public const int FiF_technique_ControlPointsLimit = 30; // Hvordan skille Fif og IMRT. Maa ha denne verdien eller lavere for at et dynamisk felt skal defineres som FiF istedenfor IMRT. Litt kunstig definisjon
            public const string FiF_technique_forklaring = "FiF"; //Output fra skriptet

            //ARC/VMAT definisjoner Aria
            public const string Arc_technique_name_Aria = "ARC"; //Definert i Aria
            public const string Arc_technique_MLCPlanType_name_Aria = "VMAT"; //Definert i Aria
            public const string Arc_technique_forklaring = "VA"; //Output fra skriptet

            //SRS ARC/VMAT definisjoner Aria
            public const string SRS_Arc_technique_name_Aria = "SRS ARC"; //Definert i Aria
            public const string SRS_Arc_technique_MLCPlanType_name_Aria = "VMAT"; //Definert i Aria
            public const string SRS_Arc_technique_forklaring = "SRS VA"; //Output fra skriptet

            //Total Body
            public const string TotalBody_technique_name_Aria = "TOTAL"; //Definert i Aria
            public const string TotalBody_technique_MLCPlanType_name_Aria = ""; //Definert i Aria    //???
            public const string TotalBody_technique_forklaring = "Total Body";

            //Elektron
            public const string Electron_technique_name_Aria = "STATIC"; //Definert i Aria
            public const string Electron_technique_MLCPlanType_name_Aria = null; // NULL -  Ikke MLC   //???
            public const string Electron_technique_forklaring = "Elektron";


            //Ikke funnet
            public const string Unknown_technique_forklaring = "Teknikk ikke funnet av script";

            //Elektroner?
        }

        //        <!-- HEX unicode -->
        //<!-- Bullet point:  "&#8226;" -->
        //<!-- Check mark:  "&#x2705;" -->
        //<!-- Warning 1:  "&#9888;" -->
        //<!-- Warning 2:  "&#x26A0;" -->
        //<!-- Error red:  "&#x26A0;" "&#x274C;" -->
        //<!-- Error black:  &#x2716; &#10006; -->
        //<!-- RED Exclamation:  "&#10071;" or "&#x2757;"  -->
        //<!-- White Exclamation:  "&#10069;" or "&#x2755;"  -->
        //<!-- White question:  "&#10068;" or "&#x2754;"  -->
        //<!-- RED question:  "&#10067;" or "&#x2753;"  -->
        //<!-- cirecle with i in:  "&#x24D8;" or "&#9432;"  -->

        //OLD CODE NOT IN USE
#region Old Code
        //public static class Templater 
        //{
        //    public const string Prostata_LIH = "Prostata_LIH";
        //    public const string Prostata_LIH_dgn = "C61";

        //    public const string Prostataseng = "Prostataseng";
        //    public const string Prostataseng_dgn = "C61";

        //    public const string Mamma_kun_bryst = "Mamma_kun_bryst/chestwall";
        //    public const string Mamma_kun_bryst_dgn = "C50*|D05*";

        //    public const string Mamma_LN = "Mamma_LN";
        //    public const string Mamma_LN_dgn = "C50*|D05*";

        //    public const string Mamma_Boost = "Mamma_Boostplan";
        //    public const string Mamma_Boost_dgn = "C50*|D05*";

        //    public const string Stereotaksi_lunge = "Stereotaksi_lunge";
        //    public const string Stereotaksi_lunge_dgn = "*";

        //    public const string Lunge = "Lunge_kurativ";
        //    public const string Lunge_dgn = "C34*|*C78*";

        //    public const string ONH = "ØNH";
        //    public const string ONH_dgn = "C0*|C11*|C12*|C13*|C30*|C31*|C32*";

        //    public const string Cerebri = "Cerebri";
        //    public const string Cerebri_dgn = "C69*|C71*|C72*|C70*|D32*|D35*|E05*|H05*|H06";

        //    public const string Ani = "Ani";
        //    public const string Ani_dgn = "C21*";

        //    public const string Recti = "Recti";
        //    public const string Recti_dgn = "C20*";

        //    public const string Tot_Hjerne = "Total_Hjerne";
        //    public const string Tot_Hjerne_dgn = "C79.3|C34.9|*";


        //    public const string Default = "Default";
        //}
#endregion Old Code





    }
}
