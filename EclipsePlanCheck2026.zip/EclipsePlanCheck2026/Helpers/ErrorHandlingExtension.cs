﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EclipsePlanCheck
{
    class ErrorHandlingExtension
    {

        //Feilmeldinger vises i eget vindu
        public static void ErrorDog(string feilmelding)
        {
            ErrorDogView errorwindow = new ErrorDogView();
            errorwindow.Error_Textbox.Text = feilmelding;
            errorwindow.ShowDialog();
        }

    }
}
