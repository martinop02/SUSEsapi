﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Text.RegularExpressions;

namespace EclipsePlanCheck.Helpers
{
    class PatientContextExtension
    {
        //Flytt denne til en annen extension?
        public static string GetUserId(ScriptContext context) //Raw userId string
        {
            string userid = context.CurrentUser.ToString();
            return userid;
        }

        public static string GetUserName(ScriptContext context) //Just the full name
        {
            string userid = context.CurrentUser.ToString();
            string result = GetUserNameFromUser(userid);
            return result;
        }
        //Flytt denne til en annen extension?
        public static string GetUserNameFromUser(string string_bruker) //hent brukernavn
        {
            string result = "";
            //fjerner eventuell unodvendig tekst fra brukernavnet
            if (string_bruker.Contains(@"hs\"))
            {
                int pFrom = string_bruker.IndexOf(@"hs\") + @"hs\".Length;
                int pTo = 0;
                if (string_bruker.Contains(":"))
                {
                    pTo = string_bruker.LastIndexOf(":");
                }
                else
                {
                    pTo = string_bruker.Length;
                }
                result = string_bruker.Substring(pFrom, pTo - pFrom);
            }
            else { result = string_bruker; }
            return result;
        }

         public static PatientContext GetPatientContext(ScriptContext context)
        {

            int sanityLevel = Constants.SanityLevelAllGood; //9999;
            string sanityDesription = "";
            string bodyID = "";

            string userID = ""; 
            string userName = "";

            PatientContext patientContext = new PatientContext();

            //---------------
            //Sanity Statuses:
            //---------------
            //0: No patient
            //1: Patient(no image)
            //2: Image(no structure set)
            //3: StructureSet(no course)
            //4: Course(no plan)
            //5: Plan(no fractionation)
            //6: Fractionation(no dose)
            //7: Dose(no target structure)
            //8: Target Structure (not drawn yet). All prerequisites present
            //Additional statuses:
            //   TargetStructureSegmented
            //   TargetStructureExist
            //Set references:
            //ChosenCourse
            //ChosenPlan
            //ChosenImage
            //BodyID
            //CouchID (this one is problematic if separated into several couches). Instead make it a list of couch structures? Eller bare en status "Det finnes couch-struktur(er) av noe slag"


            //-------------
            //UserID
            //-------------
            userID = GetUserId(context);
            userName = GetUserName(context);
            patientContext.UserId = userID;
            patientContext.UserName = userName;
            //-------------
            //set patient
            //-------------
            Patient patient = context.Patient; //Legg til try catch?
   

            //If no patient
            if (patient == null)
            {
                sanityDesription = sanityDesription + "Ingen pasient lastet inn. ";
                sanityLevel = Constants.SanityLevelNoPatient; // 0;
            }
            else 
            {
                patientContext.ChosenPatient = patient;
                sanityLevel = Constants.SanityLevelPatientExist;
                sanityDesription = sanityDesription + "Pasient finnes. ";
            }

            //-------------
            //check Image
            //-------------
            Image image = context.Image;              //ExternalPlanSetup plan = context.ExternalPlanSetup;

            //if no Image
            if (image == null)
            {
                //sanityLevel = Constants.SanityLevelPatientExist; //1;
                sanityDesription = sanityDesription + "Ingen bilder lastet inn. ";
            }
            else
            {
                patientContext.ChosenImage = image;
                sanityLevel = Constants.SanityLevelImageExist;  //2;
                sanityDesription = sanityDesription + "Bilder finnes. ";
            }

            //-------------
            //set StructureSet
            //-------------
            StructureSet strSet = context.StructureSet;              //ExternalPlanSetup plan = context.ExternalPlanSetup;

            // if no str set
            if (strSet == null)
            {
                //sanityLevel = Constants.SanityLevelImageExist;  //2;
                sanityDesription = sanityDesription + "Ingen strukturset lastet inn. ";
            }
            else
            {
                patientContext.ChosenStructureSet = strSet;
                sanityLevel = Constants.SanityLevelStructureSetExist; //3;
                sanityDesription = sanityDesription + "Strukturset finnes. ";

                //Get Couch
                patientContext.CouchId = StructureExtension.GetCouchSurfaceID(strSet);

                //Get Body
                bodyID = StructureExtension.GetBodyId(strSet);
                patientContext.BodyId = bodyID;
            }

            if (bodyID != "")
            {
                patientContext.HasBody =true;
            }
            else { patientContext.HasBody = true; }

            //-------------
            //set Course
            //-------------
            Course course = context.Course;              //ExternalPlanSetup plan = context.ExternalPlanSetup;
            //if no course
            if (course == null)
            {
                sanityDesription = sanityDesription + "Ingen course lastet inn. ";
                //sanityLevel = Constants.SanityLevelStructureSetExist;  //3;
            }
            else // can a course exist without images? yes, must differentiate
            {
                //image, structureset and course exists
                if(sanityLevel >= Constants.SanityLevelPatientExist && sanityLevel >= Constants.SanityLevelStructureSetExist)
                {
                    patientContext.ChosenCourse = course;
                    sanityLevel = Constants.SanityLevelCourseExist; //Higher score 5;
                }
                //course exists, but not necessarily image and strucutre set
                else
                {
                    patientContext.ChosenCourse = course;
                    sanityLevel = Constants.SanityLevelCourseExistNotStructureSetOrImage; //Lower Score 4;
                }
                sanityDesription = sanityDesription + "Course finnes. ";

            }


            //-------------
            //set Plan //Also means reference Point must exist.  //Handle Proton plan? Different object
            //-------------
            ExternalPlanSetup plan = context.ExternalPlanSetup;
            
            //sjekker om plan eksisterer
            if (plan == null)
            {
                sanityDesription = sanityDesription + "Ingen plan lastet inn. ";
                //sanityLevel = Constants.SanityLevelCourseExist;//4;
            }
            else
            {
                patientContext.ChosenPlan = plan;
                sanityLevel = Constants.SanityLevelPlanExist;//5;
                sanityDesription = sanityDesription + "Plan finnes. ";
            }

            //-------------
            //Check fractionation exist
            //-------------
            //if plan exists
            if (plan != null)
            {
                double doseperFraksjon;
                int antallFraksjoner;

                // Check if fractionation valid
                try
                {
                    doseperFraksjon = plan.DosePerFraction.Dose;
                    antallFraksjoner = plan.NumberOfFractions.Value;
                    if (doseperFraksjon > 0 && antallFraksjoner > 0)
                    {
                        //Ok
                        sanityLevel = Constants.SanityLevelFractionationExist;//6;
                        sanityDesription = sanityDesription + "Fraksjonering finnes. ";
                    }
                    else
                    {
                        sanityDesription = sanityDesription + "Ingen fraksjonering lagt inn på plan. ";
                        sanityLevel = Constants.SanityLevelPlanExist;  //5;
                    }
                }
                catch 
                {
                    sanityDesription = sanityDesription + "Ingen fraksjonering lagt inn på plan. ";
                    sanityLevel = Constants.SanityLevelPlanExist; //5;
                }

            }

            //-------------
            //check calculated dose
            //-------------
            if (plan != null)
            {
                if (plan.IsDoseValid == false)
                {
                    sanityDesription = sanityDesription + "Ingen kalkulert dose på plan. ";
                    //Same level as set before 

                }
                else
                {
                    sanityLevel = Constants.SanityLevelCalculatedDoseExist; // 7
                    sanityDesription = sanityDesription + "Kalkulert dose på plan. ";

                }
            }

            //-------------
            //check if target volume exist
            //-------------
            if (plan != null)
            {
                Structure ptv = strSet.Structures.Where(o => o.Id == context.PlanSetup.TargetVolumeID).FirstOrDefault();
                if (ptv == null)
                {
                    sanityDesription = sanityDesription + "Ingen Target Structure. ";
                    //sanityLevel = Constants.SanityLevelCalculatedDoseExist; //7;
                    patientContext.TargetStructureExist = false;
                }
                else
                {
                    patientContext.TargetVolume = ptv;
                    if (ptv.Volume < double.Epsilon)
                    {
                        sanityDesription = sanityDesription + "Target Structure eksisterer, men er ikke tegnet. ";
                        //sanityLevel = Constants.SanityLevelTargetStructureExist; //8;
                        patientContext.TargetStructureSegmented = false;
                    }
                    else
                    { //ALl good
                        patientContext.TargetStructureSegmented = true; 
                        //sanityLevel = Constants.SanityLevelAllGood; //9999;
                        //sanityDesription = "All is good.";
                    }
                    patientContext.TargetStructureExist = true;
                }
            }


            // Splitting the string wit new lines
            // if it is too long
            
            string[] split = Regex.Split(sanityDesription, @"(?<=[.])"); //Split but keep the delimiter still in the sentence //Old code: //string[] split = sanityDesription.Split('.');
            string modifiedSanityDescription = "";

            int numberOfSentences = 0;
            foreach (var sentence in split)
            {
                numberOfSentences++;

                if (numberOfSentences > 3)
                {
                    modifiedSanityDescription = modifiedSanityDescription + Environment.NewLine + sentence.TrimStart();
                    numberOfSentences = 0;
                }
                else
                {
                    modifiedSanityDescription = modifiedSanityDescription + sentence;
                }
            }



            //-------------
            //set SanityLevel
            //-------------

            patientContext.SanityLevel = sanityLevel;
            patientContext.SanityDescription = modifiedSanityDescription;

            return patientContext;

        }

        //Not used - delete
        public static SanityCheck CheckPatientContextSanity(PatientContext patientContext, int sanityLevelRequired)
        {
            bool sanityState = true;
            int realSanityLevel = 0;
            string sanityDescription = patientContext.SanityDescription;
            string errorMessage = "";

            try
            {
                realSanityLevel = patientContext.SanityLevel;
            }
            catch { }



            //If required patient info not set
            if (realSanityLevel >= sanityLevelRequired)
            {
                sanityState = true;

            }
            else
            {
                //if (sanityLevelRequired == 0) { } //check something that does not require patient will work, but then

                if (sanityLevelRequired > 0 && realSanityLevel == 0) //patient does not exist
                {
                    errorMessage = sanityDescription + " Megateit! Skriptet kan bare kjoere når du har lastet inn en pasient! Dette gidder jeg ikke! Avslutter kode!";
                }
                else if (sanityLevelRequired > 1 && realSanityLevel <= 1) //Image does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 2 && realSanityLevel <= 2) //StructureSet does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 3 && realSanityLevel <= 3) //Course does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 4 && realSanityLevel <= 4) //Plan does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 5 && realSanityLevel <= 5) //Fractionation not set yet.
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 6 && realSanityLevel <= 6) //Calculated dose does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 7 && realSanityLevel <= 7) //Target Structure does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                else if (sanityLevelRequired > 8 && realSanityLevel <= 8) //Target Structure Drawing does not exist
                {
                    errorMessage = sanityDescription + " Fjerner sjekker som krever dette!";
                }
                sanityState = false;
            }
            SanityCheck sanityErrorMessage = new SanityCheck();
            sanityErrorMessage.ErrorMessageText = errorMessage;
            sanityErrorMessage.SanityState = sanityState;

            return sanityErrorMessage;
        }






    }
}
