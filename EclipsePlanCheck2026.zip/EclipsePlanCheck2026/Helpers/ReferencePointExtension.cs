﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

using System.Windows.Media.Media3D;
//Endre strukturer til transluce:
using System.Drawing;

//Slipper eksplisitt referere til Helpers
using EclipsePlanCheck.Helpers;

namespace EclipsePlanCheck.Helpers
{
    class ReferencePointExtension
    {

        public static bool ShouldReferencePointsBeShown(string controlType)
        {
            //string showControlTyperResult = "";
            bool showControlTyperResult = false;
            if (GeneralExtension.CheckStringsVsStrings(controlType, Constants.DoNotShowReferencePointsTaskTypes) != "")
            {
                //showControlTyperResult = Constants.False;
                showControlTyperResult = false;
                //refpkt_label.Visibility = Visibility.Hidden;
            }
            else
            {
                //showControlTyperResult = Constants.True;
                showControlTyperResult = true;
            }

            //return showControlTyperResult;
            return showControlTyperResult;
        }
        public static string GetPrimaryRef(ExternalPlanSetup plan)
        {
            string primref = plan.PrimaryReferencePoint.Id;
            return primref;
        }

        public static CheckPoint CheckPrimaryReferencePointAgainstStructureID(CheckPoint s, ExternalPlanSetup plan, Structure ptv, PatientContext patientContext)
        {
            string feilmelding = "";
            //Det eksisterer alltid primært refpunkt: sjekker om det finnes tilsvarende struktur. //Must check if target volume exist! Not true for 3d party plans from Ethos for instance
            string primref = ReferencePointExtension.GetPrimaryRef(plan);
            string ptvId = "";
            string ptvIdOtherMatch = "";
            if (patientContext.TargetStructureExist == true)
            {
                ptvId = ptv.Id;
            }
            else
            { ptvId = ""; } //"No Target Structure";

            string finalStatusResult = "";




            //set finalStatusResult
            if (primref == ptvId)
            {   //Sjekker mot templatet i så fall:

                //Sjekker mot templatverdi ogsaa
                string statusResultTemplat = CheckPointExtension.CheckResultVsTemplate(primref, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
                if (statusResultTemplat == s.CheckTrafficLight )
                {   //Ikke i henhold til templatet.
                    feilmelding = feilmelding + "Target Structure = primær ref.pkt., men ikke i henhold til templatet. ";
                    s.CheckDebug = s.CheckDebug + Environment.NewLine + feilmelding;
                    //override to Info:
                    statusResultTemplat = Constants.Info;
                }
                else if (statusResultTemplat == Constants.Unknown)
                { //Ingen templat
                    statusResultTemplat = Constants.Ok;
                }


                finalStatusResult = statusResultTemplat; //statusResult; //strResult = Constants.Ok;
            }
            else
            {
                //Handle if there is another structure matching that is not primary target structure.
                if(patientContext.ChosenStructureSet.Structures.FirstOrDefault(structure => structure.Id == primref) != null)
                {
                    ptvIdOtherMatch = patientContext.ChosenStructureSet.Structures.FirstOrDefault(structure => structure.Id == primref).Id;
                }




                if (feilmelding != "") { feilmelding = feilmelding + Environment.NewLine; }
                feilmelding = feilmelding + "Planens prim. refpunkt og Target Structure samsvarer ikke. " + primref + " =! " + ptvId + ".";
                if (ptvIdOtherMatch != "") //Catch the case where another structure than the Target Structure is matching with primary referencepoint.
                {
                    feilmelding = feilmelding + Environment.NewLine + " OK da det finnes en annen matchende struktur: " + ptvIdOtherMatch + " (" + ptvIdOtherMatch + " må da ha Visir-koden på seg!)"  ;
                    finalStatusResult = Constants.Info;
                }
                else
                {
                    finalStatusResult = s.CheckTrafficLight;
                }
                s.CheckDebug = s.CheckDebug + Environment.NewLine + feilmelding;
            }

            //Skriver verdier
            string otherMatchHeader = "";
            string otherMatchResult = "";
            if (ptvIdOtherMatch != "")
            {
                otherMatchHeader = Constants.StringSeparator + "Annen str.-match:";
                otherMatchResult = Constants.StringSeparator + ptvIdOtherMatch;
            }
            s.CheckResultValue = GeneralExtension.FormatString(-17, -17, "Prim.ref.pkt:" + Constants.StringSeparator + "Target Structure:" + otherMatchHeader);
            if (ptvId == "") { ptvId = "-"; }
            s.CheckResultValue = s.CheckResultValue + Environment.NewLine + GeneralExtension.FormatString(-17, -17, primref + Constants.StringSeparator + ptvId + otherMatchResult);

            //CSV result
            s.CheckResultValueCSV = primref + Constants.StringSeparator + ptvId + otherMatchResult; //+ otherMatchResult;

            //s.CheckResultValue = (ptvId != "") ? primref + " / " + ptvId : primref; //primref + " / " + ptvId; // newLine mellom dem?
            s.CheckDebug = "Target Structure: " + ptvId + Environment.NewLine + "Refpkt: " + primref + Environment.NewLine + "Annen str.-match: " + ptvIdOtherMatch;


            s.CheckStatus = finalStatusResult; //Hjelpefunksjoner.SjekkRefVsStructure(plan, s.SjekkResultatVerdi); //// Unodvendig - sjekker mot "ptv" istedet
            s.CheckComment = s.CheckComment + feilmelding;
            return s;
        }

        public static CheckPoint CheckSecondaryReferencePointAgainstStructureID(CheckPoint s, ExternalPlanSetup plan, Structure ptv, StructureSet strset, PatientContext patientContext)
        {

            //string primary = Hjelpefunksjoner.GetPrimaryRef(plan); kan bruke "ptv" 
            //strukturliste kan vaere null, forhindre krasj.
            string strukturliste_str = (s.CheckTemplateValue != null) ? s.CheckTemplateValue : "";
            string ptvId = "";

            // --- Alternativ 1 ----
            //Start med strukturliste -> sjekk refpunkt 
            if (strukturliste_str != null && strukturliste_str != "")
            {

                //Fjern primær struktur da det sjekkes i eget pkt
                if (patientContext.TargetStructureExist == true)  //Kan liksomgodt bruke ptv != null. Hindre krasj.
                {
                    ptvId = ptv.Id;
                }
                else { }
                    

                strukturliste_str = ReferencePointExtension.RemovePrimaryStructureFromString(strukturliste_str, ptvId);
                //Fjerner alle strukturer som ikke er tegnet
                strukturliste_str = ReferencePointExtension.RemoveUnusedStructuresFromString(strukturliste_str, strset);
                //Rensker opp i stringen   //MessageBox.Show(strukturliste_str);
                strukturliste_str = strukturliste_str.Replace(Constants.StringSeparator + Constants.StringSeparator, Constants.StringSeparator); //Fjerner dobble ;  
                char[] separators = new char[] { Constants.CharSeparator };

                if (strukturliste_str != "") //Length >= 1
                {
                    string substr1 = strukturliste_str.Substring(0, 1);
                    if (substr1 == Constants.StringSeparator) { strukturliste_str = strukturliste_str.Substring(1); } // Fjerner ; hvis første char
                }
                s.CheckDebug = s.CheckDebug + "Rensket strukturliste: " + strukturliste_str;
                //Genererer en liste av strukturer
                List<string> strukturliste = strukturliste_str.Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();

                CheckPoint s_temp1 = ReferencePointExtension.SjekkStrukturListeVsStructures(plan, strukturliste, s, s.CheckTrafficLight);

                //Hvis ingen templater eksisterer, status = ok
                s.CheckComment = s_temp1.CheckComment;

                if (s_temp1.CheckStatus == Constants.Unknown)
                {
                    s.CheckStatus = Constants.Ok;
                    s_temp1.CheckDebug = s_temp1.CheckDebug + Environment.NewLine + "Status for sjekk mot templat: " + Constants.Unknown + ". Finnes ikke noe i templat.";
                }
                else { s.CheckStatus = s_temp1.CheckStatus; }

                s.CheckResultValue = s_temp1.CheckResultValue;
                s.CheckResultValueCSV = s_temp1.CheckResultValueCSV;
                s.CheckDebug = s_temp1.CheckDebug;


            }
            // --- Alternativ 2 ----
            //start med refpunkt -> sjekk etter strukturer
            else
            {
                //Fjærne primær
                CheckPoint s_temp2 = ReferencePointExtension.SjekkRefPktListeVsStructures(plan, s);
                s.CheckComment = s_temp2.CheckComment;
                s.CheckStatus = s_temp2.CheckStatus;
                s.CheckDebug = s_temp2.CheckDebug;
                s.CheckResultValue = s_temp2.CheckResultValue;
                s.CheckResultValueCSV = s_temp2.CheckResultValueCSV;
                //s.SjekkResultatVerdi = s_temp2.SjekkResultatVerdi;

            }

            if (s.CheckResultValue == Constants.Calculating)
            {
                s.CheckResultValue = ""; //Finnished calculating
            }

            if (s.CheckResultValue == "" || s.CheckResultValue == null)
            {
                s.CheckDiscardedAtRuntime = Constants.True; //Remove checkpoint as it is not relevant.
            }
            return s;
        }

        public static string CompareReferencePointIDToStructureID(ExternalPlanSetup plan, string refpkt)
        {
            string statusResult = Constants.Error;
            if (plan.StructureSet.Structures.Any(x => x.Id == refpkt))
            {
                statusResult = Constants.Ok;
            }

            return statusResult;
        }


        public static string RemovePrimaryStructureFromString(string _strukturliste_str = "", string _primary = "")
        {
            // Finner hovedvolum og fjerner fra string da denne ikke skal sjekkes på nytt
            if (_strukturliste_str.Contains(_primary))
            {
                // _strukturliste_str = _strukturliste_str.Replace(_primary, "");
                //Fjerner første occurance av primary rfp.pkt-navn (=prim strukturnavn) fra string   //strukturliste_str.Replace(primary, "");
                int index = _strukturliste_str.IndexOf(_primary);
                _strukturliste_str = (index < 0)
               ? _strukturliste_str
               : _strukturliste_str.Remove(index, _primary.Length);
            }

            return _strukturliste_str;
        }
        public static string RemoveUnusedStructuresFromString(string _strukturliste_str, StructureSet _strset)
        {
            //Genererer en liste av strukturer separert med Constants.StringSeparator
            char[] separators = new char[] { Constants.CharSeparator };
            List<string> _strukturliste = _strukturliste_str.Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();

            //Sjekker listen av strukturer. Fjerner alle strukturer som ikke er tegnet
            foreach (string struktur in _strukturliste)
            {
                //Sjekker om strukturen eksisterer i StructureSet:
                Structure _st = _strset.Structures.FirstOrDefault(o => o.Id == struktur);  //vurdere (o => o.Id.Contains("CouchSurface")

                //Hvis strukturen ikke eksisterer - fjerner fra listen
                if (_st == null)
                {

                    //Fjerner første occurance av struktur fra string  
                    //_strukturliste_str = _strukturliste_str.Replace(struktur, "");
                    int index = _strukturliste_str.IndexOf(struktur, StringComparison.Ordinal);  //_strukturliste_str.IndexOf(struktur);
                    _strukturliste_str = (index < 0)
                        ? _strukturliste_str
                        : _strukturliste_str.Remove(index, struktur.Length);

                }
                //Hvis strukturen eksisterer
                else
                {
                    //Hvis strukturen eksisterer, men ikke er tegnet - også fjern fra listen:
                    if (_st.Volume < double.Epsilon)
                    {
                        //Fjerner første occurance av struktur fra string  
                        //_strukturliste_str = _strukturliste_str.Replace(struktur, "");
                        int index = _strukturliste_str.IndexOf(struktur, StringComparison.Ordinal);
                        _strukturliste_str = (index < 0)
                            ? _strukturliste_str
                            : _strukturliste_str.Remove(index, struktur.Length);

                    }
                }

            }
            //returnerer listestring:
            return _strukturliste_str;
        }


        public static CheckPoint SjekkRefPktListeVsStructures(ExternalPlanSetup plan, CheckPoint _s)
        {
            _s.CheckResultValue = ""; //clear result.
            //_s.CheckResultValue.Replace(Constants.Calculating, string.Empty); //Clear Constants.Calculating if it exists. Did not work.
            //


            string _result = Constants.Ok;
            string feilmelding = "";
            string primrefId = plan.PrimaryReferencePoint.Id;
            List<RefPoint> rfpListe = new List<RefPoint>();
            rfpListe = ReferencePointExtension.GetRefPktListe(plan);
            rfpListe = ReferencePointExtension.SjekkRefPktListe(rfpListe);
            _s.CheckDebug = _s.CheckDebug + "Denne sjekken itererer gjennom alle referansepunkt og kontrollerer om det finnes tilsvarende struktur.";
            foreach (RefPoint refpkt in rfpListe)
            {
                //Kun sekundære referansepunkt, skipper prim
                if (refpkt.RefPointID != primrefId)
                {
                    string _tempresult = "";

                    //structureID modify for output
                    string structureIdEdited = refpkt.StructureID;
                    if (refpkt.StructureID == "") { structureIdEdited = "-"; }

                    //Match found - set status
                    if (refpkt.RefPointID == refpkt.StructureID)
                    {
                        _s.CheckDebug = _s.CheckDebug + Environment.NewLine + "Referansepunkt: " + refpkt.RefPointID + "  // " + "Strukturnavn: " + refpkt.StructureID;
                        _tempresult = Constants.Ok;
                        //new formatting
                        //if (_s.CheckResultValue != "")
                        //{ _s.CheckResultValue = _s.CheckResultValue + Environment.NewLine; }
                        //_s.CheckResultValue = _s.CheckResultValue + GeneralExtension.FormatString(-17, -17, refpkt.RefPointID + Constants.StringSeparator + structureIdEdited);

                        //Old formatting
                        //_s.CheckResultValue = _s.CheckResultValue + refpkt.RefPointID; 
                    }
                    else
                    //No match found - set status
                    {
                        _tempresult = Constants.Error; 
                    }
                    //Print result
                    if (_s.CheckResultValue != "")
                    { _s.CheckResultValue = _s.CheckResultValue + Environment.NewLine; } //Add new line if necessary
                    _s.CheckResultValue = _s.CheckResultValue + GeneralExtension.FormatString(-17, -17, refpkt.RefPointID + Constants.StringSeparator + structureIdEdited);

                    //CSV
                    //Print result
                    if (_s.CheckResultValueCSV != "")
                    { _s.CheckResultValueCSV = _s.CheckResultValueCSV + Constants.CharSeparator; } //Add new line if necessary
                    _s.CheckResultValueCSV = _s.CheckResultValueCSV +refpkt.RefPointID + ":" + structureIdEdited;


                    if (_result == Constants.Ok && _tempresult == Constants.Error)
                    {
                        _result = Constants.Error;
                        if (feilmelding != "") { feilmelding = feilmelding + ". "; }
                        feilmelding = feilmelding + "Feil for: " + refpkt.RefPointID + ". Struktur ikke samme navn som referansepunkt."; //+ " / " + refpkt.Volumnavn;
                        _s.CheckDebug = _s.CheckDebug + Environment.NewLine + "Referansepunkt: " + refpkt + "  // " + "Strukturnavn: " + refpkt.StructureID;

                    }
                }

            }
            
            if (_s.CheckResultValue != "")
            {
                //Add headers:
                _s.CheckResultValue = GeneralExtension.FormatString(-17, -17, "Sek.ref.pkt:" + Constants.StringSeparator + "Target Structure:") + Environment.NewLine + _s.CheckResultValue;
            }
            _s.CheckStatus = _result;
            _s.CheckComment = feilmelding;
            return _s;
        }


        public static CheckPoint SjekkStrukturListeVsStructures(ExternalPlanSetup plan, List<string> structureList, CheckPoint _s, string trafikklys)
        {
            string _result = Constants.Ok;
            string feilmelding = "";
            string _tempresult = "";
            string _tempUthenting = "";
            string _Uthenting = "";
            int i = 0;
            string resultCSV = "";


            //lager liste av refpunkt
            List<RefPoint> rfpListe = new List<RefPoint>();
            rfpListe = ReferencePointExtension.GetRefPktListe(plan);
            rfpListe = ReferencePointExtension.SjekkRefPktListe(rfpListe);

            //Header: //ONLY ADD HEADER IF THERE ARE ANY ACTUAL REFPOINTS
            //Old formatting:
            _Uthenting = GeneralExtension.GenerateTableLine(6, 4, "Sek.ref.pkt:" + Constants.StringSeparator + "Strukturnavn:");
            //Changed formatting:
            _Uthenting = GeneralExtension.FormatString(-17, -17, "Sek.ref.pkt:" + Constants.StringSeparator + "Target Structure:");


            //Sjekker alle strukturer i liste av strukturer
            foreach (string structure in structureList)
            {

                //Sjekker om det eksisterer et referanspunkt for strukturen, blir NULL hvis det ikke finnes.
                RefPoint temp_rf = rfpListe.Where(o => o.RefPointID == structure).FirstOrDefault();
                //MessageBox.Show("st:" + st);
                //Setter resultat av sjekken paa enkel struktur
                if (structure != "PTVdosering") //Exeption for "PTVdosering"
                {
                    if (temp_rf != null)
                    {
                        i = i + 1;
                        //MessageBox.Show("rf:" + temp_rf.Refpktnavn);
                        _tempresult = Constants.Ok;
                        //Sender til debug:
                        if (_s.CheckDebug != "") { _s.CheckDebug = _s.CheckDebug + Environment.NewLine; }
                        _s.CheckDebug = _s.CheckDebug + "Strukturnavn (" + i + "): " + structure + Environment.NewLine + "Refpkt (" + i + "): " + temp_rf.RefPointID;
                        //skriver alle struktur-refpkt kombinasjoner funnet til resultat:
                        //if (_tempUthenting != "")
                        //{

                        //old Formatting:
                        //_tempUthenting = _tempUthenting + Environment.NewLine;
                        //_tempUthenting = _tempUthenting + GeneralExtension.GenerateTableLine(5, 4, temp_rf.RefPointID + Constants.StringSeparator + structure);

                        //new formatting:
                        _tempUthenting = _tempUthenting + Environment.NewLine + GeneralExtension.FormatString(-17, -17, temp_rf.RefPointID + Constants.StringSeparator + structure); //if (ptvId == "") { ptvId = "-"; }

                        //CSV:
                        if (resultCSV != "" && resultCSV != null) { resultCSV = resultCSV + Constants.StringSeparator; }
                        resultCSV = resultCSV + temp_rf.RefPointID + ":" + structure;

                        //Oldest formatting:
                        //_tempUthenting = _tempUthenting + " / " + structure; 
                        //}
                        //else
                        //{
                        //    _tempUthenting = structure;
                        //}
                    }
                    else
                    {
                        _tempresult = Constants.Error;
                    }
                }

                //Setter totalresultat av sjekken 
                if (_result == Constants.Ok && _tempresult == Constants.Error)
                {
                    //Advarsel om struktur som ikke har referansepunkt (om ikke union struktur eksisterer).
                    //--------------------
                    var match = plan.StructureSet.Structures
                    .FirstOrDefault(stringToCheck => stringToCheck.Id.Contains(Constants.UnionPTV));
                    if (match == null) // !StrListe.Contains("u_")) !_tempUthenting.Contains("PTVu_")
                    {
                        _result = trafikklys;
                        if (feilmelding != "") { feilmelding = feilmelding + ". "; }
                        feilmelding = feilmelding + "Advarsel for: " + structure + ". Finner strukturen, men den har ingen referansepunkt."; //+ " / " + refpkt.Volumnavn;
                        if (_s.CheckDebug != "") { _s.CheckDebug = _s.CheckDebug + Environment.NewLine; }
                        _s.CheckDebug = _s.CheckDebug + "Referansepunkt: IKKE FUNNET" + Environment.NewLine + "Strukturnavn: " + structure;
                        //if (_tempUthenting != "")
                        //{ _tempUthenting = _tempUthenting + " / " + structure; }
                        //else
                        //{
                        //    _tempUthenting = structure;
                        //}
                        _tempUthenting = _tempUthenting + Environment.NewLine;
                        _tempUthenting = _tempUthenting + GeneralExtension.GenerateTableLine(5, 4, "-" + Constants.StringSeparator + structure);

                        //CSV:
                        if (resultCSV != "" && resultCSV != null) { resultCSV = resultCSV + Constants.StringSeparator; }
                        resultCSV = resultCSV + "-" + ":" + structure;
                    }
                    else  //Unntak for union-strukturer:
                    {
                        _result = Constants.Ok;
                        if (_s.CheckDebug != "") { _s.CheckDebug = _s.CheckDebug + Environment.NewLine; }
                        _s.CheckDebug = _s.CheckDebug + "Referansepunkt: IKKE FUNNET" + Environment.NewLine + "Strukturnavn: " + structure + Environment.NewLine + "Ikke advarsel pga. unntak ved unionstrukturer.";
                    }
                    //--------------------

                    //+ " / " + refpkt.Volumnavn;
                }
                if (_result == Constants.Ok && _tempresult == Constants.Ok)
                {
                    _result = Constants.Ok;
                }
            }
            _s.CheckStatus = _result;
            _s.CheckComment = _s.CheckComment + feilmelding;
            _s.CheckResultValueCSV = resultCSV;
            if (_tempUthenting != "") //ONLY ADD HEADER IF THERE ARE ANY ACTUAL REFPOINTS
            {
                _s.CheckResultValue = _Uthenting + _tempUthenting;
            }
            else
            {
                _s.CheckResultValue = ""; //Clear "Calculation" symbol
            }
            //else { _s.CheckResultValue = ""; }



            return _s;
        }

        public static List<RefPoint> SjekkRefPktListe(List<RefPoint> rfplist)
        {
            //Om vi onsker aa bruke bilder istedenfor farge:
            //BitmapImage okok = Hjelpefunksjoner.BitmapToBitmapImage(BasicPlanCheck.Properties.Resources.check);
            //BitmapImage neinei = Hjelpefunksjoner.BitmapToBitmapImage(BasicPlanCheck.Properties.Resources.error);
            //BitmapImage huh = Hjelpefunksjoner.BitmapToBitmapImage(BasicPlanCheck.Properties.Resources.warning);

            foreach (var p in rfplist)
            {
                p.Explanation = p.Explanation + System.Environment.NewLine + System.Environment.NewLine + "|---- Advarsler: ----| ";

                //p.ColorSet = "Green";
                bool _IngenVerdi = false;
                double _sessionDiff; // Convert.ToDouble(p.SessionDiff);
                double _totalDiff; //= Convert.ToDouble(p.TotalDiff);
                double _dagsToleranse;
                double _sessionToleranse;

                //Sjekker om det er lagt inn gyldige verdier
                //----------------------------------------------------
                if (Double.TryParse(p.SessionDoseDifference, out _sessionDiff))
                {
                    // success 
                }
                else
                {
                    _IngenVerdi = true;

                }

                if (Double.TryParse(p.DailyDoseTolerance, out _dagsToleranse))
                {
                    // success 
                }
                else
                {
                    _IngenVerdi = true;
                    if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                    p.Explanation = p.Explanation + " -" + p.RefPointID + " har ikke daglig toleransegrense.";
                }
                if (Double.TryParse(p.SessionDoseTolerance, out _sessionToleranse))
                {
                    // success 
                }
                else
                {
                    _IngenVerdi = true;
                    if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                    p.Explanation = p.Explanation + " -" + p.RefPointID + " har ikke session toleransegrense.";
                }
                //Sjekker om det er lagt inn gyldige verdier
                if (Double.TryParse(p.TotalDoseDifference, out _totalDiff))
                {
                    // success
                }
                else
                {
                    _IngenVerdi = true;
                    if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                    p.Explanation = p.Explanation + " -" + "For " + p.RefPointID + " var det ikke mulig å regne ut differanse mellom totaldose gitt og toleranse.";
                }
                //----------------------------------------------------

                //Setter fargen
                //----------------------------------------------------
                if (_IngenVerdi == true)
                {
                    p.ColorSet = "Red";
                    p.CheckResult = "Feil";
                }
                else
                {
                    //liten feil i sessdiff i rett retning = gul, kan vaere avrunding
                    if ((_sessionDiff >= -0.05 && _sessionDiff < 0)) //||  (_sessionDiff > 0 && _sessionDiff <= 0.1))
                    {
                        p.ColorSet = "Yellow";
                        //p.Resultat = huh;
                        if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                        p.Explanation = p.Explanation + " -" + p.RefPointID + " har et lite avvik mellom sesjonsdose og toleranse. Toleransen litt høyere enn dosen.";
                        p.CheckResult = Constants.Warning;
                    }
                    //stor feil.
                    else if ((_sessionDiff > 0 || _sessionDiff < -0.05)) //||  (_sessionDiff > 0 && _sessionDiff <= 0.1))  //_sessionDiff > 0.05
                    {
                        p.ColorSet = "Yellow";
                        if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                        p.Explanation = p.Explanation + " -" + p.RefPointID + " har et avvik mellom sesjonsdose og toleranse.";
                        //p.Resultat = huh;
                        p.CheckResult = Constants.Warning;
                    }


                    //liten feil i totaldiff i rett retning = gul, kan vaere avrunding
                    if ((_totalDiff >= -0.05 && _totalDiff < 0)) //||  (_sessionDiff > 0 && _sessionDiff <= 0.1))
                    {
                        if (!(p.ColorSet == "Red"))
                        {
                            p.ColorSet = "Yellow";
                            p.CheckResult = Constants.Warning;
                        }
                        if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                        p.Explanation = p.Explanation + " -" + p.RefPointID + " har et lite avvik mellom totaldose og toleranse. Toleransen er høyere enn dosen. ";
                        //p.Resultat = huh;

                    }
                    //stor feil. Bruker kun Red hvis det ikke er lagt inn toleranser. Gult for alle andre.
                    else if (_totalDiff > 0 || _totalDiff < -0.05)  // _totalDiff > 0.05
                    {
                        p.ColorSet = "Yellow";
                        if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                        p.Explanation = p.Explanation + " -" + p.RefPointID + " har et avvik mellom totaldose og toleranse.";
                        p.CheckResult = Constants.Warning;
                        // p.Resultat = huh;
                    }
                    //dagstoleransen < sesjonstoleransen er feil.

                    //Sjekker dagstoleransen:
                    if (_dagsToleranse < _sessionToleranse)
                    {
                        p.ColorSet = "Yellow";
                        if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                        p.Explanation = p.Explanation + " -" + p.RefPointID + " har dagstoleranse lavere enn sesjonstoleranse.";
                        // p.Resultat = huh;
                        p.CheckResult = Constants.Warning;
                    }
                    //TOleransen er god, innenfor en litt slingring
                    if ((_dagsToleranse - _sessionToleranse > -0.01) && (_dagsToleranse - _sessionToleranse <= 0))
                    {
                        if (!(p.ColorSet == "Red") && !(p.ColorSet == "Yellow"))
                        {
                            p.ColorSet = "Green";
                            p.CheckResult = Constants.Ok;
                            //p.Forklaring = p.Forklaring + " - For " + p.Refpktnavn + " er toleransen " + -_sessionDiff + "høyere enn dosen som gis.";
                        }


                    }
                    //to fraksjoner om dagen = farger turkis, med litt slingring i rett retning.
                    else if ((_dagsToleranse - (2 * _sessionToleranse) < 0.1) && (_dagsToleranse - (2 * _sessionToleranse) >= 0))
                    {
                        if (!(p.ColorSet == "Red") && !(p.ColorSet == "Yellow"))
                        {
                            p.ColorSet = "Turquoise";
                            p.CheckResult = "Ok";
                            if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                            p.Explanation = p.Explanation + " -" + "Refpnkt " + p.RefPointID + " lagt opp til to fraksjoner om dagen, (dagstoleranse er dobbelt av sessiontoleranse).";
                        }


                    }
                    else
                    {   //dagstoleransen er ikke lik sesjonstoleransen og heller ikke dobbelt av den
                        if (!(p.ColorSet == "Red"))
                        {
                            p.ColorSet = "Yellow";
                            p.CheckResult = Constants.Warning;
                        }
                        // p.Resultat = huh;

                    }

                    //refpunkt har ikke samme navn som struktur (dvs ingen strukturmatch)
                    if (p.RefPointID != p.StructureID)
                    {
                        p.ColorSet = "Yellow";
                        p.CheckResult = Constants.Warning;
                        if (p.Explanation != "") { p.Explanation = p.Explanation + "." + System.Environment.NewLine; }
                        p.Explanation = p.Explanation + " -" + "Refpnkt " + p.RefPointID + " har navn som ikke matcher med noen strukturnavn.";
                    }

                    //Hvis ikke rod eller gul:
                    if (!(p.ColorSet == "Red") && !(p.ColorSet == "Yellow"))
                    {
                        p.ColorSet = "Green";
                        p.CheckResult = "Ok";
                        //p.Resultat = okok;
                    }
                }

                //----------------------------------------------------
                p.Explanation = p.Explanation + Environment.NewLine + Environment.NewLine + Environment.NewLine; //Gir litt rom i tool-tips på slutten.
            }


            return rfplist;
        }


        //if (boostplanExisterer == true)
        //{
        //    foreach (var felt in boostplan.Beams)
        //    {
        //            FieldReferencePoint r = felt.FieldReferencePoints.FirstOrDefault(x => x.Id == felles_refpkt_id);
        //    } //Avslutter iterasjon over felt
        //}


        public static List<RefPoint> SummerDoserTilRefpktFraPlan(ExternalPlanSetup plan, List<RefPoint> _rfliste, string felles_sekv_refpkt = "")
        {
            //kanskje inkludere en tredje dimensjon som er feltnavnet.
            string dose_temp = "";
            int felt_tall = 0;
            int global_ant_ref = 0;
            int AntallFraksjoner =  0;
            try { AntallFraksjoner = plan.NumberOfFractions.Value; }
            catch { }

            string primRef = GetPrimaryRef(plan); //finner primær refpkt
            //-----------------------------
            //Definerer stuff jeg trenger:
            //-----------------------------  //tidligere 12, nå 38 felt maks
            string[,,] varFeltRefpktDose = new string[38, 9, 5]
            {
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
                { { "", "", "" , "", "" }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "", ""  }, { "", "", "", "" , "" }, { "", "", "", "", ""  } },
             };

            //-----------------------------------------------------------------------------------
            //Sjekker DOSEBIDRAG fra FELTENE til hvert refpkt. kun for behandlingsfelt - fyller opp en array.
            //-----------------------------------------------------------------------------------

            char[] separators = new char[] { Constants.CharSeparator };
            //Splitter liste av referansepunkt som er felles og itererer over dem
            List<string> _RefListeStr = felles_sekv_refpkt.Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();

            foreach (var felt in plan.Beams)
            {
                var Toleransetabell = felt.ToleranceTableLabel;

                if (felt.IsSetupField == false)
                {
                    //variabler
                    felt_tall = felt_tall + 1;
                    int antall_ref = 0; //antall refpkt
                    int ant_ref_m_dose = 0;
                    int ant_ref_u_dose = 0;

                    //Hvis vi er på en sekvensiell plan
                    if (felles_sekv_refpkt != "" && plan.IsDoseValid) //Added IsDoseValid 07.05.2025
                    {
                        foreach (FieldReferencePoint r in felt.FieldReferencePoints)
                        {
                            string temp_rf = _RefListeStr.FirstOrDefault(o => o == r.ReferencePoint.Id);
                            if (temp_rf != null)
                            {
                                dose_temp = r.FieldDose.ToString();
                                if (dose_temp.Contains("N/A"))
                                {
                                    ant_ref_u_dose = ant_ref_u_dose + 1;
                                    dose_temp = "0";
                                }
                                else
                                {
                                    dose_temp = r.FieldDose.ToString().Replace("Gy", "").Trim();

                                    ant_ref_m_dose = ant_ref_m_dose + 1;
                                }
                                antall_ref = antall_ref + 1;   //kanskje vi bare må telle opp antall FieldReferencePoints og sammenligne med antall RefPkt med toleransegrenser?
                                //MessageBox.Show("Antallref:" + antall_ref + "." + " felt_tall:" + felt_tall + "." + " dose_temp:" + dose_temp + "." + " global_ant_ref:" + global_ant_ref + ".");//global_ant_ref
                                if (antall_ref > global_ant_ref) { global_ant_ref = antall_ref; } //setter ant_ref etter feltet som har maks refpkt.

                                varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 0] = r.ReferencePoint.Id.ToString(); //0 = referansepunktnavnet
                                varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 1] = dose_temp;  //1 = dosebidraget
                                varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 2] = r.ReferencePoint.TotalDoseLimit.ToString().Replace("Gy", "").Trim(); //2 = totaltoleransen
                                varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 3] = r.ReferencePoint.SessionDoseLimit.ToString().Replace("Gy", "").Trim();
                                varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 4] = r.ReferencePoint.DailyDoseLimit.ToString().Replace("Gy", "").Trim();
                            }
                        }
                    }
                    else //standard ikke-sekvesiell plan - henter fra alle referansepunkt
                    {
                        foreach (FieldReferencePoint r in felt.FieldReferencePoints)
                        {

                            dose_temp = r.FieldDose.ToString();
                            if (dose_temp.Contains("N/A"))
                            {
                                ant_ref_u_dose = ant_ref_u_dose + 1;
                                dose_temp = "0";
                            }
                            else
                            {
                                dose_temp = r.FieldDose.ToString().Replace("Gy", "").Trim();

                                ant_ref_m_dose = ant_ref_m_dose + 1;
                            }
                            antall_ref = antall_ref + 1;   //kanskje vi bare må telle opp antall FieldReferencePoints og sammenligne med antall RefPkt med toleransegrenser?
                            //MessageBox.Show("Antallref:" + antall_ref + "." + " felt_tall:" + felt_tall + "." + " dose_temp:" + dose_temp + "." + " global_ant_ref:" + global_ant_ref + ".");//global_ant_ref
                            if (antall_ref > global_ant_ref) { global_ant_ref = antall_ref; } //setter ant_ref etter feltet som har maks refpkt.

                            varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 0] = r.ReferencePoint.Id.ToString(); //0 = referansepunktnavnet
                            varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 1] = dose_temp;  //1 = dosebidraget
                            varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 2] = r.ReferencePoint.TotalDoseLimit.ToString().Replace("Gy", "").Trim(); //2 = totaltoleransen
                            varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 3] = r.ReferencePoint.SessionDoseLimit.ToString().Replace("Gy", "").Trim();
                            varFeltRefpktDose[felt_tall - 1, antall_ref - 1, 4] = r.ReferencePoint.DailyDoseLimit.ToString().Replace("Gy", "").Trim();

                        }
                    }



                    //Skal supplere med sekvensielle planer  FieldReferencePoint r = felt.FieldReferencePoints.FirstOrDefault(x => x.Id == felles_refpkt_id);


                } //--------------------------Avslutter Iterasjon over behandlignsfelt -------------------------------------------------------
            } //Avslutter iterasjon over felt

            //------------------------- Summer opp dosene for hvert felt i ny array --------------
            object[,,] varfeltrefpktdose_int = new object[1, global_ant_ref, 5]; //object fordi kan være varierende hva som kommer ut
            int gjeldende_felt = 0;  //brukes til navigering i arrays

            //itererer over refpkt
            for (int i = 0; i < global_ant_ref; i++)   //varfeltrefpktdose.getlength(1)
            {
                //itererer over felt
                for (int k = 0; k < felt_tall; k++)
                {
                    gjeldende_felt = k + 1;
                    decimal value;
                    //sjekker om vi har en numerisk verdi.

                    if (Decimal.TryParse(varFeltRefpktDose[k, i, 1], out value))
                    {
                        //summerer opp verdiene fra alle felt hvis numerisk.
                        varfeltrefpktdose_int[0, i, 1] = Convert.ToDouble(varfeltrefpktdose_int[0, i, 1], CultureInfo.InvariantCulture) + Convert.ToDouble(varFeltRefpktDose[k, i, 1], CultureInfo.InvariantCulture);
                    }
                    else { }
                }

                Double sesjonsdosen = 0;
                try { sesjonsdosen = Convert.ToDouble(varfeltrefpktdose_int[0, i, 1], CultureInfo.InvariantCulture); }
                catch { }
                //Double sesjonsdosen = Convert.ToDouble(varfeltrefpktdose_int[0, i, 1], CultureInfo.InvariantCulture);
                //finner totaldosen til refpkt fra alle felt over alle fraksjonene
                varfeltrefpktdose_int[0, i, 1] = sesjonsdosen * AntallFraksjoner; //gitt tot dose  //vurder å rund av til 2 desimaler, da Eclipse gjør det! Formater så det har 3 desimaler, likt eclipse
                varfeltrefpktdose_int[0, i, 0] = varFeltRefpktDose[0, i, 0]; //refpkt navnet
                varfeltrefpktdose_int[0, i, 2] = varFeltRefpktDose[0, i, 2]; //tot dose
                varfeltrefpktdose_int[0, i, 3] = varFeltRefpktDose[0, i, 3]; //ses dose
                varfeltrefpktdose_int[0, i, 4] = varFeltRefpktDose[0, i, 4]; //dag dose

                bool _gyldigDouble = true; //brukes til aa sjekke om en string kan omgjores til double.

                // resultatene fra om de kan gjores om til double
                bool _gyldigSessionInput = true;
                bool _gyldigDagsInput = true;
                bool _gyldigTotalInput = true;
                bool _gyldigPlanDoseInput = true;

                double diff;
                double result_test = 0;

                //Forbedring: trenger ikke ta med toleranser i tabellen

                // refpunktnavn
                //-------------------------
                string refpkt_tot = varfeltrefpktdose_int[0, i, 0].ToString();  //refpkt navnet
                //-------------------------
                // Validering av input 
                //---------------------------------------------------------------------------------------------

                //-------------------------------
                //--Pga Eclipse er teit og ikke gir meg sesjonsdosen til primear referansepunkt med tilstrekkelig antall desimaler (som kan lede til advarsel når det sjekkes mot toleranser), 
                //--overrider vi med faktisk totaldose og sesjonsdose fra fraksjoneringen til planen:
                //-------------------------------
                if (refpkt_tot == primRef)
                {//Primært ref override
                    try { sesjonsdosen = plan.DosePerFraction.Dose; }
                    catch{ sesjonsdosen = 0; }
                    
                }
                //Korrigerer sesjonsdosen hvis plansummer
                //Ta hensyn til total dose gitt fra før - bruker maks dose som gis til referansepunktet
                RefPoint result = _rfliste.FirstOrDefault(x => x.RefPointID == varFeltRefpktDose[0, i, 0]);
                if (result != null)
                {
                    if (result.SessionDose != null)
                    {
                        _gyldigDouble = double.TryParse(result.SessionDose.ToString(),
                            NumberStyles.Any, CultureInfo.InvariantCulture,
                            out result_test);
                        if (_gyldigDouble != false)
                        { sesjonsdosen = Math.Max(result_test, sesjonsdosen); }
                        //else if 
                    }
                }
                //-------------------------------

                // Sessiontoleranse - konverterer til double hvis mulig
                //-------------------------
                double sestol_ref;
                _gyldigDouble = double.TryParse(varfeltrefpktdose_int[0, i, 3].ToString(),
                     NumberStyles.Any, CultureInfo.InvariantCulture,
                    out sestol_ref);
                if (_gyldigDouble == false) { _gyldigSessionInput = false; }
                //Gammel kode:    double sestol_ref = Convert.ToDouble(varfeltrefpktdose_int[0, i, 3], CultureInfo.InvariantCulture);  //ses dose
                //-------------------------

                // dagstoleranse  - konverterer til double hvis mulig
                //-------------------------
                double dagtol_ref;
                _gyldigDouble = double.TryParse(varfeltrefpktdose_int[0, i, 4].ToString(),
                    NumberStyles.Any, CultureInfo.InvariantCulture,
                    out dagtol_ref);
                if (_gyldigDouble == false) { _gyldigDagsInput = false; }
                //Gammel kode:    double dagtol_ref = Convert.ToDouble(varfeltrefpktdose_int[0, i, 4], CultureInfo.InvariantCulture);  //dag dose
                //-------------------------

                // Gitt total dose  - konverterer til double hvis mulig
                //-------------------------
                double tottol_ref;
                _gyldigDouble = double.TryParse(varfeltrefpktdose_int[0, i, 1].ToString(),
                    NumberStyles.Any, CultureInfo.InvariantCulture,
                    out tottol_ref);
                if (_gyldigDouble == false) { _gyldigPlanDoseInput = false; }
                //Override primær
                if (refpkt_tot == primRef)
                {//Primært ref override
                    tottol_ref = plan.TotalDose.Dose;
                    varfeltrefpktdose_int[0, i, 1] = tottol_ref;
                }

                //Ta hensyn til total dose gitt fra før - summerer
                result = _rfliste.FirstOrDefault(x => x.RefPointID == varFeltRefpktDose[0, i, 0]);
                if (result != null)
                {
                    if (result.TotalDose != null)
                    {
                        _gyldigDouble = double.TryParse(result.TotalDose.ToString(),
                                NumberStyles.Any, CultureInfo.InvariantCulture,
                                out result_test);
                        //Summerer hvis mulig
                        if (_gyldigDouble == true && _gyldigPlanDoseInput == true)
                        { tottol_ref = result_test + tottol_ref; }
                        else if (_gyldigDouble == true && _gyldigPlanDoseInput == false)
                        { tottol_ref = result_test; }
                        else //_gyldigDouble == false
                        { }//tottol_ref = tottol_ref;

                    }
                }

                //-------------------------

                // TotalDoseToleranse - konverterer til double hvis mulig
                //-------------------------
                double toleranse_ref;
                _gyldigDouble = double.TryParse(varfeltrefpktdose_int[0, i, 2].ToString(),
                    NumberStyles.Any, CultureInfo.InvariantCulture,
                    out toleranse_ref);
                if (_gyldigDouble == false) { _gyldigTotalInput = false; }

                //-------------------------
                //---------------------------------------------------------------------------------------------

                //Setter output
                //---------------------------------------------------------------------------------------------
                //Hvis Totaltolernse gyldig, beregn differanse hvis mulig, skriv totaldosetoleranse til string
                string diff_str = "";
                string tottol_refStr = "";
                if (_gyldigTotalInput == true)
                {
                    diff = Math.Round(tottol_ref - toleranse_ref, 3);
                    diff_str = string.Format("{0:0.000}", diff);
                    tottol_refStr = tottol_ref.ToString();
                }
                //skriver Plandose totalt (alltid gyldig)
                if (_gyldigPlanDoseInput == true)
                {
                    tottol_refStr = tottol_ref.ToString();
                }

                //Hvis Sesjonstoleranse er gyldig, beregn differanse hvis mulig, skriv sesjonsdosen til string
                string diff_ses_str = "";
                string sestol_refStr = "";
                string sesjonsdosenStr = sesjonsdosen.ToString();
                if (_gyldigSessionInput == true)
                {
                    diff = Math.Round(sesjonsdosen - sestol_ref, 3);
                    diff_ses_str = string.Format("{0:0.000}", diff);
                    sestol_refStr = sestol_ref.ToString();
                }


                //Hvis Dagstoleranse er gyldig, skriv dagstoleranse til string (ingen differanse utregnes per naa da vi ikke vet planlagt dagsdose)
                //string diff_dag_str = ""; //brukes ikke per naa
                string dagtol_refStr = "";
                if (_gyldigDagsInput == true)
                {
                    //diff = Math.Round(plan_dagsdose - dagtol_ref, 3);
                    //diff_dag_str = string.Format("{0:0.000}", diff);
                    dagtol_refStr = dagtol_ref.ToString();
                }


                //finne refpkt i rflisten skapt tidligere og legger til dosebidraget.
                result = _rfliste.FirstOrDefault(x => x.RefPointID == varFeltRefpktDose[0, i, 0]);
                if (result != null)
                {
                    var message = string.Join(Environment.NewLine, _rfliste);
                    //MessageBox.Show(message);

                    result.TotalDose = tottol_refStr;
                    result.SessionDose = sesjonsdosenStr;
                    result.SessionDoseDifference = diff_ses_str;
                    result.TotalDoseDifference = diff_str;
                    if (refpkt_tot == primRef && (felles_sekv_refpkt == "" || result.Type_RefPoint == "Primary")) //hvis primær referansepunkt og vi ikke sjekker en sekundærplan. Stringen felles_sekv_refpkt er ikke tom hvis sekundærplan. Eller om det er definert som primær fra tidligere, da beholdes primær.
                    { result.Type_RefPoint = "Primary"; }
                    else { result.Type_RefPoint = "Secondary"; }


                    message = string.Join(Environment.NewLine, _rfliste);
                    //MessageBox.Show(message);
                }
                else
                {
                    //System.Windows.MessageBox.Show("Minst ett felt gir dose til refpkt som ikke har toleransegrense!");
                    _rfliste.Add(new RefPoint() { CheckResult = "", StructureID = refpkt_tot, TotalDose = tottol_refStr, TotalDoseTolerance = tottol_refStr, DailyDoseTolerance = dagtol_refStr, SessionDoseTolerance = sestol_refStr, SessionDose = sesjonsdosenStr, SessionDoseDifference = diff_ses_str, Explanation = "" }); //Refpktnavn = refpkt.PatientVolumeId.ToString(), Dagstoleranse = refpkt.DailyDoseLimit.Dose, Sessiontoleranse = refpkt.SessionDoseLimit.Dose, Totaltoleranse = refpkt.TotalDoseLimit.Dose
                }
                //---------------------------------------------------------------------------------------------
            }

            return _rfliste;
        }

        public static List<RefPoint> GetRefPktListe(ExternalPlanSetup plan) // PatientContext patientContext)
        {
            //-----------------------------
            //Lager en liste med refpunkt
            //-----------------------------
            string _forklaring = "Refpunktliste som viser og sjekker " + Environment.NewLine + "// StrukturID vs RefpktID // " + Environment.NewLine + "// Dagstoleranse vs fraksjonsdose // " + Environment.NewLine + " // Sessiontoleranse vs fraksjonsdose // " + Environment.NewLine + " // Totaldose-toleranse vs Totaldose  //  etc.";

            List<RefPoint> _rfliste = new List<RefPoint>();
            foreach (var refpkt in plan.ReferencePoints)
            {
                // Ny kode for Eclipse v18, 09.02.2024 BP:
                //------------------------------------------------------------------------------------------------------------------
                string temprefvolum = "";

                //Code to cath that sometime primary ref.point and primary structure does not match. In this case, on second thought, it is actually desireable to find matching structure then to return actual primary target structure.
                //-----------------
                //string primref = ReferencePointExtension.GetPrimaryRef(plan);
                //string ptvId = "";
                //if (refpkt.Id == primref)
                //{
                //    if (patientContext.TargetStructureExist == true)
                //    {
                //        ptvId = patientContext.TargetVolume.Id;
                //    }
                //}
                //-----------------

                if (plan.StructureSet.Structures.Any(x => x.Id == refpkt.Id)) // && (refpkt.Id != primref)
                {
                    Structure tempstrukt = plan.StructureSet.Structures.Where(o => o.Id == refpkt.Id).FirstOrDefault();
                    temprefvolum = tempstrukt.Id;
                }
                else
                {
                    //Finner ikke tilsvarende volum, refvolum forblir en tom string.
                }

                _rfliste.Add(new RefPoint() { CheckResult = "", StructureID = refpkt.Id, RefPointID = temprefvolum, DailyDoseTolerance = refpkt.DailyDoseLimit.Dose.ToString(), SessionDoseTolerance = refpkt.SessionDoseLimit.Dose.ToString(), TotalDoseTolerance = refpkt.TotalDoseLimit.Dose.ToString(), Explanation = _forklaring }); //ColorSet = "Green"
                //_rfliste.Add(new rf() { Volumnavn = refpkt.Id, Refpktnavn = temprefvolum, Dagstoleranse = "5", Sessiontoleranse = "6", Totaltoleranse = "7", ColorSet = "Green" });
                //------------------------------------------------------------------------------------------------------------------
                // Kode som ikke lenger fungerer i Eclipse v18, 09.02.2024 BP:
                //------------------------------------------------------------------------------------------------------------------
                //rfliste.Add(new rf() { Volumnavn = refpkt.Id, Refpktnavn = refpkt.PatientVolumeId.ToString(), Dagstoleranse = refpkt.DailyDoseLimit.Dose, Sessiontoleranse = refpkt.SessionDoseLimit.Dose, Totaltoleranse = refpkt.TotalDoseLimit.Dose });
                //------------------------------------------------------------------------------------------------------------------
            }
            //------------------------------

            //Handtere boostplaner for mamma eller ev. revisjoner:
            //-----------------
            bool sekvplanExisterer = false;
            string felles_refpkt_id = "";

            //Summerer doser fra hovedplan
            _rfliste = ReferencePointExtension.SummerDoserTilRefpktFraPlan(plan, _rfliste);

            //if ((plan.Course.ExternalPlanSetups.Any(x => x.Id.ToLower().Contains("boost")) && plan.StructureSet.Structures.Any(x => x.Id.ToLower().Contains("tumbed"))) || plan.Id.Contains(":)"))
            //{
            // Itererer gjennom alle planer i samme course (tempplan)
            foreach (ExternalPlanSetup temp_plan in plan.Course.ExternalPlanSetups)
            {
                sekvplanExisterer = false; //resetter variabel for hver plan som testes.
                                           //hvis tempplanen ikke er rejected og ikke allerede sjekket plan
                if (temp_plan.ApprovalStatus != PlanSetupApprovalStatus.Rejected && temp_plan.Id != plan.Id && !temp_plan.Id.ToLower().Contains("plan sum") && !temp_plan.Id.ToLower().Contains("plansum") && temp_plan.IsDoseValid)
                {

                    //itererer gjennom alle referansepunkt i hovedplan
                    foreach (var refpkt in plan.ReferencePoints)
                    {
                        //hvis noen av referansepktene matcher mellom templplan og hovedplan, skriver dem
                        if (temp_plan.ReferencePoints.Any(x => x.Id == refpkt.Id)) //Changed from Contains() as it could add referencepoint by mistake.
                        {
                            sekvplanExisterer = true; //eksisterer boostplan med felles referansepunkt
                            if (felles_refpkt_id != "") { felles_refpkt_id = felles_refpkt_id + Constants.StringSeparator; }
                            felles_refpkt_id = felles_refpkt_id + temp_plan.ReferencePoints.FirstOrDefault(x => x.Id == refpkt.Id).Id; //Changed from Contains() as it could add referencepoint by mistake.
                        }
                    }
                    if (sekvplanExisterer == true)
                    {   //Henter bidragene fra plan
                        _rfliste = ReferencePointExtension.SummerDoserTilRefpktFraPlan(temp_plan, _rfliste, felles_refpkt_id);
                    }

                }
            }

            //}



            //-----------------

            return _rfliste;
        } //Avslutter funksjonen GetRefPktListe
        //-----------------------------------------------------------------------------------------------------------


    }
}
