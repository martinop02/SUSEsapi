﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Numerics;

namespace EclipsePlanCheck.Helpers
{
    public class StructureExtension
    {
        //Forslag til validering av strukturnavn
        private static string ValidateStructureID(string v, bool OverwriteExisting)
        {
            if (OverwriteExisting)
                v = v.Substring(1, v.Length - 1);

            string id_return = v.Trim();

            if (id_return.Length > 16)
            {
                id_return = id_return.Substring(0, 16);
            }
            StringBuilder sb = new StringBuilder();
            char[] id_array = id_return.ToCharArray();
            for (int i = 0; i < id_array.Length; i++)
            {
                if (char.IsLetterOrDigit(id_array[i]) || id_array[i] == '^' || id_array[i] == '_' || id_array[i] == '-')
                    sb.Append(id_array[i]);
                else
                    sb.Append('_');
            }

            if (OverwriteExisting)
                return sb.ToString();
            else
                return sb.ToString(); //return sb.ToString().UniqueStructureId(BaseStructureSet);
        }

        // ----  Body -----------
        public static string GetBodyId(StructureSet structureSet)
        {
            Structure body = structureSet.Structures.FirstOrDefault(o => o.Id.ToLower() == "body");
            string bodyString = "";
            if (body == null)
            {
                try
                {
                    body = structureSet.Structures.FirstOrDefault(o => o.StructureCode.Code.ToLower() == "body"); //zzMamSurface
                }
                catch
                {
                    //Not able to get StructureCode //For instance for 3rdParty approved plans from Ethos
                }


                if (body == null)
                {
                    bodyString = "";
                }
                else { bodyString = body.Id; }
            }
            else { bodyString = body.Id; }

            return bodyString;
        }

        // ----  Couch -----------


        public static List<StructureCheck> CreateCouchStructureTemplateList(string couchAndHUTemplateValue)
        {
            //--------------------
            //Parse Tolerance input:
            //--------------------

            //Split input string into StructureIDs and HUs using "!!!!"
            string splitHUandStructure = "!!!!";//Just need something silly to split the two inputs, HUs and Structures
            string[] splitHUandStructureArray = couchAndHUTemplateValue.Split(new[] { splitHUandStructure }, StringSplitOptions.RemoveEmptyEntries);

            string inputStructureIDs = "";
            string inputStructureHUs = "";
            if (splitHUandStructureArray != null && splitHUandStructureArray.Length != 0) //Handle in case there is no split
            {
                try
                {
                    inputStructureIDs = splitHUandStructureArray[0];
                    inputStructureHUs = splitHUandStructureArray[1];
                }
                catch { }

            }


            //Split input string into structure list based on "&&" (or just one string if no "&&")
            string splitString = "&&";
            string[] structureArray = inputStructureIDs.Split(new[] { splitString }, StringSplitOptions.RemoveEmptyEntries);
            string[] HUArray = inputStructureHUs.Split(new[] { splitString }, StringSplitOptions.RemoveEmptyEntries);

            //Will fill up structureTemplate list:
            List<StructureCheck> structuresTemplateList = new List<StructureCheck>();

            //Find max length of arrays
            int minLength = 0;
            int maxLength = 0;
            int structureArrayLength = structureArray.Length;
            int HUArrayLength = HUArray.Length;
            bool differentLength = false;
            if (structureArrayLength != HUArrayLength)
            {
                if (structureArrayLength > HUArrayLength)
                { minLength = HUArrayLength; maxLength = structureArrayLength; }
                else { minLength = structureArrayLength; maxLength = HUArrayLength; differentLength = true; }

            }
            else { minLength = structureArrayLength; maxLength = structureArrayLength; } //same length

            //Create structures template list
            for (int arrayPosition = 0; arrayPosition <= maxLength - 1; arrayPosition++)
            {
                //Create new empty structure
                StructureCheck structuresTemplate = new StructureCheck();

                if (differentLength == false)
                { //If same length, then fill
                    structuresTemplate.StructureID = structureArray[arrayPosition];
                    structuresTemplate.StructureHU = HUArray[arrayPosition];
                }
                else
                { //handle wrong inputs (not defined HUs or IDs), set empty where no values
                    MessageBox.Show("Input from Templates Excel-file has inconsistency for choosen template. Number of Couch structures and number of associated HUs should be same. PLease fix! Code will ignore some of the input and attempt to continue.");
                    if (structureArrayLength > HUArrayLength)
                    { //Empty HU values must be entered.
                        if (arrayPosition <= minLength - 1)
                        {
                            structuresTemplate.StructureID = structureArray[arrayPosition];
                            structuresTemplate.StructureHU = HUArray[arrayPosition];
                        }
                        if (arrayPosition > minLength - 1)
                        {
                            structuresTemplate.StructureID = structureArray[arrayPosition];
                            structuresTemplate.StructureHU = ""; //Empty if nothing.
                        }

                    }
                    else // (HUArrayLength > structureArrayLength )
                    { //Empty structure values must be entered.
                        if (arrayPosition <= minLength - 1)
                        {
                            structuresTemplate.StructureID = structureArray[arrayPosition];
                            structuresTemplate.StructureHU = HUArray[arrayPosition];
                        }
                        if (arrayPosition > minLength - 1)
                        {
                            structuresTemplate.StructureID = ""; //Empty if nothing. Should totally ignore this input
                            structuresTemplate.StructureHU = HUArray[arrayPosition];
                        }
                    }


                }
                //Add structure to template list
                structuresTemplateList.Add(structuresTemplate);

            }

            return structuresTemplateList;
        }
        //List<StructureCheck> 
        public static string ReformatCouchTemplateDisplayValue (List<StructureCheck> structuresTemplateList)
        {
            string toleranceDisplayOutput = "";
            //Create template headers
            toleranceDisplayOutput = "StrukturID:     (HU)  "; //toleranceDisplayOutut = GeneralExtension.FormatString(20, 20, "StrukturID" + Constants.StringSeparator + "HU");
            //Create Display values for tolerances:
            foreach (StructureCheck structuresTemplate in structuresTemplateList)
            {
                //Cannot use Format-method because string contains separators!
                toleranceDisplayOutput = toleranceDisplayOutput + Environment.NewLine + structuresTemplate.StructureID + " (" + structuresTemplate.StructureHU + ")";
                //Not perfect but good enough for now.
            }




            return toleranceDisplayOutput;
        }


        public static CheckPoint CheckCouchStructures(CheckPoint s, StructureSet structureSet, PatientContext patientContext)
        {

            //Create structureTemplate list:
            List <StructureCheck> structuresTemplateList = CreateCouchStructureTemplateList(s.CheckTemplateValue);

            //-------------------
            //Tolerance Display output (modified sligthly for display purposes)
            //-------------------
            string toleranceDisplayOutput = "";
            toleranceDisplayOutput = ReformatCouchTemplateDisplayValue(structuresTemplateList);


            //-------------------
            //Check if couch exist and has correct HU
            //-------------------

            //Create final list of found structures and HUs (to be displayed in Result):
            List<StructureCheck> structuresResultList = new List<StructureCheck>();

            //foundCouchStructuresList. Cannot find same structure again. Then it goes to look further.
            //List<String> foundCouchStructuresList = new List<string>();

            string globalStatus = Constants.Unknown;

            int countCouchStructureCompleteMatchFound = 0;
            int countCouchStructureMatchNameFound = 0;
            string NotAttchedCouchStructures = "";

            foreach (StructureCheck structureTemplate in structuresTemplateList)
            {

                bool foundMatchingStructure = false; //Global status for this structureTemplate
                string tempStatus = ""; //Local status for this particular structureEclipse
                string tempHU = ""; //Local status for this particular structureEclipse
                foreach (Structure structureEclipse in patientContext.ChosenStructureSet.Structures)
                {
                    string tempStructureID = structureEclipse.Id;
                    if (structureTemplate.StructureID != "") //Only if valid ID in template, no point searching for empty ID.
                    {
                        //Check this particular structure
                        tempStatus = CheckPointExtension.CheckResultVsTemplate(tempStructureID, structureTemplate.StructureID, s.CheckTrafficLight, "string", s);

                        // --------------------
                        // STATUSES 
                        // --------------------
                        //Check if it is a support structure or couch
                        bool isCouchOrSupportType = false;
                        try
                        {
                            isCouchOrSupportType = structureEclipse.Id.ToLower().Contains("couch") || structureEclipse.StructureCode.Code.ToLower().Contains("support") || structureEclipse.DicomType.ToLower().Contains("support");
                        }
                        catch //If it is an old plan, it might not have a DicomType, check only StructureCode and ID:
                        {
                            try //If Structure Code exists for all structures this should work:  check for StructureCode "Support" and also ID "couch"
                            {
                                //If structureCode is empty? If so, no point letting the code crash looking for the couch.
                                isCouchOrSupportType = structureEclipse.Id.ToLower().Contains("couch") || structureEclipse.StructureCode.Code.ToLower().Contains("support");
                            }
                            catch //If Structure Code is empty for a strucutre, only match ID
                            {
                                //If StructureCode is empty? If so, no point letting the code crash looking for the couch.
                                isCouchOrSupportType = structureEclipse.Id.ToLower().Contains("couch");
                            }
                        }

                        //Check that it is already not taken:
                        //bool alreadyAdded = foundCouchStructuresList.Any(x => x == tempStructureID);
                        bool notAlreadyAdded = !structuresResultList.Any(x => x.StructureID == tempStructureID);
                        // --------------------
                        // --------------------

                        // --------------------
                        // ADD If ok
                        // --------------------

                        //MessageBox.Show(tempStatus + " " + isCouchOrSupportType + " " + notAlreadyAdded + " " + tempStructureID);

                        //Count couch-structures found but not matching:
                        if (tempStatus != Constants.Ok && isCouchOrSupportType && notAlreadyAdded)
                        {
                            if (!NotAttchedCouchStructures.Contains(tempStructureID))
                            { 
                                if(NotAttchedCouchStructures != "") { NotAttchedCouchStructures = NotAttchedCouchStructures + ";"; }
                                NotAttchedCouchStructures = NotAttchedCouchStructures + tempStructureID;
                                //MessageBox.Show("Adding: " + NotAttchedCouchStructures);
                            }
                        }


                        //If match (name is matching, and is a suport type or contains "couch" in name. If tempstatus == ok (not if the global status is true!)
                        if (tempStatus == Constants.Ok && isCouchOrSupportType && notAlreadyAdded)
                        {
                            countCouchStructureMatchNameFound = countCouchStructureMatchNameFound + 1;
                            //Create default structureResult:
                            StructureCheck structureResult = new StructureCheck();
                            structureResult.StructureID = "";
                            structureResult.StructureHU = "";
                            structureResult.Explanation = "";
                            structureResult.Status = Constants.Unknown;

                            foundMatchingStructure = true; //Set global status
                            structureResult.StructureID = tempStructureID;
                            //foundCouchStructuresList.Add(tempStructureID);


                            //Set local statuses for both HU and Structure ID for this particular structure in structuresFoundList. Add Elaboration/Comments/Warnings.
                            //retrieve HU if possible
                            tempHU = GetStructureHUasString(structureResult.StructureID, patientContext.ChosenStructureSet);
                            structureResult.StructureHU = tempHU; //Add

                            

                            //Check if HU is correct. structureTemplate.StructureHU contains all possible acceptable values.
                            tempStatus = CheckPointExtension.CheckResultVsTemplate(tempHU, structureTemplate.StructureHU, s.CheckTrafficLight, "string", s);
                            if (tempStatus == Constants.Ok)
                            {
                                countCouchStructureCompleteMatchFound = countCouchStructureCompleteMatchFound + 1; //Number of relevant structures found
                                structureResult.Status = Constants.Ok; //All ok!
                            }
                            else
                            {
                                structureResult.Status = s.CheckTrafficLight;
                                structureResult.Explanation = structureResult.Explanation + structureResult.StructureID + " HU ikke korrekt. ";
                                globalStatus = s.CheckTrafficLight;
                            }

                            //Add to list if match found:
                            structuresResultList.Add(structureResult); // 
                            //MessageBox.Show(structureResult.StructureID + " " + structureResult.StructureHU + " " + structureResult.Status + " " + tempStructureID);
                            //outside loop it will add if no match found
                        }

                        // --------------------
                        // --------------------

                    }
                } //After going through all structures, if not one match is found, set status
                if (foundMatchingStructure != true)
                {
                    //Handle if no structures found, but template allows no structure
                    if (structureTemplate.StructureID == "*")
                    {
                        //Create default structureResult:
                        StructureCheck structureResult = new StructureCheck();
                        structureResult.StructureID = "-";
                        structureResult.StructureHU = "-";
                        structureResult.Status = Constants.Ok;
                        string wildcardExplanation = "Sjekken godtar alle resultat (ingen bord, eller hvilket som helst bord), fordi templatet er kun et wildcard ('" + structureTemplate.StructureID + "'). ";
                        structureResult.Explanation = wildcardExplanation; //Add wildcardEclpanation if it does not already exist in list. //if (!structuresResultList.Any(x => x.Explanation.Contains(wildcardExplanation))) { structureResult.Explanation = wildcardExplanation; }; 
                        //Add to list if no match:
                        structuresResultList.Add(structureResult);

                        globalStatus = Constants.Ok;


                    }
                    //If structure not found, but template demands specific structure.
                    else 
                    {
                        //Create default structureResult:
                        StructureCheck structureResult = new StructureCheck();
                        structureResult.StructureID = "-";
                        structureResult.StructureHU = "-";
                        structureResult.Status = s.CheckTrafficLight;
                        structureResult.Explanation = structureResult.Explanation + "Fant ikke struktur '" + structureTemplate.StructureID + "'. ";
                        //Add to list if no match:
                        structuresResultList.Add(structureResult);

                        globalStatus = s.CheckTrafficLight;
                    }


                }
                else
                {
                    //Comment if template allows all possible results
                    if (structureTemplate.StructureID == "*")
                    {
                        string wildcardExplanation = "OBS! Sjekken godtar ALLE resultat (ingen bord eller hvilket som helst bord), fordi templatet er kun et wildcard ('*'). ";
                        s.CheckComment = s.CheckComment +  wildcardExplanation; //Add wildcardEclpanation if it does not already exist in list. //if (!structuresResultList.Any(x => x.Explanation.Contains(wildcardExplanation))) { structureResult.Explanation = wildcardExplanation; }; 
                    }

                    if (globalStatus == Constants.Unknown || globalStatus == Constants.Ok)
                    { globalStatus = Constants.Ok; } //nothing wrong.... yet. Set globalStatus Ok for now.
                }
            }
            //-------------------
            //Finished Check Couch and HU
            //-------------------



            //Create result headers
            string resultDisplayOutut = GeneralExtension.FormatString(8, 20, "Status:" + Constants.StringSeparator + "StrukturID:")  + Constants.StringSeparator + "   HU:";

            //Build result output string:
            //int countstructureResults = structuresResultList.Count();
            //int iterator = 0;
            //MessageBox.Show("Exist: " + NotAttchedCouchStructures);
            foreach (StructureCheck finalStructureResult in structuresResultList)
            {
                //MessageBox.Show("Removing: " + finalStructureResult.StructureID);
                resultDisplayOutut = resultDisplayOutut + Environment.NewLine + GeneralExtension.FormatString(8, 20, finalStructureResult.Status + Constants.StringSeparator + finalStructureResult.StructureID) + Constants.StringSeparator + "  " + finalStructureResult.StructureHU;
                s.CheckComment = s.CheckComment + finalStructureResult.Explanation;

                //Clean up NotAttchedCouchStructures now that we have all information available:
                char charactersToTrim = ';';
                string [] NotAttchedCouchStructuresArray = NotAttchedCouchStructures.Split(';');
                foreach (string NotAttchedCouchStructure in NotAttchedCouchStructuresArray)
                {
                    if(finalStructureResult.StructureID == NotAttchedCouchStructure)
                    {
                        NotAttchedCouchStructures = NotAttchedCouchStructures.Replace(NotAttchedCouchStructure, string.Empty);
                        NotAttchedCouchStructures = NotAttchedCouchStructures.Replace(";;", string.Empty);
                        NotAttchedCouchStructures = NotAttchedCouchStructures.TrimStart(charactersToTrim);
                        NotAttchedCouchStructures = NotAttchedCouchStructures.TrimEnd(charactersToTrim);
                        //MessageBox.Show("Removed: " + finalStructureResult.StructureID + ". ArrayValue= " + NotAttchedCouchStructure + ". Result: " + NotAttchedCouchStructures);
                    }
                }

                //CSV result:
                if (s.CheckResultValueCSV != "" && s.CheckResultValueCSV != null)  { s.CheckResultValueCSV = s.CheckResultValueCSV + Constants.StringSeparator; }//Add separator if necessary
                s.CheckResultValueCSV = s.CheckResultValueCSV + finalStructureResult.Status + ":" + finalStructureResult.StructureID + ":" + finalStructureResult.StructureHU; //Add result

            }

            //If no structures found:
            if (countCouchStructureCompleteMatchFound == 0)
            {
                //Handle wildcard where all is accepted:
                if (structuresResultList.Count <= 0) { s.CheckComment = s.CheckComment + structuresResultList.FirstOrDefault().Explanation;} //Add Comment about wildcardtemplates if it exists.
                if (s.CheckComment != "") { s.CheckComment = Environment.NewLine + s.CheckComment ; } //Add new Line


                //General handling:
                string tempComment = s.CheckComment; //Store old result in variable
                s.CheckComment = "Fant ingen match på både strukturnavn og HU. "; //Reset Comment to this
                //Other not attached support-structures to that exists:
                if(NotAttchedCouchStructures !="")
                {
                    s.CheckComment = s.CheckComment + tempComment + Environment.NewLine + "Det finnes  noen andre 'support'-strukturer som ikke matchet med templat: " + NotAttchedCouchStructures + "  "; ;
                }
                else if (countCouchStructureMatchNameFound < 1)
                {
                    s.CheckComment = "Finnes ingen support-strukturer overhodet!" + tempComment;
                }
                //If warning is given - mention possible examples where this is still alright:
                if (globalStatus != Constants.Ok && countCouchStructureMatchNameFound < 1)
                {
                    s.CheckComment = s.CheckComment + Environment.NewLine + "Hvis bordet er inkludert i 'Body'-struktur så er det likevel ok å ikke ha bordstruktur.";
                }
                

            }


            //remove trailing new lines:
            char[] newlineChars = { '\r', '\n' };
            if (resultDisplayOutut.EndsWith("\r\n"))
            {
                //resultDisplayOutut.Remove(resultDisplayOutut.Length - 2);
                resultDisplayOutut.TrimEnd(newlineChars);
            }
            else if (resultDisplayOutut.EndsWith("\n")) // Handles '\n' or '\r' if only one is present
            {
                resultDisplayOutut.Remove(resultDisplayOutut.Length - 1);
            }
            //remove trailing new lines:
            if (toleranceDisplayOutput.EndsWith("\r\n"))
            {
                //toleranceDisplayOutput.Remove(toleranceDisplayOutput.Length - 2);
                toleranceDisplayOutput.TrimEnd(newlineChars);
            }
            else if (toleranceDisplayOutput.EndsWith("\n")) // Handles '\n' or '\r' if only one is present
            {
                toleranceDisplayOutput.Remove(toleranceDisplayOutput.Length - 1);
            }

            //set final result:
            s.CheckStatus = globalStatus;
            s.CheckResultValue = resultDisplayOutut;
            s.CheckTemplateValue = toleranceDisplayOutput; //Should be TemplateDisplayValyue once this is implemented
                return s;
        }

        //Outdated:
        public static CheckPoint CheckCouchSurfaceID(CheckPoint s, StructureSet structureSet, PatientContext patientContext)
        {
            string couchSurfaceID = patientContext.CouchId; //StructureExtension.GetCouchSurfaceID(structureSet);
            string testStatus = "";
            s.CheckResultValue = couchSurfaceID;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(couchSurfaceID, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            Structure couch = structureSet.Structures.Where(x => x.Id == couchSurfaceID).FirstOrDefault();
            string debug = "";
            //Check vs Standardphrase
            if (s.CheckStatus == s.CheckTrafficLight)
            {
                testStatus = CheckPointExtension.CheckResultVsTemplate(couchSurfaceID, Constants.CouchIDContainsStandardPhrase, s.CheckTrafficLight, "string", s);
                if (testStatus == Constants.Ok)
                {
                    s.CheckStatus = Constants.Warning;
                    debug = debug + "CouchID stemmer ikke direkte med templatverdi, men en couch eksisterer og Id matcher med generelle standardfraser for Couch." + Environment.NewLine; //debug = debug + "CouchID does not match directly with template value, but a couch exist and Id matches with standardphrases for Couch in general." + Environment.NewLine;
                }
                else { } //Keep TrafficLight as is

            }

            //Check if no table (but exceptions if template allows it)
            if (couchSurfaceID == "" && s.CheckStatus != Constants.Ok) // s.CheckTemplateValue != "*"
            {
                debug = debug + "Ingen bord lagt inn. ";
                s.CheckStatus = Constants.Error;
            }
            //Check if table exist and is not segmented
            if (couch != null)
            {
                if (couch.HasSegment == false)
                {
                    s.CheckStatus = Constants.Error;
                    debug = debug + "Bord er kke tegnet. ";
                }
            }
            s.CheckComment = debug;
            s.CheckDebug = debug;
            if (s.CheckResultValue == "" && s.CheckStatus == Constants.Ok) { s.CheckComment = s.CheckComment + " Templat tillater at det ikke er bord."; }

            return s;
        }

        public static string GetCouchSurfaceID(StructureSet structureSet)
        {

            //Make list of "Support" structures
            List<Structure> supportStructureList = new List<Structure>();

            //If DicomType exists for all structures this should work: search for DicomType or StructureCode "Support" and also ID "couch". AHA!!! Found a possible reason why this could crash. I think it is boluses that forces a crash because they are special! Also, som structure lack Type.
            //Todo: Create a function "SearchForStructurePropertiesWithoutCrashing" :)
            try
            {
                supportStructureList = structureSet.Structures.Where(o => o.Id.ToLower().Contains("couch") || o.StructureCode.Code.ToLower().Contains("support") || o.DicomType.ToLower().Contains("support")).ToList();
            }
            catch //If it is an old plan, it might not have a DicomType, check only StructureCode and ID:
            {
                try //If Structure Code exists for all structures this should work:  check for StructureCode "Support" and also ID "couch"
                {
                    supportStructureList = structureSet.Structures.Where(o => o.Id.ToLower().Contains("couch") || o.StructureCode.Code.ToLower().Contains("support")).ToList(); //If structureCode is empty? If so, no point letting the code crash looking for the couch.
                }
                catch //If Structure Code is empty for a strucutre, only match ID
                {
                    supportStructureList = structureSet.Structures.Where(o => o.Id.ToLower().Contains("couch")).ToList(); //If StructureCode is empty? If so, no point letting the code crash looking for the couch.
                }
            }

            string finalCouchID = "";
            int numberOfSupportStructures = supportStructureList.Count();
            //MessageBox.Show("numberOfSupportStructures: " + numberOfSupportStructures.ToString());
            //Search through standard couch names. Returns if any direct match.
            foreach (Structure supportStructure in supportStructureList)
            {
                string currentCouchID = "";
                if (supportStructure != null)
                {
                    currentCouchID = supportStructure.Id;
                    //MessageBox.Show("currentCouchID: " + currentCouchID + Environment.NewLine + "Constants.CouchExcactIDs: " + Constants.CouchExcactIDs);
                    //Check if we can find a matching standard couch name
                    string matchingCouchId = GeneralExtension.CheckStringsVsStrings(currentCouchID, Constants.CouchExcactIDs);
                    if (matchingCouchId != "")
                    {
                        finalCouchID = matchingCouchId;
                        //MessageBox.Show("currentCouchID: " + currentCouchID + Environment.NewLine + "Constants.CouchExcactIDs: " + Constants.CouchExcactIDs + Environment.NewLine + "Match found. matchingCouchId: " + matchingCouchId);
                        return finalCouchID; //return on first match
                    }
                }
                else { finalCouchID = ""; }
            }


            //Scenarios if no direct matches
            if (numberOfSupportStructures == 0) //If no couch
            {
                finalCouchID = "";
            }
            //No direct matches - should not really happen if Constants.CouchExcactIDs is set up correctly:
            else if ((numberOfSupportStructures == 1) && (finalCouchID == "")) //If only one structure, and no direct match 
            {
                finalCouchID = supportStructureList.FirstOrDefault().Id;
            }
            else if ((numberOfSupportStructures > 1) && (finalCouchID == "")) //Multiple possible couches, none are direct matches. Checks for standard couch phrases then. Picks first good match with Constants.CouchIDContainsStandardPhrase.
            {
                //MessageBox.Show("Method 'GetCouchSurfaceID' warning: No direct match found on CouchID. " + Environment.NewLine + "Make sure the search terms for couchID in the Constants-file are correct." + Environment.NewLine + "'Constants.CouchExcactIDs': " + Constants.CouchExcactIDs + Environment.NewLine + "numberOfSupportStructures found: " + numberOfSupportStructures.ToString());

                //Build string of couch-structures to check
                string couchStructureString = "";
                foreach (Structure supportStructure in supportStructureList)
                {
                    if (supportStructure != null)
                    {
                        if (couchStructureString == "") { couchStructureString = supportStructure.Id; }
                        else { couchStructureString = couchStructureString + Constants.StringSeparator + supportStructure.Id; }

                    }
                }

                //Check if we can find a matching standard couch name. Try to match all possible structures with first template value. Template values are in prioritized order. If it does not match first template value, it contiues to the next.
                string matchingCouchId = GeneralExtension.CheckStringsVsStrings(couchStructureString, Constants.CouchIDContainsStandardPhrase);
                if (matchingCouchId != "")
                {
                    finalCouchID = matchingCouchId;
                    return finalCouchID; //return on first match
                }
                else { finalCouchID = ""; }

                if (finalCouchID == "") //Still no match?
                {
                    finalCouchID = supportStructureList.FirstOrDefault().Id; //Chooses first available structure with "Support" Dicom Type.
                }
            }
            //Result:
            return finalCouchID;
        }

        public static CheckPoint CheckCouchHU(CheckPoint s, StructureSet structureSet, PatientContext patientContext)
        {
            string couchHU = StructureExtension.GetCouchHU(structureSet, patientContext).ToString();
            s.CheckResultValue = couchHU;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(couchHU, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            return s;
        }

        //
        public static string GetStructureHUasString(string structureID, StructureSet strSet) 
        {
            bool HUbool;
            double HU = -9999; //setter den midlertidig da det maa vaere double
            string HUstring = "";
            if (!(structureID == ""))
            {
                Structure structure = strSet.Structures.FirstOrDefault(o => o.Id == structureID);

                HUbool = structure.GetAssignedHU(out HU); //Attempt to retrieve
                HU = Math.Round(HU, 0);
            }
            if (HU == -9999) { HUstring = ""; } //fjerner midlertidig verdi og setter til tom string hvis det ikke fantes bord.
            else { HUstring = HU.ToString(); }
            return HUstring; //Math.Round(CouchHU,0)
        }

        public static string GetCouchHU(StructureSet structureSet, PatientContext patientContext) //tidligere double
        {
            string bordnavn = patientContext.CouchId;
            bool Bordbool;
            double CouchHU = -9999; //setter den midlertidig da det maa vaere double
            string _couchHU = "";
            if (!(bordnavn == ""))
            {
                Structure bord = structureSet.Structures.FirstOrDefault(o => o.Id == bordnavn);

                Bordbool = bord.GetAssignedHU(out CouchHU);
                CouchHU = Math.Round(CouchHU, 0);
            }
            if (CouchHU == -9999) { _couchHU = ""; } //fjerner midlertidig verdi og setter til tom string hvis det ikke fantes bord.
            else { _couchHU = CouchHU.ToString(); }
            return _couchHU; //Math.Round(CouchHU,0)
        }

        public static string GetCouchStructureCode(StructureSet structureSet)
        {
            string bordnavn = GetCouchSurfaceID(structureSet);
            string supportstring = "";
            if (!(bordnavn == ""))
            {
                Structure bord = structureSet.Structures.FirstOrDefault(o => o.Id == bordnavn);
                supportstring = bord.StructureCode.ToString();
            }

            return supportstring;
        }

        public static MarkerDetection CreateDefaultMarkerDetection()
        {
            //Oppretter ny tom targetstructures
            MarkerDetection markerDetection = new MarkerDetection()
            {

                //VoxelPlane = new double[5000,5000],
                BodyEntryFound = false,
                PixelIndex_BodyEntry_X = 0,
                MaxValueEntry = 0,
                IndexMaxValueEntry = 0,
                MarkerFoundEntry = false,

                BodyExitFound = false,
                PixelIndex_BodyExit_X = 0,
                MaxValueExit = 0,
                IndexMaxValueExit = 0,
                MarkerFoundExit = false,

                Z_slice = 0,
                Y_PixelPosition = 0,

                Z_slice_difference_from_UserOrigin_Entry = 0,
                Z_slice_difference_from_UserOrigin_Exit = 0,
                Y_position_difference_from_UserOrigin_Entry = 0,
                Y_position_difference_from_UserOrigin_Exit = 0,
                DebugMarker = "",

            };

            return markerDetection;
        }

        public static MarkerDetectionData CreateDefaultMarkerDetectionData()
        {
            //Oppretter ny tom targetstructures
            MarkerDetectionData markerDetectionData = new MarkerDetectionData()
            {
                //Not set:
                //voxelplane = "",
                //Start
                //Stop
                //Body

                //Basic info:
                MarkerDetectionList = new List<MarkerDetection>(),
                UserOriginY_Position_pixelnumber =0,
                UserOriginX_Position_pixelnumber = 0,
                UserOriginZ_slice = 0,

                X_UserOrigin = 0,
                Y_UserOrigin = 0,
                Z_UserOrigin = 0,
                X_UserOrigin_Converted = 0,
                Y_UserOrigin_Converted = 0,
                Z_UserOrigin_Converted = 0,

                X_ImageOrigin = 0,
                Y_ImageOrigin = 0,
                Z_ImageOrigin  = 0,
                X_ImageOrigin_Converted = 0,
                Y_ImageOrigin_Converted = 0,
                Z_ImageOrigin_Converted = 0,

                Y_Resolution_mm = 0,
                X_Resolution_mm = 0,
                Z_Resolution_mm = 0,

                X_Size_pixels = 0,
                Y_Size_pixels = 0,
                Z_Size_pixels = 0,


                y_StartSearch_pixel = 0,
                y_StopSearch_pixel = 0,
                z_StartSearch_pixel = 0,
                z_StopSearch_pixel = 0,

                y_StartSearch_VVector =0,
                y_StopSearch_VVector = 0,
                z_StartSearch_VVector = 0,
                z_StopSearch_VVector = 0,

                //Info about best fit (highest value)
                TotalMaxValueEntry = 0,
                TotalMaxValueExit = 0,
                TotalMaxZSliceEntry = 0,
                TotalMaxZSliceExit = 0,
                TotalMaxYPositionEntry = 0,
                TotalMaxYPositionExit = 0,

                //Best fit difference from User Origin:
                TotalMaxYPositionEntry_DifferenceMm = 0,
                TotalMaxYPositionExit_DifferenceMm = 0,
                TotalMaxZSliceEntryDifferenceMm = 0,
                TotalMaxZSliceExitDifferenceMm = 0,

                TotalEntryMarkersDetected = false,
                TotalExitMarkersDetected = false,

                Debug_TotalEntrySlice = "",
                Debug_TotalExitSlice = "",
                TotalMaxEntryListPosition = 0,
                TotalMaxExitListPosition = 0,
                //UserOriginY = 0,
                
                
            };

            return markerDetectionData;
        }



        // ----  End Bord -------


        // ----  Mesh -------

        // and some notes on 3d meshes // https://docs.microsoft.com/en-us/archive/msdn-magazine/2007/april/foundations-3d-mesh-geometries
        public static Rect3D GetMeshBounds(ExternalPlanSetup plan, string strukturnavn1)
        {
            Structure structure1 = plan.StructureSet.Structures.Where(o => o.Id == strukturnavn1).FirstOrDefault();
            Rect3D bounds = structure1.MeshGeometry.Bounds;
            return bounds;
            //bounds.Location.X;
            //bounds.SizeX
        }

        // Positions
        // these should be the vertex/edge positions of the object/structure
        public static Point3DCollection GetMeshPositions(ExternalPlanSetup plan, string strukturnavn1)
        {
            Structure structure1 = plan.StructureSet.Structures.Where(o => o.Id == strukturnavn1).FirstOrDefault();
            Point3DCollection positions = structure1.MeshGeometry.Positions;

            return positions;
        }

        // triangle indices 
        // drives the rendering - any indexes of the positions not referenced by these are ignored - ccw orientation is front facing (0, 3, 1), cw is back facing (0, 1, 3) 
        public static Int32Collection GetMesTriangleIndices(ExternalPlanSetup plan, string strukturnavn1)
        {
            Structure structure1 = plan.StructureSet.Structures.Where(o => o.Id == strukturnavn1).FirstOrDefault();
            Int32Collection triangleIndices = structure1.MeshGeometry.TriangleIndices;

            return triangleIndices;
        }

        // normals 
        // vector that determines the direction each position/vertex faces - perpindicular to the face 
        public static Vector3DCollection GetMeshNormals(ExternalPlanSetup plan, string strukturnavn1)
        {
            Structure structure1 = plan.StructureSet.Structures.Where(o => o.Id == strukturnavn1).FirstOrDefault();
            Vector3DCollection normals = structure1.MeshGeometry.Normals;

            return normals;
        }

        // texture coordinates 
        // correspondence between the vertices of the 3D object and the coordinates of the 2D brush. This collection contains one 2D point for each 3D point in Positions. 
        public static PointCollection GetMeshTextureCoordinates(ExternalPlanSetup plan, string strukturnavn1)
        {
            Structure structure1 = plan.StructureSet.Structures.Where(o => o.Id == strukturnavn1).FirstOrDefault();
            PointCollection textureCoordinates = structure1.MeshGeometry.TextureCoordinates;

            return textureCoordinates;
        }
        // ----  End Mesh -------


       

 




        //Main function to check margins. From the structure set, makes a list of PTVs and CTVs (later I should change to any large and small structure, also ITVs for instance). Attempts to match them to each other in several steps. Then run a method to check margins.
        //Afterwards generate warnings (negativ margins, small structure not within large structure etc.).  
        //Currently this is a really long method using a lot of similar code. I Intend to seperate out code sections in a separate method eventually, but for now I want to preserve debug-information that otherwise would be lost.

        //Want to create methods: MatchingStructuresForMarginCalculations (list out), CalculateMargins (already exist, want debug also in output! so 'Margin' should return), IterateToFindMatchingStructures (return list of matching structures).
        //Also want to seperate out different debug strings: debugMatchStructuresName, debugMatchStructuresDescriptionDose, debugMatchStructuresDescriptionCode, debugRejectedMatches, 
        //debugMatchStructuresSingularPair, debugNegativMargins, debugStructureWithinStructure, , debugCroppingToBody, debugAreStructureOriginsClose....
      
        // ----  End Marginer -------



        //Check for Markers. Trying to fin a segmentProfile trough Body passing through UserOrigin, potentially adjusted with a displacement. It should be used to detect the markers.
        public static MarkerDetectionData CheckMarkers( string direction, string bodyID, string TrafikLys, StructureSet structureSet, PatientContext patientContext, CheckPoint s) //GetSegmentProfilesOfUserOrigin
        {

            string debugCheckMarkers = "";
            //---------------------
            BitArray bodyProfile = new BitArray(1000); //Not used
            BitArray bodyProfileHigherResolution = new BitArray(10000);  //Not used
            double[] HUprofile = new double[1000];//Not used
            //---------------------


            //-------------------
            //Using the Body (size and centerpoint)
            //-------------------

            //Body info
            Structure body = structureSet.Structures.Single(st => st.Id == bodyID);
            List<Point3D> bodyMeshPositions = body.MeshGeometry.Positions.ToList();

            //Not using Body Bounds - found better method using intersection with body along segment further down, keeping code as reminder in case I want to use later
            //--------------------
            //double bodyMeshBoundsSizeX = body.MeshGeometry.Bounds.SizeX;
            //double bodyMeshBoundsSizeY = body.MeshGeometry.Bounds.SizeY;
            //double bodyMeshBoundsSizeZ = body.MeshGeometry.Bounds.SizeZ;

            //double bodyCenterPointX = body.CenterPoint.x;
            //double bodyCenterPointY = body.CenterPoint.y;
            //double bodyCenterPointZ = body.CenterPoint.z;

            //Set coordinates for bounds:
            //double plussCoordinateX = CalculateDirectionPlussMarginCoordinate(bodyCenterPointX, bodyMeshBoundsSizeX, 1);
            //double plussCoordinateY = CalculateDirectionMinusMarginCoordinate(bodyCenterPointY, bodyMeshBoundsSizeY, 1);
            //double plussCoordinateZ = CalculateDirectionPlussMarginCoordinate(bodyCenterPointZ, bodyMeshBoundsSizeZ, 1);
            //double minusCoordinateX = CalculateDirectionMinusMarginCoordinate(bodyCenterPointX, bodyMeshBoundsSizeX, 1);
            //double minusCoordinateY = CalculateDirectionPlussMarginCoordinate(bodyCenterPointY, bodyMeshBoundsSizeY, 1);
            //double minusCoordinateZ = CalculateDirectionMinusMarginCoordinate(bodyCenterPointZ, bodyMeshBoundsSizeZ, 1);
            //--------------------


            //--------------------
            //Using the Image (Image size, origin and centerpoint)
            //--------------------
            Image image = structureSet.Image;
            VVector imageOrigin = image.Origin; //
            double imageSizeX = image.XSize;
            double imageSizeY = image.YSize;
            double imageSizeZ = image.ZSize;

            double imageOriginX = image.Origin.x;
            double imageOriginY = image.Origin.y;
            double imageOriginZ = image.Origin.z;

            double imageCenterPointX = imageOriginX + imageSizeX / 2; //Should this be corrected for resolution? If so "+ imageSizeX * ImageResolutionX / 2 " ?
            double imageCenterPointY = imageOriginY + imageSizeY / 2;
            double imageCenterPointZ = imageOriginZ + imageSizeZ / 2;
            //--------------------

            //-------------------
            //Setting User Origin
            //------------------
            VVector userOrigin = image.UserOrigin; //mm, ikke voksler
            double userOriginX = image.UserOrigin.x;
            double userOriginY = image.UserOrigin.y;
            double userOriginZ = image.UserOrigin.z;

            //Declare temporary
            double userOriginXConverted = userOriginX;
            double userOriginYConverted = userOriginY;
            double userOriginZConverted = userOriginZ;
            //set, if possible
            VVector userOriginConverted = image.UserOrigin;
            if (patientContext.SanityLevel > Constants.SanityLevelPlanExist)
            {
                userOriginConverted = image.DicomToUser(userOrigin, patientContext.ChosenPlan);
                userOriginXConverted = userOriginConverted.x;
                userOriginYConverted = userOriginConverted.y;
                userOriginZConverted = userOriginConverted.z;
            }

            //Declare temporary
            double imageOriginXConverted = imageOriginX;
            double imageOriginYConverted = imageOriginY;
            double imageOriginZConverted = imageOriginZ;
            //set, if possible
            VVector imageOriginConverted = imageOrigin;
            if (patientContext.SanityLevel > Constants.SanityLevelPlanExist)
            {
                imageOriginConverted = image.DicomToUser(imageOrigin, patientContext.ChosenPlan);
                imageOriginXConverted = imageOriginConverted.x;
                imageOriginYConverted = imageOriginConverted.y;
                imageOriginZConverted = imageOriginConverted.z;

            }

            debugCheckMarkers = debugCheckMarkers + "image origin xyz (mm): " + Math.Round(imageOriginX) + " " + Math.Round(imageOriginY) + " " + Math.Round(imageOriginZ) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "user origin xyz (mm): " + Math.Round(userOriginX) + " " + Math.Round(userOriginY) + " " + Math.Round(userOriginZ) + Environment.NewLine;
            
            //----------------

            //declaring start/stop
            VVector startUserOrigin = new VVector(0, 0, 0);
            VVector stopUserOrigin = new VVector(0, 0, 0);

            //Delcaring buffer
            BitArray bufferBodyStructure = new BitArray(image.XSize);

            //-------------------
            //Start and Stop coordinates (can add in different directions later)
            //------------------
            double stop_x_coordinate = imageOriginX + imageSizeX*image.XRes;    //We should also have to account for different patientOrientations right? Not done yet
            if (direction == "x")
            {                       //Finding the start and stop positions of a segment profile through user origin in a particular direction  //not start at 0, could be negative mm
                startUserOrigin = new VVector(imageOriginX, userOriginY, userOriginZ); // in mm
                stopUserOrigin = new VVector(stop_x_coordinate, userOriginY, userOriginZ); // in mm
            }//Dont need the other directions, only checking in X-direction for now
            //else if (dicrection == "y")
            //{
            //    start = new VVector(userOriginX, 0, userOriginZ);
            //    stop = new VVector(userOriginX, imageSizeY, userOriginZ);
            //}
            //else if (dicrection == "z")
            //{
            //    start = new VVector(userOriginX, userOriginY, 0);
            //    stop = new VVector(userOriginX, userOriginY, imageSizeZ);
            //}



            //double startCoordinateX = segmentProfile[0].Position.x;
            //Y position of segment:
            //double Y_Postion = segmentProfile[0].Position.y;


            //Check voxelPlane where y = userOriginY:
            int pixelNumber_UserOrigin_Y = Convert_Y_Coordinate_VVector_To_pixelNumber(userOriginY, structureSet);
            //Get slice number of user origin

            int userOriginZ_slice = GetSlice(userOriginZ, structureSet); //Z slice from z coordinate of user origin.
           
            //-----------
            //PIXELS z and Y search
            //-----------
            //set start and end positions (in PIXELS, or rather, slizes!) to search z:
            int z_StartSearch_pixel = 0;
            if (userOriginZ_slice - Constants.NumberOfSlizesInSearch >= 0) { z_StartSearch_pixel = userOriginZ_slice - Constants.NumberOfSlizesInSearch; } //Must this be plus?
            int z_EndSearch_pixel = image.ZSize;
            if (userOriginZ_slice + Constants.NumberOfSlizesInSearch <= image.ZSize) { z_EndSearch_pixel = userOriginZ_slice + Constants.NumberOfSlizesInSearch; } //...not exceed size og image

            //set start an end positions (in PIXELS!) to search y:
            int y_StartSearch_pixel = 0;
            if (pixelNumber_UserOrigin_Y - Constants.NumberOfPixelsInSearch_Y >= 0) { y_StartSearch_pixel = pixelNumber_UserOrigin_Y - Constants.NumberOfPixelsInSearch_Y; }
            int y_EndSearch_pixel = image.YSize;
            if (pixelNumber_UserOrigin_Y + Constants.NumberOfPixelsInSearch_Y <= image.YSize) { y_EndSearch_pixel = pixelNumber_UserOrigin_Y + Constants.NumberOfPixelsInSearch_Y; }

            //Adjusted start and end positions far from z user origin:
            int y_StartSearch_pixel_reduced = 0;
            if (pixelNumber_UserOrigin_Y - Constants.ReducedNumberOfPixelsInSearch >= 0) { y_StartSearch_pixel_reduced = pixelNumber_UserOrigin_Y - Constants.ReducedNumberOfPixelsInSearch; }
            int y_EndSearch_pixel_reduced = image.YSize;
            if (pixelNumber_UserOrigin_Y + Constants.ReducedNumberOfPixelsInSearch <= image.YSize) { y_EndSearch_pixel_reduced = pixelNumber_UserOrigin_Y + Constants.ReducedNumberOfPixelsInSearch; }

            //-----------
            //VVECTORS z and Y search
            //-----------
            //set start and end positions (in VVector coordinates!) to search z:
            double z_StartSearch_VVector = imageOriginZ; //could be minus
            if (userOriginZ - Constants.NumberOfSlizesInSearch*image.ZRes >= imageOriginZ) { z_StartSearch_VVector = userOriginZ - Constants.NumberOfSlizesInSearch*image.ZRes; }
            double z_EndSearch_VVector = image.ZSize * image.ZRes;
            if (userOriginZ + Constants.NumberOfSlizesInSearch * image.ZRes <= imageOriginZ + imageSizeZ*image.ZRes) { z_EndSearch_VVector = userOriginZ + Constants.NumberOfSlizesInSearch * image.ZRes; }

            //set start an end positions (in VVector coordinates!) to search y:
            double y_StartSearch_VVector = 0;
            if (userOriginY - Constants.NumberOfPixelsInSearch_Y * image.YRes >= imageOriginY) { y_StartSearch_VVector = userOriginY - Constants.NumberOfPixelsInSearch_Y*image.YRes; }
            double y_EndSearch_VVector = image.YSize*image.YRes;
            if (userOriginY + Constants.NumberOfPixelsInSearch_Y * image.YRes <= imageOriginY + imageSizeY * image.YRes) { y_EndSearch_VVector = userOriginY + Constants.NumberOfPixelsInSearch_Y * image.YRes; }


            //Create class to contain all the analysis
            MarkerDetectionData markerDetectionData = CreateDefaultMarkerDetectionData();

            markerDetectionData.X_Resolution_mm = image.XRes;
            markerDetectionData.Y_Resolution_mm = image.YRes;
            markerDetectionData.Z_Resolution_mm = image.ZRes;
            markerDetectionData.X_UserOrigin = userOriginX; 
            markerDetectionData.Y_UserOrigin = userOriginY; 
            markerDetectionData.Z_UserOrigin = userOriginZ; //
            markerDetectionData.X_ImageOrigin = imageOriginX; 
            markerDetectionData.Y_ImageOrigin = imageOriginY;
            markerDetectionData.Z_ImageOrigin = imageOriginZ;

            markerDetectionData.X_UserOrigin_Converted = userOriginXConverted; 
            markerDetectionData.Y_UserOrigin_Converted = userOriginYConverted; 
            markerDetectionData.Z_UserOrigin_Converted = userOriginZConverted; 
            markerDetectionData.X_ImageOrigin_Converted = imageOriginXConverted;
            markerDetectionData.Y_ImageOrigin_Converted = imageOriginYConverted;
            markerDetectionData.Z_ImageOrigin_Converted = imageOriginZConverted;

            markerDetectionData.y_StartSearch_pixel = y_StartSearch_pixel; 
            markerDetectionData.y_StopSearch_pixel = y_EndSearch_pixel;
            markerDetectionData.y_ReducedStartSearch_pixel = y_StartSearch_pixel_reduced;
            markerDetectionData.y_ReducedStopSearch_pixel = y_EndSearch_pixel_reduced;
            markerDetectionData.z_StartSearch_pixel = z_StartSearch_pixel; 
            markerDetectionData.z_StopSearch_pixel = z_EndSearch_pixel;


            markerDetectionData.y_StartSearch_VVector = y_StartSearch_VVector;
            markerDetectionData.y_StopSearch_VVector = y_EndSearch_VVector;
            markerDetectionData.z_StartSearch_VVector = z_StartSearch_VVector;
            markerDetectionData.z_StopSearch_VVector = z_EndSearch_VVector;

            markerDetectionData.Start = startUserOrigin; //vvector start position, for first segment through userOrigin
            markerDetectionData.Stop = startUserOrigin; //Vvector stop position, for first segment through userOrigin
            markerDetectionData.UserOriginY_Position_pixelnumber = pixelNumber_UserOrigin_Y;
            markerDetectionData.UserOriginZ_slice = userOriginZ_slice;


            //-----------------------
            //Retrieve VoxelPlanes
            //-----------------------
            //For progress bar:
            //int pointsCountMax = z_EndSearch_pixel- z_StartSearch_pixel;
            //int pointsCountCurrent = 0;

            //Search all relevant z slices
            for (int z = z_StartSearch_pixel; z <= z_EndSearch_pixel; z++)  //for (int z = z_StartSearch_pixel; z <= z_EndSearch_pixel; z++)
            {
                //ProgressBar - test
                //if (pointsCountCurrent / pointsCountMax * 100 > s.Progress + 3) //only if progress has continued at least 3 percentages
                //{
                //    _ = s.UpdateTaskProgress(pointsCountMax, pointsCountCurrent); //Fire and forget asynch update
                //}
                //-------------------------------------------
                // Dynamic search to reduce calculation time ---- Not necessary to search much in y-direction too far away from z_user_origin:
                //-------------------------------------------
                int dynamic_y_StartSearch_pixel = 0;
                int dynamic_y_EndSearch_pixel = 0;
                bool z_FarFromUserOrigin = ((z < (userOriginZ_slice - Constants.ReducedSearchThisDistanceFromUserOrigin)) || (z > (userOriginZ_slice + Constants.ReducedSearchThisDistanceFromUserOrigin)));
                bool z_CloseToUserOrigin = !z_FarFromUserOrigin;
                // When far from user origin z
                if (z_FarFromUserOrigin)
                {   // search only reduced length y
                    dynamic_y_StartSearch_pixel = y_StartSearch_pixel_reduced;
                    dynamic_y_EndSearch_pixel = y_EndSearch_pixel_reduced;
                }
                else
                { //Search the full length y
                    dynamic_y_StartSearch_pixel = y_StartSearch_pixel;
                    dynamic_y_EndSearch_pixel = y_EndSearch_pixel;
                }

                //------------------------------
                //Create buffer for voxelPlane
                //------------------------------
                int[,] voxelPlaneRaw = new int[image.XSize, image.YSize]; // values not corrected to Display values
                double[,] voxelPlaneCorrected = new double[image.XSize, image.YSize]; // HU values in proper Display values (HU)

                //Get all raw value voxels of that plane and put in voxelPlaneRaw buffer.
                image.GetVoxels(z, voxelPlaneRaw);
                
                //-----------------------
                //make corrected voxelplane (need only create this per slize Z)
                //-----------------------
                for (int y = 0; y < image.YSize; y++) //iterate over voxels Y
                {
                    //for all x-positions
                    for (int x = 0; x < image.XSize; x++)
                    {
                        //voxelPlaneCorrected[x, y] = image.VoxelToDisplayValue(voxelPlaneRaw[x, y]); //new  //markerDetection.VoxelPlane[x, y] = image.VoxelToDisplayValue(voxelPlaneRaw[x, y]);
                        voxelPlaneCorrected[x, y] = (double)voxelPlaneRaw[x, y];                                                                        //voxelPlaneCorrected[x, y] = image.VoxelToDisplayValue(voxelPlaneRaw[x, y]); // old
                    }
                }
                //-----------------------


                //-------------------------------------------
                //We need to create one "markerDetection" object for each y-position to be investigated also, just so we can analyze them per y- and z-position and write result seperately! Where there is only variation in y, we can use the same VoxelPlane.
                //-------------------------------------------
                for (int y_pixel = dynamic_y_StartSearch_pixel; y_pixel <= dynamic_y_EndSearch_pixel; y_pixel++)
                {

                    //-------------------------------------------
                    // Dynamic search to reduce calculation time ----only check if NOT both far from z origin AND far from y origin, assuming at least one of them is close
                    //-------------------------------------------
                    bool y_CloseToUserOrigin = ((y_pixel >= (pixelNumber_UserOrigin_Y - Constants.ReducedSearchThisDistanceFromUserOrigin)) && (y_pixel <= (pixelNumber_UserOrigin_Y + Constants.ReducedSearchThisDistanceFromUserOrigin))); //||
                    bool y_FarFromUserOrigin = !y_CloseToUserOrigin;
                    if ((z_CloseToUserOrigin && y_CloseToUserOrigin) || (z_CloseToUserOrigin && y_FarFromUserOrigin) || (z_FarFromUserOrigin && y_CloseToUserOrigin))
                    {

                        //----------------------------
                        // Create "markerDetection"
                        //---------------------------
                        MarkerDetection markerDetection = new MarkerDetection(); //Object to store all results in for this postion
                        markerDetection = CreateDefaultMarkerDetection(); //add default values to prevent crashes
                        //Add voxelplane
                        markerDetection.VoxelPlane = new double[image.XSize, image.YSize];
                        markerDetection.VoxelPlane = voxelPlaneCorrected;
                        //set Z:
                        markerDetection.Z_slice = z; //GetSlice(z, structureSet);//z; //Set slice position //Z must be a Vvector coordinate to use GetSlice!
                        markerDetection.Z_VVector = imageOriginZ + z * markerDetectionData.Z_Resolution_mm; // imageOriginZ + z * markerDetectionData.Z_Resolution_mm;    ///Something fishy here, not correct slice! Trying out (z+1)                  //Current Vvector position. ImageOriginZ is already a Vvector double, correctig by slicenumber*thickness
                        //Add y-related information:
                        markerDetection.Y_PixelPosition = y_pixel; //pixel position //markerDetectionData.MarkerDetectionList[i].Y_PixelPosition = y;

                            //Set the new start/stop postion in VVector coordinates, used to find where body entry and exit is, so we know where to search
                        double z_VVector = markerDetection.Z_VVector;
                        double y_VVector = imageOriginY + y_pixel * markerDetectionData.Y_Resolution_mm;
                        //markerDetection.Z_VVector = z_VVector;

                        //Adjust start and stop coordinates y and z. This constitutes a line with all voxels across the entire image in x-direction:
                        markerDetection.Start = new VVector(imageOriginX, y_VVector, z_VVector); // in mm
                        markerDetection.Stop = new VVector(stop_x_coordinate, y_VVector, z_VVector); // in mm
                            //MessageBox.Show("creating list: " + Environment.NewLine + "y_pixel: " + y_pixel + Environment.NewLine + "z_pixel: " + z + Environment.NewLine + "y_VVector: " + y_VVector);
                            //ADD all to list
                        markerDetectionData.MarkerDetectionList.Add(markerDetection);
                    }
                    //------------------------------



                }

            }
            debugCheckMarkers = debugCheckMarkers + "userOriginZ_slice: " + userOriginZ_slice + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "pixelNumber_UserOrigin_Y: " + pixelNumber_UserOrigin_Y + Environment.NewLine;
            //-----------------------


            //-----------------------
            //Check all relevant planes in X-direction for different Y and Z positions (around User Origin):
            //-----------------------

            //Keep track of current maxvalues
            double currentMaxValue_BodyEntry = -99999; //Could be negative
            double currentMaxValue_BodyExit = -99999; //Could be negative


            //Iterate over line scans (altering both z and y now)
            int countMarkerDetections = markerDetectionData.MarkerDetectionList.Count();
            for( int i = 0; i < countMarkerDetections; i++) //(MarkerDetection markerDetection in markerDetectionData.MarkerDetectionList) //Create separate functions for each task.
            {

                    //Get y and z for ease of use
                    int y_pixel = markerDetectionData.MarkerDetectionList[i].Y_PixelPosition;
                    int z_pixel = markerDetectionData.MarkerDetectionList[i].Z_slice;

                    //1. Get indexes of enter and exit body (for that z slice and y position) - return indexes of body along profile, also debugstring of slice values:
                    markerDetectionData.MarkerDetectionList[i] = GetBodyEntryExitPositions(markerDetectionData.MarkerDetectionList[i], markerDetectionData, body, structureSet, patientContext);

                    //2. Search for marker in area close to body entrance and exit along X - return MaxValue, MaxValueIndex and true/false if deteted:
                    markerDetectionData.MarkerDetectionList[i] = GetMarkerPositionsAndValues(markerDetectionData.MarkerDetectionList[i], markerDetectionData, structureSet);

                    //3. Update total statuses in marketDetectionData. Check for every iteration.
                        
                    //Entry
                    if (markerDetectionData.MarkerDetectionList[i].MaxValueEntry > currentMaxValue_BodyEntry)
                    {
                        currentMaxValue_BodyEntry = markerDetectionData.MarkerDetectionList[i].MaxValueEntry;
                        //set global result position, value and index 
                        markerDetectionData.TotalMaxValueEntry = currentMaxValue_BodyEntry;
                        markerDetectionData.TotalMaxYPositionEntry = y_pixel;
                        markerDetectionData.TotalMaxYPositionEntry_DifferenceMm = markerDetectionData.MarkerDetectionList[i].Y_position_difference_from_UserOrigin_Entry* markerDetectionData.Y_Resolution_mm;
                        markerDetectionData.TotalMaxZSliceEntry = z_pixel;
                        markerDetectionData.TotalMaxZSliceEntryDifferenceMm = markerDetectionData.MarkerDetectionList[i].Z_slice_difference_from_UserOrigin_Entry * markerDetectionData.Z_Resolution_mm;
                        markerDetectionData.Z_slice_difference_from_UserOrigin_Entry = markerDetectionData.MarkerDetectionList[i].Z_slice_difference_from_UserOrigin_Entry;
                        markerDetectionData.TotalMaxEntryListPosition = i;
                        markerDetectionData.Debug_TotalEntrySlice = markerDetectionData.MarkerDetectionList[i].DebugMarker;
                        markerDetectionData.TotalEntryMarkersDetected = markerDetectionData.MarkerDetectionList[i].MarkerFoundEntry;

                        //Set VVector position to user coordinates:
                        VVector startToUser = markerDetectionData.MarkerDetectionList[i].Start;
                        VVector stopToUser = markerDetectionData.MarkerDetectionList[i].Stop;

                        markerDetectionData.Total_Start_Converted_Entry = markerDetectionData.MarkerDetectionList[i].Start_Converted; //startToUser;
                        markerDetectionData.Total_Stop_Converted_Entry = markerDetectionData.MarkerDetectionList[i].Stop_Converted;  //stopToUser;

                    //X search positions
                    markerDetectionData.pixelIndex_BodyEntry_X_StartSearch_BestFit = markerDetectionData.MarkerDetectionList[i].pixelIndex_BodyEntry_X_StartSearch;
                    markerDetectionData.pixelIndex_BodyEntry_X_StopSearch_BestFit = markerDetectionData.MarkerDetectionList[i].pixelIndex_BodyEntry_X_StopSearch;


                    }

                    //Exit
                    if (markerDetectionData.MarkerDetectionList[i].MaxValueExit > currentMaxValue_BodyExit)
                    {
                        currentMaxValue_BodyExit = markerDetectionData.MarkerDetectionList[i].MaxValueExit;
                        //set global result position, value and index 
                        markerDetectionData.TotalMaxValueExit = currentMaxValue_BodyExit;
                        markerDetectionData.TotalMaxYPositionExit = y_pixel;
                        markerDetectionData.TotalMaxYPositionExit_DifferenceMm = markerDetectionData.MarkerDetectionList[i].Y_position_difference_from_UserOrigin_Exit * markerDetectionData.Y_Resolution_mm;
                        markerDetectionData.TotalMaxZSliceExit = z_pixel;
                        markerDetectionData.TotalMaxZSliceExitDifferenceMm = markerDetectionData.MarkerDetectionList[i].Z_slice_difference_from_UserOrigin_Exit * markerDetectionData.Z_Resolution_mm;
                        markerDetectionData.Z_slice_difference_from_UserOrigin_Exit = markerDetectionData.MarkerDetectionList[i].Z_slice_difference_from_UserOrigin_Exit;
                        markerDetectionData.TotalMaxExitListPosition = i;
                        markerDetectionData.Debug_TotalExitSlice = markerDetectionData.MarkerDetectionList[i].DebugMarker;
                        markerDetectionData.TotalExitMarkersDetected = markerDetectionData.MarkerDetectionList[i].MarkerFoundExit;

                        markerDetectionData.Total_Start_Converted_Exit = markerDetectionData.MarkerDetectionList[i].Start_Converted; //startToUser;
                        markerDetectionData.Total_Stop_Converted_Exit = markerDetectionData.MarkerDetectionList[i].Stop_Converted;  //stopToUser;

                        //X search positions
                        markerDetectionData.pixelIndex_BodyExit_X_StartSearch_BestFit = markerDetectionData.MarkerDetectionList[i].pixelIndex_BodyExit_X_StartSearch;
                        markerDetectionData.pixelIndex_BodyExit_X_StopSearch_BestFit = markerDetectionData.MarkerDetectionList[i].pixelIndex_BodyExit_X_StopSearch;


                }
                    //Debug of UserOrigin
                    if (y_pixel == pixelNumber_UserOrigin_Y && z_pixel == userOriginZ_slice)
                    {
                        markerDetectionData.Debug_OriginSlice = markerDetectionData.MarkerDetectionList[i].DebugMarker;
                    }

            }

            //Final difference distance to markers
            double totalEntryDifferenceMm = Math.Round(Math.Sqrt(markerDetectionData.TotalMaxYPositionEntry_DifferenceMm * markerDetectionData.TotalMaxYPositionEntry_DifferenceMm + markerDetectionData.TotalMaxZSliceEntryDifferenceMm * markerDetectionData.TotalMaxZSliceEntryDifferenceMm), 1);
            double totalExitDifferenceMm = Math.Round(Math.Sqrt(markerDetectionData.TotalMaxYPositionExit_DifferenceMm * markerDetectionData.TotalMaxYPositionExit_DifferenceMm + markerDetectionData.TotalMaxZSliceExitDifferenceMm * markerDetectionData.TotalMaxZSliceExitDifferenceMm), 1);
            markerDetectionData.TotalEntryDifferenceMm = totalEntryDifferenceMm;
            markerDetectionData.TotalExitDifferenceMm = totalExitDifferenceMm;

            //Searh through total max'es and set final result. Already done

            //Debug
            debugCheckMarkers = debugCheckMarkers + "-------- Search ---------" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "z_StartSearch pixel: " + markerDetectionData.z_StartSearch_pixel + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "z_StopSearch pixel: " + markerDetectionData.z_StopSearch_pixel + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "y_StartSearch pixel: " + markerDetectionData.y_StartSearch_pixel + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "y_StopSearch pixel: " + markerDetectionData.y_StopSearch_pixel + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "-------- Search ---------" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "z_StartSearch VV: " + markerDetectionData.z_StartSearch_VVector + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "z_StopSearch VV: " + markerDetectionData.z_StopSearch_VVector + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "y_StartSearch VV: " + markerDetectionData.y_StartSearch_VVector + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "y_StopSearch VV: " + markerDetectionData.y_StopSearch_VVector + Environment.NewLine;

            //Entry
            debugCheckMarkers = debugCheckMarkers + Environment.NewLine + "-------- Entry ---------" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxValueEntry: " + markerDetectionData.TotalMaxValueEntry + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "   --y--" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxYPositionEntry: " + markerDetectionData.TotalMaxYPositionEntry + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxYPositionEntry_DifferenceMm: " + markerDetectionData.TotalMaxYPositionEntry_DifferenceMm + Environment.NewLine;

            debugCheckMarkers = debugCheckMarkers + "   --z--" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxZSliceEntry: " + markerDetectionData.TotalMaxZSliceEntry + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxZSliceEntryDifferenceMm: " + markerDetectionData.TotalMaxZSliceEntryDifferenceMm + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Z_slice_difference_from_UserOrigin_Entry: " + markerDetectionData.Z_slice_difference_from_UserOrigin_Entry + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxEntryListPosition: " + markerDetectionData.TotalMaxEntryListPosition + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "   --status--" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalEntryMarkesDetected: " + markerDetectionData.TotalEntryMarkersDetected + Environment.NewLine;

            //Exit
            debugCheckMarkers = debugCheckMarkers + Environment.NewLine + "-------- Exit ---------" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxValueExit: " + markerDetectionData.TotalMaxValueExit + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "   --y--" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxYPositionExit: " + markerDetectionData.TotalMaxYPositionExit + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxYPositionExit_DifferenceMm: " + markerDetectionData.TotalMaxYPositionExit_DifferenceMm + Environment.NewLine;

            debugCheckMarkers = debugCheckMarkers + "   --z--" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxZSliceExit: " + markerDetectionData.TotalMaxZSliceExit + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxZSliceExitDifferenceMm: " + markerDetectionData.TotalMaxZSliceExitDifferenceMm + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Z_slice_difference_from_UserOrigin_Exit: " + markerDetectionData.Z_slice_difference_from_UserOrigin_Exit + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalMaxExitListPosition: " + markerDetectionData.TotalMaxExitListPosition + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "   --status--" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "TotalExitMarkesDetected: " + markerDetectionData.TotalExitMarkersDetected + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "-------- Resuloution ---------" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "X_Resolution_mm: " + markerDetectionData.X_Resolution_mm + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Y_Resolution_mm: " + markerDetectionData.Y_Resolution_mm + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Z_Resolution_mm: " + markerDetectionData.Z_Resolution_mm + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "-------- Coordinates ---------" + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + Environment.NewLine + Environment.NewLine + "user origin: " + Math.Round(markerDetectionData.X_UserOrigin, 1) + " " + Math.Round(markerDetectionData.Y_UserOrigin, 1) + " " + Math.Round(markerDetectionData.Z_UserOrigin, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "image origin: " + Math.Round(markerDetectionData.X_ImageOrigin, 1) + " " + Math.Round(markerDetectionData.Y_ImageOrigin, 1) + " " + Math.Round(markerDetectionData.Z_ImageOrigin, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "user origin converted: " + Math.Round(markerDetectionData.X_UserOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Y_UserOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Z_UserOrigin_Converted, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "image origin converted: " + Math.Round(markerDetectionData.X_ImageOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Y_ImageOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Z_ImageOrigin_Converted, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Total_Start_Converted_Entry: " + Math.Round(markerDetectionData.Total_Start_Converted_Entry.x, 1) + " " + Math.Round(markerDetectionData.Total_Start_Converted_Entry.y, 1) + " " + Math.Round(markerDetectionData.Total_Start_Converted_Entry.z, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Total_Stop_Converted_Entry: " + Math.Round(markerDetectionData.Total_Stop_Converted_Entry.x, 1) + " " + Math.Round(markerDetectionData.Total_Stop_Converted_Entry.y, 1) + " " + Math.Round(markerDetectionData.Total_Stop_Converted_Entry.z, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Total_Start_Converted_Exit: " + Math.Round(markerDetectionData.Total_Start_Converted_Exit.x, 1) + " " + Math.Round(markerDetectionData.Total_Start_Converted_Exit.y, 1) + " " + Math.Round(markerDetectionData.Total_Start_Converted_Exit.z, 1) + Environment.NewLine;
            debugCheckMarkers = debugCheckMarkers + "Total_Stop_Converted_Exit: " + Math.Round(markerDetectionData.Total_Stop_Converted_Entry.x, 1) + " " + Math.Round(markerDetectionData.Total_Stop_Converted_Exit.y, 1) + " " + Math.Round(markerDetectionData.Total_Stop_Converted_Exit.z, 1) + Environment.NewLine;

            // --- Printing debug ---
            //MessageBox.Show(debugCheckMarkers);
            //MessageBox.Show("Debug_OriginSlice: " + Environment.NewLine + markerDetectionData.Debug_OriginSlice); //UserOriginSlice
            //debugCheckMarkers = "Debug_TotalExitSlice: " + Environment.NewLine + markerDetectionData.Debug_TotalExitSlice + Environment.NewLine;
            //MessageBox.Show(debugCheckMarkers);
            //debugCheckMarkers = "Debug_TotalEntrySlice: " + Environment.NewLine + markerDetectionData.Debug_TotalEntrySlice + Environment.NewLine;
            //MessageBox.Show(debugCheckMarkers);


            //Which marker is right and left - depandant on patient orientation
            string laterality1 = Constants.Hoyre;
            string laterality2 = Constants.Venstre;
            laterality1 = PlanExtension.CorrectLateralityToPatientOrientation(image.ImagingOrientation, laterality1); // If not one of four standard orientations, just give up and just use "First" and "Second" for now....
            laterality2 = PlanExtension.CorrectLateralityToPatientOrientation(image.ImagingOrientation, laterality2);


            //Warnings if markerposition out of tolerance
            markerDetectionData.TotalEntryDifferenceMmWithinTolerance = true;
            markerDetectionData.TotalExitDifferenceMmWithinTolerance = true;

            if (totalEntryDifferenceMm > Constants.ToleranceMarkerPositionDifferenceMm && markerDetectionData.TotalEntryMarkersDetected == true)
            {
                markerDetectionData.TotalEntryDifferenceMmWithinTolerance = false;
                markerDetectionData.Comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(markerDetectionData.Comment, laterality1 + " markør er over " + Constants.ToleranceMarkerPositionDifferenceMm + "mm avstand fra UserOrigin.");
            }

            if (totalExitDifferenceMm > Constants.ToleranceMarkerPositionDifferenceMm && markerDetectionData.TotalExitMarkersDetected == true)
            {
                markerDetectionData.TotalExitDifferenceMmWithinTolerance = false;
                markerDetectionData.Comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(markerDetectionData.Comment, laterality2 + " markør er over " + Constants.ToleranceMarkerPositionDifferenceMm + "mm avstand fra UserOrigin.");
            }

            if (markerDetectionData.TotalExitDifferenceMmWithinTolerance == false || markerDetectionData.TotalEntryDifferenceMmWithinTolerance == false)
            {
                markerDetectionData.Status = TrafikLys;
            }
            else { markerDetectionData.Status = Constants.Ok; }

             //Set results as strings, and adjust if no results:
             //Entry
            string totalEntryMarkersDetected = markerDetectionData.TotalEntryMarkersDetected.ToString();
            string totalMaxZSliceEntryDifferenceMm = Math.Round(markerDetectionData.TotalMaxZSliceEntryDifferenceMm, 1).ToString();
            string totalMaxYPositionEntry_DifferenceMm = Math.Round(markerDetectionData.TotalMaxYPositionEntry_DifferenceMm, 1).ToString();
            string totalEntryDifferenceMmString = markerDetectionData.TotalEntryDifferenceMm.ToString();
            string totalEntryDifferenceMmWithinTolerance = markerDetectionData.TotalEntryDifferenceMmWithinTolerance.ToString();
            //Exit
            string totalExitMarkersDetected = markerDetectionData.TotalExitMarkersDetected.ToString();
            string totalMaxZSliceExitDifferenceMm = Math.Round(markerDetectionData.TotalMaxZSliceExitDifferenceMm, 1).ToString();
            string totalMaxYPositionExit_DifferenceMm = Math.Round(markerDetectionData.TotalMaxYPositionExit_DifferenceMm, 1).ToString();
            string totalExitDifferenceMmString = markerDetectionData.TotalExitDifferenceMm.ToString();
            string totalExitDifferenceMmWithinTolerance = markerDetectionData.TotalExitDifferenceMmWithinTolerance.ToString();

            try { markerDetectionData.MarkerDetectionListCount = markerDetectionData.MarkerDetectionList.Count(); } catch { markerDetectionData.MarkerDetectionListCount = 0; }
            


            //Adjust output/warnings if markers not detected
            if (markerDetectionData.TotalEntryMarkersDetected == false || markerDetectionData.TotalExitMarkersDetected == false)
            {
                string markerId = "";
                if(markerDetectionData.TotalEntryMarkersDetected == false)
                {
                    markerId = GeneralExtension.AddStringWithSeparatorIfNotEmpty(markerId, laterality1 + " markør");
                    //Remove all data regarding distances as marker were not found

                    totalMaxZSliceEntryDifferenceMm = "-";
                    totalMaxYPositionEntry_DifferenceMm = "-";
                    totalEntryDifferenceMmString = "-";
                    totalEntryDifferenceMmWithinTolerance = "-";

                }
                if (markerDetectionData.TotalExitMarkersDetected == false)
                {
                    if (markerId != "") { markerId  = markerId + " og " + laterality2 + " markør"; }
                    else { markerId = markerId + laterality2 + " markør"; }


                    //Remove all data regarding distances as marker were not found
                    totalMaxZSliceExitDifferenceMm = "-";
                    totalMaxYPositionExit_DifferenceMm = "-";
                    totalExitDifferenceMmString = "-";
                    totalExitDifferenceMmWithinTolerance = "-";


                }

                markerDetectionData.Comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(markerDetectionData.Comment,  markerId + " ikke detektert.");
                markerDetectionData.Status = TrafikLys;
            }
            else { }


            //--------
            //Addition for countoured Markers, used in Protons:
            //Only used if a contoured marker exists
            bool markerStructureFound = false;
            Structure markerStructure = structureSet.Structures.FirstOrDefault(); //Declare variable.
            string markerZOutput = "";
            string originsPrint = "";
            foreach (Structure str in structureSet.Structures)
            {
                string strId = str.Id.ToLower();

                if (strId.Contains("zmarker") || strId.Contains("zmarkør") || strId.Contains("zmark"))
                {
                    if (str.HasSegment)
                    {
                        markerStructureFound = true;
                        markerStructure = str;
                    }
                }
            }

            if (markerStructureFound == true)
            {
                //Find ZMarker Center: (Must be corrected from the origin: bottom left corner to center of mesh)
                double markerXCenter = markerStructure.MeshGeometry.Bounds.Location.X + markerStructure.MeshGeometry.Bounds.SizeX / 2;
                double markerYCenter = markerStructure.MeshGeometry.Bounds.Location.Y + markerStructure.MeshGeometry.Bounds.SizeY / 2;
                double MarkerZCenter = markerStructure.MeshGeometry.Bounds.Location.Z + markerStructure.MeshGeometry.Bounds.SizeZ / 2;

                

                VVector ZMarker = new VVector(markerStructure.MeshGeometry.Bounds.Location.X, markerStructure.MeshGeometry.Bounds.Location.Y, markerStructure.MeshGeometry.Bounds.Location.Z);
                ZMarker = markerStructure.CenterPoint;
                ////Find meshgeometry extremal point positions in X-direction
                ////Entry
                //double X_Entry = markerStructure.MeshGeometry.Bounds.Location.X;
                ////Exit
                //double X_Exit = markerStructure.MeshGeometry.Bounds.Location.X + markerStructure.MeshGeometry.Bounds.SizeX;
                ////Find meshgeometry centerposition in Y-direction
                ////Entry
                //double Y_Entry = markerStructure.MeshGeometry.Bounds.Location.Y;
                ////Exit
                //double Y_Exit = markerStructure.MeshGeometry.Bounds.Location.Y + markerStructure.MeshGeometry.Bounds.SizeY;

                double distance = Math.Sqrt(Math.Pow(ZMarker.y - userOrigin.y, 2) + Math.Pow(ZMarker.z - userOrigin.z, 2));
                originsPrint = originsPrint + "'" + markerStructure.Id + "'-struktur senterpunkt xyz (mm): " + Math.Round(ZMarker.x) + " " + Math.Round(ZMarker.y) + " " + Math.Round(ZMarker.z) + Environment.NewLine;
                originsPrint = originsPrint + "User Origin xyz (mm): " + Math.Round(userOriginX) + " " + Math.Round(userOriginY) + " " + Math.Round(userOriginZ); //+ Environment.NewLine;


                markerZOutput = "'" + markerStructure.Id + "' struktur detektert!" + Environment.NewLine + " Struktur sin avstand i Y- og Z-retning til User Origin: " + Math.Round(distance,1) + "mm.";
                if(totalEntryMarkersDetected == Constants.False && totalExitMarkersDetected == Constants.False) //If Not detected with regular method
                {
                    //Override status
                    if (distance > Constants.ToleranceMarkerPositionDifferenceMm)
                    {
                        markerZOutput = markerZOutput + " ( > tol. " + Constants.ToleranceMarkerPositionDifferenceMm + "mm)";
                        markerDetectionData.Status = TrafikLys;
                    }
                    else
                    {
                        markerZOutput = markerZOutput + " ( < tol. " + Constants.ToleranceMarkerPositionDifferenceMm + "mm)";
                        markerDetectionData.Status = Constants.Ok;
                    }
                }

                //markerZOutput = markerZOutput + Environment.NewLine + originsPrint;
                //Status


                //KAN OGSÅ BARE HENTE UT DIPLAY VALUE TIL MARKØR DA USER ORIGIN ER  PER DEFINISJON 0, 0, 0!!! (Hvis du kan bruke ToDisplayValues.

            }
            //--------
            




            //Adjust data depandant on if markers are found or not:




            //Create a output
            string header = "Markør: " + Constants.StringSeparator + "Detektert:" +  Constants.StringSeparator + "ΔZ(mm):" + Constants.StringSeparator + "ΔY(mm):" + Constants.StringSeparator + "ΔTot(mm):" + Constants.StringSeparator + "Innenfor toleranse:";
            string marker1 = laterality1 + Constants.StringSeparator + totalEntryMarkersDetected + Constants.StringSeparator + totalMaxZSliceEntryDifferenceMm + Constants.StringSeparator + totalMaxYPositionEntry_DifferenceMm + Constants.StringSeparator +  totalEntryDifferenceMmString + Constants.StringSeparator + totalEntryDifferenceMmWithinTolerance;
            string marker2 = laterality2 + Constants.StringSeparator + totalExitMarkersDetected + Constants.StringSeparator + totalMaxZSliceExitDifferenceMm + Constants.StringSeparator + totalMaxYPositionExit_DifferenceMm + Constants.StringSeparator + totalExitDifferenceMmString + Constants.StringSeparator + totalExitDifferenceMmWithinTolerance;

            markerDetectionData.Output = markerDetectionData.Output + GeneralExtension.FormatString(-10, -12, header) + Environment.NewLine;
            markerDetectionData.Output = markerDetectionData.Output + GeneralExtension.FormatString(-10, -12, marker1) + Environment.NewLine;
            markerDetectionData.Output = markerDetectionData.Output + GeneralExtension.FormatString(-10, -12, marker2);
            //GeneralExtension.FormatString(-15, -9,
            //markerDetectionData.Output = markerDetectionData.Output + GeneralExtension.GenerateTableLine(4, 4, header) + Environment.NewLine;
            //markerDetectionData.Output = markerDetectionData.Output + GeneralExtension.GenerateTableLine(4, 4, marker1) + Environment.NewLine;
            //markerDetectionData.Output = markerDetectionData.Output + GeneralExtension.GenerateTableLine(4, 4, marker2);

            //Alternate answer if structure is found:
            if (markerStructureFound == true) 
            { 
                markerDetectionData.Output = originsPrint;
                markerDetectionData.Comment = markerZOutput;
            }

            //Write tolerance
            string tolerance = "Tolerance: " + Environment.NewLine + "<" + Constants.ToleranceMarkerPositionDifferenceMm + "mm" + Environment.NewLine + "<" + Constants.ToleranceMarkerPositionDifferenceMm + "mm";
            markerDetectionData.Tolerance = tolerance;



            //Entry








            return markerDetectionData;

            //foreach (SegmentProfilePoint point in segmentProfile)
            //{
            //    VVector position = point.Position;

            //    int slice = GetSlice(position.z,structureSet);

            //    if (point.Value == false)
            //    {
            //        //first point outside structure

            //        break;
            //    }
            //}


            //----------------------
            //IEnumerable<double> HUprofileInsideBody = HUprofile.Where((x, index) => bodyProfile[index]); // portion of the HU array that is inside body
            //double scalingFactor = HUprofileInsideBody.ToList().Select(x => x + 1000).Average() / 1000;
            //structureSet.Structures.Single(x => x.DicomType == bodyID).GetSegmentProfile(start, stop, bodyProfileHigherResolution);
            //int count = 0;
            //foreach (bool value in bodyProfileHigherResolution)
            //{
            //    if (value) count++;
            //}
            //string profile = "";
            //foreach (double x in HUprofile.Where((x, index) => bodyProfile[index]).Where(x => !double.IsNaN(x)))
            //{
            //    profile += x.ToString() + ",";
            //}
            ////----------------------
            ///

        }

        public static MarkerDetection GetMarkerPositionsAndValues(MarkerDetection markerDetection, MarkerDetectionData markerDetectionData, StructureSet structureSet)
        {
            //Set variables
            Image image = structureSet.Image;
            bool bodyEntryFound = markerDetection.BodyEntryFound; 
            bool bodyExitFound = markerDetection.BodyExitFound;

            int pixelIndex_BodyEntry_X = markerDetection.PixelIndex_BodyEntry_X; //First cooridnate of body along profile
            int pixelIndex_BodyExit_X = markerDetection.PixelIndex_BodyExit_X; //last cooridnate of body along profile

            double[,] voxelPlaneCorrected = markerDetection.VoxelPlane;
            int pixelNumber_Y_To_Search = markerDetection.Y_PixelPosition; //int pixelNumber_UserOrigin_Y = markerDetectionData.UserOriginY_Position_pixelnumber;




            //variables we must define:
            int pixelIndex_BodyEntry_X_StartSearch = 0;
            int pixelIndex_BodyEntry_X_StopSearch = 0;
            int pixelIndex_BodyExit_X_StartSearch = 0;
            int pixelIndex_BodyExit_X_StopSearch = 0;


            //-----------------------
            //Search for marker in area close to body entrance and exit along X segment:
            //-----------------------
            if (bodyEntryFound == true && bodyExitFound == true) //If body exit and entry exists
            {

                //------------
                //Define start and stop of search, validate that it will not crash
                //------------

                // start index X Body Entry
                if (pixelIndex_BodyEntry_X >= Constants.NumberOfPixelsOutsideBodySearch)
                {
                    pixelIndex_BodyEntry_X_StartSearch = pixelIndex_BodyEntry_X - Constants.NumberOfPixelsOutsideBodySearch;
                }
                else { pixelIndex_BodyEntry_X_StartSearch = 0; }
                //-----

                // stop index X Body Entry
                if (pixelIndex_BodyEntry_X + Constants.NumberOfPixelsInsideBodySearch < image.XSize) //Changed <= to < so we dont go out of index
                {
                    pixelIndex_BodyEntry_X_StopSearch = pixelIndex_BodyEntry_X + Constants.NumberOfPixelsInsideBodySearch;
                }
                else { pixelIndex_BodyEntry_X_StopSearch = image.XSize-1; }  //Changed to XSize-1 so we dont go out of index
                //-----


                // start index X Body Exit
                if (pixelIndex_BodyExit_X - Constants.NumberOfPixelsInsideBodySearch >= 0)
                {
                    pixelIndex_BodyExit_X_StartSearch = pixelIndex_BodyExit_X - Constants.NumberOfPixelsInsideBodySearch;
                }
                else { pixelIndex_BodyExit_X_StartSearch = 0; }
                //-----

                // End index X Body Exit
                if (pixelIndex_BodyExit_X + Constants.NumberOfPixelsOutsideBodySearch < image.XSize) //Changed <= to < so we dont go out of index
                {
                    pixelIndex_BodyExit_X_StopSearch = pixelIndex_BodyExit_X + Constants.NumberOfPixelsOutsideBodySearch;
                }
                else { pixelIndex_BodyExit_X_StopSearch = image.XSize-1; } //Changed to XSize-1 so we dont go out of index
                                                                           //-----
                                                                           //----------------

                //------------
                //Do the search in BodyEntry:
                //------------

                double maxValueEntry = -99999; //Could be negative
                int indexMaxValueEntry = 0;
                bool markerFoundEntry = false;
                for (int x = pixelIndex_BodyEntry_X_StartSearch; x <= pixelIndex_BodyEntry_X_StopSearch; x++)
                {
                    double seachHUValue = voxelPlaneCorrected[x, pixelNumber_Y_To_Search]; //Do the HU-calculation here instead of doing it in advance! See next line:
                    seachHUValue = image.VoxelToDisplayValue((int)voxelPlaneCorrected[x, pixelNumber_Y_To_Search]);
                    //voxelPlaneCorrected[x, y] = image.VoxelToDisplayValue(voxelPlaneRaw[x, y])

                    if (seachHUValue > maxValueEntry)
                    {
                        maxValueEntry = seachHUValue;
                        indexMaxValueEntry = x;
                        if (maxValueEntry > Constants.MarkerFoundCriteriaHUValue)
                        {
                            markerFoundEntry = true;
                        }
                    }
                }
                //debugSegment = debugSegment + "maxValueEntry: " + maxValueEntry + Environment.NewLine;
                //debugSegment = debugSegment + "indexMaxValueEntry: " + indexMaxValueEntry + Environment.NewLine;
                //debugSegment = debugSegment + "imarkerFoundEntry: " + markerFoundEntry + Environment.NewLine;

                //------------
                //Do the search in BodyExit:
                //------------
                double maxValueExit = -99999;//Could be negative
                int indexMaxValueExit = 0;
                bool markerFoundExit = false;
                for (int x = pixelIndex_BodyExit_X_StartSearch; x <= pixelIndex_BodyExit_X_StopSearch; x++)
                {
                    double seachHUValue = voxelPlaneCorrected[x, pixelNumber_Y_To_Search]; //Do the HU-calculation here instead of doing it in advance! See next line:
                    seachHUValue = image.VoxelToDisplayValue((int)voxelPlaneCorrected[x, pixelNumber_Y_To_Search]);
                    if (seachHUValue > maxValueExit)
                    {
                        maxValueExit = seachHUValue;
                        indexMaxValueExit = x;
                        if (maxValueExit > Constants.MarkerFoundCriteriaHUValue)
                        {
                            markerFoundExit = true;
                        }
                    }

                }
                //debugSegment = debugSegment + "maxValueExit: " + maxValueExit + Environment.NewLine;
                //debugSegment = debugSegment + "indexMaxValueExit: " + indexMaxValueExit + Environment.NewLine;
                //debugSegment = debugSegment + "imarkerFoundExit: " + markerFoundExit + Environment.NewLine;

                //Set result:
                markerDetection.IndexMaxValueEntry = indexMaxValueEntry;
                markerDetection.MaxValueEntry = maxValueEntry;
                markerDetection.MarkerFoundEntry = markerFoundEntry;
                markerDetection.IndexMaxValueExit = indexMaxValueExit;
                markerDetection.MaxValueExit = maxValueExit;
                markerDetection.MarkerFoundExit = markerFoundExit;

                //Search in x -direction:
                markerDetection.pixelIndex_BodyEntry_X_StartSearch = pixelIndex_BodyEntry_X_StartSearch;
                markerDetection.pixelIndex_BodyEntry_X_StopSearch = pixelIndex_BodyEntry_X_StopSearch;
                markerDetection.pixelIndex_BodyEntry_X_StartSearch = pixelIndex_BodyEntry_X_StartSearch;
                markerDetection.pixelIndex_BodyExit_X_StopSearch = pixelIndex_BodyExit_X_StopSearch;

                //Difference expressed in slices and pixels
                markerDetection.Y_position_difference_from_UserOrigin_Entry = markerDetection.Y_PixelPosition - markerDetectionData.UserOriginY_Position_pixelnumber;
                markerDetection.Y_position_difference_from_UserOrigin_Exit = markerDetection.Y_PixelPosition - markerDetectionData.UserOriginY_Position_pixelnumber;
                markerDetection.Z_slice_difference_from_UserOrigin_Entry = markerDetection.Z_slice - markerDetectionData.UserOriginZ_slice;
                markerDetection.Z_slice_difference_from_UserOrigin_Exit = markerDetection.Z_slice - markerDetectionData.UserOriginZ_slice;
                //Difference expressed in mm happens only in final analysis


            }

            return markerDetection;
        }
        public static MarkerDetection GetBodyEntryExitPositions(MarkerDetection markerDetection, MarkerDetectionData markerDetectionData, Structure body, StructureSet structureSet, PatientContext patientContext)
        {
            Image image = structureSet.Image;
            //Initialize variables
            BitArray bufferBodyStructure = new BitArray(image.XSize); // new BitArray(1000); //This can be used to store false/true if a this point is inside a structure
            VVector start = markerDetection.Start; //VVector start = markerDetectionData.Start;
            VVector stop = markerDetection.Stop; //VVector stop = markerDetectionData.Stop;
            double[,] voxelPlaneCorrected = markerDetection.VoxelPlane; // new double[image.XSize, image.YSize];
            int pixelNumber_Y = markerDetection.Y_PixelPosition;
            //----



            //MessageBox.Show("inside GetBodyEntry...: " + Environment.NewLine + "y_pixel: " + pixelNumber_Y + Environment.NewLine + "z_pixel: " + markerDetection.Z_slice + Environment.NewLine + "y_VVector: " + start.y);

            int pixelIndex_BodyEntry_X = 0; //This is what we really want, position where we enter body starting from direction X minus.
            int pixelIndex_BodyExit_X = 0; //This is what we really want, position where we exit body starting from direction X minus.
            bool bodyEntryFound = false; //Assume we start outside body
            bool bodyExitFound = false;

            //Debug
            string voxelsString = "";
            string addString = "";

            SegmentProfile segmentProfile = body.GetSegmentProfile(start, stop, bufferBodyStructure); //true and false dependant on where it is inside or outside body, is stored in the buffer.
            bool insideBody = false; //is position [x] inside body, true/false.
            bool lastInsideBody = false; //was [x-1] inside body, true false //What was last status, used to identify if there is change of status.

            for (int x = 0; x < image.XSize; x++)
            {
                int corrected_X = (int)Math.Round((x * image.XRes), 0); //Needs to correct array coordinate for resolution of pixels. Lets say we have resolution of 1.2mm. Pixel number 10 will have corrected coordinate of 10 x 1.2  = 12
                if (corrected_X > image.XSize - 1) { corrected_X = image.XSize - 1; }
                if (corrected_X < 0) { corrected_X = 0; }  

                insideBody = bufferBodyStructure[x]; //insideBody = bufferBodyStructure[corrected_X]; //Apparantly did not need the correxted_X, thought one was in vVector coordinates (mm) and the other in pixels...

                //Debug: Adding change marks for debugging
                if (insideBody == true)
                {
                    addString = "**(" + x + ")";
                }
                else if (insideBody == false)
                {
                    addString = "##(" + x + ")";
                }

                ////First change (Body Entry) - going from bein outside body to being inside body.
                if ((insideBody == true && lastInsideBody == false && bodyEntryFound == false) && bodyExitFound == false) //first time we go from being outside body to bein inside body.
                {
                    addString = " !!!!!" + Environment.NewLine + Environment.NewLine + addString;
                    bodyEntryFound = true;
                    pixelIndex_BodyEntry_X = x; //x; //The index of the pixel (in the HoundsField Array) where we cross into Body.
                    bodyExitFound = false; //Reset, as we have reentered the body

                }
                //    //second change (Body Exit), going from being inside body to bein outside body
                if (insideBody == false && lastInsideBody == true && bodyEntryFound == true) //After having been inside, changes to outside, (and have allready been inside body - do not really need that)
                {
                    addString =  " !!!!! " + addString + Environment.NewLine + Environment.NewLine;
                    bodyExitFound = true;
                    pixelIndex_BodyExit_X = x;  //x; //The index of the pixel (in the HoundsField Array) where we cross out of the Body again.
                }

                //Debugging //Add voxel to string (incuding marks)
                //voxelsString = voxelsString + voxelPlaneCorrected[x, pixelNumber_Y].ToString() + addString + "  |||  "; //voxelsString = voxelsString + voxelPlaneCorrected[x, pixelNumber_UserOrigin_Y].ToString() + addString + "  |||  ";
                
                int stringlength = x.ToString().Length;
                if (stringlength > 2)
                {
                    if (x.ToString().Substring(stringlength - 2) == "00") { voxelsString = voxelsString + Environment.NewLine + Environment.NewLine; } // add line shift for every 100, for readability.
                }

                lastInsideBody = insideBody; //Setting last status, used to identify if there is change of status. Must be at end of loop.
            }

            
            markerDetection.BodyExitFound = bodyExitFound;
            markerDetection.BodyEntryFound = bodyEntryFound;
            markerDetection.PixelIndex_BodyEntry_X = pixelIndex_BodyEntry_X;
            markerDetection.PixelIndex_BodyExit_X = pixelIndex_BodyExit_X;

            VVector startToUser = start;
            VVector stopToUser = stop;
            if (patientContext.SanityLevel > Constants.SanityLevelPlanExist)
            {
                startToUser = image.DicomToUser(start, patientContext.ChosenPlan);
                stopToUser = image.DicomToUser(stop, patientContext.ChosenPlan);
            }
            markerDetection.Start_Converted = startToUser;
            markerDetection.Stop_Converted = stopToUser;


            //Debug
            voxelsString =  voxelsString + Environment.NewLine + Environment.NewLine + "user origin: " + Math.Round(markerDetectionData.X_UserOrigin, 1) + " " + Math.Round(markerDetectionData.Y_UserOrigin, 1) + " " + Math.Round(markerDetectionData.Z_UserOrigin, 1) + Environment.NewLine;
            voxelsString = voxelsString + "image origin: " + Math.Round(markerDetectionData.X_ImageOrigin, 1) + " " + Math.Round(markerDetectionData.Y_ImageOrigin, 1) + " " + Math.Round(markerDetectionData.Z_ImageOrigin, 1) + Environment.NewLine;
            voxelsString =  voxelsString + "user origin converted: " + Math.Round(markerDetectionData.X_UserOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Y_UserOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Z_UserOrigin_Converted, 1) + Environment.NewLine;
            voxelsString = voxelsString + "image origin converted: " + Math.Round(markerDetectionData.X_ImageOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Y_ImageOrigin_Converted, 1) + " " + Math.Round(markerDetectionData.Z_ImageOrigin_Converted, 1) + Environment.NewLine;

            voxelsString = voxelsString + "start: " + Math.Round(start.x, 1) + " " + Math.Round(start.y, 1) + " " + Math.Round(start.z, 1) + Environment.NewLine;
            voxelsString = voxelsString + "stop: " + Math.Round(stop.x, 1) + " " + Math.Round(stop.y, 1) + " " + Math.Round(stop.z, 1) + Environment.NewLine;
            voxelsString =  voxelsString + "start conv.: " + Math.Round(startToUser.x,1) + " " + Math.Round(startToUser.y,1)+ " " + Math.Round(startToUser.z,1) + Environment.NewLine;
            voxelsString = voxelsString + "stop conv.: " + Math.Round(stopToUser.x,1) + " " + Math.Round(stopToUser.y,1) + " " + Math.Round(stopToUser.z,1) + Environment.NewLine; 
            voxelsString = voxelsString + "bodyExitFound " + bodyExitFound + Environment.NewLine;
            voxelsString = voxelsString + "BodyEntryFound " + bodyEntryFound + Environment.NewLine;
            voxelsString = voxelsString + "PixelIndex_BodyEntry_X " + pixelIndex_BodyEntry_X + Environment.NewLine;
            voxelsString = voxelsString + "PixelIndex_BodyExit_X " + pixelIndex_BodyExit_X + Environment.NewLine;
            voxelsString = voxelsString + "X_Resolution_mm: " + markerDetectionData.X_Resolution_mm + Environment.NewLine;
            voxelsString = voxelsString + "Y_Resolution_mm: " + markerDetectionData.Y_Resolution_mm + Environment.NewLine;
            voxelsString = voxelsString + "Z_Resolution_mm: " + markerDetectionData.Z_Resolution_mm + Environment.NewLine;
            voxelsString = voxelsString + "Z_slice: " + markerDetection.Z_slice + Environment.NewLine;
            voxelsString = voxelsString + "Z_VVector: " + markerDetection.Z_VVector + Environment.NewLine;
            voxelsString = voxelsString + "Y_PixelPosition: " + markerDetection.Y_PixelPosition + Environment.NewLine;

            voxelsString = voxelsString + GeneralExtension.ToBitString(bufferBodyStructure);
            markerDetection.DebugMarker = voxelsString;

            //MessageBox.Show(voxelsString);
            //If user origin, then print it:
            //if ((start.x == markerDetectionData.Start.x && start.y == markerDetectionData.Start.y && start.z == markerDetectionData.Start.z) && (stop.x == markerDetectionData.Stop.x && stop.y == markerDetectionData.Stop.y && stop.z == markerDetectionData.Stop.z))
            //{
                //MessageBox.Show(voxelsString);
            //}


                return markerDetection;
        }

        public static int GetSlice(double z, StructureSet SS)
        {
            var imageRes = SS.Image.ZRes;
            return Convert.ToInt32((z - SS.Image.Origin.z) / imageRes);
        }

        public static int Convert_Y_Coordinate_VVector_To_pixelNumber(double y0, StructureSet SS)
        {
            double dy = (y0 - SS.Image.Origin.y) / (SS.Image.YRes * SS.Image.YDirection.y);
            return (int)Math.Round(dy);
        }
        public static int Convert_X_Coordinate_VVector_To_pixelNumber(double x0, StructureSet SS)
        {
            double dx = (x0 - SS.Image.Origin.x) / (SS.Image.XRes * SS.Image.YDirection.x);
            return (int)Math.Round(dx);
        }

        public static int Get_VVector_X_Coordinate_From_Pixel_Coordinate(double pixelNumber, StructureSet SS)
        {
            double vVectorCoordinate = pixelNumber* (SS.Image.YRes * SS.Image.YDirection.x) + SS.Image.Origin.x;
            return (int)Math.Round(vVectorCoordinate);
        }

        private static double GetHUAtLocation(Image image, double x0, double y0, double z0)
        {
            int[,] buffer = new int[image.XSize, image.YSize];
            double[,] hu = new double[image.XSize, image.YSize];

            //Calculate the voxel locations (integers) from actual 3D spatial coordinates
            var dx = (x0 - image.Origin.x) / (image.XRes * image.XDirection.x);
            var dy = (y0 - image.Origin.y) / (image.YRes * image.YDirection.y);
            var dz = (z0 - image.Origin.z) / (image.ZRes * image.ZDirection.z);

            //Fill buffer with voxels from current slice
            image.GetVoxels((int)dz, buffer);
            for (int x = 0; x < image.XSize; x++)
            {
                for (int y = 0; y < image.YSize; y++)
                {
                    //Set HU from "voxel value" - have to convert
                    hu[x, y] = image.VoxelToDisplayValue(buffer[x, y]);
                }
            }
            return hu[(int)Math.Round(dx), (int)Math.Round(dy)];
        }










    

        public static double[,] VoxelsOnSlice(Structure str, Image image, int sliceZ)
        {
            var buffer = new int[image.XSize, image.YSize];
            var hu = new double[image.XSize, image.YSize];

            var contour = str.GetContoursOnImagePlane(sliceZ);
            if (contour.Count() > 0)
            {
                image.GetVoxels(sliceZ, buffer);
                for (var x = 0; x < image.XSize; x++)
                    for (var y = 0; y < image.YSize; y++)
                    {
                        var dx = (x * image.XRes * image.XDirection + image.Origin).x;
                        var dy = (y * image.YRes * image.YDirection + image.Origin).y;
                        var dz = (sliceZ * image.ZRes * image.ZDirection + image.Origin).z;
                        var insideSegment = str.IsPointInsideSegment(new VVector(dx, dy, dz));
                        hu[x, y] = insideSegment ? image.VoxelToDisplayValue(buffer[x, y]) : double.NaN;
                    }
            }
            return hu;
        }

        private static bool CheckForOverlap(Structure firstStructure, Structure secondStructure, StructureSet structureSet) // PlanSetup planSetup
        {
            bool isOverlapping = false;
            int slicesInImage = structureSet.Image.ZSize;
            List<VVector[][]> firstStructureCoords = new List<VVector[][]>();
            for (int i = 0; i < slicesInImage; i++) // image z slices are stored in DICOM format so starts at 0. To iterate through the 3D data set start at 0 and count up to the total number of slices in the image.
            {
                VVector[][] firstStructureCoordsOnZSlice = firstStructure.GetContoursOnImagePlane(i);
                if (firstStructureCoordsOnZSlice.GetLength(0) > 0) // checks if first dimension of the rectangular VVector[][] array contains a value to add to list
                {
                    firstStructureCoords.Add(firstStructureCoordsOnZSlice);
                }
            }
            foreach (var vVectorJaggedArray in firstStructureCoords)
            {
                foreach (var vVectorArrays in vVectorJaggedArray)
                {
                    foreach (var vVector in vVectorArrays)
                    {
                        isOverlapping = secondStructure.IsPointInsideSegment(vVector);
                        if (isOverlapping)
                        {
                            return isOverlapping;
                        }
                    }
                }
            }
            return isOverlapping;
        }







        //Kontrollere strukturer for maxlengde:
        public static string CheckStructureIds(StructureSet ss, string wantedId)
        {
            var maxLength = 16;
            if (ss.Structures.Any(e => e.Id.ToLower() == wantedId.ToLower()))
            {
                wantedId = LimitChars(new Random().Next(0, 9).ToString() + "_" + wantedId, maxLength);
            }
            return wantedId;
        }
        public static string LimitChars(string wantedId, int maxLength)
        {
            return wantedId.Length <= maxLength ? wantedId : wantedId.Substring(0, maxLength);

        }

        public static string DistanceFromCouchSurfaceIsosenter(ExternalPlanSetup plan)
        {
            string avstandString = "";
            double avstandIsoTIlBordDouble = 0;
            double isosenterposisjon_Y = 0;
            double bordposisjon_y = 0;
            string bordnavnString = "";

            //Definerer forste felt for aa finne isosenter. Tar ikke hensyn til flere isosenter:
            Beam b = plan.Beams.FirstOrDefault();

            // Finner Couch-strukturnavn:
            bordnavnString = GetCouchSurfaceID(plan.StructureSet);


            // ---- Gjore et isosenter om til en VVektor? ---- Funket ikke helt.
            //Point3D refPoint3D = new Point3D(b.IsocenterPosition.x, b.IsocenterPosition.y, b.IsocenterPosition.z);
            ////Endre til en VVector:
            //Structure isosenter = (Vector3D)refPoint3D;

            // --- enkelere løsning ----:

            //Y-posisjon til isosenter (Sjekk om det må korrigeres for pasientanatomi): 
            isosenterposisjon_Y = b.IsocenterPosition.y / 10;

            //Y-posisjon til toppen av Couch-struktur (bruker mesh geometry):
            Structure bordstruktur = plan.StructureSet.Structures.Where(o => o.Id == bordnavnString).FirstOrDefault();
            Rect3D bounds_bord_Rect3d;
            if (bordstruktur != null)
            {
                bounds_bord_Rect3d = bordstruktur.MeshGeometry.Bounds;
                //Setter bordposisjon (topp av bordet)
                bordposisjon_y = bounds_bord_Rect3d.Location.Y / 10;




                //avstand til bunn av bordet
            }

            //Avstand i cm, kun positivt tall:
            avstandIsoTIlBordDouble = System.Math.Abs(Math.Round(isosenterposisjon_Y - bordposisjon_y, 3));
            avstandString = avstandIsoTIlBordDouble.ToString();


            MessageBox.Show("Bordposisjon y i cm: " + bordposisjon_y + Environment.NewLine + "Iso posisjon y i cm: " + isosenterposisjon_Y + Environment.NewLine + "avstand y i cm: " + avstandString);

            return avstandString;
        }

        public static CheckPoint CheckIfUserOriginPlaced(CheckPoint s, StructureSet structureSet, PatientContext patientContext) //Korrigert for fiksering inkludert i bordstrukturen
        {

            //----------------
            // Is user origin placed at all
            //----------------

            string kommentar = "";
            string debug = "";
            string _sjekkstatus = "";
            var io = structureSet.Image.Origin;
            var uo = structureSet.Image.UserOrigin;

            debug = debug + "User origin:" + Environment.NewLine + "X: " + uo.x + Environment.NewLine + "Y: " + uo.y + Environment.NewLine + "Z: " + uo.z + Environment.NewLine;
            debug = debug + "Image origin:" + Environment.NewLine + "X: " + io.x + Environment.NewLine + "Y: " + io.y + Environment.NewLine + "Z: " + io.z;


            if (structureSet.Image.HasUserOrigin)
            {
                debug = debug + Environment.NewLine + "UserOrigin eksisterer.";

                if ((uo.x == 0) && (uo.y == 0) && (uo.x == 0)) // Mulig detter er ekvivalent med "HasUserOrigin". Beholder for nå.
                {
                    kommentar = kommentar + "UserOrigin er ikke flyttet. ";
                    _sjekkstatus = Constants.Warning;
                }
                else //UserOrigin eksisterer og har blitt endret. Ingen garanti for om det er satt fornuftig.
                {
                    // kommentar = kommentar + "UserOrigin er satt. ";
                    _sjekkstatus = Constants.Ok;
                }

            }
            else
            {
                kommentar = kommentar + "UserOrigin ikke satt. ";
                debug = debug + Environment.NewLine + "UserOrigin ikke satt. ";
                _sjekkstatus = Constants.Warning;
            }
            s.CheckComment = kommentar;
            s.CheckDebug = debug;
            //s.SjekkResultatVerdi = "";
            s.CheckStatus = _sjekkstatus;
            return s;
        }

        public static CheckPoint CheckUserOrigin(CheckPoint s, StructureSet structureSet, PatientContext patientContext) //Korrigert for fiksering inkludert i bordstrukturen
        {

            //----------------
            // Is user origin placed at all
            //----------------

            string kommentar = "";
            string debug = "";
            string _sjekkstatus = "";
            var io = structureSet.Image.Origin;
            var uo = structureSet.Image.UserOrigin;

            debug = debug + "User origin:" + Environment.NewLine + "X: " + uo.x + Environment.NewLine + "Y: " + uo.y + Environment.NewLine + "Z: " + uo.z + Environment.NewLine;
            debug = debug + "Image origin:" + Environment.NewLine + "X: " + io.x + Environment.NewLine + "Y: " + io.y + Environment.NewLine + "Z: " + io.z;


            if (structureSet.Image.HasUserOrigin)
            {
                debug = debug + Environment.NewLine + "UserOrigin eksisterer.";

                if ((uo.x == 0) && (uo.y == 0) && (uo.x == 0)) // Mulig detter er ekvivalent med "HasUserOrigin". Beholder for nå.
                {
                    kommentar = kommentar + "UserOrigin er ikke flyttet. ";
                    _sjekkstatus = Constants.Warning;
                }
                else //UserOrigin eksisterer og har blitt endret. Ingen garanti for om det er satt fornuftig.
                {
                    //----------------------------- COMMENT THIS AWAY TO RESTORE ---------------------------------------------------
                    kommentar = kommentar + "UserOrigin er satt. ";
                    _sjekkstatus = Constants.Ok; //Earlier we were satisfied with this
                    //----------------------------- COMMENT THIS AWAY TO RESTORE ---------------------------------------------------
                }

            }
            else
            {
                kommentar = kommentar + "UserOrigin er ikke blitt manuelt endret. UserOrigin = ImageOrigin! Lite sannsynlig. ";
                debug = debug + Environment.NewLine + "UserOrigin ikke satt. ";
                _sjekkstatus = Constants.Warning;
            }
            s.CheckComment = kommentar;
            s.CheckDebug = debug;
            s.CheckResultValue = ""; //----------------------------- COMMENT THIS AWAY TO RESTORE ---------------------------------------------------
            s.CheckStatus = _sjekkstatus;

            //----------------

            //----------------
            // Are the markers detected where user origin is?
            //----------------
            //Retrieves a segment through user origin and attemt to detect markers close to where the segment line crosses the body contour.
            //Checks this also with different z- and y-positions to see if another position fits better. 
            //Gives distance to "best" match. Of course "best" here is just where the HU-values are highest, not necessarily correct


            //Temporarily deactivated because we changed how we have markers to only using one centrally located marker .... :(
            //----------------------------- UNCOMMENT THIS TO RESTORE ---------------------------------------------------
            //MarkerDetectionData markerDetectionData = StructureExtension.CheckMarkers("x", patientContext.BodyId, s.CheckTrafficLight, patientContext.ChosenStructureSet, patientContext, s);
            ////Set result
            //string markerDetectionDebug = GeneralExtension.ClassToString(markerDetectionData);
            //if (markerDetectionData.Comment != "") { s.CheckComment = GeneralExtension.AddStringWithNewLineIfNotEmpty(s.CheckComment, markerDetectionData.Comment); }
            ////s.CheckDebug = GeneralExtension.AddStringWithNewLineIfNotEmpty(s.CheckDebug , markerDetectionDebug); //Removed Debug as it is too much - clutters up the ToolTip-window
            //s.CheckTemplateValue = GeneralExtension.AddStringWithNewLineIfNotEmpty(s.CheckTemplateValue, markerDetectionData.Tolerance);
            //s.CheckStatus = markerDetectionData.Status;
            //s.CheckResultValue = markerDetectionData.Output;

            ////CSV result Entry
            //if (markerDetectionData.TotalEntryMarkersDetected == true)
            //{
            //    s.CheckResultValueCSV = s.CheckResultValueCSV + markerDetectionData.TotalEntryMarkersDetected.ToString() + ":";
            //    s.CheckResultValueCSV = s.CheckResultValueCSV + markerDetectionData.TotalEntryDifferenceMm.ToString();
            //}
            //else
            //{
            //    s.CheckResultValueCSV = s.CheckResultValueCSV + markerDetectionData.TotalEntryMarkersDetected.ToString() + ":-";
            //}
            ////Separatr
            //s.CheckResultValueCSV = s.CheckResultValueCSV + Constants.StringSeparator;
            ////CSV result Exit
            //if (markerDetectionData.TotalExitMarkersDetected == true)
            //{
            //    s.CheckResultValueCSV = s.CheckResultValueCSV + markerDetectionData.TotalExitMarkersDetected.ToString() + ":";
            //    s.CheckResultValueCSV = s.CheckResultValueCSV + markerDetectionData.TotalExitDifferenceMm.ToString();
            //}
            //else
            //{
            //    s.CheckResultValueCSV = s.CheckResultValueCSV + markerDetectionData.TotalExitMarkersDetected.ToString() + ":-";
            //}

            //----------------------------- UNCOMMENT THIS TO RESTORE ---------------------------------------------------

            //----------------


            return s;
        }

        public static string DistanceFromCouchToIsosenter_Corrected(ExternalPlanSetup plan) //Korrigert for fiksering inkludert i bordstrukturen
        {
            string avstandString = "";
            double avstandIsoTIlBordDouble = 0;
            double isosenterposisjon_Y = 0;
            double bordposisjon_y_topp = 0;
            double bordposisjon_y_bunn = 0;
            double tykkelseBordDouble = 0;
            string bordnavnString = "";
            string debugmessage = "";

            //Definerer forste felt for aa finne isosenter. Tar ikke hensyn til flere isosenter:
            Beam b = plan.Beams.FirstOrDefault();

            StructureSet structureSet = plan.StructureSet;

            // Finner Couch-strukturnavn:
            bordnavnString = StructureExtension.GetCouchSurfaceID(plan.StructureSet);


            // ---- Gjore et isosenter om til en VVektor? ---- Funket ikke helt.
            //Point3D refPoint3D = new Point3D(b.IsocenterPosition.x, b.IsocenterPosition.y, b.IsocenterPosition.z);
            ////Endre til en VVector:
            //Structure isosenter = (Vector3D)refPoint3D;

            // --- enkelere løsning ----:

            //Y-posisjon til isosenter i cm: 
            isosenterposisjon_Y = b.IsocenterPosition.y / 10;

            //Y-posisjon til toppen av Couch-struktur (bruker mesh geometry):
            Structure bordstruktur = plan.StructureSet.Structures.Where(o => o.Id == bordnavnString).FirstOrDefault();
            Rect3D bounds_bord_Rect3d;
            if (bordstruktur != null)
            {
                bounds_bord_Rect3d = bordstruktur.MeshGeometry.Bounds;
                //Setter bordposisjon, topp av bordet, i cm:
                bordposisjon_y_topp = bounds_bord_Rect3d.Location.Y / 10;
                //storrelse på bordstrukturen, også hvis den inneholder ekstra fiksering på toppen (cm):
                tykkelseBordDouble = MarginsExtension.FindStructureRect3D_size(bordnavnString, "y", structureSet) / 10;
                //Setter bordposisjon, bunn av bordet, i cm:
                bordposisjon_y_bunn = bordposisjon_y_topp + tykkelseBordDouble; //enda lengre avstand
            }

            //Avstand i cm fra isosenter til bunn av bordet (positivt tall), trekker deretter fra tykkelsen på bord. Faar da astand fra isosenter til topp av bordet (positivt tall):
            avstandIsoTIlBordDouble = System.Math.Round(System.Math.Abs(isosenterposisjon_Y - bordposisjon_y_bunn) - Constants.ThicknessOfCouch_CM, 3);
            avstandString = avstandIsoTIlBordDouble.ToString();

            debugmessage = "Bordposisjon bunn av bord y, i cm: " + bordposisjon_y_bunn + Environment.NewLine + "Iso posisjon y i cm: " + Math.Round(isosenterposisjon_Y, 3) + Environment.NewLine + "bordposisjon_y_topp: " + Math.Round(bordposisjon_y_topp, 3) + Environment.NewLine + "bordposisjon_y_bunn: " + Math.Round(bordposisjon_y_bunn, 3) + Environment.NewLine + "avstand isosenter til bordtopp i cm (y-retning): " + avstandString;
            //MessageBox.Show(debugmessage);

            return avstandString;
        }

        public static CheckPoint CheckDistanceFromCouchToIsosenter_Corrected(ExternalPlanSetup plan, CheckPoint s) //Korrigert for fiksering inkludert i bordstrukturen
        {
            string avstandString = "";
            double avstandIsoTIlBordDouble = 0;
            double isosenterposisjon_Y = 0;
            double bordposisjon_y_topp = 0;
            double bordposisjon_y_bunn = 0;
            double tykkelseBordDouble = 0;
            string bordnavnString = "";
            string debugmessage = "";
            string kommentar = "";

            //Definerer forste felt for aa finne isosenter. Tar ikke hensyn til flere isosenter:
            Beam b = plan.Beams.FirstOrDefault();

            // Finner Couch-strukturnavn:
            bordnavnString = GetCouchSurfaceID(plan.StructureSet);


            // --- enkelere løsning ----:

            //Y-posisjon til isosenter i cm: 
            isosenterposisjon_Y = b.IsocenterPosition.y / 10;

            //Y-posisjon til toppen av Couch-struktur (bruker mesh geometry):
            Structure bordstruktur = plan.StructureSet.Structures.Where(o => o.Id == bordnavnString).FirstOrDefault();
            Rect3D bounds_bord_Rect3d;
            if (bordstruktur != null)
            {
                bounds_bord_Rect3d = bordstruktur.MeshGeometry.Bounds;
                //Setter bordposisjon, topp av bordet, i cm:
                bordposisjon_y_topp = bounds_bord_Rect3d.Location.Y / 10;
                //storrelse på bordstrukturen, også hvis den inneholder ekstra fiksering på toppen (cm):
                tykkelseBordDouble = MarginsExtension.FindStructureRect3D_size(bordnavnString, "y", plan.StructureSet) / 10;  // .Bounds.SizeY
                //Setter bordposisjon, bunn av bordet, i cm:
                bordposisjon_y_bunn = bordposisjon_y_topp + tykkelseBordDouble; //enda lengre avstand
            }
            else
            {
                debugmessage = debugmessage + "Bord ikke detektert. ";
                kommentar = kommentar + "Bord ikke detektert. ";
            }

            //Avstand i cm fra isosenter til bunn av bordet (positivt tall), trekker deretter fra tykkelsen på bord. Faar da astand fra isosenter til topp av bordet (positivt tall):
            if (bordstruktur != null)
            {
                avstandIsoTIlBordDouble = System.Math.Round(System.Math.Abs(isosenterposisjon_Y - bordposisjon_y_bunn) - Constants.ThicknessOfCouch_CM, 2);
                avstandString = avstandIsoTIlBordDouble.ToString() + " cm";
                //Mer debug:
                debugmessage = debugmessage + "Bordposisjon bunn av bord y, i cm: " + bordposisjon_y_bunn + Environment.NewLine + "Iso posisjon y i cm: " + Math.Round(isosenterposisjon_Y, 3) + Environment.NewLine + "bordposisjon_y_topp: " + Math.Round(bordposisjon_y_topp, 3) + Environment.NewLine + "bordposisjon_y_bunn: " + Math.Round(bordposisjon_y_bunn, 3) + Environment.NewLine + "avstand isosenter til bordtopp i cm (y-retning): " + avstandString;

            }

            //Skriver resultatetene tilbake til SjekkPunkt:
            //---------------------------------------
            s.CheckResultValue = avstandString;
            s.CheckResultValueCSV = avstandString;
            if (avstandIsoTIlBordDouble > Constants.ToleranseAvstandBordTilIsosenterCm && bordstruktur != null) //Standardresultat
            {
                s.CheckStatus = Constants.Warning;
                kommentar = kommentar + "Sjekk kollisjonsfare.";
            }
            else if (bordstruktur == null) //bord finnes ikke
            {
                s.CheckStatus = Constants.Warning;
            }
            else //ok
            {
                s.CheckStatus = Constants.Ok;
            }
            s.CheckDebug = s.CheckDebug + debugmessage;
            s.CheckComment = s.CheckComment + kommentar;
            //---------------------------------------
            //MessageBox.Show(debugmessage);

            return s;
        }


        //1. Korteste avstand mellom strukturer?
        public static double ShortestDistanceBetweenStructuresCm(ExternalPlanSetup plan, string structurename1, string structurename2)
        {
            //Finn strukturer

            Structure structure1 = plan.StructureSet.Structures.Where(o => o.Id == structurename1).FirstOrDefault();

            Structure structure2 = plan.StructureSet.Structures.Where(o => o.Id == structurename2).FirstOrDefault();


            //Legg inn errorhandering! Hvis null!

            double shortestDistance = double.MaxValue;

            //Finn avstand

            foreach (var p1 in structure1.MeshGeometry.Positions)
            {
                foreach (var p2 in structure2.MeshGeometry.Positions)
                {
                    //https://byjus.com/maths/distance-between-two-points-formula/
                    // sqrt( (x2-x1)2 + (y2-y1)2 + (z2 - z1)2 ) 
                    double x = p2.X - p1.X;
                    double y = p2.Y - p1.Y;
                    double z = p2.Z - p1.Z;

                    double distance = x* x + y*y +z*z;
                    //"Math"-funksjonen er tregere - bedre aa multiplisre distansen med seg selv hver gang - Endre!
                    if (distance < shortestDistance)
                    {
                        shortestDistance = distance;
                    }
                }
            }

            double shortestDistance_corrected = Math.Sqrt(shortestDistance);


            //Error if the structure has no positions...
            if (shortestDistance == double.MaxValue) { shortestDistance_corrected = -1; }


            return shortestDistance_corrected;
        }



        // ------- User origin og Isosenter --------

        // ------- Tomme strukturer --------

        public static CheckPoint CheckEmptyStructures(CheckPoint s, StructureSet structureSet)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            string tommeStrukturer = "";
            string tommeStrukturerCSV = "";

            string status = Constants.Ok;
            int antall = 0;
            foreach (Structure st in structureSet.Structures)
            {
                if (st.IsEmpty)
                {
                    //Strukturliste til resultat
                    if (antall > 8) //Ny linje. Hindre at wpf skjerm blir for stor
                    {
                        tommeStrukturer = tommeStrukturer + Environment.NewLine;
                        antall = 0; //Resetter
                    }

                    if (tommeStrukturer != "") 
                    { tommeStrukturer = tommeStrukturer + Constants.StringSeparator;
                        tommeStrukturerCSV = tommeStrukturerCSV + Constants.StringSeparator;
                    }
                    tommeStrukturer = tommeStrukturer + st.Id;
                    tommeStrukturerCSV = tommeStrukturerCSV + st.Id;
                    //Status
                    status = Constants.Info;
                }
            }
            s.CheckResultValue = tommeStrukturer;
            s.CheckResultValueCSV = tommeStrukturerCSV;
            s.CheckStatus = status;

            if (s.CheckResultValue == "")
            {
                s.CheckDiscardedAtRuntime = Constants.True;
            }

            return s;
        }

        // ------- HighResolution strukturer --------
        public static CheckPoint CheckHighResolutionStructures(CheckPoint s, StructureSet structureSet, PatientContext patientContext, string chosenTemplateName)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            //string highResolutionStruktures = "";
            //string status = Constants.Ok;
            string checkResult = "";
            string checkResultCSV = "";
            bool isStereotaxy = false;

            //Exist extra checks for stereotaxy
            if (chosenTemplateName.ToLower().Contains("stereotaksi") || chosenTemplateName.ToLower().Contains("stx") || chosenTemplateName.ToLower().Contains("stereo"))
            {
                isStereotaxy = true;
            }

            //Get templatelist:
            string highResolutionTemplate = s.CheckTemplateValue;

            List<StructureResolution> highResolutionStructureList = new List<StructureResolution>();

            //-------------------
            //Collect information
            //-------------------
            foreach (Structure st in structureSet.Structures)
            {
                //Create structure object
                StructureResolution highResolutionStructure = new StructureResolution();
                
                //Pass Structure as a class
                highResolutionStructure.StructureItem = st;

                //High Resolution?
                highResolutionStructure.StructureId = st.Id;
                if (st.IsHighResolution)
                {
                    highResolutionStructure.IsHighResolution = Constants.True;

                    //Strukturliste til resultat
                    //if (highResolutionStruktures != "") { highResolutionStruktures = highResolutionStruktures + Constants.StringSeparator; }
                    //highResolutionStruktures = highResolutionStruktures + st.Id;
                    //status = Constants.Info; //Status
                }
                else
                {
                    highResolutionStructure.IsHighResolution = Constants.False;
                }

                //Set dicomType
                string dicomType = "";
                try { dicomType = st.DicomType; }
                catch { dicomType = Constants.Unknown; }
                highResolutionStructure.DicomType = dicomType;

                //Target or OAR or unknown
                if (highResolutionStructure.StructureId.ToUpper().StartsWith(Constants.PTV_StartWith))
                {
                    highResolutionStructure.IsPTV = Constants.True;
                    highResolutionStructure.IsTargetStructure = Constants.True;
                }
                else if ((highResolutionStructure.StructureId.ToUpper().StartsWith(Constants.CTV_StartWith)) || (highResolutionStructure.StructureId.ToUpper().StartsWith(Constants.GTV_StartWith)) || (highResolutionStructure.StructureId.ToUpper().StartsWith(Constants.ITV_StartWith)) || (highResolutionStructure.StructureId.ToUpper().StartsWith(Constants.IGTV_StartWith)))
                {
                    highResolutionStructure.IsTargetStructure = Constants.True;
                }
                else if (dicomType.ToUpper().Contains("ORGAN"))
                {
                    highResolutionStructure.IsOAR = Constants.True;
                }
                else
                {
                    highResolutionStructure.IsPTV = Constants.Unknown; //Default value
                    highResolutionStructure.IsOAR = Constants.Unknown; //Default value
                }

                //PRV?
                if (highResolutionStructure.StructureId.ToUpper().Contains("PRV"))
                {
                    highResolutionStructure.IsPRV = Constants.True;
                }
                else
                {
                    highResolutionStructure.IsPRV = Constants.False;
                }

                //Empty and volume?
                if (st.IsEmpty || !st.HasSegment) 
                {
                    highResolutionStructure.IsEmpty = Constants.True;
                    highResolutionStructure.Volume = 0;
                }
                else 
                { 
                    highResolutionStructure.IsEmpty = Constants.False;
                    highResolutionStructure.Volume = Math.Round(st.Volume,1);
                }

                highResolutionStructure.ShouldBeHighResolution = Constants.Unknown; //Default value 
                highResolutionStructure.ExistInTemplateList = Constants.Unknown; //Default value
                //-------------------
                //Add item to list
                //-------------------
                highResolutionStructureList.Add(highResolutionStructure);
            }

            //-------------------
            //Check distances in the list (relevant only for stereotaxy)
            //-------------------

            //Create a list of only target structures that should be checked against
            List<StructureResolution> listOfTargetStructure = highResolutionStructureList.Where(sr => sr.IsPTV == Constants.True).ToList();

            int skipMeasurmentUntilNumberReached = 2; //Only check a certain number of points to save time, every second or third point.

            //Check distance
            foreach (StructureResolution currenthighResolutionStructure in highResolutionStructureList)
            {
                if (isStereotaxy)
                {
                    //This is the structure to be checked
                    if (currenthighResolutionStructure.IsTargetStructure == Constants.True)
                    {
                        currenthighResolutionStructure.SmallestDistanceToTargetStructure = 0;
                    }
                    else if (currenthighResolutionStructure.IsEmpty == Constants.True)
                    {
                        currenthighResolutionStructure.SmallestDistanceToTargetStructure = -1;
                    }
                    else
                    {
                        //Do not do this for Body, no point
                        if (currenthighResolutionStructure.StructureId != patientContext.BodyId)
                        {
                            //Do not do this for too large volumes, no point
                            if (currenthighResolutionStructure.Volume < Constants.ShouldNotBeHighResolutionStructureIfVolumeHigherThanCm3)
                            {

                                List<Point3D> currentStructure3DPoints = currenthighResolutionStructure.StructureItem.MeshGeometry.Positions.ToList();

                                //For each target structure - search for closest distance to target all target structures
                                double closestDistance = 9999;

                                foreach (StructureResolution hrs in listOfTargetStructure) //Checks against ALL target
                                {
                                    if (hrs.IsEmpty == Constants.False) //Must ensure that the target is delineated first!
                                    {

                                        double distanceCurentStructureToTargetStructures = 9999;
                                        List<Point3D> targetStructure3DPoints = hrs.StructureItem.MeshGeometry.Positions.ToList(); //This crashes if structure is not delineated!
                                        Point3D point2 = new Point3D { X = 0, Y = 0, Z = 0 };
                                        int skipCount = 0;

                                        foreach (var p1 in currentStructure3DPoints)
                                        {
                                            //Beregner bare noen punkter for aa spare kalkuleringstid, skipper resten
                                            if (skipCount < skipMeasurmentUntilNumberReached)
                                            { skipCount++; }
                                            else if (skipCount >= skipMeasurmentUntilNumberReached)
                                            {

                                                int countTargetStructurePoints = targetStructure3DPoints.Count();
                                                for (int i = 0; i < countTargetStructurePoints - 1; i++)  //foreach (var p2 in set2)
                                                {
                                                    var p2 = targetStructure3DPoints[i];
                                                    double tempdistance = MarginsExtension.Distance(p1, p2) / 10;
                                                    //tempLastSmallStructureDistance = tempdistance;
                                                    if (tempdistance < distanceCurentStructureToTargetStructures)
                                                    {
                                                        distanceCurentStructureToTargetStructures = tempdistance;
                                                        point2 = p2;
                                                        //Break loop
                                                        if (tempdistance < Constants.HighResolutionStructureDistanceStopSearchCm)
                                                        {
                                                            break; //No need to check further, only if distance is REALLY interesting to someone...
                                                        }
                                                    }

                                                }
                                                //reset skipCount
                                                skipCount = 0;
                                                //break loop
                                                if (distanceCurentStructureToTargetStructures < Constants.HighResolutionStructureDistanceStopSearchCm)
                                                {
                                                    break; //No need to check further, only if distance is REALLY interesting to someone...
                                                }
                                            }
                                        }
                                        //Check if distance is shorter than last structure distance - set min distance:
                                        if (distanceCurentStructureToTargetStructures < closestDistance)
                                        {
                                            closestDistance = distanceCurentStructureToTargetStructures;
                                        }
                                    }
                                }
                                currenthighResolutionStructure.SmallestDistanceToTargetStructure = Math.Round(closestDistance, 1);

                            }
                            else
                            {
                                currenthighResolutionStructure.SmallestDistanceToTargetStructure = -1;
                            }
                        }
                        else
                        {
                            currenthighResolutionStructure.SmallestDistanceToTargetStructure = -1;
                        }
                    }
                }
                else //Dont care about distances anymore
                {
                    currenthighResolutionStructure.SmallestDistanceToTargetStructure = -1;
                }
            }
            


            //-------------------
            //Set statuses based on full info:
            //-------------------
            foreach (StructureResolution currenthighResolutionStructure in highResolutionStructureList)
            {
                //---------------------------------------
                //Stereotaxy: Distance check if it is an organ, and not too far away or too large volume
                //---------------------------------------
                if (isStereotaxy)
                {
                    //Is (1) within a distance and (2) not too large and (3) a "Organ" Dicom Type structure
                    if (currenthighResolutionStructure.SmallestDistanceToTargetStructure < Constants.HighResolutionStructureIfDistanceLessThanCm && currenthighResolutionStructure.SmallestDistanceToTargetStructure != -1 && currenthighResolutionStructure.Volume < Constants.ShouldNotBeHighResolutionStructureShortDistanceFromTargetIfVolumeHigherThanCm3 && currenthighResolutionStructure.StructureId != patientContext.BodyId && currenthighResolutionStructure.IsOAR == Constants.True)
                    {
                        currenthighResolutionStructure.ShouldBeHighResolution = "Vurder";
                    }
                    else if (currenthighResolutionStructure.SmallestDistanceToTargetStructure < Constants.HighResolutionStructureIfDistanceLessThanCm && currenthighResolutionStructure.SmallestDistanceToTargetStructure != -1 && currenthighResolutionStructure.Volume > Constants.ShouldNotBeHighResolutionStructureShortDistanceFromTargetIfVolumeHigherThanCm3 && currenthighResolutionStructure.StructureId != patientContext.BodyId && currenthighResolutionStructure.IsOAR == Constants.True)
                    {
                        currenthighResolutionStructure.ShouldBeHighResolution = Constants.False; //Large Organs like Liver and Kidney close to target should explicitly not be high resolution (this means it will be show in the list of structures in the result)
                    }

                    //Is target (and not empty)
                    if (currenthighResolutionStructure.IsTargetStructure == Constants.True && currenthighResolutionStructure.IsEmpty != Constants.True)
                    {
                        currenthighResolutionStructure.ShouldBeHighResolution = Constants.True;
                    }
                }

                //---------------------------------------
                // Exist in high resolution template list - overrides everything else:
                //---------------------------------------
                string checkTemplate = GeneralExtension.CheckStringsVsStrings(currenthighResolutionStructure.StructureId, s.CheckTemplateValue);
                if (checkTemplate == currenthighResolutionStructure.StructureId) //Exist match
                {
                    currenthighResolutionStructure.ExistInTemplateList = Constants.True;
                    currenthighResolutionStructure.ShouldBeHighResolution = Constants.True;
                }
                else if (checkTemplate == "") //No match
                {
                    currenthighResolutionStructure.ExistInTemplateList = Constants.False;
                } //catch any other scenario
                else
                {
                    currenthighResolutionStructure.ExistInTemplateList = Constants.False;
                }

                //---------------------------------------
                //Volume check - should NOT be high resolution (exeption if in template list)
                //---------------------------------------
                if (currenthighResolutionStructure.Volume > Constants.ShouldNotBeHighResolutionStructureIfVolumeHigherThanCm3 && currenthighResolutionStructure.IsTargetStructure == Constants.False && currenthighResolutionStructure.ExistInTemplateList != Constants.False)// && currenthighResolutionStructure.Volume != -1)
                {
                    currenthighResolutionStructure.ShouldBeHighResolution = Constants.False;
                }
                //---------------------------------------
                //Volume check - evaluate if HighResolution should be checked
                //---------------------------------------


                //Body check (NEVER high resolution)
                if (currenthighResolutionStructure.StructureId == patientContext.BodyId)
                {
                    currenthighResolutionStructure.ShouldBeHighResolution = Constants.False;

                }

            }



            //-------------------
            //Set Final Check status
            //-------------------

            //Set header: 
            string checkResultHeader = GeneralExtension.FormatString(-20, -15, "StructurID" + Constants.StringSeparator + "Er HR?" + Constants.StringSeparator + "Skal være HR?" + Constants.StringSeparator + "Status:" +  Constants.StringSeparator + "Avst. MV(cm):" + Constants.StringSeparator + "Volum (cc):");
            string finalStatus = Constants.Ok;
            string comment = "";
            string commentShouldBeHR = "";
            string commentShouldNotBeHR = "";
            string commentEvaluateIfShouldBeHR = "";
            foreach (StructureResolution currenthighResolutionStructure in highResolutionStructureList)
            {
                string statusHR = Constants.Ok;
                //Set  statuses and comments:
                //Should not be High Resolution
                if (currenthighResolutionStructure.ShouldBeHighResolution == Constants.False && currenthighResolutionStructure.IsHighResolution == Constants.True)
                {
                    //Unntak for target structures
                    if (currenthighResolutionStructure.IsTargetStructure != Constants.True)
                    {
                        statusHR = s.CheckTrafficLight;
                        finalStatus = s.CheckTrafficLight;
                        //comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(comment, currenthighResolutionStructure.StructureId + " er HR, burde ikke være HR.");
                        commentShouldNotBeHR = GeneralExtension.AddStringWithSeparatorIfNotEmpty(commentShouldNotBeHR, currenthighResolutionStructure.StructureId);
                    }

                }
                //Evaluate if necessary
                if (currenthighResolutionStructure.ShouldBeHighResolution == "Vurder" && currenthighResolutionStructure.IsHighResolution == Constants.False)
                {
                    statusHR = "Vurder";
                    if(finalStatus == Constants.Ok) 
                    { 
                        finalStatus = Constants.OBS;
                        commentEvaluateIfShouldBeHR = GeneralExtension.AddStringWithSeparatorIfNotEmpty(commentEvaluateIfShouldBeHR, currenthighResolutionStructure.StructureId);
                    }
                }
                //Should be High Resolution
                if (currenthighResolutionStructure.ShouldBeHighResolution == Constants.True && currenthighResolutionStructure.IsHighResolution == Constants.False)
                {
                    commentShouldBeHR = GeneralExtension.AddStringWithSeparatorIfNotEmpty(commentShouldBeHR, currenthighResolutionStructure.StructureId);
                    //comment = GeneralExtension.AddStringWithNewLineIfNotEmpty(comment, currenthighResolutionStructure.StructureId + " er ikke HR, burde være HR.");
                    statusHR = s.CheckTrafficLight;
                    finalStatus = s.CheckTrafficLight;

                }
                //Adjust distance to target:
                string distanceToTargets = "   -   ";  //not include -1.
                if(currenthighResolutionStructure.SmallestDistanceToTargetStructure != -1) { distanceToTargets = currenthighResolutionStructure.SmallestDistanceToTargetStructure.ToString(); }
                //Print list:
                if (currenthighResolutionStructure.ShouldBeHighResolution == Constants.True || statusHR == "Vurder" || currenthighResolutionStructure.IsHighResolution == Constants.True || (currenthighResolutionStructure.SmallestDistanceToTargetStructure < Constants.HighResolutionStructureIfDistanceLessThanCm && currenthighResolutionStructure.SmallestDistanceToTargetStructure != 0 && currenthighResolutionStructure.SmallestDistanceToTargetStructure != -1)) //Remove condition to get full list
                {

                    checkResult = checkResult + Environment.NewLine + GeneralExtension.FormatString(-20, -15, currenthighResolutionStructure.StructureId + Constants.StringSeparator + currenthighResolutionStructure.IsHighResolution + Constants.StringSeparator + currenthighResolutionStructure.ShouldBeHighResolution + Constants.StringSeparator + statusHR + Constants.StringSeparator + distanceToTargets + Constants.StringSeparator + currenthighResolutionStructure.Volume);

                    //CSV result
                    if (checkResultCSV != "" && checkResultCSV != null)
                    { checkResultCSV = checkResultCSV + Constants.StringSeparator; }
                    checkResultCSV = checkResultCSV + currenthighResolutionStructure.StructureId + ":" + currenthighResolutionStructure.IsHighResolution + ":" + currenthighResolutionStructure.ShouldBeHighResolution + ":" + statusHR + ":" + distanceToTargets + ":" + currenthighResolutionStructure.Volume;


                }

            }
            //Add Comment if relevant
            if (commentShouldBeHR != "")
            {
                comment = "Skal være HR: " + commentShouldBeHR;
            }
            if (commentShouldNotBeHR != "")
            {
                if (comment != "")
                {
                    comment = comment + Environment.NewLine;
                }
                comment = comment + "Burde IKKE være HR: " + commentShouldNotBeHR;

            }
            if (commentEvaluateIfShouldBeHR != "")
            {
                if (comment != "")
                {
                    comment = comment + Environment.NewLine;
                }
                comment = comment + "Vurder om det skal være HR: " + commentEvaluateIfShouldBeHR;

            }

                //comment = "Burde være HR: " + commentShouldBeHR + Environment.NewLine + "Burde IKKE være HR: " + commentShouldNotBeHR;

            //Result
            if (checkResult != "")
            {
                s.CheckResultValue = checkResultHeader + checkResult;
            }
            else
            {
                s.CheckResultValue = ""; //Must set to emtpy to clear "Calculating" image.
            }
            s.CheckResultValueCSV = checkResultCSV;

            //status
            s.CheckStatus = finalStatus;
            s.CheckComment = comment;

            //s.CheckResultValue = highResolutionStruktures;
            //if (s.CheckResultValue == "")
            //{
            //    s.CheckInactivated = Constants.True;
            //}

            return s;
        }




        // ----  Hent  protese -------
        public static string GetProthesisId(ExternalPlanSetup plan)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            Structure protese = plan.StructureSet.Structures.FirstOrDefault(o => o.Id.ToLower().Contains("protese"));  //vurdere (o => o.Id.Contains("CouchSurface")
            string proteseString = "";
            if (protese != null)
            {
                proteseString = protese.Id;
            }

            return proteseString;
        }
        // ----  End Protese -------

        // -----  Hent Bolus ----
        public static List<StructureCheck> GetBolusList(PatientContext patientContext)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            string bnavn = "";
            string bHU = "";
            string bType = "";
            string feltId = "";
            string forklaring = "Boluser som er attached til felt vil komme opp i denne listen, med HU og og hvilke felt de er attached til. Eclipseboluser som ikke er attached til minst ett felt vil gi advarsel.";
            string _sjekkType = Constants.Printout;
            //Forbedring: legge til fields not attached ogsaa, ikke bare fields with bolus attached!
            List<StructureCheck> _struktsjekkliste = new List<StructureCheck>();

            int Feltnnr = 1;

            //Denne viser kun bolser som er attached til felt.
            if (patientContext.SanityLevel > Constants.SanityLevelPlanExist) //Earlier:  Constants.SanityLevelPatientExist (Must have been misclick)
            {

         
                foreach (Beam f in patientContext.ChosenPlan.Beams)
                {
                    if (f.IsSetupField == false)
                    {
                        Feltnnr = Feltnnr + 1;

                        foreach (Bolus b in f.Boluses)
                        {

                            bnavn = b.Id + b.Name;
                            bHU = b.MaterialCTValue.ToString();
                            bType = "eclipsebolus";
                            feltId = f.Id;
                            //MessageBox.Show("feltnr: " + Feltnnr + ", bolusnummer" + bolusnummer + ", bnavn:" + bnavn + ", bHU;" + bHU);

                            //Hvis bolusnavnet ikke allerede eksisterer i listen, legg til
                            if (!_struktsjekkliste.Any(x => x.StructureID == bnavn))
                            {
                                _struktsjekkliste.Add(new StructureCheck() { StructureID = bnavn, StructureHU = bHU, StructureType = bType, AttachedFields = feltId, NonAttachedFields = "", Explanation = forklaring, Status = _sjekkType, ColorSet = "Cyan" }); //ColorSet = "Green" //"Cyan" // "Lavender"
                                                                                                                                                                                                                                              //LastIndexOf
                            }
                            else
                            {
                                //legg til flere feltnummer i eksisterende boluser  //Sjekker om siste linje har mer enn 40 bokstaver, splitter i så fall i ny linje igjen.
                                _struktsjekkliste.Where(w => w.StructureID == bnavn).ToList().ForEach(s => s.AttachedFields = (s.AttachedFields.Split(new string[] { Environment.NewLine }, StringSplitOptions.None).Last().Count() > 40) ? s.AttachedFields + " //" + Environment.NewLine + feltId : s.AttachedFields + " // " + feltId);

                            }

                        }
                        //hvis ikke bolus: Legg til liste med fields uten bolus
                    }
                }
                //For Each eclipsebolus, make list of fields that are not attached also:
                foreach (Beam f in patientContext.ChosenPlan.Beams)
                {
                    if (f.IsSetupField == false)
                    {
                        feltId = f.Id;

                        foreach (StructureCheck struktSjekk in _struktsjekkliste)
                        {
                            if (!struktSjekk.AttachedFields.Contains(feltId))
                            {
                                if (struktSjekk.NonAttachedFields == "")
                                {
                                    struktSjekk.NonAttachedFields = feltId; //First field
                                }
                                else //More fields
                                {
                                    struktSjekk.NonAttachedFields = (struktSjekk.NonAttachedFields.Split(new string[] { Environment.NewLine }, StringSplitOptions.None).Last().Count() > 40) ? struktSjekk.NonAttachedFields + " //" + Environment.NewLine + feltId : struktSjekk.NonAttachedFields + " // " + feltId;
                                }
                            }

                        }
                    }
                }
            }

            //Set Warning if not attached to a field
            foreach (StructureCheck struktSjekk in _struktsjekkliste)
            {
                if (struktSjekk.NonAttachedFields != "")
                {
                    struktSjekk.ColorSet = "Yellow"; //Warning
                    struktSjekk.Status = Constants.Warning;
                    struktSjekk.Explanation = struktSjekk.Explanation + Environment.NewLine + "Warning! Eclipsebolus ikke attached til behandlingsfelt: " + struktSjekk.NonAttachedFields;
                }

            }

            //struktSjekk.Explanation = struktSjekk.Explanation + Environment.NewLine + "Eclipsebolus is not attached to treatment fields: " + 


            //Structure-boluses:
            if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist)
            {
                foreach (Structure structure in patientContext.ChosenStructureSet.Structures)
                {
                    if (structure.Id.ToLower().Contains("bolus"))
                    {
                        bnavn = structure.Id;// added - see next line comment
                        if (!_struktsjekkliste.Any(x => x.StructureID == bnavn)) //Her skal det vel stå "structure.id" og ikke bnavn!!!!!
                        {
                            bnavn = structure.Id;
                            bType = "strukturbolus";
                            double valueHU = 0;
                            bool hasHU = false;
                            try
                            {
                                hasHU = structure.GetAssignedHU(out valueHU);
                            }
                            catch
                            {
                                hasHU = false;
                            }
                            //Set HU
                            if (hasHU == true)
                            { bHU = valueHU.ToString(); }
                            else { bHU = ""; }

                            _struktsjekkliste.Add(new StructureCheck() { StructureID = bnavn, StructureHU = bHU, StructureType = bType, AttachedFields = "", Explanation = forklaring, Status = _sjekkType, ColorSet = "Cyan" });
                        }

                    }

                }
            }

            //
            //Set Warning if wrong HU
            
            foreach (StructureCheck struktSjekk in _struktsjekkliste)
            {
                string matchingID = "";
                string templateHU = "";
                string templateID = "";
                //Get match from template on ID, and set template HU:
                foreach (StructureCheck bolusTemplate in Constants.BolusTemplates)
                {
                    //get matching bolus ID from plan
                    matchingID = GeneralExtension.CheckStringsVsStrings(struktSjekk.StructureID.ToLower(), bolusTemplate.StructureID.ToLower());
                    if (matchingID != "")
                    {
                        templateHU = bolusTemplate.StructureHU; //Set expected HU
                        templateID = bolusTemplate.StructureID; //Matched template bolus
                        continue; //Exit loop and continue
                    }

                }
                //If no matches on ID, use generic bolus HU
                if (matchingID == "")
                {
                    //Generic bolus wihout any specification:
                    templateHU = Constants.BolusStandardHU;
                    matchingID = "Generic bolus";
                    templateID = "Generic bolus";
                }

                //Get bolus HU from plan
                string matchHU = GeneralExtension.CheckStringsVsStrings(struktSjekk.StructureHU, templateHU); //string matchHU = GeneralExtension.CheckStringsVsStrings(struktSjekk.StructureHU, Constants.BolusStandardHU);
                
                //If plan bolus HU and template bolus HU does not match. Give warning.
                if (matchHU == "")
                {
                    struktSjekk.ColorSet = "Yellow"; //Warning
                    struktSjekk.Status = Constants.Warning;
                    struktSjekk.Explanation = struktSjekk.Explanation + Environment.NewLine + "Warning! Bolus har feil  HU: " + struktSjekk.StructureHU + ". Burde ha: " + templateHU + ". Type bolus : " + templateID;
                }
            }

            //

            return _struktsjekkliste;
        }


        // ----  End Bolus -------


        public static List<StructureCheck> GetAssignedHUStructures(StructureSet structureSet)  //Legge til optional input-parameter med type teknikk (ARC, IMRT etc). Hvis ikke valgt, alle felt utenom setup.
        {
            string bnavn = "";
            string bHU = "";
            string bType = "";
            string forklaring = "Her kommer en liste av alle strukturer som har override på HU (hjelpestrukturer som protese, metall etc, inkludert boluser)";
            double StructureHU = 9999;
            int antallStrukter = 0; //totalt
            string _sjekkType = Constants.Printout;

            List<StructureCheck> _struktsjekkliste = new List<StructureCheck>();

            antallStrukter = 0;
            //Ny sjekk av bolus i strukturer kan legges inn her...., kan sammenligne med BoluserSjekket.
            foreach (Structure s in structureSet.Structures)
            {
                //hvis nytt bolusnavn finnes, legg til
                if (s.GetAssignedHU(out StructureHU) == true & !s.Id.ToLower().Contains("couch")) //& !s.Id.ToLower().Contains("bolus")  //Fjern structurer som inneholder noen av frasene fra CouchIDContainsStandardPhrase
                {
                    bnavn = s.Id;
                    bHU = Math.Round(StructureHU, 0).ToString();
                    //Bolus eller struktur?
                    if (bnavn.ToLower().Contains("bolus"))
                    {

                        bType = s.DicomType;//s.GetType().ToString();

                        //if(!s.HasSegment)  //s.Type = "Bolus"? /Boluser har ikke segmentering?
                        //{
                        //    bType = "bolus";
                        //}
                        //else 
                        //{
                        //    bType = "structure";
                        //}
                    }
                    else
                    {
                        bType = "structure";
                    }

                    antallStrukter = antallStrukter + 1;

                    _struktsjekkliste.Add(new StructureCheck() { StructureID = bnavn, StructureHU = bHU, StructureType = bType, Explanation = forklaring, Status = _sjekkType, ColorSet = "Cyan" }); //ColorSet = "Green" "Lavender" "Cyan"
                }
            }
            //
            return _struktsjekkliste;
        }

        // ----  End Bolus -------


    }
}
