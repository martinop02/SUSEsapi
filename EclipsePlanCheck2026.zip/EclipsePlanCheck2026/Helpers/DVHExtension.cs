﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

using System.Windows.Media.Media3D;
//Endre strukturer til transluce:
using System.Drawing;

//Slipper eksplisitt referere til Helpers
using EclipsePlanCheck.Helpers;
namespace EclipsePlanCheck.Helpers
{
    class DVHExtension
    {


        public static CheckPoint GetDvhValue(ExternalPlanSetup plan, CheckPoint _s, DvhValue dvhValue)
        {
            // Erklærer div. variabler / konstanter 
            //------------------------------
            double s_binWidth = 0.001; //DVH binwidth i sjekken naar man henter ut en dvh-verdi
            bool struktfinnes = false;
            double overdi = 0; //evnt Var
            double tempvol = 0; //brukes i Critical Volume-utregning.
            bool skip_parameter;
            skip_parameter = false;
            int antallmatch = 0;
            string nytest = "";
            string FlereStruktMatcher = "";
            string ForsteStruktMatch = "";
            string beskjed = "";
            string dvh_beskrivelse = "";
            bool defaultenhetbrukes = false;  // fang opp hvis enhet ikke er korrekt definert.
            string result = Constants.Unknown;
            //------------------------------

            //Definerer plantype. Senere kan vi legge inn håndtering av uthenting av verdier fra plansum (egen syntax). Per nå takler den kun en vanlig plan.
            PlanningItem ValgtPlanItem = plan;  //PlanningItem ValgtPlanItem = plan != null ? (PlanningItem)plan : (PlanningItem)plnsum;


            //Henter dvh-info
            //------------------------------
            string strukturnavn = dvhValue.StructureID;
            string pprefiks = dvhValue.pPrefix;
            double pVerdi = dvhValue.pValue == null ? default(double) : Convert.ToDouble(dvhValue.pValue); //sjekker om Null-verdi først
            string pEnhet = dvhValue.pEnhet;
            string rEnhet = dvhValue.rEnhet;
            double? ToleranseAdv = dvhValue.ToleranceAdv; //== null ? default(double) : Convert.ToDouble(dvhValue.ToleranseAdv); //sjekker om Null-verdi først
            double? ToleranseErr = dvhValue.ToleranceErr; //== null ? default(double) : Convert.ToDouble(dvhValue.ToleranseAdv); //sjekker om Null-verdi først
            string op = dvhValue.Operator;
            //------------------------------
            string opprinnelig_strukturnavn = strukturnavn;
            //Splitter array og sjekker hver struktur
            string[] strnavnarray = strukturnavn.Split(Constants.CharSeparator);


            //------------------------------------------------------
            //              FINNER STRUKTUREN
            //------------------------------------------------------
            // splitter struktur i array og leter etter match, godtar første match
            foreach (var strnavn_f in strnavnarray)
            {
                var strnavn = strnavn_f;
                strnavn = strnavn_f;
                Structure Eclipse_str_forsok = plan.StructureSet.Structures.Where(o => o.Id == strnavn).FirstOrDefault();
                if (Eclipse_str_forsok != null)
                {
                    nytest = strnavn;
                }
                //Hvis strukturen har "*" i seg og ingen direkte match, fjern '*' og se om noen struktur inneholder resten (Contains). 
                if (strnavn.Contains("*") && (Eclipse_str_forsok == null))
                {
                    string opprinneligtest = "";
                    nytest = strnavn.Replace("*", "");
                    Eclipse_str_forsok = plan.StructureSet.Structures.Where(o => o.Id.StartsWith(nytest)).FirstOrDefault();
                    if (Eclipse_str_forsok != null)
                    {
                        opprinneligtest = nytest;
                        nytest = Eclipse_str_forsok.Id.ToString(); //Husk å KUN sende ID til string, ikke navn og ID.
                    }
                }
                else { }
                //Hvis en av metodene funket - går videre (teller også opp antall treff)
                if (Eclipse_str_forsok != null && !Eclipse_str_forsok.IsEmpty)
                {
                    //setter struktnavn til match
                    strukturnavn = nytest;  //strnavn  //Eclipse_str_forsok.ToString();

                    //MessageBox.Show("strukt funnet: " + strukturnavn);
                    antallmatch = antallmatch + 1;
                    //advarsel om multiple matcher
                    if (antallmatch > 1)
                    {
                        //MessageBox.Show(strnavn + ": OBS! Det er flere strukturnavn som matcher! Sjekk manuelt!" + Environment.NewLine + "Aliasliste:" + Environment.NewLine + dataReader.GetValue(1).ToString());
                        FlereStruktMatcher = " Flere strukturer i listen matcher.";
                    }
                    else
                    {
                        ForsteStruktMatch = strukturnavn;
                    }

                }
                else { }//MessageBox.Show("strukt ikke funnet: " + strnavn);
            }
            //------------------------------------------------------
            //------------------------------------------------------
            //Setter endelig Eclipse_struktur
            Structure Eclipse_struktur = plan.StructureSet.Structures.Where(o => o.Id == ForsteStruktMatch).FirstOrDefault();

            //----------------
            //    Definerer om struktur finnes. Sender også til Debug
            //----------------
            if (Eclipse_struktur == null) //Eclipse_str_forsok_er_tegnet == true
            {
                beskjed = beskjed + strukturnavn + " finnes ikke. "; //Liste over strukturer
                struktfinnes = false;
            }
            else
            {
                if (Eclipse_struktur != null && Eclipse_struktur.IsEmpty)  //Eclipse_str_forsok_er_tegnet == false
                {
                    beskjed = beskjed + ForsteStruktMatch + " finnes, men ikke tegnet. " + FlereStruktMatcher; //Liste over strukturer
                    struktfinnes = false;
                }
                else
                {
                    beskjed = beskjed + ForsteStruktMatch + " finnes. " + FlereStruktMatcher; //Liste over strukturer
                    struktfinnes = true;
                }

            }
            //----------------
            //----------------

            //-------------------------------------------------------------------------------------
            //Avklarer: Har vi absoluttdose, relativddose. Har vi absoluttvolum eller relativ volum 
            //-------------------------------------------------------------------------------------
            //Default: skal sendes
            skip_parameter = false;

            if (struktfinnes == true)
            {

                //Hent ut verdien:

                //Deklarerer variablene //default cc og Gy.
                VolumePresentation volPres = VolumePresentation.AbsoluteCm3;
                DoseValuePresentation dosePres = DoseValuePresentation.Absolute;

                //Setter uthenting basert på tabellen
                // 1. Hente ut et volum
                if (pprefiks == "V")
                {

                    //volumet for hvilken doseenhet
                    if (pEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (pEnhet == "%")
                    {
                        if (plan == null)
                        {
                            MessageBox.Show("Kan ikke hente ut % dose for en verdi når det er plan sum. Henter ut volumet som får XX Gy istedenfor XX %. Vær OBS!");
                            dosePres = DoseValuePresentation.Absolute;
                        }
                        else { dosePres = DoseValuePresentation.Relative; }


                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }
                    //resultat hentes ut i cc eller %

                    if (rEnhet == "cc")
                    {
                        volPres = VolumePresentation.AbsoluteCm3;
                    }
                    else if (rEnhet == "%")
                    {
                        volPres = VolumePresentation.Relative;
                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }

                    dvh_beskrivelse = "Volumet som får " + pVerdi + " " + pEnhet + " i " + rEnhet;

                    DVHData dvhData = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, s_binWidth);
                    DoseValue.DoseUnit doseUnit = dvhData.MaxDose.Unit; //bruker maxdosen for å hente ut enheten
                    double vol = ValgtPlanItem.GetVolumeAtDose(Eclipse_struktur, new DoseValue(pVerdi, doseUnit), volPres);
                    overdi = vol;
                }
                // 2. Hente ut en dose  (trenger vi egen for å hente ut dosemaks, eller bruke D0cc?). OBS krasjer hvis dosen hentes ut i % for plansum
                else if (pprefiks == "D")
                {
                    //dosen for hvilken volumenhet
                    if (pEnhet == "cc")
                    {
                        volPres = VolumePresentation.AbsoluteCm3;
                    }
                    else if (pEnhet == "%")
                    {
                        volPres = VolumePresentation.Relative;
                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }
                    //resultat hentes ut i Gy eller %
                    if (rEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (rEnhet == "%")
                    {
                        if (plan == null)
                        {
                            MessageBox.Show("Kan ikke hente ut % dose for en verdi når det er plan sum. Endrer til dose i Gy. Vær OBS!");
                            dosePres = DoseValuePresentation.Absolute;
                        }
                        else { dosePres = DoseValuePresentation.Relative; }


                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }
                    Double SamlingCoverage_struktur = 0;

                    dvh_beskrivelse = "Dosen til " + pVerdi + " " + pEnhet + " av volumet i " + rEnhet;
                    DVHData dvhData = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, s_binWidth);
                    //bool samlingCoverageSucess = Double.TryParse(dvhData.SamplingCoverage.ToString(), out SamlingCoverage_struktur);
                    if (dvhData == null) //Melding om feil oppstått:
                    {
                        MessageBox.Show(dvh_beskrivelse + " str: " + Eclipse_struktur);
                    }
                    SamlingCoverage_struktur = Convert.ToDouble(dvhData.SamplingCoverage);
                    String Str_SamlingCoverage_struktur = Convert.ToString(SamlingCoverage_struktur);

                    //MessageBox.Show(Str_SamlingCoverage_struktur);
                    if (SamlingCoverage_struktur >= 0.9)
                    {
                        DoseValue val = ValgtPlanItem.GetDoseAtVolume(Eclipse_struktur, pVerdi, volPres, dosePres);
                        overdi = Convert.ToDouble(val.Dose);
                    }
                    else
                    {
                        overdi = -1;
                        MessageBox.Show("OBS! Fordi Sampling Coverage er <90% (" + Str_SamlingCoverage_struktur + ") kan ikke dosen hentes ut for " + Eclipse_struktur + ". Sender isteden verdien '-1' og skipper til neste for å forhindre krasj.");
                    }

                    //MessageBox.Show("Strukt: " + strukturnavn + ". Overdi = " + overdi.ToString());
                }
                else if (pprefiks == "Mean") // Hente ut meanDose
                {
                    //resultat hentes ut i Gy eller %
                    if (rEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (rEnhet == "%")
                    {
                        dosePres = DoseValuePresentation.Relative;
                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }
                    dvh_beskrivelse = "Meandosen til strukturen i " + rEnhet;
                    DoseValue val = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).MeanDose;
                    overdi = Convert.ToDouble(val.Dose);
                }
                else if (pprefiks == "Median") // Hente ut mediandose
                {
                    //resultat hentes ut i Gy eller %
                    if (rEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (rEnhet == "%")
                    {
                        dosePres = DoseValuePresentation.Relative;
                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }

                    dvh_beskrivelse = "Mediandosen til strukturen i " + rEnhet;
                    DoseValue val = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).MedianDose;
                    overdi = Convert.ToDouble(val.Dose);
                }
                else if (pprefiks == "Max") // Hente ut maksdose
                {
                    //resultat hentes ut i Gy eller %
                    if (rEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (rEnhet == "%")
                    {
                        if (plan == null)
                        {
                            MessageBox.Show("Kan ikke hente ut % dose for en verdi når det er plan sum. Endrer til dose i Gy. Vær OBS!");
                            dosePres = DoseValuePresentation.Absolute;
                        }
                        else { dosePres = DoseValuePresentation.Relative; }

                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }

                    dvh_beskrivelse = "Maxdosen til strukturen i " + rEnhet;
                    DoseValue val = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).MaxDose;
                    overdi = Convert.ToDouble(val.Dose);
                }
                else if (pprefiks == "Min") // Hente ut maksdose
                {
                    //resultat hentes ut i Gy eller %
                    if (rEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (rEnhet == "%")
                    {
                        if (plan == null)
                        {
                            MessageBox.Show("Kan ikke hente ut % dose for en verdi når det er plan sum. Endrer til dose i Gy. Vær OBS!");
                            dosePres = DoseValuePresentation.Absolute;
                        }
                        else { dosePres = DoseValuePresentation.Relative; }

                    }
                    else
                    {
                        defaultenhetbrukes = true;
                    }
                    dvh_beskrivelse = "Minste dosen til strukturen met i " + rEnhet;
                    DoseValue val = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).MinDose;
                    overdi = Convert.ToDouble(val.Dose);
                }
                else if (pprefiks == "Volume")
                {
                    overdi = Eclipse_struktur.Volume; //skal komme i cc.
                    dvh_beskrivelse = "Volumet til strukturen i " + rEnhet;
                }
                else if (pprefiks == "Konformitet")
                { //konformitet sendes ikke per nå! Skipper! Regnes ut basert på volumer. Ikke send til oppdrag.

                    //overdi = plan.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).Coverage;
                    overdi = 0;
                    skip_parameter = true;
                }
                else if (pprefiks == "CI")
                { //konformitet sendes ikke per nå! Skipper! Regnes ut basert på volumer. Ikke send til oppdrag.

                    //overdi = plan.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).Coverage;
                    overdi = 0;
                    skip_parameter = true;
                }
                //Her kan vi kanskje bruke en funksjon som finnes eller lage nye
                //(Confirmity Index, Paddick Index, Gradient Measure etc.) "Conformity Index (95%)" hvor det i parantes hentes ut til å finne isodosen.
                else if (pprefiks == "DCV")  //Superteit variant av CV hvor man konverterer det til et "hot" constraint
                {
                    // dosen til hvilket volum
                    if (pEnhet == "cc")
                    {
                        volPres = VolumePresentation.AbsoluteCm3;
                        tempvol = Eclipse_struktur.Volume;
                    }
                    else { defaultenhetbrukes = true; }

                    //resultat hentes ut i Gy
                    if (rEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else { defaultenhetbrukes = true; }

                    DVHData dvhData = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, s_binWidth);
                    DoseValue.DoseUnit doseUnit = dvhData.MaxDose.Unit; //bruker maxdosen for å hente ut enheten

                    double vol = ValgtPlanItem.GetVolumeAtDose(Eclipse_struktur, new DoseValue(pVerdi, doseUnit), volPres);
                    DoseValue val = ValgtPlanItem.GetDoseAtVolume(Eclipse_struktur, tempvol - vol, volPres, dosePres); //Dosen til dynamisk volum: (Totvol - Volum som får X Gy)
                    overdi = Convert.ToDouble(val.Dose);
                }
                else if (pprefiks == "CV")
                {
                    //volumet for hvilken doseenhet
                    if (pEnhet == "Gy")
                    {
                        dosePres = DoseValuePresentation.Absolute;
                    }
                    else if (pEnhet == "%") //burde vanligvis ikke brukes, men ikke problem
                    {
                        dosePres = DoseValuePresentation.Relative;
                    }
                    else { defaultenhetbrukes = true; }

                    //resultat hentes ut i cc eller %
                    if (rEnhet == "cc")
                    {
                        volPres = VolumePresentation.AbsoluteCm3;
                        tempvol = Eclipse_struktur.Volume; //skal komme i cc. 
                    }
                    else if (rEnhet == "%") //burde ikke brukes. 
                    {
                        volPres = VolumePresentation.Relative;
                        tempvol = 100; //i %, burde ikke brukes!
                        defaultenhetbrukes = true; //Gi beskjed om teit enhet.
                    }
                    else { defaultenhetbrukes = true; }

                    dvh_beskrivelse = "'Critical Volume'. Definisjon: Volumet som ikke får " + pVerdi + " " + pEnhet + " av dosen (hentet ut i " + rEnhet + ")" + Environment.NewLine + " (dvs: totalvolumet minus volumet som får " + pVerdi + " " + pEnhet + ")" + Environment.NewLine;
                    _s.CheckComment = _s.CheckComment + "Definisjon: CV = 'Critical Volume'. Altså " + rEnhet + " volum av " + ForsteStruktMatch + " som får MINDRE ENN " + pVerdi + " " + pEnhet + " av dosen."; //Kommentaren kommer bare hvis strukturen ble funnet.
                    DVHData dvhData = ValgtPlanItem.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, s_binWidth);
                    DoseValue.DoseUnit doseUnit = dvhData.MaxDose.Unit; //bruker maxdosen for å hente ut enheten

                    double vol = ValgtPlanItem.GetVolumeAtDose(Eclipse_struktur, new DoseValue(pVerdi, doseUnit), volPres);
                    overdi = tempvol - vol;
                }
                else if (pprefiks == "GM")  //Gradientmål
                {
                    Eclipse_struktur = plan.StructureSet.Structures.Where(o => o.Id == plan.TargetVolumeID).FirstOrDefault(); //finne target volume uansett.
                                                                                                                              //DoseValue val = plan.GetDVHCumulativeData(Eclipse_struktur, dosePres, volPres, Convert.ToDouble(dosePres)).MinDose;
                    skip_parameter = true;
                }
                else
                {
                    beskjed = beskjed + Environment.NewLine + strukturnavn + ": klarer ikke å hente ut verdien " + pprefiks + pVerdi + pEnhet + " [" + rEnhet + "]. Noe gikk feil!"; //Liste over strukturer
                    skip_parameter = true;
                }

                //-----------------------
                //Sjekker om noe gikk feil
                //-----------------------
                if (defaultenhetbrukes == true)
                {
                    beskjed = beskjed + "OBS! Feil i definisjon av enhet i templatet! Sjekk verdi manuelt!"; //Liste over strukturer     
                    _s.CheckComment = _s.CheckComment + "OBS! Feil i definisjon av enhet i templatet! Sjekk verdi manuelt!";
                }
                else
                {
                    string pverdi_str;
                    if (pVerdi == 0)
                    {
                        pverdi_str = "";
                    }
                    else { pverdi_str = pVerdi.ToString(); }
                    beskjed = beskjed + "(" + pprefiks + pverdi_str + pEnhet + ")";
                }

                dvhValue.rValue = overdi;
            }



            //Sjekker uthentet verdi mot toleransen
            if (struktfinnes == true)
            {
                bool advResult = true;//ok
                bool errResult = true; //ok
                if (op != "" && (op == ">" || op == "<" || op == ">=" || op == "<=" || op == "=" || op == "==")) //sjekker om gyldig operator
                {

                    //Sjekker advarsel. true = ok
                    if (ToleranseAdv != null)
                    {
                        advResult = GeneralExtension.SolveBooleanExpression(op, overdi, ToleranseAdv, _s);
                        beskjed = beskjed + Environment.NewLine + "Bestod test for toleranse Adv: " + advResult;
                    }
                    //Sjekker error hvis advarsel allerede
                    if (ToleranseErr != null)
                    {
                        errResult = GeneralExtension.SolveBooleanExpression(op, overdi, ToleranseErr, _s);
                        beskjed = beskjed + Environment.NewLine + "Bestod test for toleranse Err: " + errResult;
                    }

                    if (advResult == false && errResult == true)
                    {//kun adv
                        result = Constants.Warning;
                    }
                    else if (errResult == false)
                    {//error
                        result = Constants.Error;
                    }
                    else
                    {//ok
                        result = Constants.Ok;
                    }
                    beskjed = beskjed + Environment.NewLine + " Status for sjekk: " + result;
                }
                else
                {
                    _s.CheckDebug = _s.CheckDebug + "Feil i sjekk av resultat. Operator '" + op + "' ugyldig.";
                    _s.CheckComment = _s.CheckComment + "Feil i sjekk av resultat. Operator '" + op + "' ugyldig.";
                    result = Constants.Unknown;
                }
            }


            //Printer til Debug
            string dvh = "DVH-verdier: " + dvhValue.pPrefix + dvhValue.pValue + dvhValue.pEnhet + " = " + dvhValue.rValue.ToString() + Environment.NewLine + "Adv. Tol: " + dvhValue.Operator + " " + dvhValue.ToleranceAdv + Environment.NewLine + "Abs. Tol: " + dvhValue.Operator + " " + dvhValue.ToleranceErr;
            _s.CheckDebug = "Strukturliste: " + dvhValue.StructureID + Environment.NewLine + "Antall Match: " + antallmatch + Environment.NewLine + "Første struktmatch: " + ForsteStruktMatch + Environment.NewLine + "Diverse debug: " + beskjed + Environment.NewLine + dvh + Environment.NewLine + "Skip parameter: " + skip_parameter; //antallmatch FlereStruktMatcher ForsteStruktMatch  beskjed  skip_parameter


            //SjekkNavn: Renavner sjekken med reelle verdier
            string ForsteStrukturnavnIListe = strnavnarray[0];
            if (struktfinnes == true)
            {
                _s.CheckName = ForsteStruktMatch + " " + dvhValue.pPrefix + dvhValue.pValue;
            }
            else //Finner ikke strukturen
            {
                //Henter ut første hypotetiske struktur fra strukturliste:

                _s.CheckName = ForsteStrukturnavnIListe + " " + dvhValue.pPrefix + dvhValue.pValue;
            }
            //SjekkNavn: Legger til korrekte enheter i sjekknavn
            if (dvhValue.pEnhet != "" && (dvhValue.pPrefix == "D" || dvhValue.pPrefix == "V" || dvhValue.pPrefix == "CV" || dvhValue.pPrefix == "DCV")) { _s.CheckName = _s.CheckName + dvhValue.pEnhet; }
            if (dvhValue.rEnhet != "" && (dvhValue.pPrefix == "D" || dvhValue.pPrefix == "V" || dvhValue.pPrefix == "CV" || dvhValue.pPrefix == "DCV" || dvhValue.pPrefix == "Max" || dvhValue.pPrefix == "Mean" || dvhValue.pPrefix == "Median")) { _s.CheckName = _s.CheckName + " (" + dvhValue.rEnhet + ")"; }
            _s.CheckElaboration = dvh_beskrivelse;

            //SjekkResultatVerdi: setter endelig resultatverdi
            if (struktfinnes == true)
            {
                dvhValue.rValue = overdi;
                _s.CheckResultValue = Math.Round(overdi, 3).ToString();
                _s.CheckResultValueCSV = Math.Round(overdi, 3).ToString();
                _s.CheckStatus = result;
            }
            else //Struktur finnes ikke
            {
                _s.CheckResultValue = ForsteStrukturnavnIListe + " finnes ikke.";
                _s.CheckResultValueCSV = ForsteStrukturnavnIListe + " finnes ikke.";
                _s.CheckStatus = Constants.Printout;
            }

            //SjekkTemplatVerdi: Setter templatverdier
            if (ToleranseAdv != null)
            {//Finnes Adv. toleranse
                _s.CheckTemplateValue = op + " " + _s.DvhValue.ToleranceAdv;
            }
            if (ToleranseErr != null)
            { //Finnes Abs. toleranse
                if (ToleranseAdv != null)
                { //To toleranser
                    _s.CheckTemplateValue = _s.CheckTemplateValue + " (" + _s.DvhValue.ToleranceErr + ")";
                }
                else
                {  //Kun Abs toleranse
                    _s.CheckTemplateValue = op + " " + _s.DvhValue.ToleranceErr;
                }

            }
            _s.CheckTemplateValue = _s.CheckTemplateValue + rEnhet;

            //sender resultat tilbake
            return _s;
        }


    }
}
