﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//---------
using System.Windows.Media.Media3D;
using System.Windows.Media;
using System.Collections.ObjectModel;
using VMS.TPS.Common.Model.API;
using System.Text.RegularExpressions;
using System.Windows;
using System.Diagnostics;

//Used code from CollisionCalculator by LDClark and Geometry from Helix toolkit

namespace EclipsePlanCheck.Helpers
{
    class CollisionCheck
    {

        static readonly DiffuseMaterial redMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.Red));
        static readonly DiffuseMaterial darkBlueMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.DarkBlue));
        static readonly DiffuseMaterial greenYellowMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.GreenYellow));
        static readonly DiffuseMaterial lightBlueMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.LightBlue));
        static readonly DiffuseMaterial magentaMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.Magenta));
        static readonly DiffuseMaterial greenMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.Green));
        static readonly DiffuseMaterial darkOrangeMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.DarkOrange));
        static readonly DiffuseMaterial yellowMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.Yellow));
        static readonly DiffuseMaterial darkGreenMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.DarkGreen));
        static readonly DiffuseMaterial lightGreenMaterial = new DiffuseMaterial(new SolidColorBrush(Colors.LightGreen));

        //linac gantry parameters in cm
        static readonly double distToCollFace = 43.7; //41.5; //39.8  I mobius: 40 //iso to collimator //43.5
        static readonly double distToCollFaceElectron = 5.0;  //distance from iso to electron cone tray
        static readonly double distToCollFaceSRS = 25.5;  //distance from iso to srs cone

        static readonly double collimatorDiameter1 = 48.0;  //Earlier 47 //gantry face diameter (metal plate)
        static readonly double collimatorDiameter2 = 77.0; //earlier 75 //gantry diameter (plastic hub)
        static readonly double collimatorDiameterSRS = 7.0;  //diameter of srs cone

        static readonly double collimatorFaceThickness = 4; //Should be 4 //metal plate thickness //2.75 //1  //4 (gir 43.5-4 = 39.5)
        static readonly double collimatorTopThickness = 20.0; //gantry plastic hub thickness
        static readonly double collimatorThicknessElectron = 30.0;  //thickness of electron cone
        static readonly double collimatorThicknessSRS = 10.0;  //thickness of srs cone

        //Collision check tolerances warnings in cm - see constants
        //public const double CollisionDistanceError = 3.0;
        //public const double CollisionDistanceWarning = 4.0;


        //---
        //Checks collision for a single beam
        //---
        //public static CollisionCheckViewModel CheckBeamCollision(Beam field, ExternalPlanSetup plan)
        //{
        //    var calculator = new CollisionCheck();

        //    return calculator.CalculateBeamCollision(plan, field);

        //}




        public static CollisionCheckViewModel CalculateBeamCollision(PlanSetup planSetup, Beam beam, MeshGeometry3D couchMesh, MeshGeometry3D bodyMesh, Structure couch, Structure body)
        {
            //Body and couch is allready defined in previous steps and should not have to be done again each time we calculate collision (per field)! Fix

            var calculator = new CollisionCheck();
            var modelGroup = new Model3DGroup();

            //time

            string debugGetCollimatorMesh = "";
            string debugShortestDistanceBody = "";
            string debugShortestDistanceCouch = "";

            //--------------------
            // Get Isosenter
            //--------------------
            var isoctr = GetIsocenter(beam);
            //var iso3DMesh = CalculateIsoMesh(isoctr);
            //--------------------

            //--------------------
            // Get Body and Couch
            //--------------------
            //var body = planSetup.StructureSet.Structures.Where(x => x.Id.Contains("BODY")).First();
            //Structure couch = null;
            //MeshGeometry3D couchMesh = null;
            //MeshBuilder couchMeshBuilder = new MeshBuilder(false,false); //Added 25.02 breped //False for normalization demanded
            //try
            //{
            //    foreach (Structure structure in planSetup.StructureSet.Structures)
            //    {
            //        if (structure.StructureCodeInfos.FirstOrDefault().Code == "Support" && structure.HasSegment && !structure.IsEmpty) //Will crash if not properly segmented
            //        {
            //            couch = structure;
            //            couchMesh = couch.MeshGeometry;
            //            couchMeshBuilder.Append(couchMesh); //Added 25.02 breped
            //        }
            //    }
            //    //Combine all couch structure in the end:
            //    couchMesh = couchMeshBuilder.ToMesh(); //Added 25.02 breped
            //}
            //catch ( Exception e)
            //{
            //    couch = null;
            //    MessageBox.Show("Feilmelding oppstod i CalculateBeamCollision angående summering av support-strukturer. Så teit da. Hopper til neste punkt. Feilmelding: " + Environment.NewLine + e.Message); //Added 25.02 breped
            //}
            //var bodyMesh = body.MeshGeometry;
            //--------------------

            //Create CollimatorMesh
            var stopwatch1 = Stopwatch.StartNew();
            MeshGeometry3D collimatorMesh = GetCollimatorMesh(beam, isoctr); //Should use simplified collimator model to save time.
            stopwatch1.Stop();
            debugGetCollimatorMesh = "CollimatorMesh: " + stopwatch1.ElapsedMilliseconds.ToString() + "ms(" + collimatorMesh.Positions.Count().ToString() + "pts)";

            string shortestDistanceBody;
            string shortestDistanceTable;
            string status = Constants.Ok; //"Clear";

            double? shortestDistanceBodyDouble = 999;
            double? shortestDistanceTableDouble = 999;

            //Distance to Body
            var stopwatch2 = Stopwatch.StartNew();
            if (body != null)
            {
                //shortestDistanceBody = ShortestDistance(collimatorMesh, bodyMesh);
                //shortestDistanceBody = (Math.Sqrt(ShortestDistance2(collimatorMesh, bodyMesh))/10).ToString("0.0"); //faster
                shortestDistanceBody = ShortestDistanceFast(collimatorMesh, bodyMesh).ToString("0.0");
                shortestDistanceBodyDouble = Convert.ToDouble(shortestDistanceBody);
            }
            else {
                shortestDistanceBody = " - ";
                status = " - ";
            }
            stopwatch2.Stop();
            debugShortestDistanceBody = "DistanceBody: " + stopwatch2.ElapsedMilliseconds.ToString() + "ms(" + bodyMesh.Positions.Count().ToString() + "pts)";

            //Distance to Couch
            var stopwatch3 = Stopwatch.StartNew();
            if (couch != null)
            {
                //shortestDistanceTable = ShortestDistance(collimatorMesh, couchMesh);
                //shortestDistanceTable = (Math.Sqrt(ShortestDistance2(collimatorMesh, couchMesh)) / 10).ToString("0.0");
                shortestDistanceTable = (ShortestDistanceFast(collimatorMesh, couchMesh)).ToString("0.0");
                shortestDistanceTableDouble = Convert.ToDouble(shortestDistanceTable);
            }
            else
            {
                shortestDistanceTable = " - ";
                status = " - ";
            }
            stopwatch3.Stop();
            debugShortestDistanceCouch = "DistanceCouch: " + stopwatch3.ElapsedMilliseconds.ToString() + "ms("+couchMesh.Positions.Count().ToString() + "pts)";

            Console.WriteLine(beam.Id + " - gantry to body is " + shortestDistanceBody + " cm");
            Console.WriteLine(beam.Id + " - gantry to table is " + shortestDistanceTable + " cm");
            if (shortestDistanceTable != " - " &&  shortestDistanceBody != " - ")
            {
                if ((shortestDistanceBodyDouble < Constants.CollisionDistanceError) || (shortestDistanceTableDouble < Constants.CollisionDistanceError))
                {
                    status = Constants.Error; //"Collision";
                }
                else if ((shortestDistanceBodyDouble < Constants.CollisionDistanceWarning) || (shortestDistanceTableDouble < Constants.CollisionDistanceWarning))
                {
                    status = Constants.Warning; //"Warning";
                }
            }
            else {

                status = Constants.OBS; //Not possible to calculate
            }
            var collisionSummary = new CollisionCheckViewModel
            {
                View = true,
                FieldID = beam.Id,
                GantryToBody = shortestDistanceBody + " cm",
                GantryToTable = shortestDistanceTable + " cm",
                Status = status,
                Debug = debugGetCollimatorMesh + " " + debugShortestDistanceBody + " " + debugShortestDistanceCouch
            };
            return collisionSummary;
        }

        public static Model3DGroup AddFieldMesh(Beam beam, string status)
        {
            var collimatorMaterial = lightGreenMaterial; //lightGreenMaterial darkGreenMaterial
            var backMaterial = greenYellowMaterial;
            var modelGroup = new Model3DGroup();
            var isoctr = GetIsocenter(beam); //This is done twice now!
            var iso3DMesh = CalculateIsoMesh(isoctr);
            if (beam.MLCPlanType.ToString() == "VMAT" || beam.Technique.Id.Contains("ARC"))
                collimatorMaterial = greenYellowMaterial;
            if (beam.EnergyModeDisplayName.Contains("E"))
            {
                collimatorMaterial = yellowMaterial;
                backMaterial = yellowMaterial;
            }
            if (status == Constants.Error) //"Collision"
            {
                collimatorMaterial = redMaterial;
            }
            if (status == Constants.Warning) //"Warning"
            {
                collimatorMaterial = darkOrangeMaterial;
            }
            MeshGeometry3D collimatorMesh = GetCollimatorMesh(beam, isoctr, false);
            modelGroup.Children.Add(new GeometryModel3D { Geometry = collimatorMesh, Material = collimatorMaterial, BackMaterial = backMaterial });
            modelGroup.Children.Add(new GeometryModel3D { Geometry = iso3DMesh, Material = redMaterial, BackMaterial = redMaterial });
            modelGroup.Freeze();
            return modelGroup;
        }

        public static Model3DGroup AddCouchBodyMesh(Structure body, StructureSet strset)
        {
            var modelGroup = new Model3DGroup();
            //Check All Support structures
            try
            {
                foreach (Structure structure in strset.Structures)
                {
                    if (structure.StructureCodeInfos.FirstOrDefault().Code == "Support")
                    {
                        Structure couch = structure;
                        if (couch != null)
                            modelGroup.Children.Add(new GeometryModel3D { Geometry = couch.MeshGeometry, Material = magentaMaterial, BackMaterial = yellowMaterial });
                    }
                }
            }
            catch
            {
            }

            if (body != null)
                modelGroup.Children.Add(new GeometryModel3D { Geometry = body.MeshGeometry, Material = lightBlueMaterial, BackMaterial = yellowMaterial });
            modelGroup.Freeze();
            return modelGroup;
        }


        public static Point3D GetIsocenter(Beam beam)
        {
            Point3D iso = new Point3D();
            iso.X = beam.IsocenterPosition.x;
            iso.Y = beam.IsocenterPosition.y;
            iso.Z = beam.IsocenterPosition.z;
            return iso;
        }

        public static Point3D GetCameraPosition(Beam beam)
        {
            Point3D cameraPosition = new Point3D();
            cameraPosition.X = beam.IsocenterPosition.x;
            cameraPosition.Y = beam.IsocenterPosition.y;
            cameraPosition.Z = beam.IsocenterPosition.z - 2000;
            return cameraPosition;
        }

        //To do: NEED to add support for multiple patient orientations. Now if it is not headfirstsupine, it ASSUMES headfirstprone!
        //// Not correct necessarily. Should instead refuse or give warning that it cannot calculate instead
        public static MeshGeometry3D GetCollimatorMesh(Beam beam, Point3D iso, bool simplifiedForCalculation = true)
        {
            var meshBuilder = new MeshBuilder(false, false);
            int thetaDiv = 20;
            double tableAngle = beam.ControlPoints.First().PatientSupportAngle <= 180.0f ? (Math.PI / 180.0f) *
                beam.ControlPoints.First().PatientSupportAngle : (Math.PI / 180.0f) * (beam.ControlPoints.First().PatientSupportAngle - 360.0f);
            double gantryAngle;

            if (beam.MLCPlanType.ToString() == "VMAT" || beam.Technique.Id.Contains("ARC"))  //Should cover "SRS ARC" as well.
            {
                int i = 0;
                int arcAngleResolution = 0;  //number of degrees to skip
                foreach (ControlPoint cp in beam.ControlPoints)
                {
                    if (beam.Plan.TreatmentOrientation.ToString() == "HeadFirstProne")
                        gantryAngle = ConvertProneGantryAngleToRadians(cp.GantryAngle);

                        //Test out this one to solve orientationproblem:  beam.GantryAngleToUser
                    else
                        gantryAngle = ConvertSupineGantryAngleToRadians(cp.GantryAngle); ;
                    i++;
                    if ((cp.Index == beam.ControlPoints.First().Index) ||
                        (beam.GantryDirection.ToString() == "Clockwise" && cp.Index == (beam.ControlPoints.First().Index + arcAngleResolution)) ||
                        (beam.GantryDirection.ToString() == "CounterClockwise" && cp.Index == (beam.ControlPoints.First().Index + arcAngleResolution)) ||
                        (cp.Index == beam.ControlPoints.Last().Index))
                    {
                        if(simplifiedForCalculation == true)
                        {
                            AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace - collimatorFaceThickness, collimatorFaceThickness, collimatorDiameter1); //AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorFaceThickness, collimatorDiameter1);
                            AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorTopThickness, collimatorDiameter2); //collimatorFaceThickness //AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorTopThickness, collimatorDiameter2);
                        }
                        else
                        {
                            AddCylinderToMeshWithCap(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace - collimatorFaceThickness, collimatorFaceThickness, collimatorDiameter1); //AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorFaceThickness, collimatorDiameter1);
                            AddCylinderToMeshWithCap(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorTopThickness, collimatorDiameter2); //collimatorFaceThickness //AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorTopThickness, collimatorDiameter2);
                        }

                       
                    }

                    if (i > arcAngleResolution)
                        arcAngleResolution = arcAngleResolution + 20;
                }
            }
            if (beam.Technique.ToString().Contains("STATIC"))
            {
                if (beam.Plan.TreatmentOrientation.ToString() == "HeadFirstProne")
                    gantryAngle = ConvertProneGantryAngleToRadians(beam.ControlPoints.First().GantryAngle);
                else
                    gantryAngle = ConvertSupineGantryAngleToRadians(beam.ControlPoints.First().GantryAngle);
                
                if (simplifiedForCalculation == true)
                { //Model more collision calculation-friendly
                    AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace - collimatorFaceThickness, collimatorFaceThickness, collimatorDiameter1); //AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorFaceThickness, collimatorDiameter1);
                    AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorTopThickness, collimatorDiameter2);
                }
                else
                { //Model more view-friendly
                    AddCylinderToMeshWithCap(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace - collimatorFaceThickness, collimatorFaceThickness, collimatorDiameter1); //AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorFaceThickness, collimatorDiameter1);
                    AddCylinderToMeshWithCap(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFace, collimatorTopThickness, collimatorDiameter2);
                }


            }
            if (beam.EnergyModeDisplayName.Contains("E"))
            {
                double fieldSize = Double.Parse(Regex.Match(beam.Applicator.Id, @"\d+").Value);
                double collimatorDiameterElectron = fieldSize + 9.0; //add 9 cm safety margin

                if (beam.Plan.TreatmentOrientation.ToString() == "HeadFirstProne")
                    gantryAngle = ConvertProneGantryAngleToRadians(beam.ControlPoints.First().GantryAngle);
                else
                    gantryAngle = ConvertSupineGantryAngleToRadians(beam.ControlPoints.First().GantryAngle);
                AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFaceElectron, collimatorThicknessElectron, collimatorDiameterElectron);

            }
            if (beam.EnergyModeDisplayName.Contains("SRS")) //Remove this section as we do not use cones.
            {
                thetaDiv = 10;
                double gantryAngleLast;

                if (beam.Plan.TreatmentOrientation.ToString() == "HeadFirstProne")
                    gantryAngleLast = ConvertProneGantryAngleToRadians(beam.ControlPoints.Last().GantryAngle);
                else
                    gantryAngleLast = ConvertSupineGantryAngleToRadians(beam.ControlPoints.Last().GantryAngle);

                foreach (ControlPoint cp in beam.ControlPoints)
                {
                    if (beam.Plan.TreatmentOrientation.ToString() == "HeadFirstProne")
                        gantryAngle = ConvertProneGantryAngleToRadians(cp.GantryAngle);
                    else
                        gantryAngle = ConvertSupineGantryAngleToRadians(cp.GantryAngle);
                    if ((cp.Index == beam.ControlPoints.First().Index) ||
                        (cp.Index == beam.ControlPoints.Last().Index))
                    {
                        AddCylinderToMesh(meshBuilder, gantryAngle, tableAngle, iso, thetaDiv, distToCollFaceSRS, collimatorThicknessSRS, collimatorDiameterSRS);
                    }
                    if (beam.GantryDirection.ToString() == "Clockwise" && cp.Index == beam.ControlPoints.First().Index)
                        for (double g = gantryAngle; g < gantryAngleLast; g = g + thetaDiv * (Math.PI / 180))
                            AddCylinderToMesh(meshBuilder, g, tableAngle, iso, thetaDiv, distToCollFaceSRS, collimatorThicknessSRS, collimatorDiameterSRS);

                    if (beam.GantryDirection.ToString() == "CounterClockwise" && cp.Index == beam.ControlPoints.First().Index)
                        for (double g = gantryAngle; g > gantryAngleLast; g = g - thetaDiv * (Math.PI / 180))
                            AddCylinderToMesh(meshBuilder, g, tableAngle, iso, thetaDiv, distToCollFaceSRS, collimatorThicknessSRS, collimatorDiameterSRS);
                }
            }
            return meshBuilder.ToMesh(true);
        }

        public static double ConvertProneGantryAngleToRadians(double angle)
        {
            return angle <= 180.0 ? (Math.PI / 180.0) * (angle - 180.0) : (Math.PI / 180.0) * (angle - 180.0);
        }

        public static double ConvertSupineGantryAngleToRadians(double angle)
        {
            return angle <= 180.0 ? (Math.PI / 180.0) * angle : (Math.PI / 180.0) * (angle - 360.0);
        }

        public static MeshBuilder AddCylinderToMesh(MeshBuilder meshBuilder, double gantryAngle, double tableAngle,
            Point3D iso, int thetaDiv, double distanceFromIso, double cylinderThickness, double diameter)
        {
            Point3D circleCenter1 = new Point3D();
            Point3D circleCenter2 = new Point3D();

            //convert from cm to mm
            distanceFromIso = distanceFromIso * 10;
            cylinderThickness = cylinderThickness * 10;
            diameter = diameter * 10;

            circleCenter1.X = iso.X + distanceFromIso * Math.Cos(tableAngle) * Math.Sin(gantryAngle);
            circleCenter1.Y = iso.Y - distanceFromIso * Math.Cos(gantryAngle);
            circleCenter1.Z = iso.Z - distanceFromIso * Math.Sin(tableAngle) * Math.Sin(gantryAngle);

            circleCenter2.X = iso.X + (distanceFromIso + cylinderThickness) * Math.Cos(tableAngle) * Math.Sin(gantryAngle);
            circleCenter2.Y = iso.Y - (distanceFromIso + cylinderThickness) * Math.Cos(gantryAngle);
            circleCenter2.Z = iso.Z - (distanceFromIso + cylinderThickness) * Math.Sin(tableAngle) * Math.Sin(gantryAngle);

            meshBuilder.AddCylinder(circleCenter1, circleCenter2, diameter, thetaDiv); //No caps
            //use this if you want CAPPing of the ends:
            //meshBuilder.AddCylinder(circleCenter1, circleCenter2, diameter/2, thetaDiv, true, true); //Adding CAPs

            return meshBuilder;
        }

        public static MeshBuilder AddCylinderToMeshWithCap(MeshBuilder meshBuilder, double gantryAngle, double tableAngle,
            Point3D iso, int thetaDiv, double distanceFromIso, double cylinderThickness, double diameter)
        {
            Point3D circleCenter1 = new Point3D();
            Point3D circleCenter2 = new Point3D();

            //convert from cm to mm
            distanceFromIso = distanceFromIso * 10;
            cylinderThickness = cylinderThickness * 10;
            diameter = diameter * 10;

            circleCenter1.X = iso.X + distanceFromIso * Math.Cos(tableAngle) * Math.Sin(gantryAngle);
            circleCenter1.Y = iso.Y - distanceFromIso * Math.Cos(gantryAngle);
            circleCenter1.Z = iso.Z - distanceFromIso * Math.Sin(tableAngle) * Math.Sin(gantryAngle);

            circleCenter2.X = iso.X + (distanceFromIso + cylinderThickness) * Math.Cos(tableAngle) * Math.Sin(gantryAngle);
            circleCenter2.Y = iso.Y - (distanceFromIso + cylinderThickness) * Math.Cos(gantryAngle);
            circleCenter2.Z = iso.Z - (distanceFromIso + cylinderThickness) * Math.Sin(tableAngle) * Math.Sin(gantryAngle);

            //meshBuilder.AddCylinder(circleCenter1, circleCenter2, diameter, thetaDiv); //No caps
            //testing out a CAPPing the ends:
            meshBuilder.AddCylinder(circleCenter1, circleCenter2, diameter / 2, thetaDiv, true, true); //Adding CAPs

            return meshBuilder;
        }
        //Slow
        public static string ShortestDistance(MeshGeometry3D mesh1, MeshGeometry3D mesh2)
        {
            Point3DCollection meshPositions1 = mesh1.Positions;
            Point3DCollection meshPositions2 = mesh2.Positions;
            double shortestDistance = 2000000;
            foreach (Point3D point1 in meshPositions1)
            {
                foreach (Point3D point2 in meshPositions2)  //Speed may be improved by changing from using pow(x,2) to instead x*x. Test it and implement if faster.
                {
                    double distance = (Math.Sqrt((Math.Pow((point2.X - point1.X), 2)) + (Math.Pow((point2.Y - point1.Y), 2))
                        + (Math.Pow((point2.Z - point1.Z), 2)))) / 10;
                    if (distance < shortestDistance)
                    {
                        shortestDistance = distance;
                    }
                }
            }
            return shortestDistance.ToString("0.0");
        }
        //Fast! Modified for speed
        public static double ShortestDistanceFast(MeshGeometry3D mesh1, MeshGeometry3D mesh2)
        {
            Point3DCollection meshPositions1 = mesh1.Positions;
            Point3DCollection meshPositions2 = mesh2.Positions;
            double shortestDistance = double.MaxValue;
            foreach (Point3D point1 in meshPositions1)
            {
                foreach (Point3D point2 in meshPositions2)  //Speed may be improved by changing from using pow(x,2) to instead x*x. Test it and implement if faster.
                {
                    double x = (point2.X - point1.X);
                    double y = (point2.Y - point1.Y);
                    double z = (point2.Z - point1.Z);
                    double distance = (x * x) + (y * y) + (z * z);
                    if (distance < shortestDistance)
                    {
                        shortestDistance = distance;
                    }
                }
            }
            double shortestDistance_final = (Math.Sqrt(shortestDistance) / 10);

            return shortestDistance_final;
        }

        public static MeshGeometry3D CalculateIsoMesh(Point3D iso)
        {
            var meshBuilder = new MeshBuilder(false, false);
            meshBuilder.AddSphere(iso, 10);

            return meshBuilder.ToMesh(true);
        }






    }
}
