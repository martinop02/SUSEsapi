﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using EclipsePlanCheck.Helpers;
using System.Diagnostics;

namespace EclipsePlanCheck.Helpers
{
    class CheckPointExtension
    {



        public static CheckPoint AddDvhCheckPoint(string _SjekkTrafikklys, string _pPrefix, string _pEnhet, string _strukturID, string _Operator, string _rEnhet, Double _pValue = 99999, Double _ToleranseAdv = 99999, Double _ToleranseErr = 99999, string _Kommentar = "")
        {

            DvhValue _dvhValue = new DvhValue();
            _dvhValue = new DvhValue { pPrefix = _pPrefix, pEnhet = _pEnhet, StructureID = _strukturID, Operator = _Operator, rEnhet = _rEnhet };

            //legger til optional parametre:
            if (_pValue != 99999) { _dvhValue.pValue = _pValue; }
            if (_ToleranseAdv != 99999) { _dvhValue.ToleranceAdv = _ToleranseAdv; }
            if (_ToleranseErr != 99999) { _dvhValue.ToleranceErr = _ToleranseErr; }

            //Oppretter sjekkpunktet:
            CheckPoint checkpoint = new CheckPoint()
            {
                CheckSwitchCode = "DVH",
                CheckListCategory = "DVH",
                CheckNumber = "6.1",
                CheckCategory = "DVH",
                CheckName = "",
                CheckTemplateValue = "",
                CheckVerification = "",
                CheckComment = _Kommentar,
                CheckType = Constants.Check,
                CheckExplanation = "Sjekker om dvh-verdi er innenfor toleranse. Kan hente Dx[Gy/%] i [Gy/%], Vx[cc/%] i [Gy/%], Mean i [Gy/%], Max i [Gy/%], Min i [Gy/%], CVx[Gy/%] i [cc/%] (Critical Volume). Hvor x er et tall. sjekkpunktene kan legges inn i CreateDVHCheckPointList",
                CheckTrafficLight = _SjekkTrafikklys,
                CheckTaskName = "Fysiker|Doseplan",
                DvhValue = _dvhValue,
                CheckInactivated = Constants.False,
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist,
                CheckInvisibleUnlessWarningOrError = Constants.False,


            }; ;

            return checkpoint; //returnerer
        }


        public static CheckPoint AddMarginsCheckPoint(Margins margins, MarginList marginList, CheckPoint marginsCPsettings, Double expectedMeanMargin = -1, Double meanNotCroppedMarginToleranceLowWarning = -1, Double meanNotCroppedMarginToleranceHighWarning = -1, Double meanNotCroppedMarginToleranceLowError = -1, Double meanNotCroppedMarginToleranceHighError = -1) //We have to load the tolerances from somewhere
        {

            //Margins MarginsResult = StructureExtension.CreateDefaultMargins();
            string checkListCategory = "CT og strukturer";
            string tolerance = "";
            string debug = "";
            bool tolerancedoesNotExist = true;
            string trafficLight = "";

            //------------------
            //Add optional tolerance parametre (using dummy number to detect if it is set or not):
            //-----------------
            tolerancedoesNotExist = ((expectedMeanMargin == -1) && (meanNotCroppedMarginToleranceLowWarning == -1) && (meanNotCroppedMarginToleranceHighWarning == -1) && (meanNotCroppedMarginToleranceLowError == -1) && (meanNotCroppedMarginToleranceHighError == -1));
            //We do not use "standard" margin, just print without any evaluation then.  //expectedMeanMargin = Constants.StandardMarginIfNoTemplateValue;}


            if (tolerancedoesNotExist == false)
            {
                //tolerance = GeneralExtension.GenerateTableLine(4, 4, "Expected:|Tol. warn:|Tol. err:");
                //tolerance = tolerance + Environment.NewLine + GeneralExtension.GenerateTableLine(4, 4, expectedMeanMargin + "|" + meanNotCroppedMarginToleranceLowWarning.ToString() + "-" + meanNotCroppedMarginToleranceHighWarning  + "|" + meanNotCroppedMarginToleranceLowError.ToString() + "-" + meanNotCroppedMarginToleranceHighError);
                trafficLight = marginsCPsettings.CheckTrafficLight; //Constants.Warning;
            }
            else
            {
                tolerance = "Ingen" + Environment.NewLine + "templat";
                trafficLight = Constants.Info;
            }

            //Create Debug:
            debug = "------- Margin List Matching Debug ------" + Environment.NewLine;
            debug = debug + marginList.Debug; 
            if (marginList.Debug != "") { debug = debug + Environment.NewLine; }
            debug = debug + "------- Margin Debug ------" + Environment.NewLine;
            debug = debug + margins.Debug;

            //MessageBox.Show("AddMarginsCheckPoint");
            //MarginsExtension.PrintMarginTemplate(margins);
            CheckPoint checkpoint = new CheckPoint();


            //IF settings were loaded successfully:
            if (marginsCPsettings != null)
            {
                //Oppretter sjekkpunktet:
                CheckPoint checkpointA = new CheckPoint()
                {
                    CheckSwitchCode = marginsCPsettings.CheckSwitchCode,
                    CheckListCategory = checkListCategory,
                    CheckNumber = marginsCPsettings.CheckNumber, //"2.6",
                    CheckCategory = marginsCPsettings.CheckCategory, //"Strukturer",
                    CheckName = "Marginer: " + Environment.NewLine + margins.SmallStructureID + " -> " + Environment.NewLine + margins.LargeStructureID, // + Environment.NewLine +
                    CheckTemplateValue = tolerance, //Put in tolerances here in string "Tolerance range warning:" + "[4-6mm]" + "Tolerances range Error:" + "[3-7mm]") 
                    CheckTemplateValueDisplay = "",
                    CheckVerification = marginsCPsettings.CheckVerification,
                    CheckComment = margins.Comment,
                    CheckType = marginsCPsettings.CheckType, //Constants.Check,
                    CheckExplanation = marginsCPsettings.CheckExplanation, //"Sjekker om marginene er innenfor toleranse. Hvis ingen toleranser oppgitt, vises bare marginene til info.",
                    CheckTrafficLight = trafficLight, //differenciate between info and warnings depanding on if there is a margins template.
                    CheckTaskName = marginsCPsettings.CheckTaskName, //"Fysiker|Doseplan",
                    CheckInactivated = marginsCPsettings.CheckInactivated, //Constants.False,
                    CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist, //Keeping this one set in code.
                    CheckInvisibleUnlessWarningOrError = marginsCPsettings.CheckInvisibleUnlessWarningOrError, //Constants.False,
                    Margins = margins, //Sends updated margin back
                    CheckStatus = "",
                    CheckDebug = debug, //plus marginsList.Debug?
                    CheckResultValue = margins.Output,
                    CalculateLate = marginsCPsettings.CalculateLate, //true, //CalculateLate = true,
                                                                     //Progress = 0,
                };
                checkpoint = checkpointA;

            }
            //Values to use if settings were NOT loaded successfully:
            else
            {
                MessageBox.Show("Failed to load custom CheckPointSettings for 'Margins' CheckPoint. Using default settings. ");
                CheckPoint checkpointB = new CheckPoint()
                {
                    CheckSwitchCode = "Margins",
                    CheckListCategory = checkListCategory,
                    CheckNumber = "2.6",
                    CheckCategory = "Strukturer",
                    CheckName = "Marginer: " + Environment.NewLine + margins.SmallStructureID + " -> " + Environment.NewLine + margins.LargeStructureID, // + Environment.NewLine +
                    CheckTemplateValue = tolerance, //Put in tolerances here in string "Tolerance range warning:" + "[4-6mm]" + "Tolerances range Error:" + "[3-7mm]") 
                    CheckTemplateValueDisplay = "",
                    CheckVerification = "",
                    CheckComment = "Failed to load custom CheckPointSettings for 'Margins' CheckPoint. Using default settings" + Environment.NewLine + margins.Comment,
                    CheckType = Constants.Check, //Constants.Check,
                    CheckExplanation = "Sjekker om marginene er innenfor toleranse. Hvis ingen toleranser oppgitt, vises bare marginene til info.", //"Sjekker om marginene er innenfor toleranse. Hvis ingen toleranser oppgitt, vises bare marginene til info.",
                    CheckTrafficLight = trafficLight, //differenciate between info and warnings depanding on if there is a margins template.
                    CheckTaskName = "Fysiker|Doseplan", //"Fysiker|Doseplan",
                    CheckInactivated = Constants.False, //Constants.False,
                    CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist, //Keeping this one set in code.
                    CheckInvisibleUnlessWarningOrError = Constants.False, //Constants.False,
                    Margins = margins, //Sends updated margin back
                    CheckStatus = "",
                    CheckDebug = debug, //plus marginsList.Debug?
                    CheckResultValue = margins.Output,
                    CalculateLate = true, //true, //CalculateLate = true,
                                                                     //Progress = 0,
                };
                checkpoint = checkpointB;
            }
            //MessageBox.Show("After Margins CP modified.");
            //GeneralExtension.PrintObject(checkpoint);



            return checkpoint; //returnerer
        }

        public static CheckPoint CheckFractionationVsTemplate(string resultatverdi, string templatverdi, CheckPoint s)
        {
            // ---- Fraksjonering ----

            //Genererer liste av fraksjon
            List<Fractionation> frliste_resultat = PlanExtension.ConvertStringToFractionationClass(resultatverdi); //ConvertStringToFractionationClass
            List<Fractionation> frliste_templat = PlanExtension.ConvertStringToFractionationClass(templatverdi);
            Double frd_r = 0;
            Double antfr_r = 0;
            Double totD_r = 0;

            Double frd_t = 0;
            Double antfr_t = 0;
            Double totD_t = 0;

            bool Avvikerhelt = false;

            string tempresult = "";
            string tempforklaring = "";

            bool match = false; //kun en match

            Double.TryParse(frliste_resultat.First().DosePerFraction.Replace(",", "."), out frd_r); //NumberStyles.Number, CultureInfo.InvariantCulture
            Double.TryParse(frliste_resultat.First().TotalDose.Replace(",", "."), out totD_r);
            Double.TryParse(frliste_resultat.First().NumberOfFractions.Replace(",", "."), out antfr_r);

            //Sjekker templatlisten om det er match
            foreach (Fractionation fr in frliste_templat)
            {


                Double.TryParse(fr.DosePerFraction.Replace(",", "."), out frd_t);
                Double.TryParse(fr.TotalDose.Replace(",", "."), out totD_t);
                Double.TryParse(fr.NumberOfFractions.Replace(",", "."), out antfr_t);

                //MessageBox.Show(fr.d + " x " + fr.Ant + " = " + fr.D + " Konvertert templat: " + frd_t + " x " + antfr_t + " = " + totD_t + Environment.NewLine + fr.d + " x " + fr.Ant + " = " + fr.D + " Konvertert resultat: " + frd_r + " x " + antfr_r + " = " + totD_r + Environment.NewLine + ((frd_r == frd_t) && (antfr_r == antfr_t) && (totD_t == totD_r) && match == false).ToString() );


                //Sjekker om fraksjoneringen stemmer
                if ((frd_r == frd_t) && (antfr_r == antfr_t) && (totD_t == totD_r) && match == false)
                {//Match
                    tempresult = Constants.Ok;
                    s.CheckElaboration = s.CheckElaboration + " Matcher med " + frd_r + " x " + antfr_t + " = " + totD_t;
                    match = true;
                    Avvikerhelt = false;
                    break;//Går ut av foreach-loop
                }
                else if (tempresult != Constants.Ok)
                {//Ikke match + finnes ingen tidligere match.
                    // Sjekk om den er nesten korrekt:
                    if ((frd_r - frd_t < 0.1 && frd_r - frd_t > -0.1) && (antfr_r == antfr_t) && (frd_r - frd_t <= 0.5 && totD_r - totD_t >= -0.5))
                    {
                        tempresult = Constants.Warning;
                        tempforklaring = " Matcher nesten med: " + frd_t + " x " + antfr_t + " = " + totD_t;
                        s.CheckElaboration = s.CheckElaboration + tempforklaring;
                    }
                    else //Ellers helt feil
                    {
                        //Kun skriv hvis ikke allerede warning
                        if (tempresult != Constants.Warning)
                        {
                            tempresult = s.CheckTrafficLight;
                            Avvikerhelt = true;
                        }
                    }
                }

            }


            //Setter resultat
            s.CheckStatus = tempresult;

            //Setter kommentar etter status hvis warning eller feil
            if (Avvikerhelt == true)
            {
                s.CheckElaboration = "Fraksjonering avviker fra templatet.";
                s.CheckComment = "Fraksjonering avviker fra templatet.";
            }
            else if (tempresult == Constants.Warning)
            {
                s.CheckElaboration = "Fraksjonering avviker litt (<0.1Gy pr fraksjon, <= 0.5Gy totdose) fra templatet." + tempforklaring;
                s.CheckComment = "Fraksjonering avviker litt (<0.1Gy pr fraksjon, <= 0.5Gy totdose) fra templatet." + tempforklaring;
            }

            //Hvis ingen templat -> setter ukjent status.
            if (frliste_templat.Count == 0)
            {
                s.CheckStatus = Constants.Unknown;
                s.CheckElaboration = "Ingen templatverdi å sjekke mot. Kan ikke vurdere fraksjonering.";
            }

            return s;
        }

        //Only input two strings.
        public static String SjekkFraksjoneringMotTemplat(string resultatverdi, string templatverdi)
        {
            // ---- Fraksjonering ----

            //Genererer liste av fraksjon
            List<Fractionation> frliste_resultat = PlanExtension.ConvertStringToFractionationClass(resultatverdi);
            List<Fractionation> frliste_templat = PlanExtension.ConvertStringToFractionationClass(templatverdi);
            Double frd_r = 0;
            Double antfr_r = 0;
            Double totD_r = 0;

            Double frd_t = 0;
            Double antfr_t = 0;
            Double totD_t = 0;

            string tempresult = "";

            bool match = false; //kun en match

            Double.TryParse(frliste_resultat.First().DosePerFraction.Replace(",", "."), out frd_r); //NumberStyles.Number, CultureInfo.InvariantCulture
            Double.TryParse(frliste_resultat.First().TotalDose.Replace(",", "."), out totD_r);
            Double.TryParse(frliste_resultat.First().NumberOfFractions.Replace(",", "."), out antfr_r);

            //Sjekker templatlisten om det er match
            foreach (Fractionation fr in frliste_templat)
            {

                Double.TryParse(fr.DosePerFraction.Replace(",", "."), out frd_t);
                Double.TryParse(fr.TotalDose.Replace(",", "."), out totD_t);
                Double.TryParse(fr.NumberOfFractions.Replace(",", "."), out antfr_t);

                //Sjekker om fraksjoneringen stemmer
                if ((frd_r == frd_t) && (antfr_r == antfr_t) && (totD_t == totD_r) && match == false)
                {//Match
                    tempresult = Constants.True;

                    break;//Går ut av foreach-loop for bedre performance
                }
                else if (tempresult != Constants.True)
                {//Ikke match + finnes ingen tidligere match.
                 //Kun skriv hvis ikke allerede True. Beholder alltid match.
                    if (tempresult != Constants.True)
                    {
                        tempresult = Constants.False;
                    }
                }
            }

            return tempresult;
        }

        //Input CheckPoint
        public static string CheckResultVsTemplate(string resultatverdi, string templatverdi, string trafikklys, string typeSjekk, CheckPoint s, string op = "")
        {
            string boolSjekk = ""; // "Error";
            string debug = "";

            //String til array, hvis flere uthentinger eller flere templatverdier:
            //string[] res_arr = resultatverdi.Split(Constants.CharSeparator);
            //string[] temp_arr = templatverdi.Split(Constants.CharSeparator);

            // ---- Stringsjekk ----
            if (typeSjekk == "string")
            {
                boolSjekk = PlanExtension.CompareStringArrays(resultatverdi, templatverdi, trafikklys);
            }



            // ---- numerisk ----
            //IKKE IMPLEMENTERT ENDA
            
            if (typeSjekk == "numerisk")
            {

                bool _gyldigDoubleTemplate = false;
                bool _gyldigDoubleresult = false;
                double _Double_templatverdi = 0;
                double _Double_resultatverdi = 0;
                bool advResult = true;//ok

                //Sjekker om input er gyldig
                _gyldigDoubleTemplate = double.TryParse(templatverdi,
                        NumberStyles.Any, CultureInfo.InvariantCulture,
                        out _Double_templatverdi);

     
                _gyldigDoubleresult = double.TryParse(resultatverdi,
                NumberStyles.Any, CultureInfo.InvariantCulture,
                out _Double_resultatverdi);

                debug = "_Double_templatverdi:" + _Double_templatverdi + Environment.NewLine + "_Double_resultatverdi:" + _Double_resultatverdi + Environment.NewLine + "op:" + op + Environment.NewLine;
                debug = debug + "_gyldigDoubleTemplate:" + _gyldigDoubleTemplate + Environment.NewLine + "_gyldigDoubleresult:" + _gyldigDoubleresult + Environment.NewLine;
                //Hvis operator er gyldig
                if ((op == ">" || op == "<" || op == ">=" || op == "<=" || op == "=" || op == "==") && (_gyldigDoubleTemplate != false) && (_gyldigDoubleresult != false))
                {
                    //Sjekker advarsel. true = ok, false = fail.
                    advResult = GeneralExtension.SolveBooleanExpression(op, _Double_resultatverdi, _Double_templatverdi, s);
                    debug = debug + "advResult: " + advResult + Environment.NewLine;
                    if (advResult == false)
                    {//kun adv
                        boolSjekk = trafikklys; //s.CheckTrafficLight;
                    }
                    else
                    {//ok
                        boolSjekk = Constants.Ok;
                    }
                    debug = debug + "boolSjekk: " + boolSjekk + Environment.NewLine;
                }
                else
                {
                    boolSjekk = Constants.Unknown;
                    s.CheckDebug = s.CheckDebug + "Ugyldig input i numerisk sjekk. Sjekkpunkt: " + s.CheckNumber + " " + s.CheckName + ". "; //Sendes ikke tilbake til sjekkpunktet.
                    debug = debug + "boolSjekk: " + boolSjekk + Environment.NewLine + "Ugyldig input i numerisk sjekk. Sjekkpunkt: " + s.CheckNumber + " " + s.CheckName + ". ";
                }
               
            }
            //Debug
            //if (debug != "") { MessageBox.Show(debug); }
            return boolSjekk;
        }

        public static string stopWatchTimeElapsed (Stopwatch stopwatch)
        {

            //TimeSpan ts = stopwatch.Elapsed;
            //string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
            //    ts.Hours, ts.Minutes, ts.Seconds,
            //    ts.Milliseconds / 10);

            string elapsedTime = stopwatch.ElapsedMilliseconds.ToString();

            return elapsedTime;
        }



    }
}
