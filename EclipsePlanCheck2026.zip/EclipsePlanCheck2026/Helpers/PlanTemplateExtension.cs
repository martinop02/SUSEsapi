﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using EclipsePlanCheck.Helpers;
using System.Text.RegularExpressions;
using Image = VMS.TPS.Common.Model.API.Image;
using System.Reflection;



namespace EclipsePlanCheck.Helpers
{
    class PlanTemplateExtension
    {


        public static string ChangeColorByScore(int score)
        {
            int LessThanMinimumScoreToChoosetemplate = (int)(Constants.MinimumScoreToChooseATemplate - Math.Round(0.3 * Constants.MinimumScoreToChooseATemplate));

            string result = "Gray";
            if (score == 0)
            {
                result = "DarkGray"; //grå
            }
            else if ((score > 0) && (score <= 3))
            {
                result = "Olive"; // YellowGreen // Colors.Olive //Colors.Chartreuse //Colors.Lime //gulgrønn  //lime?
            }
            else if ((score > 3) && (score <= 10 || score <= LessThanMinimumScoreToChoosetemplate) )
            {
                result = "GreenYellow"; //grønngul - lysegrønn
            }
            else if ((score > LessThanMinimumScoreToChoosetemplate) && (score <= Constants.MinimumScoreToChooseATemplate))
            {
                result = "Green";
            }
            else if ((score > Constants.MinimumScoreToChooseATemplate))
            {
                result = "DarkGreen";
            }

            return result;
        }

        public static void PrintEclipseCheckTemplate(EclipseCheckTemplate eclipseCheckTemplate)
        {
            MessageBox.Show(EclipseCheckTemplateToString(eclipseCheckTemplate));
        }

    

        public static string EclipseCheckTemplateToString(EclipseCheckTemplate eclipseCheckTemplate)
        {
            string resultPrintEclipseCheckTemplate = "";

            //Get all properties from class
            PropertyInfo[] properties = typeof(EclipseCheckTemplate).GetProperties();
            //Iterate through all properties 
            foreach (PropertyInfo property in properties) //Must have exception for certain fields we do not want to override.
            {
                string value = "";
                //If property value not empty
                try
                {
                    value = property.GetValue(eclipseCheckTemplate).ToString();
                }
                catch
                {
                    value = "Unable to retrieve value from template. ";
                }
                string EclipseCheckTemplate = property.Name;

                if (resultPrintEclipseCheckTemplate == "") { resultPrintEclipseCheckTemplate = EclipseCheckTemplate + ": " + value; }
                else { resultPrintEclipseCheckTemplate = resultPrintEclipseCheckTemplate + Environment.NewLine + EclipseCheckTemplate + ": " + value; }
            }

            return resultPrintEclipseCheckTemplate;
        }

        public static string MarginsTemplateToString(Margins margins)
        {
            string resultPrintEclipseCheckTemplate = "";

            //Get all properties from class
            PropertyInfo[] properties = typeof(Margins).GetProperties();
            //Iterate through all properties 
            foreach (PropertyInfo property in properties) //Must have exception for certain fields we do not want to override.
            {
                string value = "";
                //If property value not empty
                try
                {
                    value = property.GetValue(margins).ToString();
                }
                catch
                {
                    value = "Unable to retrieve value from template. ";
                }
                string EclipseCheckTemplate = property.Name;

                if (resultPrintEclipseCheckTemplate == "") { resultPrintEclipseCheckTemplate = EclipseCheckTemplate + ": " + value; }
                else { resultPrintEclipseCheckTemplate = resultPrintEclipseCheckTemplate + Environment.NewLine + EclipseCheckTemplate + ": " + value; }
            }

            return resultPrintEclipseCheckTemplate;
        }


        public static string SetFilePathEclipseCheckTemplates()
        {
            string filePathTemplates = "";
#if Debug
        filePathTemplates = Constants.PlanCheckTemplateTestFolderPath + Constants.PlanCheckTemplateFileName; //PlanCheckTemplateTestFileName
#endif

#if Clinical
            filePathTemplates = Constants.PlanCheckTemplateFolderPath + Constants.PlanCheckTemplateFileName; 
#endif
            //if (Constants.TestMode == false)
            //{
            //    filePathTemplates = Constants.PlanCheckTemplateFolderPath + Constants.PlanCheckTemplateFileName;
            //}
            //else if (Constants.TestMode == true)
            //{
            //    filePathTemplates = Constants.PlanCheckTemplateTestFolderPath + Constants.PlanCheckTemplateTestFileName;
            //}

            return filePathTemplates;
        }

        public static string SetFilePathEclipseCheckMachineOverrideTemplates()
        {
            string filePathTemplates = Constants.PlanCheckTemplateMachineOverideFolderPath + Constants.PlanCheckTemplateMachineOverideFileName;
            return filePathTemplates;
        }

        public static string SetFilePathMarginsTemplates()
        {
            string filePathTemplates = Constants.MarginTemplatesFolderPath + Constants.MarginTemplatesFileName;
            return filePathTemplates;
        }

        //PlanCheckTemplateMachineOverideFolderPath PlanCheckTemplateMachineOverideFileName

        //Imporement: Make a function LoadSingleEclipseCheckTemplate and run it several times instead?
        public static List<EclipseCheckTemplate> LoadEclipseCheckTemplates(string filePathTemplates) 
        {
            //patientContext not required yet here, but could be used to skip loading uneccesary parts of templates?
            
            //Create empty list
            List<EclipseCheckTemplate> eclipseCheckTemplatesList = new List<EclipseCheckTemplate>();
            string line = "";
            int linesCount = 0;
            int columnsCount = 0;
            int lastcolumnsCount = 0;


            IEnumerable<string> lines = File.ReadLines(filePathTemplates);
            linesCount = lines.Count();

            //Iterate over lines. Start from 1 to skip the headers.
            for (int i = 1; i < lines.Count(); i++)
            {
                line = lines.ElementAt(i); //One line is a template

                //Split templates into array:
                string[] lineArray = line.Split(';');  // List<char> lineList = line.ToList();
                    
                    //Any validation we need to add here??
                    //MessageBox.Show(line);
                columnsCount = lineArray.Length;

                //Validate input
                if ((columnsCount != lastcolumnsCount) && (lastcolumnsCount!= 0))
                {
                    //Check if one template has wrong number of columns and warn user
                    MessageBox.Show("One line in a template csv-file has different number of columns. This could be because of using characters (like ';') similar to separator used in csv-file, thus causing an extra column. Columns current template:" + columnsCount.ToString() + " . Columns last template checked: " + lastcolumnsCount);
                }
                lastcolumnsCount = columnsCount;
                
                //Add to class
                eclipseCheckTemplatesList.Add(new EclipseCheckTemplate
                    {
                        TemplateName = lineArray[0],
                        TemplateDiagnosis = lineArray[1],
                        TemplateStrukturSetIDs = lineArray[2],
                        TemplatePTVStructureIDs = lineArray[3],
                        TemplateCTVStructureIDs = lineArray[4],
                        TemplateOARStructureIDs = lineArray[5],
                        TemplateOtherStructureIDs = lineArray[6],
                        TemplateCourseIDs = lineArray[7],
                        TemplatePlanIDs = lineArray[8],
                        TemplateFractionations = lineArray[9],
                        TemplateTechniqueName = lineArray[10],
                        TemplateIntent = lineArray[11],
                        TemplatePatientOrientation = lineArray[12],
                        TemplateCTSliceThickness = lineArray[13],
                        TemplateNormalization = lineArray[14],
                        TemplateCalculationAlgorithm = lineArray[15],
                        TemplateCalculationResolution = lineArray[16],
                        TemplateToleranceTableTreat = lineArray[17],
                        TemplateToleranceTableSetup = lineArray[18],
                        TemplateNumberOfSetupFields = lineArray[19],
                        TemplateEnergyChoice = lineArray[20],
                        TemplateBasePlanContribution = lineArray[21],
                        TemplateCouchName = lineArray[22],
                        TemplateCouchHU = lineArray[23],
                        TemplateMandatoryHighResolutionStructureIDs = lineArray[24],
                        TemplateMandatoryStructureIDs = lineArray[25],
                        Debug = "",

                        TemplateComment = lineArray[26],
                    });

                }
            //}
            //catch
            //{
            //    ErrorHandlingExtension.ErrorDog("Kan ikke laste inn templater. Kontroller filen " + filePathTemplates + Environment.NewLine + "Siste linje lest foer feilen oppstod: " + line + Environment.NewLine + "Returnerer tom templatliste.");

            //}


            return eclipseCheckTemplatesList;
        }


        public static EclipseCheckTemplate OverideElipseTemplatePropertiesIfNotEmpty(EclipseCheckTemplate eclipseCheckTemplateToOverride, EclipseCheckTemplate eclipseCheckTemplatContainingOverride) //use input (PatientContext patientContext)?
        {
            //--------- DEBUG ----------------
            string overriddenProperties = "";
            //PrintEclipseCheckTemplate(eclipseCheckTemplateToOverride);//OverideElipseTemplatePropertiesIfNotEmpty
            //EclipseCheckTemplate record = new EclipseCheckTemplate();
            //-------------------------------

            //Get all properties from class
            PropertyInfo[] properties = typeof(EclipseCheckTemplate).GetProperties();
            //Iterate through all properties 
            foreach (PropertyInfo property in properties.Where(a => a.Name != "TemplateName" && a.Name != "TemplateScore" && a.Name != "ColorSet" && a.Name != "TemplateComment" && a.Name != "Debug")) //Must have exception for certain fields we do not want to override.
            {
                //If property value not empty
                string value = property.GetValue(eclipseCheckTemplatContainingOverride).ToString(); //Need an exeption if value is null/empty! ----- If (property.GetValue(eclipseCheckTemplatContainingOverride) != null){}
                string propertyOverridden = property.Name;
                if (value != "")
                {
                    //Set property
                    property.SetValue(eclipseCheckTemplateToOverride, value);
                    // overriddenProperties = overriddenProperties + "Override Success " + eclipseCheckTemplateToOverride.TemplateName + "! MachineOverride property: " + propertyOverridden + ". MachineOverride value: " + property.GetValue(eclipseCheckTemplateToOverride).ToString() + Environment.NewLine;
                    overriddenProperties = overriddenProperties + property.Name + ": " + value + " | ";
                }
            }
            eclipseCheckTemplateToOverride.Debug = eclipseCheckTemplateToOverride.Debug + overriddenProperties; //Debug to inform that certain properties are overridden
            // Debug: MessageBox.Show(overriddenProperties);
            //PrintEclipseCheckTemplate(eclipseCheckTemplateToOverride);/// Debug: 

            return eclipseCheckTemplateToOverride;
        }

        //Must be run on templates prior running all CheckPoins
        public static List<EclipseCheckTemplate> MachineTechniqueOverrideEclipseCheckTemplates(List<EclipseCheckTemplate> eclipseCheckTemplateList, List<EclipseCheckTemplate> machineOverrideTemplate, string machineID, List<Field> fieldList, PatientContext patientContext, string planTechnique) //use input (PatientContext patientContext)?
        {

            //MessageBox.Show("Start MachineOverrideEclipseCheckTemplates");
            //EclipseCheckTemplate record = new EclipseCheckTemplate();
            string machineType = ""; //PlanExtension.GetMachineType(fieldList); //patientContext.
            string machineMatch = "";
            string machineTypeMatch = "";
            string techniqueMatch = "";
            //string overrideDebug = "";
                              
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist) //Plan exists
            {
                machineType = PlanExtension.GetMachineType(fieldList);
           
                for (int iteratorMachineOverrideTemplate = machineOverrideTemplate.Count - 1; iteratorMachineOverrideTemplate >= 0; iteratorMachineOverrideTemplate--)
                {

                    //Check machine match, returns matching matchine ID:
                    machineMatch = GeneralExtension.CheckStringsVsStrings(machineID, machineOverrideTemplate[iteratorMachineOverrideTemplate].TemplateName);
                    machineTypeMatch = GeneralExtension.CheckStringsVsStrings(machineType, machineOverrideTemplate[iteratorMachineOverrideTemplate].TemplateName);
                    techniqueMatch = GeneralExtension.CheckStringsVsStrings(planTechnique, machineOverrideTemplate[iteratorMachineOverrideTemplate].TemplateName);
                    //MessageBox.Show("mid: " + machineID.ToString() + Environment.NewLine + "machineOverrideTemplate: " + machineOverrideTemplate[templateIterator].TemplateName + Environment.NewLine + "machineType: " + machineType + Environment.NewLine + "machineOverrideTemplate[templateIterator].TemplateName : " + machineOverrideTemplate[templateIterator].TemplateName + Environment.NewLine);

                    //If machine name matches or machineType, Override all properties except TemplateName, Score, ColorSet and Comment
                    if (machineMatch != "" || machineTypeMatch != "" || techniqueMatch != "")
                    {
                        // Override templates with machine temlate properties
                        for (var iteratorTemplateList = 0; iteratorTemplateList < eclipseCheckTemplateList.Count; iteratorTemplateList++)   // Former code: eclipseCheckTemplateList[chosenTemplateIndex] = PlanTemplateExtension.MachineOverrideEclipseCheckTemplates(eclipseCheckTemplateList[chosenTemplateIndex], eclipseCheckTemplateMachineOverrideList, planMachine, planFieldList, patientContext);
                        {
                            //if (eclipseCheckTemplateList[iteratorTemplateList].TemplateName != "Default") //Changed my mind. Also override even if default template!
                            //{
                                eclipseCheckTemplateList[iteratorTemplateList] = OverideElipseTemplatePropertiesIfNotEmpty(eclipseCheckTemplateList[iteratorTemplateList], machineOverrideTemplate[iteratorMachineOverrideTemplate]);
                            //}
                        }
                        //overrideDebug = eclipseCheckTemplateList[0].Debug;
                        //Iteratoe over columns and look for non-empty entries
                        //for (int columnsIterator = typeof(EclipseCheckTemplate).GetProperties().Length - 1; columnsIterator >= 0; columnsIterator--) {}
                    }

                }
            }
            return eclipseCheckTemplateList;
        }

        //Must be run on templates prior running all CheckPoints
        public static EclipseCheckTemplate ModifyLateralityEclipseCheckTemplate(EclipseCheckTemplate eclipseCheckTemplate, string laterality) //PatientContext patientContext
        {
            eclipseCheckTemplate.TemplatePTVStructureIDs = PlanTemplateExtension.AddLateralityToID(eclipseCheckTemplate.TemplatePTVStructureIDs, laterality, "struktur");  // PlanTemplateExtension.HentTemplatlister(templatNavn, maskin, teknikk, lateralitet, plan, "ptv");
            eclipseCheckTemplate.TemplateCTVStructureIDs = PlanTemplateExtension.AddLateralityToID(eclipseCheckTemplate.TemplateCTVStructureIDs, laterality, "struktur");  //PlanTemplateExtension.HentTemplatlister(templatNavn, maskin, teknikk, lateralitet, plan, "ctv");
            eclipseCheckTemplate.TemplatePlanIDs = PlanTemplateExtension.AddLateralityToID(eclipseCheckTemplate.TemplatePlanIDs, laterality, "plan");  // PlanTemplateExtension.HentTemplatlister(templatNavn, maskin, teknikk, lateralitet, plan, "planID");
            return eclipseCheckTemplate;
        }

        public static List<EclipseCheckTemplate> ModifyLateralityForAllEclipseCheckTemplates(List<EclipseCheckTemplate> eclipseCheckTemplates, PatientContext patientContext, string laterality)
        {
            for (int i = eclipseCheckTemplates.Count - 1; i >= 0; i--)
            {
                if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage) //Only if structureSet exists. If no plan exists, laterality is empty.
                {
                    eclipseCheckTemplates[i] = ModifyLateralityEclipseCheckTemplate(eclipseCheckTemplates[i], laterality);
                }
                else
                {
                    //Possibility to consider: if no plan laterality, add BOTH left and right structures!
                    //eclipseCheckTemplates[i] = ModifyLateralityEclipseCheckTemplate(eclipseCheckTemplates[i], lateralitet);
                }

            }
            return eclipseCheckTemplates;
        }

        public static string AddLateralityToID(string stringIDs, string laterality, string typeliste)
        {
            //separators
            char[] separators = new char[] { Constants.CharSeparator };

            //split input in array
            string[] IDsArray = stringIDs.Split(separators);
            // DEBUG: MessageBox.Show(string.Join(", ", IDsArray));
            //Empty arrays to be filled
            string[] lateralityArrayEndsWith = new string[] { };
            string[] lateralityArrayContains = new string[] { };

            //output
            string outputStringIdIncludingLaterality = "";

            //Decide what laterality array to use
            //--------------------------------------------
            switch (typeliste)
            {
                case "struktur":
                    //Define laterality arrays
                     if (laterality == Constants.Venstre)
                    {
                        lateralityArrayEndsWith = Constants.Structures_Template_Laterality_Left_EndsWith_String.Split(separators);
                        lateralityArrayContains = Constants.Structures_Template_Laterality_Left_Contains_String.Split(separators);
                    }
                    else if (laterality == Constants.Hoyre)
                    {
                        lateralityArrayEndsWith = Constants.Structures_Template_Laterality_Right_EndsWith_String.Split(separators);
                        lateralityArrayContains = Constants.Structures_Template_Laterality_Right_Contains_String.Split(separators);
                    }
                    else //ingen lateralitet
                    {
                        //Empty or both? or empty AND both?
                        lateralityArrayEndsWith = Enumerable.Concat(Constants.Structures_Template_Laterality_Left_EndsWith_String.Split(Constants.CharSeparator), Constants.Structures_Template_Laterality_Right_EndsWith_String.Split(Constants.CharSeparator)).ToArray();
                        lateralityArrayContains = Enumerable.Concat(Constants.Structures_Template_Laterality_Left_Contains_String.Split(Constants.CharSeparator), Constants.Structures_Template_Laterality_Right_Contains_String.Split(Constants.CharSeparator)).ToArray();
                    }

                    break;
                case "plan":
                    //Define laterality arrays
                    if (laterality == Constants.Venstre)
                    {
                        lateralityArrayEndsWith = Constants.PlanID_Template_Laterality_Left_EndsWith_String.Split(separators);
                        lateralityArrayContains = Constants.PlanID_Template_Laterality_Left_Contains_String.Split(separators);
                    }
                    else if (laterality == Constants.Hoyre)
                    {
                        lateralityArrayEndsWith = Constants.PlanID_Template_Laterality_Right_EndsWith_String.Split(separators);
                        lateralityArrayContains = Constants.PlanID_Template_Laterality_Right_Contains_String.Split(separators);
                    }
                    else //ingen lateralitet
                    {
                        //Empty
                    }
                    break;
            }

            //--------------------------------------------


            //After chosen laterality - change structure and plan IDs
            //--------------------------------------------
                //If laterality
            //if (laterality == Constants.Venstre || laterality == Constants.Hoyre)
            //{
            foreach (string stringID in IDsArray)
            {

                //if $$ is at end of string 
                if (stringID.EndsWith("$$"))
                {

                    foreach (string lat in lateralityArrayEndsWith)
                    {
                        if (!outputStringIdIncludingLaterality.EndsWith(Constants.StringSeparator) && outputStringIdIncludingLaterality != "") { outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + Constants.StringSeparator; }
                        outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + stringID.Replace("$$", lat);
                    }

                }
                //if $$ exist and is not at end of string
                if (!stringID.EndsWith("$$") && stringID.Contains("$$"))
                {
                    foreach (string lat in lateralityArrayContains)
                    {
                        if (!outputStringIdIncludingLaterality.EndsWith(Constants.StringSeparator) && outputStringIdIncludingLaterality != "") { outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + Constants.StringSeparator; }
                        outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + stringID.Replace("$$", lat);
                    }

                }
                //If string does not contain $$
                if (!stringID.Contains("$$"))
                {
                    if (!outputStringIdIncludingLaterality.EndsWith(Constants.StringSeparator) && outputStringIdIncludingLaterality != "") { outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + Constants.StringSeparator; }
                    outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + stringID; 
                }

                //If string contains $$ and there is noe laterality
                if (stringID.Contains("$$") && laterality != Constants.Venstre && laterality != Constants.Hoyre)
                {
                    if (!outputStringIdIncludingLaterality.EndsWith(Constants.StringSeparator) && outputStringIdIncludingLaterality != "") { outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + Constants.StringSeparator; }
                    outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + stringID.Replace("$$", "");
                }

            }

            //}
            //else //If no laterality  (OR add both maybe?)
            //{
            //    foreach (string stringID in IDsArray)
            //    {
            //        {
            //            //Remove
            //            if (!outputStringIdIncludingLaterality.EndsWith(Constants.StringSeparator) && outputStringIdIncludingLaterality != "") { outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + Constants.StringSeparator; }
            //            outputStringIdIncludingLaterality = outputStringIdIncludingLaterality + stringID.Replace("$$", "");
            //        }
            //    }
            //}
            //--------------------------------------------

            return outputStringIdIncludingLaterality;
        }




        public static int ScoreTemplate(string patientData, string templateData, int scoreToAdd)
        {
            int scoreResult = 0;
            char[] separators = new char[] { Constants.CharSeparator };


            string[] patientDataArray = patientData.Split(separators);
            string[] templateDataArray = templateData.Split(separators);

            //Iterate over template values
            foreach (string choseTemplateData in templateDataArray)
            {
                //Iterate over chosen patient values
                foreach (string chosenPatientData in patientDataArray)
                {
                    if (GeneralExtension.MatchWildcardString(choseTemplateData, chosenPatientData) == true)
                    {
                        scoreResult = scoreResult + scoreToAdd;

                    }
                }

            }


            return scoreResult;
        }



        public static string CreateStructureList(StructureSet strSet)
        {
            string patientStructureIDs = "";

            foreach (Structure str in strSet.Structures)
            {
                if (patientStructureIDs != "") { patientStructureIDs = patientStructureIDs + Constants.StringSeparator; }
                patientStructureIDs = patientStructureIDs + str.Id;
            }
            return patientStructureIDs;
        }

        public static List<string> CreateControlTaskList()
        {
            char[] separators = new char[] { Constants.CharSeparator };
            List<string> controlTaskTypeList = Constants.ControlTaskTypes.Split(separators, StringSplitOptions.RemoveEmptyEntries).ToList();
            return controlTaskTypeList;
        }

        public static List<EclipseCheckTemplate> ScoreTemplates(List <EclipseCheckTemplate> templateList, PatientContext patientContext, PlanTechnique planTechnique, string planMachine) //ExternalPlanSetup plan, Course course, PlanTechnique teknikk
        {
            //These variables will be set if patientContext allows it:
            //Image image; //StructureSet patientStrSet; //Course course; //ExternalPlanSetup plan;


            //-------------------
            //Set variables based on patientContext
            //-------------------
            string patientStrSetID = "";
            string patientStructureIDs = "";
            string patientDiagnosis = "";
            string patientCourseID = "";
            string patientPlanID = "";
            string patientNumberOfFractions = "";
            double patientDosePerFraction = 0;
            string patientDosePerFractionString = "";
            string patientFractionation = "";
            string patientTechnique = "";


            //StructureSet exists:
            if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage)
            { 
                //StructureSet patientStrSet = patientContext.ChosenStructureSet; //Old code
                patientStrSetID = patientContext.ChosenStructureSet.Id;
                patientStructureIDs = CreateStructureList(patientContext.ChosenStructureSet); //Henter strukturer til en string
            }

            //Course exists
            if (patientContext.SanityLevel >= Constants.SanityLevelCourseExist || patientContext.SanityLevel == Constants.SanityLevelCourseExistNotStructureSetOrImage)
            {
                patientDiagnosis = CourseExtension.GetAllAttachedDiagnosis(patientContext.ChosenCourse);
                patientCourseID = patientContext.ChosenCourse.Id;
            }

            //Plan exists
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist)
            {
                patientPlanID = patientContext.ChosenPlan.Id;
                patientTechnique = planTechnique.TechniqueName;
            }

            //Fractionation exists
            if (patientContext.SanityLevel >= Constants.SanityLevelFractionationExist)
            {
                //Fractionation //There can exist plan without fractionation, could cause issues when retrieving fractionation. Untested!
                patientNumberOfFractions = patientContext.ChosenPlan.NumberOfFractions.ToString(); //plan.NumberOfFractions.ToString();
                try { patientDosePerFraction = patientContext.ChosenPlan.DosePerFraction.Dose; } //plan.DosePerFraction.Dose;
                catch { }
                try { patientDosePerFractionString = string.Format("{0:0.##}", patientDosePerFraction); } //string.Format("{0:0.##}", patientDosePerFraction);
                catch { }
                try { patientFractionation = PlanExtension.GetFractionation(patientContext.ChosenPlan); } //string.Format("{0:0.##}", patientDosePerFraction);
                catch { }
                //PlanExtension.HentFraksjonering(plan);
            }

            //Dose exists
            if (patientContext.SanityLevel >= Constants.SanityLevelCalculatedDoseExist)
            {
                patientPlanID = patientContext.ChosenPlan.Id;
            }


            //-------------------
            //Get Score:
            //-------------------
            int templateListIndex = 0; //Brukes ikke til noe nyttig enda
            foreach (EclipseCheckTemplate chosen_template in templateList)
            {
                //MessageBox.Show(templateListIndex.ToString());
                List <Fractionation> templateFractionationList = PlanExtension.ConvertStringToFractionationClass(chosen_template.TemplateFractionations);
                
                //Splitter opp fraksjoneringsliste i DosePerFraksjon og AntallFraksjoner, sjekkes opp mot reell pasient sin DosePerFraksjon og AntallFraksjoner hvor det er relevant.
                string templateNumberOfFractions = "";
                string templateDosePerFraction = "";
                foreach (Fractionation fr in templateFractionationList)
                {
                    if (templateNumberOfFractions != "") { templateNumberOfFractions = templateNumberOfFractions + Constants.StringSeparator; }
                    templateNumberOfFractions = templateNumberOfFractions + fr.NumberOfFractions;

                    if (templateDosePerFraction != "") { templateDosePerFraction = templateDosePerFraction + Constants.StringSeparator; }
                    templateDosePerFraction = templateDosePerFraction + fr.DosePerFraction;
                }

                //------------
                // Get Score
                //------------
                if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage)
                {
                    //Sjekk strSetID
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientStrSetID, chosen_template.TemplateStrukturSetIDs, Constants.MatchScoreStruktSet);

                    //Sjekk PTVID
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientStructureIDs, chosen_template.TemplatePTVStructureIDs, Constants.MatchScorePTV);

                    //Sjekk CTVID
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientStructureIDs, chosen_template.TemplateCTVStructureIDs, Constants.MatchScoreCTV);

                    //Sjekk OAR
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientStructureIDs, chosen_template.TemplateOARStructureIDs, Constants.MatchScoreOAR);

                    //Sjekk Andre strukturer
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientStructureIDs, chosen_template.TemplatePTVStructureIDs, Constants.MatchScoreStructure);
                }

                //Course exists
                if (patientContext.SanityLevel >= Constants.SanityLevelCourseExist)
                {
                    //If Course exists
                    //Sjekk Diagnose
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientDiagnosis, chosen_template.TemplateDiagnosis, Constants.MatchScoreDiagnosis);

                    //Sjekk CourseID
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientCourseID, chosen_template.TemplateCourseIDs, Constants.MatchScoreCourse);

                }

                //Plan exists
                if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist)
                {
                    //Sjekk planID
                    chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientPlanID, chosen_template.TemplatePlanIDs, Constants.MatchScorePlanID);

                    //Sjekker Teknikk
                    if (chosen_template.TemplateTechniqueName.Contains(Constants.Teknikk.SRS_Arc_technique_forklaring)) // && !(Constants.MachinesHalcyon.Contains(planMachine) || Constants.MachinesEthos.Contains(planMachine))) //If FFF -> Stereotaxy technique. higher score if match, nut not if ringmachine, which only has 6X FFF anyway
                    {
                        chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientTechnique, chosen_template.TemplateTechniqueName, Constants.MatchScoreSRSTechnique); 
                    }
                    else
                    {
                        chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientTechnique, chosen_template.TemplateTechniqueName, Constants.MatchScoreTechnique);
                    }
                    

                    //Ekstra poeng for SRS?


                    //If Fractionation exists
                    if (patientContext.SanityLevel >= Constants.SanityLevelFractionationExist)
                    {
                        //Sjekker fraksjoneringer
                        chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientNumberOfFractions, templateNumberOfFractions, Constants.MatchScoreNumberOfFractions);
                        //Sjekker fraksjoneringer
                        chosen_template.TemplateScore = chosen_template.TemplateScore + ScoreTemplate(patientDosePerFractionString, templateDosePerFraction, Constants.MatchScoreDosePerFraction);
                        //Sjekker fraksjoneringer
                        if (CheckPointExtension.SjekkFraksjoneringMotTemplat(patientFractionation, chosen_template.TemplateFractionations) == Constants.True)
                        {
                            chosen_template.TemplateScore = chosen_template.TemplateScore + Constants.MatchScoreFractionation;
                        }

                    }
                }

                //------------
                //Set Color based on the score:
                //------------
                chosen_template.ColorSet = PlanTemplateExtension.ChangeColorByScore(chosen_template.TemplateScore);  //templateList[templateListIndex].ColorSet = PlanTemplateExtension.ChangeColorAfterScore(templateList[templateListIndex].TemplatScore);
                //Override color for Default template, so it is more visible
                if(chosen_template.TemplateName == Constants.DefaultTemplat)
                {
                    chosen_template.ColorSet = Constants.DefaultTemplatColor;
                }


                templateListIndex++;
            }

            return templateList;
        }

        public static int ChooseTemplateByScore(List<EclipseCheckTemplate> templateList)
        {
            //--------------------------------
            //Bestemmer templat som skal brukes
            //--------------------------------
            int score = 0;
            int max = templateList.Max(t => t.TemplateScore);
            int index_max = templateList.FindIndex(a => a.TemplateScore == max); //will crash if no templates exist
            int index_default = templateList.FindIndex(c => c.TemplateName == Constants.DefaultTemplat);
            int index_chosen = 0;

            if (max > 1) //Maa ha mer enn ett poeng for aa velge et templat
            {
                if (max < Constants.MinimumScoreToChooseATemplate)
                { //ingen gode treff, setter til default
                    index_chosen = index_default;
                }
                else
                { //ok treff
                    index_chosen = index_max;
                }
            }
            else //Ellers bruker default
            {
                score = max;
                index_chosen = index_default;
            }

            return index_chosen;

        }

    }
}
