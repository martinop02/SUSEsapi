﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Windows.Media.Media3D;
using System.Windows;
using System.Windows.Media;

namespace EclipsePlanCheck.Helpers
{
    class CTExtension
    {


        //Hent CTnavn

        public static string GetCTName(ExternalPlanSetup plan)
        {
            string navn = "";
            VMS.TPS.Common.Model.API.Image i = plan.StructureSet.Image;
            if (i != null)
            {
                navn = i.Series.Id;
            }
            else
            {
                MessageBox.Show("Feil: ingen bilde funnet (i = null). Kan ikke kjore funksjonen GetCTName().");
            }

            return navn;
        }

        //Imaging device
        //string s = plan.StructureSet.Image.Series.ImagingDeviceId;



        public static CheckPoint CheckCTSliceThickness(CheckPoint s, Image  image)
        {
            string ctSliceThickness = CTExtension.GetCTSliceThickness(image).ToString();
            s.CheckResultValue = ctSliceThickness;
            s.CheckResultValueCSV = ctSliceThickness;
            s.CheckStatus = CheckPointExtension.CheckResultVsTemplate(ctSliceThickness, s.CheckTemplateValue, s.CheckTrafficLight, "string", s);
            return s;

        }

        //Experimental:
        public static CheckPoint BodyToFreeBreathingExist(PatientContext patientContext, FieldsAnalysis f_analyse, CheckPoint cp)
        {
            // TODO : Add here the code that is called when the script is launched from Eclipse.
            //string studiesAndSeriesAndImages = "";
            //string listOfSeries = "";
            //string listOfImages = "";
            string listOfImagesInStructureSet = "";
            string seriesWithFreeBreathingDescription = "";
            //temp values:
            Image image = patientContext.ChosenImage;
            Patient patient = patientContext.ChosenPatient;
            StructureSet structsetFripustCT = patientContext.ChosenStructureSet;
            Structure structreBodyFripustCT = patientContext.ChosenStructureSet.Structures.FirstOrDefault();
            Structure structreBodyFreeBreathingFripustCT = patientContext.ChosenStructureSet.Structures.FirstOrDefault();
            Image imageFripustCT = image;
            Study studyFripustCT = image.Series.Study;
            Series seriesFripustCT = image.Series;


            bool imageFripustFound = false;
            bool structsetFripustFound = false;
            bool bodyStructure80kVFound = false;
            bool bodyFreeBreathingStructure80kVFound = false;
            bool NeedToChangeBodyToBodyFreeBreathing = false;
            bool structuresSegmented = false;

            DateTime now = DateTime.Now;
            TimeSpan difference = now - now;
            int differenceDays = 0;

            //--------------
            //If structureset already exists:
            //--------------
            foreach (StructureSet strset in patient.StructureSets)
            {
                
                Image imageInStructureSet = strset.Image;
                listOfImagesInStructureSet = listOfImagesInStructureSet + Environment.NewLine + imageInStructureSet.Id;
                //// I suppose only a 3D image would have "imageInStructureSet.ZRes". Could be exploited to filter out all 2D images.


                //Quit if task is already done:
                if (NeedToChangeBodyToBodyFreeBreathing == true)
                {
                    continue;
                }

                Series seriesInStructureSet = imageInStructureSet.Series;

                string seriesId = seriesInStructureSet.Id;
                string seriesModality = seriesInStructureSet.Modality.ToString();
                string seriesName = seriesInStructureSet.Name; //Maybe name = description? Nope, tested and it was empty. Useless!
                string seriesDescription = seriesInStructureSet.Comment; //Aha, "Comment" in ESAPI is the same as "Description" of the Series.

                //Create list of series with "fripust"
                //--------------
                if (seriesDescription.ToLower().Contains("fripust"))
                {
                    if(!seriesWithFreeBreathingDescription.Contains(seriesInStructureSet.Id)) //If this series is not already added
                    {
                        if (seriesWithFreeBreathingDescription != "") { seriesWithFreeBreathingDescription = seriesWithFreeBreathingDescription + Environment.NewLine; } //add new line
                        seriesWithFreeBreathingDescription = seriesWithFreeBreathingDescription + seriesId + ": " + seriesDescription; //Add all series that contain the description "fripust".
                    }

                }
                //--------------


                if (imageInStructureSet.Id == "fripust 80kV" || imageInStructureSet.Id.ToLower().Contains("fripust"))
                {

                    //Image found
                    imageFripustFound = true;
                    imageFripustCT = imageInStructureSet;
                    //Set the structureset that is connected to 80kV:
                    structsetFripustCT = strset;
                    structsetFripustFound = true;

                    //Set study:
                    studyFripustCT = imageFripustCT.Series.Study;
                    //Set series:
                    seriesFripustCT = imageFripustCT.Series;

                    //Set series info of 80kV:
                    string series80kVModality = seriesFripustCT.Modality.ToString();
                    string series80kVDescription = seriesFripustCT.Comment;



                    foreach (Structure structure in structsetFripustCT.Structures)
                    {
                        if (structure.Id.ToLower() == "body")
                        {
                            structreBodyFripustCT = structure;
                            bodyStructure80kVFound = true;

                            //Change Body
                            if (structsetFripustCT.Structures.Any(x => x.Id == "BodyFreeBreathing") == false)
                            {
                                //Need permission to SET:
                                //structreBody80kV.Id = "BodyFreeBreathing";
                                //MessageBox.Show("Endret 'Body' til 'BodyFreeBreathing' i strukturset '" + structset80kV + "' som har bildet '" + image80kV + "' i study '" + study80kV + "'.");
                                NeedToChangeBodyToBodyFreeBreathing = true;
                            }
                        }
                        if (structure.Id.ToLower() == "bodyfreebreathing" || ((structure.Id.ToLower().Contains("body")) && (structure.Id.ToLower().Contains("free") && (structure.Id.ToLower().Contains("breathing")) )))
                        {
                            NeedToChangeBodyToBodyFreeBreathing = false; //both exists
                            structreBodyFreeBreathingFripustCT = structure;
                            bodyFreeBreathingStructure80kVFound = true;
                            //MessageBox.Show("'BodyFreeBreathing' finnes allerede i strukturset '" + structset80kV + "' som har bildet '" + image80kV + "' i study '" + study80kV + "'.");
                            difference = now - structure.HistoryDateTime.Date;
                            differenceDays = difference.Days;
                            //Set
                            if (cp.CheckResultValue == Constants.Calculating) { cp.CheckResultValue = ""; } //Remove Calculating sign.
                            cp.CheckResultValue = cp.CheckResultValue  + "Skapt for " + differenceDays + " dager siden." + Environment.NewLine + "Struktur: '" + structure.Id + "'. Image: '" + imageFripustCT + "'. Serie: '" + seriesFripustCT  + Environment.NewLine +"' " + "(Descr: " + series80kVDescription + ") (Modality: " + series80kVModality + ")" + ". Study: '" + studyFripustCT + "'. ";
                            cp.CheckTemplateValueCSV = cp.CheckTemplateValueCSV + structure.Id + " ";
                            //If it has segment and is created not too long from today
                            if (structure.HasSegment == true) // && difference.Days < 30
                            {
                                structuresSegmented = true;
                            }
                        }
                    }
                }
            }
            //--------------
            //--------------

            //Set status and comment
            if (f_analyse.PlanLaterality == Constants.Venstre) //Left
            { 
                if (bodyFreeBreathingStructure80kVFound == true && structuresSegmented == true && differenceDays < 30)
                {
                    cp.CheckStatus = Constants.Ok;

                }
                else
                {
                    cp.CheckStatus = cp.CheckTrafficLight;

                    if (bodyFreeBreathingStructure80kVFound == false)
                    {
                        cp.CheckComment = cp.CheckComment + "Fant ikke BodyFreeBreathing. ";

                    }
                    if (bodyFreeBreathingStructure80kVFound == true && structuresSegmented == false)
                    {
                        cp.CheckComment = cp.CheckComment + "BodyFreeBreathing eksisterer, men ikke segmentert. ";

                    }
                    if (bodyFreeBreathingStructure80kVFound == true && difference.Days > 30)
                    {
                        cp.CheckComment = cp.CheckComment + "BodyFreeBreathing eksisterer, men er skapt for " + difference + " dager siden. ";

                    }
                }
            }
            else if(f_analyse.PlanLaterality == Constants.Hoyre) //Right
            {
                if (bodyFreeBreathingStructure80kVFound == true && structuresSegmented == true && differenceDays < 30)
                {
                    cp.CheckStatus = Constants.Ok;
                    cp.CheckComment = cp.CheckComment + "BodyFreeBreathing finnes, men trengs kanskje ikke. Ok, lateralitet = " + f_analyse.PlanLaterality;
                }
                else
                {
                    cp.CheckStatus = Constants.Ok;
                    cp.CheckComment = cp.CheckComment + "Fant ikke BodyFreeBreathing. Ok. Lateralitet er ikke Venstre. (Lat = " + f_analyse.PlanLaterality + ")";
                }
            }
            else //Medial (bilat) or unknown laterality
            {
                if (bodyFreeBreathingStructure80kVFound == true && structuresSegmented == true && differenceDays < 30)
                {
                    cp.CheckStatus = Constants.Ok;
                    cp.CheckComment = cp.CheckComment + "BodyFreeBreathing finnes. Ok, lateralitet = " + f_analyse.PlanLaterality;
                }
                else
                {
                    cp.CheckStatus = Constants.OBS;
                    cp.CheckStatus = Constants.OBS;
                    cp.CheckComment = cp.CheckComment + "Fant ikke BodyFreeBreathing. Lateralitet er ikke Venstre. (Lat = " + f_analyse.PlanLaterality + ")";
                }
            }
            if (cp.CheckResultValue == Constants.Calculating) { cp.CheckResultValue = ""; } //Remove calculation status

            return cp;

        }
        public static void RenameBodyToFreeBreathing(Image image, Patient patient)
        {
            string listOfSeries = "";
            string listOfImages = "";
            string listOfImagesInStructureSet = "";


            foreach (StructureSet strset in patient.StructureSets)
            {
                Image imageInStructureSet = strset.Image;
                listOfImagesInStructureSet = listOfImagesInStructureSet + Environment.NewLine + imageInStructureSet.Id;
                
            }

            foreach ( Image tempimage in image.Series.Images)
            {
                listOfImages = listOfImages + Environment.NewLine + tempimage.Id;
            }

            Study st = image.Series.Study;
            string studyId = st.Id;

            foreach(Series series in st.Series)
            {
                listOfSeries = listOfSeries + Environment.NewLine + series.Id;
            }

            string output = "Study: " + studyId + Environment.NewLine + "Series:" + listOfSeries + Environment.NewLine + "Images: " + listOfImages;
            MessageBox.Show(output);

            Image i = (Image)image.Series.Images.Where(x => x.Id.Contains("Fripust 80 kV"));

        }

        //HentCTSnittTykkelse
        public static string GetCTSliceThickness(Image image)
        {
            string snitttykkelse = "";
            //MessageBox.Show("start ctsnitt");
            VMS.TPS.Common.Model.API.Image i = image; //Plan-StructureSet.Image

            //MessageBox.Show("ID: " + i.Id);
            if (i != null)
            {

                string _zres = i.ZRes.ToString();
                snitttykkelse = "" + _zres + "mm";  //+ "  (x:" + _xres + ";y:" + _yres + ")";
                string _sjekk = _zres.Substring(0, 1);
                if (_sjekk != "2") { } //MessageBox.Show("Til info: CT har ikke 2mm snitt.")

            }
            else
            {
                MessageBox.Show("Feil: ingen bilde funnet (i = null). Kan ikke kjore funksjonen HentCTSnittTykkelse().");
            }

            return snitttykkelse;
        }




    }
}
