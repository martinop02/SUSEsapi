﻿//using Image = VMS.TPS.Common.Model.API.Image;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using EclipsePlanCheck.Helpers;
using System.Collections.Generic;
using System.Windows;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Windows.Input;
using System.ComponentModel;
using System.Threading.Tasks;
using System;
using System.Collections.ObjectModel;
using System.Windows.Media.Media3D;
using System.Linq;

namespace EclipsePlanCheck
{
    public class MainViewModel : INotifyPropertyChanged
    {
        //Model:
        private EclipseCheckModel _eclipseCheckResult;
        public EclipseCheckModel EclipseCheckResult //{ get; set; } //make iNotify update on change
        {

            get { return _eclipseCheckResult; }
            set
            {
                if (_eclipseCheckResult != value)
                {
                    _eclipseCheckResult = value;
                    RaisePropertyChanged(nameof(EclipseCheckResult));
                }
            }
        }


        //Property change
        public event PropertyChangedEventHandler PropertyChanged;

        private void RaisePropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }

        //------------------------------------------
        // Managed to implement progress bar inside the model (EclipseCheckModel) - so now these can be deleted from the mainView! Hurrah!
        //------------------------------------------
        //private double _progressValue;
        //public double ProgressValue
        //{
        //    get => _progressValue;
        //    set
        //    {
        //        _progressValue = value;
        //        RaisePropertyChanged(nameof(ProgressValue));
        //    }
        //}

        //private string _progressText;
        //public string ProgressText
        //{
        //    get => _progressText;
        //    set
        //    {
        //        _progressText = value;
        //        RaisePropertyChanged(nameof(ProgressText));
        //    }
        //}
        //------------------------------------------
        //------------------------------------------

        //EsapiWorker
        private EsapiWorker _esapiWorker;
        public EsapiWorker EsapiWorker //{ get; set; } //make iNotify update on change
        {

            get { return _esapiWorker; }
            set
            {
                if (_esapiWorker != value)
                {
                    _esapiWorker = value;
                    RaisePropertyChanged(nameof(EsapiWorker));
                }
            }
        }


        //Commands to use businesslogic in Model
        public ICommand UpdateCheckpointCommand { get; }
        public ICommand PopulateStructureListsCommand { get; } //
        public ICommand CreateMarginListsCommand { get; } //
        public ICommand CreateReferencePointListCommand { get; } //

        public ICommand FillUpCheckPointListCommand { get; } // 
        public ICommand CleanUpCheckPointListCommand { get; } //  Also some debug updated
        public ICommand UpdateCheckPointListCommand { get; } // Also some debug updated

        public ICommand CountStatusesCheckPointListCommand { get; } // Just for debug

        public ICommand PopulateCheckPointListsCommand { get; } // Also some debug updated

        public ICommand TestCalculateMeanDoseCommand { get; } // Just for debug

        public ICommand RunFullUpdateCommand { get; }

        public ICommand ScanMobiusFolderCommand { get; }

        public ICommand DelayedCalculationCommand { get; } //Should maybe be DelayedCalculation

        public ICommand ExportResultCSVCommand { get; } //Should maybe be DelayedCalculation


        //Need PatientContext and CheckScenarioResult also:
        public PatientContext Context { get; }
        public CheckScenarioResult ScenarioResult { get; }



        //Constructor
        public MainViewModel(EsapiWorker esapiWorker, PatientContext patientContext, CheckScenarioResult checkScenarioResultat)  //PatientContext patientContext, CheckScenarioResult checkScenarioResultat  //tar inn hele contexten
        {
            //PatientContext patientContext = esa
            //setting scenario and context
            ScenarioResult = checkScenarioResultat;
            Context = patientContext;
            _esapiWorker = esapiWorker;

            //Moving data from checkScenario to viewModel:
            ScriptVersionHandling scriptVersionHandling = checkScenarioResultat.ScriptVersionHandling; //version handling
            string templateName = checkScenarioResultat.TemplateName; //Templatnavn 
            string chosenControlTaskType = checkScenarioResultat.ValgtKontrollTask; //Task type

            //Moving data from patientContext
            ExternalPlanSetup plan = patientContext.ChosenPlan; //set plan

            //Get structure lists
            List<StructureCheck> strukturer = new List<StructureCheck>();
            List<StructureCheck> boluser = new List<StructureCheck>();


            //PopulateStructureLists //Attempt to make into a separate command in the Model, not in ViewModel.
            PopulateStructureListsCommand = new RelayCommand(PopulateStructureLists);//Command 

            //Example of running the command here:
            //if (PopulateStructureListsCommand.CanExecute(null))
            //    PopulateStructureListsCommand.Execute(null);

            CreateMarginListsCommand = new RelayCommand(CreateMarginLists);//Command 

            CreateReferencePointListCommand = new RelayCommand(CreateReferencePointList);//Command 


            List<MarginList> listOfMarginLists = new List<MarginList>();

            //Get refpktdata 
            List<RefPoint> rfpList = new List<RefPoint>();

            //Setting
            bool shouldReferencePointsBeShown = true; //Constants.True; //Default //Checks if referencepoints should be shown for control task. See Constants.
            try
            { //Already figured out in precheck
                shouldReferencePointsBeShown = ReferencePointExtension.ShouldReferencePointsBeShown(checkScenarioResultat.ValgtKontrollTask);
            }
            catch { }

                    //-----------------------------
                    //Make a full list of CheckPoints, and seperate ones for those that is discarded/inactivated/failed controltype
                    //-----------------------------
                    List <CheckPoint> sjekkpunktliste = new List<CheckPoint>();
            List<CheckPoint> inactivatedCheckPoints = new List<CheckPoint>();
            List<CheckPoint> discardedAtRuntimeCheckPoints = new List<CheckPoint>();
            List<CheckPoint> sanityFailedCheckPoints = new List<CheckPoint>();
            List<CheckPoint> controlTypeFailedCheckPoints = new List<CheckPoint>();

            // Final lists of used checkpoints, seperated by category, sendt to UI:
            List<CheckPoint> sjekkpunktlisteCourse = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "Course"));
            List<CheckPoint> sjekkpunktlisteStruktur = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "CT og strukturer"));
            List<CheckPoint> sjekkpunktlistePlan = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "Plan"));
            List<CheckPoint> sjekkpunktlisteTeknikk = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "Teknikk"));
            List<CheckPoint> sjekkpunktlisteRefpkt = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "Refpkt"));
            List<CheckPoint> sjekkpunktlisteDVH = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "DVH"));
            List<CheckPoint> sjekkpunktlisteSUS = new List<CheckPoint>(sjekkpunktliste.FindAll(a => a.CheckListCategory == "SUS")); //To do: should be removed. Make instead "Uncategorized" list.

            //Todo: Instead of many separate statuses (like numberOfInactivatedCheckPoints etc.) , make a list and add items ----

            //----------------------------
            // ---- Commands -----
            //----------------------------
            FillUpCheckPointListCommand = new RelayCommand(FillUpCheckPointList);//Command 
            //Fill up entire CheckPointList - must be cleaned later
            //sjekkpunktliste = CreateCheckPoint.CreateCheckPointList(patientContext, checkScenarioResultat, listOfMarginLists); //Set margins tolerances to -1 if no tolerance. //boluser

            CleanUpCheckPointListCommand = new RelayCommand(CleanUpCheckPointList);//Command. 
            //Looks at and removes: inactivated CP, CP with faild sanity , CP with faild ControlType. 
            //Updates statistics for these things. Leaves a final list with only all valid checkpoints.

            UpdateCheckPointListCommand = new RelayCommand(UpdateCheckPointList);//Command 
            //Update and run remaining CheckPoints in list. Time-consuming.

            CountStatusesCheckPointListCommand = new RelayCommand(CountStatusesCheckPointList);
            //Get Debug: Count OK, warning, errors and unknowns:
            //numberOfErrorStatusCheckPoints = sjekkpunktliste.FindAll(a => a.CheckStatus == Constants.Error).Count.ToString();
            //numberOfWarningStatusCheckPoints = sjekkpunktliste.FindAll(a => (a.CheckStatus == Constants.Warning || a.CheckStatus == Constants.Warning2)).Count.ToString();
            //numberOfOkStatusCheckPoints = sjekkpunktliste.FindAll(a => a.CheckStatus == Constants.Ok).Count.ToString();
            //numberOfUnknownStatusCheckPoints = sjekkpunktliste.FindAll(a => a.CheckStatus == Constants.Unknown).Count.ToString();

            PopulateCheckPointListsCommand = new RelayCommand(PopulateCheckPointLists);
            //Split CP-list i several lists grouped by CheckListCategory. These are the lists actually sent to the UI

             RunFullUpdateCommand = new RelayCommand(RunFullUpdate);
            //RunFullUpdateCommand: Runs all of the above commands in the correct order.

            ScanMobiusFolderCommand = new RelayCommand(ScanMobiusFolder);

            //Command to run a delayed calculation CP. Those are not run in the regular UpdateCheckPointListCommand.
            DelayedCalculationCommand = new RelayCommand(DelayedCalculation);

            //test commands:
            UpdateCheckpointCommand = new RelayCommand(UpdateCheckpoint); //Test, not used now                         
            TestCalculateMeanDoseCommand = new RelayCommand(TestCalculateMeanDoseThroughCommand);//This is only a test to try out this method of RelayCommand

            ExportResultCSVCommand = new RelayCommand(ExportResultCSV);//Command 

            //----------------------------
            //----------------------------

            //Setter resultatet som sendes til wpf MainView
            EclipseCheckResult = new EclipseCheckModel
            {

                //Legge til checkScenario?

                //navn paa templatet
                TemplateName = templateName,

                ChosenControlTask = chosenControlTaskType,

                ShowReferencePoints = shouldReferencePointsBeShown, //""shouldReferencePointsBeShown

                //Skriptversjon
                ScriptVersionHandling = scriptVersionHandling,
                //ScriptVersion = scriptVersionHandling.ScriptVersion//scriptVersjon,
                //NewerVersionInfo = newerVersionInfo,
                Documentation = checkScenarioResultat.Documentation,
                Hospital = checkScenarioResultat.Hospital,
                LocalProgressOngoing = false,
                //Mobius //MobiusPath = Mobiusfile_path, //No longer needed. Use CheckPoint.


                //Selve sjekklisten
                CheckPointListAll = sjekkpunktliste,
                CheckPointListCourse = sjekkpunktlisteCourse,
                CheckPointListStructures = sjekkpunktlisteStruktur,
                CheckPointListPlan = sjekkpunktlistePlan,
                CheckPointListTechnique = sjekkpunktlisteTeknikk,
                CheckPointListReferencePoints = sjekkpunktlisteRefpkt,
                CheckPointListDVH = sjekkpunktlisteDVH,
                CheckPointListSUS = sjekkpunktlisteSUS,

                //Debug - Todo: this should be changed to a list of statuses to be loaded in a single grid in UI instead of many items set separately like this
                CheckPointListInactivated = inactivatedCheckPoints,
                CheckPointListDiscarded = discardedAtRuntimeCheckPoints,
                CheckPointListFailedSanityLevel = sanityFailedCheckPoints,
                CheckPointListWrongControlType = controlTypeFailedCheckPoints,
                NumberOfErrorStatusCheckPoints = "",//numberOfErrorStatusCheckPoints,
                NumberOfOkStatusCheckPoints = "",//numberOfOkStatusCheckPoints,
                NumberOfUnknownStatusCheckPoints = "",//numberOfUnknownStatusCheckPoints,
                NumberOfWarningStatusCheckPoints = "",//numberOfWarningStatusCheckPoints,

                NumberOfFailedSanityCheckPoints = "",//numberOfFailedSanityCheckPoints,
                NumberOfInactivatedCheckPoints = "",//numberOfInactivatedCheckPoints,
                NumberOfDiscardedCheckPoints = "",
                NumberOfWrongControlTypeCheckPoints = "",//numberOfWrongControlTypeCheckPoints,

                SanityLevel = patientContext.SanityLevel.ToString(),
                SanityDescription = patientContext.SanityDescription,

                ListOfMarginLists = listOfMarginLists, //Added 25.10.2025

                //Titles
                CheckPointListCourse_Title = "1. Course",
                CheckPointListStructures_Title = "2. CT og strukturer",
                CheckPointListPlan_Title = "3. Plan",
                CheckPointListTechnique_Title = "4. Teknikk",
                CheckPointListReferencePoints_Title = "5. Refpkt",
                CheckPointListReferenceDVH_Title = "6. DVH-verdier",
                CheckPointListOther_Title = "", //"7. Other"

                //Other lists
                RfpList = rfpList,
                Strukturer = strukturer,
                Boluser = boluser


            };

            // Attach EventHandler when changes occur, so it updates the view. //This one is necessary to populate changes in model to the viewmodel, and hence to the view! For any change in EclipseCheckResult.
            EclipseCheckResult.PropertyChanged += EclipseCheckResult_PropertyChanged;
        }
        //End Constructor

        // When property gets changed in the Model, raise the PropertyChanged 
        // event of the ViewModel copy of the property
        private void EclipseCheckResult_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //if (e.PropertyName == nameof(EclipseCheckResult.LocalProgressValue))
            //    RaisePropertyChanged(nameof(EclipseCheckResult));
            //if (e.PropertyName == nameof(EclipseCheckResult.LocalProgressText))
                RaisePropertyChanged(nameof(EclipseCheckResult)); //This one is necessary to populate changes in model to the viewmodel, and hence to the view!!
        }

        //-----------------------------------------
        //Test command
        //-----------------------------------------
        public void TestCalculateMeanDose() //, EsapiWorker esapiWorker
        {
            //esapiWorker.Run(xpatientContext)
            MessageBox.Show("Inside TestCalculateMeanDose");
            _esapiWorker.Run(patientContext =>  //Dont need to pass afterall?
            {
                EclipseCheckResult.LocalProgressValue = 1; //Attemt to update in Model and not ViewModel. Must set to LocalProgressValue in xaml too.
                EclipseCheckResult.LocalProgressText = "Start";
                MessageBox.Show("Inside RUN TestCalculateMeanDose");
                //ProgressText = "Start"; //Attemt to update directly in ViewModel
                //ProgressValue = 1;
                var dose = patientContext.ChosenPlan.Dose;
                var meanDose = new DoseValue(0.0, dose.DoseMax3D.Unit);

                for (int z = 0; z < dose.ZSize; z++)
                {
                    EclipseCheckResult.LocalProgressValue = (double)(z + 1) / dose.ZSize * 100;
                    EclipseCheckResult.LocalProgressText = EclipseCheckResult.LocalProgressValue + "%";
                    var buffer = new int[dose.XSize, dose.YSize];
                    dose.GetVoxels(z, buffer);

                    for (int x = 0; x < dose.XSize; x++)
                        for (int y = 0; y < dose.YSize; y++)
                            meanDose += dose.VoxelToDoseValue(buffer[x, y]);
                }

                meanDose /= dose.XSize * dose.YSize * dose.ZSize;
                EclipseCheckResult.LocalProgressText = "Finished. MeanDose er " + meanDose.ValueAsString;
                EclipseCheckResult.CheckPointListCourse_Title = "TEEEEEST  1";
            });
        }

        private void TestCalculateMeanDoseThroughCommand(object parameter)
        {

            MessageBox.Show("Inside Command TestCalculateMeanDose");
            _eclipseCheckResult.TestCalculateMeanDose(ScenarioResult, EsapiWorker); // (Context,...) (.... ProgressValue, ProgressText) // Attempting to pass the ProgressValue and ProgressText to see if they are updated in the GUI
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        //-----------------------------------------
        //Test end
        //-----------------------------------------
        private void ScanMobiusFolder(object parameter) //(object parameter) 
        {
            //            if (parameter is string quantityString && int.TryParse(quantityString, out int quantity))
            //{ }
            _eclipseCheckResult.ScanMobiusFolder(_eclipseCheckResult, ScenarioResult, EsapiWorker); //, EsapiWorker)// Delegate to Model's business logic  //PatientContext and CheckScenarioResult already available. Pass it, as it is necessary.
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        private void ExportResultCSV(object parameter) //(object parameter) 
        {
            //            if (parameter is string quantityString && int.TryParse(quantityString, out int quantity))
            //{ }
            _eclipseCheckResult.ExportResultCSV(_eclipseCheckResult,ScenarioResult, EsapiWorker); //, EsapiWorker)// Delegate to Model's business logic  //PatientContext and CheckScenarioResult already available. Pass it, as it is necessary.
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }

        private void PopulateStructureLists(object parameter) //(object parameter) 
        {
            //            if (parameter is string quantityString && int.TryParse(quantityString, out int quantity))
            //{ }
                _eclipseCheckResult.PopulateStructureLists(Context, ScenarioResult); //, EsapiWorker)// Delegate to Model's business logic  //PatientContext and CheckScenarioResult already available. Pass it, as it is necessary.
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        private void CreateMarginLists(object parameter)
        {
            _eclipseCheckResult.CreateMarginLists(Context, ScenarioResult); 
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        private void CreateReferencePointList(object parameter)
        {
            _eclipseCheckResult.CreateReferencePointList(Context, ScenarioResult); 
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        private void FillUpCheckPointList(object parameter) //Basically run "CreateCheckPointList" in the extention method, just wanted to give a different name for the command to separate them
        {
            _eclipseCheckResult.FillUpCheckPointList(Context, ScenarioResult); //, _eclipseCheckResult.ListOfMarginLists); //untested if the margin list is sendt properly...
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        private void CleanUpCheckPointList(object parameter) 
        {
            _eclipseCheckResult.CleanUpCheckPointList(Context, ScenarioResult);
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }
        private void UpdateCheckPointList(object parameter) 
        {
            //double progressValue = 0; //fake progress since it is required to pass it.
            //var progress = new Progress<double>(value => progressValue = value);
            _eclipseCheckResult.UpdateCheckPointList(Context, ScenarioResult); //, progress
            RaisePropertyChanged(nameof(EclipseCheckResult));
        } 
        private void CountStatusesCheckPointList(object parameter) 
        {
            _eclipseCheckResult.CountStatusesCheckPointList(Context, ScenarioResult);
            RaisePropertyChanged(nameof(EclipseCheckResult));
        } 
        private void PopulateCheckPointLists(object parameter) 
        {
            _eclipseCheckResult.PopulateCheckPointLists(Context, ScenarioResult);
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }

        private void RunFullUpdate(object parameter)
        {
            _eclipseCheckResult.RunFullUpdate( ScenarioResult, EsapiWorker);
            RaisePropertyChanged(nameof(EclipseCheckResult));
        }

        private void DelayedCalculation(object parameter) //(object parameter) 
        {
            //            if (parameter is string quantityString && int.TryParse(quantityString, out int quantity))
            //{ }
            if (parameter is CheckPoint cp)
            {
                _eclipseCheckResult.DelayedCalculation(cp, ScenarioResult, EsapiWorker); //, EsapiWorker)// Delegate to Model's business logic  //PatientContext and CheckScenarioResult already available. Pass it, as it is necessary.
                RaisePropertyChanged(nameof(EclipseCheckResult));
            }
        }

        private void UpdateCheckpoint(object parameter) //Test, not in use
        {
            MessageBox.Show("UpdateCheckPoint blir kjørt");

            if (parameter is CheckPoint cp)
            {

                cp.CalculateLate = false;

                //Ikke i bruk
                //UpdateCheckPoint.RunCheckPointSwitch(cp, Context, ScenarioResult);
                // Add any other updates you want.
            }
        }


    }

    //ICommand exist in separate file. See "RelayCommand.Cs"

}
