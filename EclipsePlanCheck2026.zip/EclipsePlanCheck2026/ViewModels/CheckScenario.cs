﻿using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using EclipsePlanCheck.Helpers;

namespace EclipsePlanCheck
{
    public class CheckScenario
    {

        //Template list
        public List<EclipseCheckTemplate> eclipseCheckTemplateList = new List<EclipseCheckTemplate>(); //List of templates to score and choose between
        public CheckScenarioResult CheckScenarioResult { get; } //All results that is sendt to the View. 

        //Constructor force a check of NAMED template. This is NOT used now!
        public CheckScenario(string templateName, string tasktype, PatientContext patientContext) 
        {

            //Variables technique
            PlanTechnique planTechnique = new PlanTechnique();
            string planMachine = "";
            List<Field> planFieldList = new List<Field>();
            FieldsAnalysis planFieldsAnalysis = new FieldsAnalysis();

            //------------------------------
            // ---- Retrieves Technique and Machine: 
            //------------------------------
            #region "Retrieves Technique and Machine"
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist) //Plan eksisterer
            {
                planTechnique = FieldExtension.GetTechniqueFromPlan(patientContext.ChosenPlan, patientContext); //Necessary for technique-spesific checks
                planMachine = PlanExtension.GetMachineIDsAll(patientContext.ChosenPlan);  //Necessary for machine-specific checks
                planFieldList = PlanExtension.CreateFieldList(patientContext.ChosenPlan); //Necessary for field-specific checks
                planFieldsAnalysis = PlanExtension.AnalyzeFields(planTechnique.TechniqueName, planFieldList, patientContext.ChosenPlan); //Necessary for field-specific checks //Analysere ev. 180 grader felt og feltvekting, samt lateralitet etc.:
            }
            #endregion "Retrieves Technique and Machine"
            //------------------------------

            //------------------------------
            //--- Generate list of templates
            //------------------------------ // PlanCheckTemplates 
            string filePathTemplates = PlanTemplateExtension.SetFilePathEclipseCheckTemplates();
            eclipseCheckTemplateList = PlanTemplateExtension.LoadEclipseCheckTemplates(filePathTemplates); //patientContext//(planMachine, planTechnique.TechniqueName, planFieldsAnalysis.PlanLaterality, plan
                                                                                          //Go through templates and score them

            //ModifyLateralityEclipseCheckTemplate
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist) //Only if plan exist. 
            {
                eclipseCheckTemplateList = PlanTemplateExtension.ModifyLateralityForAllEclipseCheckTemplates(eclipseCheckTemplateList, patientContext, planFieldsAnalysis.PlanLaterality); //patientContext
            }
            if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage)
            {
                //Possibility for later: if no plan exist -modyfy structure list so BOTH left and right structure names are added! Not done yet.Now scoring the structure names is an issue if no laterality.
                //This could also be part of ModifyLateralityForAllEclipseCheckTemplates method.
                eclipseCheckTemplateList = PlanTemplateExtension.ModifyLateralityForAllEclipseCheckTemplates(eclipseCheckTemplateList, patientContext, ""); //Laterality not defined
            }
            else { } //No structureset exist

            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist) //Only if plan exist. 
            {
                eclipseCheckTemplateList = PlanTemplateExtension.ScoreTemplates(eclipseCheckTemplateList, patientContext, planTechnique, planMachine);
            }
            else
            {
                foreach (EclipseCheckTemplate chosen_template in eclipseCheckTemplateList)
                {
                    chosen_template.TemplateScore = 0;
                }
            }

            EclipseCheckTemplate ValgtEclipseTemplat = eclipseCheckTemplateList.Where(x => x.TemplateName == templateName).FirstOrDefault();

            if (ValgtEclipseTemplat == null) //Denne er ikke testet
            {
                ValgtEclipseTemplat = eclipseCheckTemplateList.Where(x => x.TemplateName == Constants.DefaultTemplat).FirstOrDefault();
            }
            //------------------------------

            //--------------------------------
            //Set result
            //--------------------------------
            CheckScenarioResult = new CheckScenarioResult
            {
                //Kan vi passe alle templater isteden for dette?
                TemplateChosen = ValgtEclipseTemplat,
                TemplateScore = ValgtEclipseTemplat.TemplateScore,
                //Index

                //Ekstra info
                CheckScenarioTechnique = planTechnique,
                CheckScenarioMaskin = planMachine,
                CheckScenarioFieldList = planFieldList,
                CheckScenarioFieldAnalysis = planFieldsAnalysis,
                EclipseCheckTemplateList = eclipseCheckTemplateList, //Alle templater
                ValgtKontrollTask = tasktype,

            };
        }

        //Constructor. The code finds a fitting template by scoring the list of templates and selecting the most probable template
        public CheckScenario(PatientContext patientContext) //(Patient p, Course course,ExternalPlanSetup plan, StructureSet strset)  //ScriptContext context
        {

            if (patientContext == null) throw new ArgumentNullException(nameof(patientContext));
            
            //Handle scriptversions, give warnings if newer exist in same folder:
            ScriptVersionHandling scriptVersionHandling = new ScriptVersionHandling();
            scriptVersionHandling = GeneralExtension.GetScriptVersionHandling(scriptVersionHandling);

            //Variables template
            string chosenTemplateName = "";
            int chosenTemplateIndex = 0;
            int chosenTemplateScore = 0;

            //Variables technique  
            PlanTechnique planTechnique = new PlanTechnique();
            string planMachine = "";
            List<Field> planFieldList = new List<Field>(); 
            FieldsAnalysis planFieldsAnalysis = new FieldsAnalysis();
            //

            //------------------------------
            // ---- Retrieves Technique and Machine (This is dependant on having a plan): 
            //------------------------------
            #region "Retrieves Technique and Machine"
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist) //Plan eksisterer
            { 
                planTechnique = FieldExtension.GetTechniqueFromPlan(patientContext.ChosenPlan, patientContext); //Necessary for technique-spesific checks
                planMachine = PlanExtension.GetMachineIDsAll(patientContext.ChosenPlan);  //Necessary for machine-specific checks
                planFieldList = PlanExtension.CreateFieldList(patientContext.ChosenPlan); //Necessary for field-specific checks
                planFieldsAnalysis = PlanExtension.AnalyzeFields(planTechnique.TechniqueName, planFieldList, patientContext.ChosenPlan); //Necessary for field-specific checks //Analysere ev. 180 grader felt og feltvekting, samt lateralitet etc.:
            }
            #endregion "Retrieves Technique and Machine"
            //------------------------------

            //------------------------------
            //--- Generate list of templates
            //------------------------------
            #region "CheckScenario Generate Templates"
            string filePathTemplates = PlanTemplateExtension.SetFilePathEclipseCheckTemplates();
            List <EclipseCheckTemplate> eclipseCheckTemplateList = PlanTemplateExtension.LoadEclipseCheckTemplates(filePathTemplates);

            //------------------------------
            //Print for debug:
            //------------------------------
            //foreach (EclipseCheckTemplate eclipseCheckTemplateTemp in eclipseCheckTemplateList)
            //{
            //    PlanTemplateExtension.PrintEclipseCheckTemplate(eclipseCheckTemplateTemp);
            //}
            //------------------------------


            //--------------------------------------
            //Modify Laterality in structures and plan names in EclipseCheckTemplate
            //--------------------------------------
            if (patientContext.SanityLevel >= Constants.SanityLevelPlanExist) //Only if plan exist. 
            {
                eclipseCheckTemplateList = PlanTemplateExtension.ModifyLateralityForAllEclipseCheckTemplates(eclipseCheckTemplateList, patientContext, planFieldsAnalysis.PlanLaterality); //patientContext
            }
            if (patientContext.SanityLevel > Constants.SanityLevelStructureSetExist && patientContext.SanityLevel != Constants.SanityLevelCourseExistNotStructureSetOrImage)
            {
                //Possibility for later: if no plan exist -modyfy structure list so BOTH left and right structure names are added! Not done yet.Now scoring the structure names is an issue if no laterality.
                //This could also be part of ModifyLateralityForAllEclipseCheckTemplates method.
                eclipseCheckTemplateList = PlanTemplateExtension.ModifyLateralityForAllEclipseCheckTemplates(eclipseCheckTemplateList, patientContext, "");
            }
            else { } //No structureset exist

            //--------------------------------------
            //Go through templates and score them
            //--------------------------------------
            eclipseCheckTemplateList = PlanTemplateExtension.ScoreTemplates(eclipseCheckTemplateList, patientContext, planTechnique, planMachine);
            //Decide which template to use
            if (eclipseCheckTemplateList.Count > 0) //Will crash if list is empty...
            {
                chosenTemplateIndex = PlanTemplateExtension.ChooseTemplateByScore(eclipseCheckTemplateList);  
                //Max Scores and Index for Default template
                chosenTemplateScore = eclipseCheckTemplateList[chosenTemplateIndex].TemplateScore; //int maxTemplateScore = eclipseCheckTemplateList.Max(t => t.TemplateScore);
                int index_default = eclipseCheckTemplateList.FindIndex(c => c.TemplateName == Constants.DefaultTemplat);
                //Set color to Dark Green of chosen template if high enough score to be chosen (Not if default template - Default always stays same color)
                if (chosenTemplateScore > Constants.MinimumScoreToChooseATemplate && chosenTemplateIndex != index_default) { eclipseCheckTemplateList[chosenTemplateIndex].ColorSet = "DarkGreen"; }
                chosenTemplateName = eclipseCheckTemplateList[chosenTemplateIndex].TemplateName;
            }

            //-------------------------------------
            //Modify main template because of machine:  (Override all templates)
            //--------------------------------------
            string filePathTemplatesMachineOverride = PlanTemplateExtension.SetFilePathEclipseCheckMachineOverrideTemplates();
            List<EclipseCheckTemplate> eclipseCheckTemplateMachineOverrideList = PlanTemplateExtension.LoadEclipseCheckTemplates(filePathTemplatesMachineOverride); //Loading Machine override template
            //Printer for debug: //PlanTemplateExtension.PrintEclipseCheckTemplate(eclipseCheckTemplateList[chosenTemplateIndex]);

            eclipseCheckTemplateList = PlanTemplateExtension.MachineTechniqueOverrideEclipseCheckTemplates(eclipseCheckTemplateList, eclipseCheckTemplateMachineOverrideList, planMachine, planFieldList, patientContext, planTechnique.TechniqueName);

            string debug = "";
            if (eclipseCheckTemplateList.Count >= 0)
            {
                debug = eclipseCheckTemplateList[0].Debug;
            }
            
            //------------------------------
            //Generate ControlTaskTypeList: Control type. Make a list of tasks which the user can choose from in the View
            //------------------------------
            List<string> controlTaskTypeList = PlanTemplateExtension.CreateControlTaskList();
            #endregion "CheckScenario Generate Templates"
            //------------------------------

            //Printer for debug: //PlanTemplateExtension.PrintEclipseCheckTemplate(eclipseCheckTemplateList[chosenTemplateIndex]);

            //--------------------------------
            //Set result
            //--------------------------------
            #region "Set Result"
            CheckScenarioResult = new CheckScenarioResult
            {
                //Version control
                ScriptVersionHandling = scriptVersionHandling,
                Hospital = Constants.Hospital,
                //Template chosen
                TemplateChosen = eclipseCheckTemplateList[chosenTemplateIndex],
                TemplateName = chosenTemplateName,
                TemplateIndex = chosenTemplateIndex, //Used to preselect option in View
                TemplateScore = chosenTemplateScore,
            
                EclipseCheckTemplateList = eclipseCheckTemplateList, //Alle templates
                KontrollTask = controlTaskTypeList, //Control task list that user can choose from

                //Extra info necessary
                Debug = debug,
                CheckScenarioTechnique = planTechnique,
                CheckScenarioMaskin = planMachine,
                CheckScenarioFieldList = planFieldList,
                CheckScenarioFieldAnalysis = planFieldsAnalysis,

                //
            };
            #endregion "Set Result"

        }

    }


}


//Vinnertemplatet:
//TemplateName = templatnavn,
//TemplatScore = score,
//TemplatCourseIDer = templatCourseIDer,
//TemplatStrukturSetIDer = templatStrukturSetIDer,
//TemplatDiagnoser = templatDiagnoser,
//TemplatPlanIDer = templatPlanIDer,
//TemplatPTVStrukturIDer = templatPTVstrukturIDer,
//TemplatCTVStrukturIDer = templatCTVstrukturIDer,
//TemplatAndreStrukturIDer = templatAndreStrukturIDer,
//TemplatFraksjoneringer = templatFraksjoneringer,
//TemplatOARStrukturIDer = templatOARStrukturIDer,