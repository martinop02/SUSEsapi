﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using EclipsePlanCheck.Helpers;
using System.Diagnostics;
using System.Dynamic;

namespace EclipsePlanCheck //.CheckPoints
{
    class UpdateCheckPoint
    {
        //---- OLD_UpdateCheckPointList ----
        //This one is not used now because progress cannot be reported back to interface via IProgress...
        //Consider moving  methods under the Model instead of this class. Then UI progressbar etc. can be updated directly... (EclipseCheckModel)
        //public static List<CheckPoint> OLD_UpdateCheckPointList(PatientContext patientContext, List<CheckPoint> checkPointListInput, CheckScenarioResult checkScenarioResultat, IProgress<double> progress, EsapiWorker esapiWorker) // List<StructureCheck> boluses, List<MarginList> listOfMarginLists  //string sjekknavn, string oppdateringsverdi
        //{
        //    List<CheckPoint> completeCheckPointList = checkPointListInput;

        //    //Itererer gjennom sjekklisten og oppdaterer hvert punkt 

        //    //progress 
        //    //progress bar updating does not really work (only if you add a messagebox.show, which somehow foreces focus on UI.
        //    double maxCheckPoints = completeCheckPointList.Count();
        //    double progressBarStart = 25;
        //    double progressBarEnd = 95;
        //    double progressCheckPoints = 0;
        //    double progress_total = 25;
        //    double checkPointNumber = 0;
        //    string test = progress.ToString();
        //    //MessageBox.Show("Inside UpdateCheckPointList. maxCheckPoints = " + maxCheckPoints);



        //        foreach (CheckPoint s in completeCheckPointList)
        //        {
        //            //if (checkPointNumber == 0)
        //            //{
        //            //    MessageBox.Show("Inside Ucheckpoint loop");
        //            //}


        //            checkPointNumber = checkPointNumber + 1;
        //            progressCheckPoints = (double)(checkPointNumber / maxCheckPoints); //Number between 0 and 1.
        //            progress_total = progressBarStart + progressCheckPoints * (progressBarEnd - progressBarStart);

        //            progress.Report(progress_total);



        //            //RunCheckPointSwitch(s, patientContext, checkScenarioResultat);

        //            //Debug
        //            //if (checkPointNumber > 40 && checkPointNumber < 43)
        //            //{
        //            //    MessageBox.Show("cp: " + checkPointNumber + " progressC: " + progressCheckPoints + " progressT: " + progress_total);
        //            //}

        //        }



        //    //-----------------------------------------------------------
        //    //---- ColorSet: Fargelegger resultat: //Make separate function
        //    //-----------------------------------------------------------
        //    completeCheckPointList = ColorCheckPointsDependingOnStatus(completeCheckPointList);
        //    //----------------------------------------------------------------

        //    //-----------------------------------------------------------------
        //    // InvisibleUnlessWarningOrError:   Remove all checkpoints that do not have warning or error if CheckPoint Settings says so //Make separate function
        //    //-----------------------------------------------------------------
        //    completeCheckPointList = RemoveCheckPointsUnlessErrorOrWarningOrComment(completeCheckPointList);
        //    //----------------------------------------------------------------

        //    //-----------------------------------------------------------------
        //    // InvisibleUnlessWarningOrError:   Remove all checkpoints that are inactivated if CheckPoint Settings says so //Make separate function
        //    //-----------------------------------------------------------------
        //    completeCheckPointList = RemoveCheckPointsIfInactive(completeCheckPointList);
        //    //----------------------------------------------------------------

        //    //-----------------------------------------------------------------
        //    // Reformat template value:   Set in line breaks where logical
        //    //-----------------------------------------------------------------
        //    completeCheckPointList = ReformatTemplateValuesWithLineBreak(completeCheckPointList);
        //    //----------------------------------------------------------------


        //    //sende modifisert liste tilbake
        //    return completeCheckPointList;
        //}
        ////-------

        public static List<CheckPoint> ReformatTemplateValuesWithLineBreak(List<CheckPoint> checkPointList)
        {
            int maxAllowedCharacterCount = 30;
            int countAttemptsExitIfTooMany = 10;

            int separatorCount = 0;
            int characterCount = 0;

            foreach (var s in checkPointList)
            {

                string templateReformatted = "";
                
                //---------------------------
                //Couch is a special expection
                //--------------------------
                if (s.CheckSwitchCode != "CouchNamesAndHUs") //Exception for Couch as it is special
                {
                    //First directly copy over from raw values.
                    
                    s.CheckTemplateValueDisplay = s.CheckTemplateValue;

                    //then reformat.
                    string templateValue = s.CheckTemplateValueDisplay;
                    if (templateValue != null)
                    {
                        separatorCount = templateValue.Count(x => x == Constants.CharSeparator); //Total number of separators in text
                        characterCount = templateValue.Length; //Length of string
                    }
                    else
                    {
                        separatorCount = 0;
                        characterCount = 0;
                        //Skip to next
                        s.CheckTemplateValue = "";
                        s.CheckTemplateValueDisplay = "";
                        continue;
                    }

                    //int halfedSeparatorCount = (int)Math.Round((double)separatorCount / 2, 0);
                    int nthOccurrence = 4; //We want new line for every nth occurance //Earlier 4
                    string[] items = templateValue.Split(new char[] { Constants.CharSeparator }, StringSplitOptions.RemoveEmptyEntries);
                    int separatorsRemaining = separatorCount;
                    //string[] everythingSplitAfterNthOccurence = items.Skip(nthOccurrence).ToArray();

                    int countAttempts = 0;


                    //Should we split?
                    if (separatorCount > nthOccurrence || characterCount > maxAllowedCharacterCount)
                    {
                        //if separators exist, easier to use separators:
                        //if (separatorCount > nthOccurrence)
                        //{
                            string remainingTemplateValues = templateValue;
                            string firstPart = "";
                            string secondPart = "";

                            //Keep doing splits if criteria is met
                            while (separatorsRemaining > nthOccurrence || characterCount > maxAllowedCharacterCount)
                            {
                                countAttempts = countAttempts + 1;
                                //Continue splitting because of high charachter count (even though not fully nthoccurance, split the remaining bits in two if possible
                                if (separatorsRemaining <= nthOccurrence && separatorsRemaining > 0 && characterCount > maxAllowedCharacterCount)
                                {
                                    //divide into two parts
                                    if (separatorsRemaining > 1)
                                    {
                                        nthOccurrence = (int)Math.Round((double)separatorsRemaining / 2, 0);
                                    }
                                }

                                // 1) //Continue splitting as long as there are at least one separator //more then one separators
                                if (separatorsRemaining > 0 && !remainingTemplateValues.Contains(Environment.NewLine)) //Contains(Environment.NewLine) added 18.11.2025 breped //(separatorsRemaining > 1)
                                {

                                    //Split in everything up to 5 separators and everything after
                                    firstPart = string.Join(Constants.StringSeparator, items.Take(nthOccurrence));
                                    secondPart = string.Join(Constants.StringSeparator, items.Skip(nthOccurrence));
                                    //set what is remaing as new inputstring:
                                    separatorsRemaining = secondPart.Count(x => x == Constants.CharSeparator); //set new separaters remaining
                                    characterCount = secondPart.Length;
                                    remainingTemplateValues = secondPart;
                                    items = remainingTemplateValues.Split(new char[] { Constants.CharSeparator }, StringSplitOptions.RemoveEmptyEntries);

                                    if (templateReformatted != "") { templateReformatted = templateReformatted + Environment.NewLine; }
                                    templateReformatted = templateReformatted + firstPart;
                                }
                                // 2)//If none separators exist anymore, split the string midway and just exit. Only if string does not contain NewLine.
                                else if (characterCount > maxAllowedCharacterCount && !remainingTemplateValues.Contains(Environment.NewLine)) 
                                {
                                    int midpoint = remainingTemplateValues.Length / 2;
                                    firstPart = remainingTemplateValues.Substring(0, midpoint);
                                    secondPart = remainingTemplateValues.Substring(midpoint);
                                    remainingTemplateValues = "";
                                    separatorsRemaining = 0;
                                    characterCount = 0;
                                //= firstPart + Environment.NewLine + secondPart;
                                    if (templateReformatted != "") { templateReformatted = templateReformatted + Environment.NewLine; }
                                    templateReformatted = templateReformatted + firstPart; //+ Environment.NewLine + secondPart;
                                    break;
                                    }
                                // 3)//If none separators exist anymore, and string contain NewLine, leave it as is, ikke tukle.
                                else if (characterCount > maxAllowedCharacterCount && (remainingTemplateValues.Contains(Environment.NewLine) || remainingTemplateValues.Contains('\n'))  )
                                {
                                    templateReformatted = templateReformatted + remainingTemplateValues;
                                    firstPart = "";
                                    secondPart = "";
                                    remainingTemplateValues = "";
                                    separatorsRemaining = 0;
                                    characterCount = 0;
                                    break;
                                }

                                //Send first part if 1) is the case
                                //if (templateReformatted != "") { templateReformatted = templateReformatted + Environment.NewLine; }
                                //templateReformatted = templateReformatted + firstPart;

                                //Exit loop if too many attempts
                                if (countAttempts > countAttemptsExitIfTooMany)
                                    { break;} //Give up if too many split have to be done
                            }
                            templateReformatted = templateReformatted + Environment.NewLine + secondPart;

                            s.CheckTemplateValueDisplay = templateReformatted;
                        //}
                        //////character count method?
                        //else
                        //{


                        //}
                    }
                } //Exception for Couch
                //--------------------------
                //--------------------------
            }
            return checkPointList;
        }

        //SetStatusToWorking
        public static List<CheckPoint> SetStatusToWorking(List<CheckPoint> checkPointList)
        {
            //-----------------------------------------------------------
            //---- ColorSet: Temporarily set status to Calculating (Hourglass image) While calculating.
            //-----------------------------------------------------------

            foreach (var s in checkPointList)
            {
                s.CheckStatus = Constants.Calculating;
                if(s.CalculateDelayed == true)
                {
                    s.CheckStatus = Constants.Delayed;
                }
            }

            return checkPointList; //Modified checkpointlist
        }

        public static List<CheckPoint> ColorCheckPointsDependingOnStatus(List<CheckPoint> checkPointList)
        {
            //-----------------------------------------------------------
            //---- ColorSet: Fargelegger resultat: //Make separate function
            //-----------------------------------------------------------




            foreach (var s in checkPointList)
            {
                ColorCheckPointDependingOnStatus(s);
            }
            //----------------------------------------------------------------
            return checkPointList; //Modified checkpointlist
        }

        public static CheckPoint ColorCheckPointDependingOnStatus(CheckPoint s)
        {
            //Sjekk
            if (s.CheckType == "Sjekk")
            {
                if (s.CheckStatus == Constants.Ok)
                {
                    s.ColorSet = "Green";
                }
                else if (s.CheckStatus == Constants.Error)
                {
                    s.ColorSet = "Red";
                }
                else if (s.CheckStatus == Constants.Warning)
                {
                    s.ColorSet = "Yellow";
                }
                else if (s.CheckStatus == Constants.Warning2)
                {
                    s.ColorSet = "Orange";
                }
                else if (s.CheckStatus == Constants.Printout)
                {
                    s.ColorSet = "Lavender";
                }
                else if (s.CheckStatus == Constants.Info)
                {
                    s.ColorSet = "Cyan";
                }
                if (s.CheckStatus == Constants.OBS)
                {
                    s.ColorSet = "Cyan";
                }
                if (s.CheckStatus == Constants.Unknown)
                {
                    s.ColorSet = "DarkGray";
                }

            }
            //Info
            else if (s.CheckType == Constants.Info)
            {
                if (s.CheckStatus == Constants.Info)
                {
                    s.ColorSet = "Cyan";
                }
                if (s.CheckStatus == Constants.OBS)
                {
                    s.ColorSet = "Cyan";
                }
                if (s.CheckStatus == Constants.Printout)
                {
                    s.ColorSet = "Lavender";
                }
                else if (s.CheckStatus == Constants.Warning)
                {
                    s.ColorSet = "Yellow";
                }
                else if (s.CheckStatus == Constants.Warning2)
                {
                    s.ColorSet = "Orange";
                }
                if (s.CheckStatus == Constants.Ok)
                {
                    s.ColorSet = "Green";
                }
            }
            //Default
            else
            {
                s.ColorSet = "DarkGray";
            }
            return s;

        }

        public static List<CheckPoint> RemoveCheckPointsUnlessErrorOrWarningOrComment(List<CheckPoint> checkPointList)
        {
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                var s = checkPointList[i];
                if (s.CheckInvisibleUnlessWarningOrError == Constants.True)
                {
                    //Remove only all checkpoints that are ok and that did not generate special comment.
                    if ((s.CheckStatus == Constants.Ok || s.CheckStatus == Constants.Info) && (s.CheckComment == ""))  //(s.CheckStatus != Constants.Error && s.CheckStatus != Constants.Warning && s.CheckStatus != Constants.Warning2)
                    {

                        //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
                        checkPointList.RemoveAt(i);
                    }
                }
            }
            return checkPointList; //Modified checkpointlist
        }

        public static List<CheckPoint> RemoveCheckPointsIfInactive(List<CheckPoint> checkPointList)
        {
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                var s = checkPointList[i];
                if (s.CheckInactivated == Constants.True)
                {
                    checkPointList.RemoveAt(i);
                }
            }
            return checkPointList; //Modified checkpointlist
        }



    }
}
