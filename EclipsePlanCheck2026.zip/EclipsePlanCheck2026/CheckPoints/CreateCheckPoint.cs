﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VMS.TPS.Common.Model.API;
using VMS.TPS.Common.Model.Types;
using System.Runtime.CompilerServices;

using System.Windows.Controls;
using System.Windows;
using System.Data; //Lagt inn bitj
//using Image = VMS.TPS.Common.Model.API.Image;
using System.Windows.Media;

//using BITJSW.Common.Data.DbCommon;
//using BITJSW.Data.ARIA;
using System.Windows.Media.Imaging;
using System.IO;
using System.Globalization;
using EclipsePlanCheck.Helpers;
using System.Reflection;



//EclipseCheckTemplate ValgtEclipseTemplat = checkScenarioResultat.EclipseCheckTemplateList.Where(x => x.TemplateName == templatnavn).FirstOrDefault();  //or: //(EclipseCheckTemplat)eclipseCheckTemplatResultat
//Seach in template list. Denne kan være nyttig. Fikk den ikke til aa fungere forst, men den fungerte om jeg la til "FirstOrDefault()". Var bare det som manglet.

namespace EclipsePlanCheck
{
    public static class CreateCheckPoint
    {
        //------------------
        // Load CheckPoint Mainmethod, from csv
        //-----------------

        public static List<CheckPoint> LoadCheckPointTemplate(string filePathTemplates, EclipseCheckTemplate chosenEclipseTemplate)
        {
            //patientContext not required yet here, but could be used to skip loading uneccesary parts of templates?

            //Create empty list
            List<CheckPoint> checkPointSettingsList = new List<CheckPoint>();
            string line = "";
            int linesCount = 0;
            int columnsCount = 0;
            int lastcolumnsCount = 0;


            IEnumerable<string> lines = File.ReadLines(filePathTemplates);
            linesCount = lines.Count();

            string lineHeaders = lines.ElementAt(1);
            string[] lineHeadersArray = lineHeaders.Split(';');
            //--------------------------
            // ADD CHECKPOINT
            //Iterate over lines. Start from 1 to skip the headers.
            //--------------------------
            for (int i = 1; i < lines.Count(); i++)
            {

                line = lines.ElementAt(i); //One line is a CheckPoint

                CheckPoint checkPoint = new CheckPoint(); //Create new checkpoint per line

                //Split checkpoint template into array:
                string[] lineArray = line.Split(';');  // List<char> lineList = line.ToList();
                
                //If no CheckSwitchCode, then skip this line!
                if (lineArray[0] == "")
                { continue; }

                //Any validation we need to add here??
                //MessageBox.Show(line);
                columnsCount = lineArray.Length;

                //Validate input
                if ((columnsCount != lastcolumnsCount) && (lastcolumnsCount != 0))
                {
                    //Check if one template has wrong number of columns and warn user
                    MessageBox.Show("One line in a template csv-file has different number of columns. This could be because of using characters (like ';' or adding a new line  with alt+enter etc.) similar to separator used in csv-file, thus causing an extra column. Columns current template:" + columnsCount.ToString() + " . Columns last template checked: " + lastcolumnsCount);
                }
                lastcolumnsCount = columnsCount;


                //Add to class (advanced method)
                //Get all properties from class
                PropertyInfo[] properties = typeof(CheckPoint).GetProperties();

                string valueFromTemplate = "";
                string headerFromTemplate = "";
                string overriddenProperties = "";


                //--------------------------
                // ADD CHECKPOINT PROPERTY
                //Go through each cell in that line and set property
                //--------------------------

                //MessageBox.Show("Line:" + i + Environment.NewLine + "columnsCount:" + columnsCount + Environment.NewLine + "lines.Count():" + lines.Count());

                //Check every column (both header and value) CHECK IF IT SHOULD BE "columnscount-1"  
                for (int cellColumn = 0; cellColumn < columnsCount-1; cellColumn++)
                {
                    //Get header and value from csv-file:
                    valueFromTemplate = lineArray[cellColumn];
                    headerFromTemplate = lineHeadersArray[cellColumn];

                    //If Header is found:
                    //Iterate through all properties searching for match on Header and add value to Checkpoint.
                    foreach (PropertyInfo property in properties.Where(a => a.Name != "ColorSet")) //Can have exception for certain fields we do not want to override. say ColorSet
                    {
                        //If match between csv-header and property name:
                        if (property.Name == headerFromTemplate)
                        {
                            if (valueFromTemplate != "" && valueFromTemplate != null)
                            {

                                //handle if property type is string (most standard)
                                if (property.PropertyType == typeof(string))
                                {
                                    //Set property
                                    try
                                    {
                                        property.SetValue(checkPoint, valueFromTemplate);
                                    }
                                    catch
                                    {
                                        MessageBox.Show("Failed to set property type to string when loading CheckPoint settings. Value: " + valueFromTemplate + " Header: " + headerFromTemplate);
                                        property.SetValue(checkPoint, "");
                                    }
                                }
                                //handle if property type is bool
                                else if (property.PropertyType == typeof(bool))
                                {
                                    //Set property
                                    try
                                    {
                                        bool resultBool = ConvertStringToBool(valueFromTemplate);
                                        property.SetValue(checkPoint, resultBool);
                                    }
                                    catch
                                    {
                                        MessageBox.Show("Failed to set property type to bool when loading CheckPoint settings. Value: " + valueFromTemplate + " Header: " + headerFromTemplate);
                                        property.SetValue(checkPoint, false);
                                    }
                                }
                                //handle if property type is int
                                else if (property.PropertyType == typeof(int))
                                {
                                    //Set property
                                    try
                                    {
                                        int resultInt = Convert.ToInt32(valueFromTemplate);
                                        property.SetValue(checkPoint, resultInt);
                                        
                                    }
                                    catch
                                    {
                                        MessageBox.Show("Failed to set property type to int when loading CheckPoint settings. Value: " + valueFromTemplate + " Header: " + headerFromTemplate);
                                        property.SetValue(checkPoint, 0);
                                    }
                                }
                                //handle if property type is int
                                else if (property.PropertyType == typeof(double))
                                {
                                    //Set property
                                    try
                                    {
                                        double resultDouble = Convert.ToDouble(valueFromTemplate);
                                        property.SetValue(checkPoint, resultDouble);
                                    }
                                    catch
                                    {
                                        MessageBox.Show("Failed to set property type to double when loading CheckPoint settings. Value: " + valueFromTemplate + " Header: " + headerFromTemplate);
                                    }
                                }
                                else
                                {
                                    //Leave property unset
                                    MessageBox.Show("Convertion method not added for this type when loading CheckPointSettings. Value: " + valueFromTemplate + " Header: " + headerFromTemplate);
                                }



                                //Set property
                                //property.SetValue(checkPoint, valueFromTemplate);
                                // overriddenProperties = overriddenProperties + "Override Success " + eclipseCheckTemplateToOverride.TemplateName + "! MachineOverride property: " + propertyOverridden + ". MachineOverride value: " + property.GetValue(eclipseCheckTemplateToOverride).ToString() + Environment.NewLine;
                                overriddenProperties = overriddenProperties + property.Name + ": " + valueFromTemplate + " | ";
                            }
                            else
                            { //Set e mpty string if no property from template. This will override if there is anything in checkpoint from before
                                if (property.PropertyType == typeof(string))
                                {
                                    property.SetValue(checkPoint, "");
                                }
                                    
                            }

                        }

                    }

                }

                //list includes lineArray[0] == "Margins". But remember that there are generated new "Margins" checkpoint for every matching set of structures (CTV->ÅTV say). The generic "Margins" will be used as a settingstemplate for them, and then deleted.


                //Add to class (simple method). The above method apparantly did not work, so use this for now.
                checkPoint = new CheckPoint()
                {
                    CheckSwitchCode = lineArray[0],
                    CheckNumber = lineArray[1],
                    CheckName = lineArray[2],
                    CheckListCategory = lineArray[3],
                    CheckType = lineArray[4],
                    CheckExplanation = lineArray[5],
                    CheckTrafficLight = lineArray[6],
                    CheckTaskName = lineArray[7],
                    CheckSortingNumber = lineArray[8],
                    CheckState = lineArray[9],
                    CheckValidationDate = lineArray[10],
                    CheckValidationComment = lineArray[11],
                    CheckLastModification = lineArray[12],
                    CheckInvisibleUnlessWarningOrError = lineArray[13],
                    CheckInactivated = lineArray[14], //We should decide wether to use bool or String on these! Now some are bool and others are strings. Should be more consistant.
                    CalculateLate = ConvertStringToBool(lineArray[15]),
                    CalculateDelayed = ConvertStringToBool(lineArray[16]),
                    CheckElaboration = lineArray[17],
                };
                //Modify Template value for Couch check, as it is special (Name and HU check has been merged into one)
                if (checkPoint.CheckSwitchCode == "CouchNamesAndHUs")
                { checkPoint.CheckTemplateValue = chosenEclipseTemplate.TemplateCouchName + "!!!!" + chosenEclipseTemplate.TemplateCouchHU;
                    //checkPoint.CheckTemplateValueDisplay = chosenEclipseTemplate.TemplateCouchName + Environment.NewLine + chosenEclipseTemplate.TemplateCouchHU; //OLD version

                } //Must ADD final result of TemplateValues to the TemplateValueDisplay and change View so it reads TemplateValueDisplay

                //Set text for calculate delayed
                if (checkPoint.CalculateDelayed == true)
                {
                    checkPoint.CheckResultValue = Constants.Delayed + " Regn ut";
                }


                checkPointSettingsList.Add(checkPoint);
            }
            return checkPointSettingsList;
        }

        public static bool ConvertStringToBool(string boolString)
        {
            //Convert: CheckInvisibleUnlessWarningOrError, CheckInactivated, CalculateLate, CalculateDelayed

            bool resultBool = false; //Default false? or can we set it to null?
            if(boolString.ToLower() == "false")
            { resultBool = false; }
            else if (boolString.ToLower() == "true")
            { resultBool = true; }
            else { }
            return resultBool;
        }

        //Make modifications to the CheckPoints before they are run. Set DiscardAtRuntime and SanityLevelRequired.
        public static List<CheckPoint> ModifyCheckPoints(List<CheckPoint> completeCheckPointList,  CheckScenarioResult checkScenarioResult, EclipseCheckTemplate chosenEclipseTemplate, PatientContext patientContext, List<Field> fieldList) //List<StructureCheck> boluses
        {
            //Set useful strings
            string techniqueName = checkScenarioResult.CheckScenarioTechnique.TechniqueName;
            string PTVIDList_Template = chosenEclipseTemplate.TemplatePTVStructureIDs;

            //-----
            //Set useful booleans 
            //-----
            bool _match_TB = PlanExtension.CheckIfTrueBeamMachine(fieldList); //No checkpoints specific to TBs now, only for Halcyon and Ethos 
            bool _match_Hal = PlanExtension.CheckIfHalcyonMachine(fieldList);
            bool _match_Eth = PlanExtension.CheckIfEthosMachine(fieldList);
            //MU/Gy sjekk for VMAT / SRS / IMRT og FiF eller Tot body
            bool boolVMAT_SRS_IMRT_FiF_TotB = ((techniqueName == Constants.Teknikk.Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.IMRT_technique_forklaring) || (techniqueName == Constants.Teknikk.TotalBody_technique_forklaring) || (techniqueName == Constants.Teknikk.FiF_technique_forklaring));
            bool boolVMAT_SRS_TotB = ((techniqueName == Constants.Teknikk.Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring));
            bool hybridIMRT = (techniqueName == Constants.Teknikk.IMRT_Hybrid_technique_forklaring);

            bool sekvplanExisterer = PlanExtension.SequentialPlanExist(patientContext);

            Field fieldWithWedge = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldWedge != "");
            bool noWedge = (fieldWithWedge == null);

            Field fieldExtended = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldExtended == Constants.True);
            bool noFieldExtended = (fieldExtended == null);
            bool bakfrafelt_bool = PlanExtension.Does180DegreeStaticFieldExist(techniqueName, fieldList);
            bool existFiF = PlanExtension.CheckIfPlanContainsFiF(patientContext.ChosenPlan, patientContext); //NOT USED YET

            bool mobiusDirectoryDoesNotExist = (!Directory.Exists(Constants.MobiusPath));

            //bool hasProtonPlanInCourse = PlanExtension.CheckIfCourseContainsProtonPlans(patientContext.ChosenPlan, patientContext); //Not used - we have a simpler solution for now
            //-------------------



            //MODIFY:
            // 1) Discard at runtime if not necessary to run it.
            // 2) Modify TemplateValues (differenciate between the unaltered original CheckTemlateValue and the one that is displayed CheckTemplateValueDisplay)

            foreach (CheckPoint cp in completeCheckPointList)
            {
                //---------------------------------
                //Remove unfinished checkpoints if it is run in Clinical mode. Otherwise keep it to test in DEBUG mode.
                //---------------------------------
#if Clinical
                if (cp.CheckState != null)
                {
                    if (cp.CheckState == "NotFinished" || cp.CheckState == "")
                    {
                        cp.CheckDiscardedAtRuntime = Constants.True; //Discard checkpoints that are not finished.

                    }
                }
# endif
                //---------------------------------

                string checkSwitchCode = cp.CheckSwitchCode;
                switch (checkSwitchCode)
                {




                    //-------------------------------------------
                    //--------    Teknikk     -------------------
                    //-------------------------------------------
                    case "Machine":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "Technique":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateTechniqueName;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "Avoidance":
                        if (boolVMAT_SRS_TotB != true)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "ElectronCustomCode":
                        if (techniqueName != Constants.Teknikk.Electron_technique_forklaring)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "EnergyChoice": //"Energivalg" //Add logics for if structure pacemaker/ICD etc exist.
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateEnergyChoice;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case string a when a.Contains("BasePlan"):

                        if (checkSwitchCode == "BasePlanExist")
                        {
                            cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        }
                        else if (checkSwitchCode == "BasePlanContribution")
                        {
                            cp.CheckTemplateValue = chosenEclipseTemplate.TemplateBasePlanContribution;
                            cp.CheckSanityLevelRequired = Constants.SanityLevelFractionationExist;
                        }
                        break;
                    case string a when a.Contains("Fluence"):

                        if (checkSwitchCode == "FluenceMaxPrint")
                        {
                            cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist;
                        }
                        if (checkSwitchCode == "SmallestFluenceMax")
                        {
                            cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist;
                        }
                        break;
                    case "CouchAngle":
                        cp.CheckTemplateValue = Constants.False;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "DoseRate":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist; // OR Constants.SanityLevelPlanExist ???
                        break;

                    // Now check is "done" before we get here. Output is simply "it exists" ish.
                    case "GantryAngleExtended":
                        if (noFieldExtended)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;

                        break;
                    case "WedgeMU":
                        if (noWedge) //if no wedge
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist;
                        break;
                    case "ExtendedStatus":
                        if (((bakfrafelt_bool) || (!noFieldExtended)) && (!_match_Hal && !_match_Eth)) //Ikke nødvendig sjekk hvis Halcyon og Ethos.                                                                 //vekting_gantryvinkel.VinkelWarning == Konstanter.True
                        { }
                        else
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "DistanceCouchIsosenter": //"DistTable": //Not in use
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "Collision":
                        cp.CheckTemplateValue = "Toleranse: " + Constants.CollisionDistanceWarning.ToString() + " - " + Constants.CollisionDistanceError.ToString() + " cm.";
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        if (_match_Hal == true)
                        {

                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }

                        break;
                        // ----------  PD --------------
                    case string checkNamePD when checkNamePD.Contains("PD"): //Endre så sjekkpunktet kommer med ogsaa for hybrid imrt. kan vaere comment "ikke nodvendig med PD for hybrid imrt".
                        //Discard check
                        if (boolVMAT_SRS_IMRT_FiF_TotB == false)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        if (checkSwitchCode == "PDNecessary")
                        {
                        }
                        if (checkSwitchCode == "PDCreated")
                        {
                            cp.CheckTemplateValue = Constants.True;
                        }
                        if (checkSwitchCode == "PDScheduled")
                        {
                            cp.CheckTemplateValue = "1";
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist; //All have same sanity requirement
                        break;
                    case "CollimatorAngle":
                        if (!(boolVMAT_SRS_IMRT_FiF_TotB == true || hybridIMRT == true)) //boolVMAT_SRS_TotB == true
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "JawTracking":
                        if (!(boolVMAT_SRS_TotB == true && (!_match_Hal && !_match_Eth)))
                        {// Kun sjekk for VMAT-teknikk. Unntak hvis Halcyon eller Ethos maskin.
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;

                    case "SmallFieldSize":
                        if (!(boolVMAT_SRS_TotB == true && (!_match_Hal && !_match_Eth)))
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                            cp.CheckTemplateValue = "Toleranse:" + Environment.NewLine + " X >= " + Constants.ToleranceFieldsize_x + "cm " + Environment.NewLine + "Y >= " + Constants.ToleranceFieldsize_y + "cm " + Environment.NewLine + "X*Y >= " + Constants.ToleranceFieldsize_xy + "cm2";
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist; 
                        break;
                    case "IsoLimitHalcyon":
                        if (_match_Hal != true)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "IsoLimitEthos":
                        if (_match_Eth != true)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        break;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                   


                    //-------
                    //Course
                    //-------
                    case "Intent":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateIntent;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCourseExist;
                        break;

                    case "Diagnosis":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateDiagnosis;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCourseExist;
                        break;
                    //-------
                    //-------


                    //-------
                    //CT strukctures
                    //-------
                    case "UserOrigin":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;
                    case "CTSliceThickness":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateCTSliceThickness;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelImageExist;
                        break;
                    case "CouchNamesAndHUs":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateCouchName + "!!!!" + chosenEclipseTemplate.TemplateCouchHU; //Separate couchNames and HU values with "!!!!". A bit silly, but should work. 
                        
                        
                        //Proton couch -anything is allowed
                        //if (hasProtonPlanInCourse == true)
                        //{
                        //    cp.CheckTemplateValue = "" + "!!!!" + "";
                        //    cp.CheckComment = "All allowed because of comparative photon and proton plan.";

                        //}

                        //cp.CheckTemplateValueDisplay = chosenEclipseTemplate.TemplateCouchName + Environment.NewLine + chosenEclipseTemplate.TemplateCouchHU; //Modifies slightly with new line, Otherwise too wide screen.
                        //Format display values properly:
                        string toleranceDisplayOutput = "";
                        List<StructureCheck> structuresTemplateList = StructureExtension.CreateCouchStructureTemplateList(cp.CheckTemplateValue);
                        toleranceDisplayOutput = StructureExtension.ReformatCouchTemplateDisplayValue(structuresTemplateList);
                        cp.CheckTemplateValueDisplay = toleranceDisplayOutput;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;
                    case "EmptyStructures":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;
                    case "HRStructures":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateMandatoryHighResolutionStructureIDs;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;
                    case "MissingCTSlices":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;
                    case "Margins":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;
                    case "HUinPTV":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist; //You sure about that?
                        break;
                    case "BodyFreeBreathingExists": 
                        if (!chosenEclipseTemplate.TemplateName.ToLower().Contains("mamma"))
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist;
                        break;

                    //-------
                    //Plan
                    //-------
                    case "Fractionation":
                        cp.CheckTemplateValue =  chosenEclipseTemplate.TemplateFractionations;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelFractionationExist;
                        break;
                    case "Normalization":
                        cp.CheckTemplateValue =  chosenEclipseTemplate.TemplateNormalization;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "CalcAlgo":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateCalculationAlgorithm;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "CalcResolution":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateCalculationResolution;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist;
                        break;
                    case "ToleranceTableTreat":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateToleranceTableTreat;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "ToleranceTableSetup":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateToleranceTableSetup;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "NumberSetupFields":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplateNumberOfSetupFields;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "NumberBolusFields":
                        cp.CheckTemplateValue = ">0";
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "PatientOrientation":
                        cp.CheckTemplateValue = chosenEclipseTemplate.TemplatePatientOrientation;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "Laterality":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "Mobius":
                        if (mobiusDirectoryDoesNotExist)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckTemplateValue = Constants.True;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "PlanUncertainties":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;

                    //-------
                    //ReferencePoints
                    //-------
                    case "PrimaryReferencePoint":
                        cp.CheckTemplateValue = PTVIDList_Template;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;

                    case "SecondaryReferencePoints":
                        cp.CheckTemplateValue = PTVIDList_Template;
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;

                    case "CommonReferencePoint":
                        if (sekvplanExisterer != true)
                        {
                            cp.CheckDiscardedAtRuntime = Constants.True;
                        }
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;

                        break;



                    case string a when a.Contains("DVH"):
                        cp.CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist;
                        break;


                    //SUS CASES
                    case "PrescriptionApproved":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "DosePlanNumberSUS": //
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "FormattingNamesSUS":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "PortalDosePlanSUS":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "PlanApprovedSUS":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "PlanUnapproved":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "NumberOfTreatments":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;
                    case "FiFMerged":
                        cp.CheckSanityLevelRequired = Constants.SanityLevelPlanExist;
                        break;



                }


            }


            return completeCheckPointList;

        }

            public static List<CheckPoint> ModifyCheckPointListDiscardedAtRuntime(List <CheckPoint> completeCheckPointList, List<Field> fieldList, CheckScenarioResult checkScenarioResult, PatientContext patientContext) //List<StructureCheck> boluses
        {
            string techniqueName = checkScenarioResult.CheckScenarioTechnique.TechniqueName;

            //Create new list of checkpoints to fill up
            //List<CheckPoint> completeCheckPointList = new List<CheckPoint>();

            //-----
            //Set useful booleans 
            //-----
            bool _match_TB = PlanExtension.CheckIfTrueBeamMachine(fieldList); //No checkpoints specific to TBs now, only for Halcyon and Ethos 
            bool _match_Hal = PlanExtension.CheckIfHalcyonMachine(fieldList);
            bool _match_Eth = PlanExtension.CheckIfEthosMachine(fieldList);
            //MU/Gy sjekk for VMAT / SRS / IMRT og FiF eller Tot body
            bool boolVMAT_SRS_IMRT_FiF_TotB = ((techniqueName == Constants.Teknikk.Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.IMRT_technique_forklaring) || (techniqueName == Constants.Teknikk.TotalBody_technique_forklaring) || (techniqueName == Constants.Teknikk.FiF_technique_forklaring));
            bool boolVMAT_SRS_TotB = ((techniqueName == Constants.Teknikk.Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring));
            bool hybridIMRT = (techniqueName == Constants.Teknikk.IMRT_Hybrid_technique_forklaring);

            bool sekvplanExisterer = PlanExtension.SequentialPlanExist(patientContext);

            Field fieldWithWedge = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldWedge != "");
            bool noWedge = (fieldWithWedge == null);

            Field fieldExtended = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldExtended == Constants.True);
            bool noFieldExtended = (fieldExtended == null);
            bool bakfrafelt_bool = PlanExtension.Does180DegreeStaticFieldExist(techniqueName, fieldList);
            bool existFiF = PlanExtension.CheckIfPlanContainsFiF(patientContext.ChosenPlan, patientContext); //NOT USED YET

            bool hasProtonPlanInCourse = PlanExtension.CheckIfCourseContainsProtonPlans(patientContext.ChosenPlan, patientContext);

            //-------------------

            //-----
            //Modify Checkpoints
            //-----

            //Modifiserer sjekker som skal gjennomfores om det finnes Halcyon maskin
            if (_match_Hal != true)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("IsoLimitHalcyon", Constants.True, completeCheckPointList);
            }

            //Legger til sjekker som skal gjennomføres om det finnes Ethos maskin
            if (_match_Eth != true)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("IsoLimitEthos", Constants.True, completeCheckPointList);
            }

            //Distance to couch //No longer relevant. Removed
            if (patientContext.CouchId == "")
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("CouchDistance", Constants.True, completeCheckPointList);
            }
            if (patientContext.CouchId == "")
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("CouchDistance", Constants.True, completeCheckPointList);
            }

            //Wedge
            if (noWedge) //if no wedge
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("WedgeMU", Constants.True, completeCheckPointList);
            }

            //Proton couch
            //if (hasProtonPlanInCourse == true)
            //{//Discard
            //    //completeCheckPointList = SetCheckPointDiscardAtRunTime("CouchNamesAndHUs", Constants.True, completeCheckPointList); //MU/Gy sjekk for VMAT / SRS / IMRT og FiF eller Tot body

            //}

            //PD
            if (boolVMAT_SRS_IMRT_FiF_TotB == false)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("PDNecessary", Constants.True, completeCheckPointList); //MU/Gy sjekk for VMAT / SRS / IMRT og FiF eller Tot body
                completeCheckPointList = SetCheckPointDiscardAtRunTime("PDCreated", Constants.True, completeCheckPointList); //PD generert, kun med hvis planen faktisk krever PD-plan.
                completeCheckPointList = SetCheckPointDiscardAtRunTime("PDScheduled", Constants.True, completeCheckPointList); //PD generert, kun med hvis planen faktisk krever PD-plan.
            }

            //VMAT sjekk Coll > 2 grader
            if (!(boolVMAT_SRS_IMRT_FiF_TotB == true || hybridIMRT == true)) //boolVMAT_SRS_TotB == true
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("CollimatorAngle", Constants.True, completeCheckPointList);
            }

            //Jaw Tracking 
            if (!(boolVMAT_SRS_TotB == true && (!_match_Hal && !_match_Eth)))
            {// Kun sjekk for VMAT-teknikk. Unntak hvis Halcyon eller Ethos maskin.
                completeCheckPointList = SetCheckPointDiscardAtRunTime("JawTracking", Constants.True, completeCheckPointList);
            }

            //Field Size Small
            if (!(boolVMAT_SRS_TotB == true && (!_match_Hal && !_match_Eth)))
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("SmallFieldSize", Constants.True, completeCheckPointList);
            }

            //Avoidance    
            if (boolVMAT_SRS_TotB != true)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("Avoidance", Constants.True, completeCheckPointList);
            }

            //Elektronsjekker
            if (techniqueName != Constants.Teknikk.Electron_technique_forklaring)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("ElectronCustomCode", Constants.True, completeCheckPointList);
            }


            //Sjekk av Extended avhengig av lateralitet og gantryvinkel.
            Field match = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldExtended == Constants.True);
            if (match == null)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("GantryAngleExtended", Constants.True, completeCheckPointList);
            }

            // Sjekker om bakgrafelt burde ha extended eller ikke. Komplisert da den må se på gantryvektingen av øvrige felt, lateralitet og pasientorientering, blant annet. Burde kanskje også ha egens sjekk på lateralitet.
            if (((bakfrafelt_bool) || (!noFieldExtended)) && (!_match_Hal && !_match_Eth)) //Ikke nødvendig sjekk hvis Halcyon og Ethos.                                                                 //vekting_gantryvinkel.VinkelWarning == Konstanter.True
            {}else
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("ExtendedStatus", Constants.True, completeCheckPointList);
            }


            // Remove check if not necessary: 
            //if (!existFiF)                                                    
            //{
            //    SetCheckPointDiscardAtRunTime("FiFMerged", Constants.True, completeCheckPointList);
            //}

            //Mobius
            if (!Directory.Exists(Constants.MobiusPath))
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("Mobius", Constants.True, completeCheckPointList);
            }

            //Sequential plan

            // Itererer gjennom alle planer i samme course (tempplan) og sjekker for revisjon og sekvensielle planer


            //legger inn sjekkpunkt hvis det eksisterte sekv. planer el. revisjoner
            if (sekvplanExisterer != true)
            {
                completeCheckPointList = SetCheckPointDiscardAtRunTime("CommonReferencePoint", Constants.True, completeCheckPointList);
            }


            return completeCheckPointList;
        }


        public static List<CheckPoint> SetCheckPointDiscardAtRunTime(string checkSwitchCode, string boolean, List<CheckPoint> completeCheckPointList)
        {
            try
            {
                CheckPoint checkPoint = completeCheckPointList.FirstOrDefault(cp => cp.CheckSwitchCode == checkSwitchCode); 
                checkPoint.CheckDiscardedAtRuntime = boolean;
            }
            catch
            {
                MessageBox.Show("Klarte ikke sette status CheckDiscardAtRunTime= " + boolean + " for CheckSwitchCode=" + checkSwitchCode);
            }
            //Return list:
            return completeCheckPointList;
        }

        //IKKE FERDIG
        public static CheckPoint OverideCheckPointPropertiesIfNotEmpty(CheckPoint checkPointToOverride, CheckPoint checkPointTemplateContainingOverride) //use input (PatientContext patientContext)?
        {
            //--------- DEBUG ----------------
            string overriddenProperties = "";
            //PrintEclipseCheckTemplate(eclipseCheckTemplateToOverride);//OverideElipseTemplatePropertiesIfNotEmpty
            //EclipseCheckTemplate record = new EclipseCheckTemplate();
            //-------------------------------

            //Get all properties from class
            PropertyInfo[] properties = typeof(EclipseCheckTemplate).GetProperties();
            //Iterate through all properties 
            foreach (PropertyInfo property in properties.Where(a => a.Name != "TemplateName" && a.Name != "TemplateScore" && a.Name != "ColorSet" && a.Name != "TemplateComment" && a.Name != "Debug")) //Must have exception for certain fields we do not want to override.
            {
                //If property value not empty
                string value = property.GetValue(checkPointTemplateContainingOverride).ToString(); //Need an exeption if value is null/empty! ----- If (property.GetValue(eclipseCheckTemplatContainingOverride) != null){}
                string propertyOverridden = property.Name;
                if (value != "")
                {
                    //Set property
                    property.SetValue(checkPointToOverride, value);
                    // overriddenProperties = overriddenProperties + "Override Success " + eclipseCheckTemplateToOverride.TemplateName + "! MachineOverride property: " + propertyOverridden + ". MachineOverride value: " + property.GetValue(eclipseCheckTemplateToOverride).ToString() + Environment.NewLine;
                    overriddenProperties = overriddenProperties + property.Name + ": " + value + " | ";
                }
            }
            //checkPOintToOverride.Debug = overriddenProperties; //Debug to inform that certain properties are overridden
            // Debug: MessageBox.Show(overriddenProperties);
            //PrintEclipseCheckTemplate(eclipseCheckTemplateToOverride);/// Debug: 

            return checkPointToOverride;
        }


        //------------------
        // Create CheckPoint Mainmethod
        //-----------------
        //Mainmethod
        #region CreateCheckPoint MainMethod
        public static List<CheckPoint> CreateCheckPointList(PatientContext patientContext, CheckScenarioResult checkScenarioResult, List<MarginList> listOfMarginLists) //List<StructureCheck> boluses
        {
            //---------------------------------------
            //Setting technique and machine, fieldlist etc.
            //---------------------------------------
            string chosenTemplateName = checkScenarioResult.TemplateName;
            string machine = checkScenarioResult.CheckScenarioMaskin;
            string techniqueName = checkScenarioResult.CheckScenarioTechnique.TechniqueName;
            List<Field> fieldList = checkScenarioResult.CheckScenarioFieldList;
            FieldsAnalysis fieldsAnalysis = checkScenarioResult.CheckScenarioFieldAnalysis;
            //Set chosen template:                               
            EclipseCheckTemplate chosenEclipseTemplate = checkScenarioResult.TemplateChosen;                                    
            //Create list of checkpoints to fill up
            List<CheckPoint> completeCheckPointList = new List<CheckPoint>();
            //---------------------------------------
            //---------------------------------------

            //LoadFromTamplate:
            completeCheckPointList = LoadCheckPointTemplate(Constants.PlanCheckTemplateFolderPath + Constants.CheckPointSettingsFileName, chosenEclipseTemplate);

            //Loading margins-settings. Will be applied to every margins-checkpoint. 
            string marginsCheckPointSwichCode = "Margins";

            //load the margins-CP for later use:
            CheckPoint marginsCP = completeCheckPointList.Where(x => x.CheckSwitchCode == marginsCheckPointSwichCode).FirstOrDefault(); //Keep this for use later!
            //GeneralExtension.PrintObject(marginsCP);
            //Remove generic margins CP from list:
            bool removedItem = completeCheckPointList.Remove(marginsCP);
            if(removedItem == false) 
            {
                MessageBox.Show("Failed to find Margins-settings in csv-file. Using code-defined default values");
            }


            //MessageBox.Show("Count completeCheckPointList: " + completeCheckPointList.Count().ToString());
            //Print for debugging
            //GeneralExtension.PrintObject(completeCheckPointList[2]);

            //Set unneccesary checkpoints to Discarded.
            //completeCheckPointList = ModifyCheckPointListDiscardedAtRuntime(completeCheckPointList, fieldList, checkScenarioResult, patientContext);
            //Add template values:
            completeCheckPointList = ModifyCheckPoints(completeCheckPointList, checkScenarioResult, chosenEclipseTemplate, patientContext, fieldList); //Should this not be RUN AFTER the Margins checkpoints and DVH checkpoints are added further down?

            //Get technical check points and add to list
            //List<CheckPoint> TechnicalCheckPointList = CreateTechnicalCheckPointList(patientContext, fieldList, techniqueName, chosenEclipseTemplate);
            //completeCheckPointList.AddRange(TechnicalCheckPointList);
            //To add:
            //Multiple isosenters warning
            //Gantry angle whole number warning
            //Jaws field junction. Y vs Y? Maybe not worth it...


            //Get Course check points and add to list
            //List<CheckPoint> CourseCheckPointList = CreateCourseCheckPointList(patientContext, chosenEclipseTemplate);
            //completeCheckPointList.AddRange(CourseCheckPointList); 

            //Get CT and Structure check points and add to list
            //List<CheckPoint> CTAndStructuresCheckPointList = CreateCTAndStructuresCheckPointList(patientContext, chosenEclipseTemplate);
            //completeCheckPointList.AddRange(CTAndStructuresCheckPointList); 
            //To add:
            //Mandatory structures (hjerte / rektum etc.)
            //HighResolution_Structures. Ok
            //CTV within PTV. OK
            //Margins CTV til PTV. Ok
            //DIBH CT grunnlag -> sjekk om....???
            //Pacemaker structure exist warning -> Valid energies for pacemaker


            //Get Plan check points and add to list
            //List<CheckPoint> PlanCheckPointList = CreatePlanCheckPointList(patientContext,  chosenEclipseTemplate);
            //completeCheckPointList.AddRange(PlanCheckPointList);
            //To add:
            //Smoothing paramaters
            //Normalisation value within 95-105%
            //Iososenter inside target PTV
            //Multiple isosenter: MultipleIsosenter()
            //To modify:
            //Hide generic energy checkpoint (exceptions? stereotaxi? add if pacemaker?)

            //Get ReferencePoint check points
            //List<CheckPoint> ReferencePointCheckPointList = CreateReferencePointCheckPointList(patientContext, chosenEclipseTemplate);
            //completeCheckPointList.AddRange(ReferencePointCheckPointList); //Add to list


            //Get DVH CheckPoints
            //if (patientContext.SanityLevel > Constants.SanityLevelCalculatedDoseExist)
            //{
            List<CheckPoint> DVHCheckPointList = CreateDVHCheckPointList(patientContext, chosenEclipseTemplate, fieldsAnalysis);
                completeCheckPointList.AddRange(DVHCheckPointList); //Add to list
            //}


            //                if (chosenTemplateName == Constants.Templater.Stereotaksi_lunge){}

            //Margin checkpoints are generated dynamically. There will be no checkpoints if the list is empty. No need to inactivate them
            List<CheckPoint> MarginsCheckPointList = CreateMarginsCheckPointList(patientContext, chosenEclipseTemplate, listOfMarginLists, marginsCP);
            if (MarginsCheckPointList != null) //MarginsCheckPointList.Count >0
            {
                completeCheckPointList.AddRange(MarginsCheckPointList); //Add to list
            }

            //List<CheckPoint> susCheckPointList = CreateSUSCheckPointList(patientContext, chosenEclipseTemplate);
            //completeCheckPointList.AddRange(susCheckPointList);


            //-------------------------------------------
            //-------- -Diagnosis specific checks -------
            //-------------------------------------------
            //To Add:
            //lymph node boost exists for prostate

            //----------------------------------

            //Remove inactivated CheckPoints:
            //completeCheckPointList = RemoveInactivatedCheckpoints(completeCheckPointList);

            //Remove CheckPoints based on SanityLevel
            //completeCheckPointList = RemoveCheckpointsFailedSanity(completeCheckPointList, patientContext);


            //strukturliste

            //Script går igjennom listen og sjekker om strukturene eksistererer. Skal være sortert etter sannsynlighet for å være normeringsstruktur (først = mest sannsynlig).
            //Forventer at første struktur som finnes er normeringsstruktur.
            //Hvis strukturen eksistererer, leter den om det finnes et referansepunkt med tilsvarende navn.

            // 0) (I framtidig skript: sjekker hvilke strukturer som burde eksistere basert på rekvisisjon og oppdatere listen med det)
            // 1) sjekk om strukturene eksisterer, fjerner de som ikke eksisterer. Forventer at resten skal brukes i planlegging. (sjekk om strukturen har tegning eller er tom.)
            // 2) Forventer at første struktur som finnes i listen er normeringsvolum og koblet til primært referansepunkt
            // 3) sjekker alle andre strukturer som eksisterer om det finnes referansepunkt med tilsvarende navn
            // 4) (I framtidig skript: fyller opp referansepunktliste med toleransegrenser og doser.)



            return completeCheckPointList;
        }
        #endregion CreateCheckPoint MainMethod

        //------------------
        // Create CheckPoint Submethods
        //-----------------
        //Submethods
        #region CreateCheckPoint SubMethods
        //Should find a way to handle if bodyID does not exist!!      if(patientContext.HasBody = false)
        //(sending Margins Checkpoint settings)
        public static List<CheckPoint> CreateMarginsCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplatestring, List<MarginList> listOfMarginLists, CheckPoint marginsCPsettings)      //List<MarginList> listOfMarginLists             //Make no changes to marginList here, as it is not passed back! Only passes back checkPoint
        {
            //------------------
            //Search in CheckPointSettings for default settings of all made checkpoints
            //------------------
            //Load default Margins template
            //CheckPoint defaultMarginsCheckPoint = new CheckPoint;... where CheckSwitchCode = "Margins" or use one defined here if not found.
            //------------------

            //------------------
            //use this loaded default template and the listOfMarginLists to create the following checkpoints:
            //------------------
            int iterator = 0; 
            //List of checkpoints
            List<CheckPoint> checkPointListMargins = new List<CheckPoint>();

            ////Margin templates are loaded in MainViewModel and tolerances added to the lists. Now we need to create checkpoints.

            foreach (MarginList marginList in listOfMarginLists)
            {
                foreach (Margins marginResult in marginList.ListOfMargins) 
                {
                    //Create checkpoint (sending Margins Checkpoint settings)
                    CheckPoint checkPoint = CheckPointExtension.AddMarginsCheckPoint(marginResult, marginList, marginsCPsettings, marginResult.ExpectedMeanMargin, marginResult.MeanMarginLowWarning, marginResult.MeanMarginHighWarning, marginResult.MeanMarginLowError, marginResult.MeanMarginHighError); //CheckPoint checkPoint  = CheckPointExtension.AddMarginsCheckPoint(marginList.ListOfMargins[iterator], marginList);
                    checkPointListMargins.Add(checkPoint);

                    iterator++;
                }
            }


            //if (s.CheckStatus != Constants.Warning && s.CheckStatus != Constants.Error) { s.CheckStatus = Constants.Info; }

            //-----------------------------------------------------
            //Resultat End
            //-----------------------------------------------------

            return checkPointListMargins;
        }

        //------------------
        //Outdated - replaced with loading from csv-file
        //------------------
        public static List<CheckPoint> CreateTechnicalCheckPointList(PatientContext patientContext, List<Field> fieldList, string techniqueName, EclipseCheckTemplate chosenEclipseTemplate)
        {
            //List of checkpoints
            List<CheckPoint> checkPointList = new List<CheckPoint>();

            //-------------------------------------------
            //--------    Machine     -------------------
            //-------------------------------------------
            string _sjekklisteKategori = "Teknikk";
            var match = new Field(); //Brukes til aa finne match i Feltliste.

            //-------------------------------
            //Isosenter for Halcyon and Ethos
            //-------------------------------

            bool _match_TB = PlanExtension.CheckIfTrueBeamMachine(fieldList); //No checkpoints specific to TBs now, only for Halcyon and Ethos 
            bool _match_Hal = PlanExtension.CheckIfHalcyonMachine(fieldList);
            bool _match_Eth = PlanExtension.CheckIfEthosMachine(fieldList);

            string checkDiscardedAtRuntime = Constants.False;


            //Legger til sjekker som skal gjennomfores om det finnes Halcyon maskin
            if (_match_Hal == true)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }


            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.9a",
                CheckCategory = "Isosenter Halcyon",
                CheckName = "Isosenter-begrensning Halcyon",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om Halcyon isosenter er satt feil. Begrensning ligger i z-retning.",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            //Legger til sjekker som skal gjennomføres om det finnes Ethos maskin
            if (_match_Eth == true)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.9b",
                CheckCategory = "Isosenter Ethos",
                CheckName = "Isosenter-begrensning Ethos",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om Ethos isosenter er satt feil. Begrensning ligger i z-retning.",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });
            //----------------------------------------------------------

            //-------------------------------
            //Distance to table
            //-------------------------------
            if (patientContext.CouchId != "")
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.9c",
                CheckCategory = "Avstand fra bord",
                CheckName = "Avstand Bordoverflate til isosenter",
                CheckTemplateValue = "< " + Constants.ToleranseAvstandBordTilIsosenterCm.ToString() + " cm",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om avstand fra isosenter til bordtoppSurface > " + Constants.ToleranseAvstandBordTilIsosenterCm.ToString() + "cm. Gir advarsel." + Environment.NewLine + "Begrensning: sjekker kun første isosenter" + Environment.NewLine + "Nøyaktighet: +/- 2mm, avhengig av bord lagt inn.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist

                //Changed from structureset exist.
            });

            //-------------------------------
            //CollisionCheck for non ring machjines
            //-------------------------------
            if (_match_Hal != true && _match_Eth != true) //Not for ring-machines, which dont have collisions.
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            //Also discadr for electrons for now...?

            //checkDiscardedAtRuntime = Constants.False; //Override for testing

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.9d",
                CheckCategory = "Collision",
                CheckName = "Kollisjonsjekk mot Body og Couch",
                CheckTemplateValue = "Toleranse: " + Constants.CollisionDistanceWarning.ToString() + " - " + Constants.CollisionDistanceError.ToString() + " cm.",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker avstand fra gantry til hhv. 'Body' og alle 'Support'-strukturer (bord-strukturer). Den lager en modell av gantry for alle gantryvinkler. Den kan ses lengre nede. OBS! Fungerer IKKE for elektroner eller for andre orienteringer enn HeadFirstSupine eller HeadFirstProne",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist,
                CalculateLate = true

                //Changed from structureset exist.
            });


            //-------------------------------------------
            //--------    Teknikk     -------------------
            //-------------------------------------------

            //////////////////////////////
            //Sjekkliste basert paa Teknikk
            /////////////////////////////
            _sjekklisteKategori = "Teknikk";

            //Maskin
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.0",
                CheckCategory = "Maskin",
                CheckName = "Maskin",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = Constants.Info,
                CheckExplanation = "Informerer om hvilken maskin det er, hvilken ID og hvilken Type (TB, Halcyon, Ethos). Gir også varsel om noen felt har forskjellig maskin.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            }); ;

            //Teknikk
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.1",
                CheckCategory = "Teknikk",
                CheckName = "Teknikk",
                CheckTemplateValue = chosenEclipseTemplate.TemplateTechniqueName,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om teknikkvalg er standard etter templatet.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist

            }); ;


            //Wedge
            match = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldWedge != "");
            if (match != null)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.2",
                CheckCategory = "Felt",
                CheckName = "Kilefelt > 20 MU",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om kiler har over 20 MU",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
            });


            string isPDNecessary = Constants.False;
            //MU/Gy sjekk for VMAT / SRS / IMRT og FiF eller Tot body
            bool boolVMAT_SRS_IMRT_FiF_TotB = ((techniqueName == Constants.Teknikk.Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.IMRT_technique_forklaring) || (techniqueName == Constants.Teknikk.TotalBody_technique_forklaring) || (techniqueName == Constants.Teknikk.FiF_technique_forklaring));
            bool boolVMAT_SRS_TotB = ((techniqueName == Constants.Teknikk.Arc_technique_forklaring) || (techniqueName == Constants.Teknikk.SRS_Arc_technique_forklaring));
            bool hybridIMRT = (techniqueName == Constants.Teknikk.IMRT_Hybrid_technique_forklaring); 

            // ----------------------------------
            // ---------- START PD --------------
            // ----------------------------------
            if (boolVMAT_SRS_IMRT_FiF_TotB == true)
            {
                checkDiscardedAtRuntime = Constants.False;
                isPDNecessary = Constants.True;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
                {
                    CheckListCategory = _sjekklisteKategori,
                    CheckNumber = "4.3",
                    CheckCategory = "PD",
                    CheckName = "PD nødvendig: (MU/Gy > grenseverdi)",
                    CheckTemplateValue = "",
                    CheckVerification = "False",
                    CheckType = "Sjekk",
                    CheckExplanation = "Sjekker om MU/Gy er over grenseverdi for PD-verifikasjon. Sjekker også andre grunner til at PD er nødvendig " + Environment.NewLine + "Status om PD nodvendig og laget: Info" + Environment.NewLine + "Status om PD nodvendig og ikke allerede laget: Warning" + Environment.NewLine + "Status om PD ikke nødvendig: ok",
                    CheckTrafficLight = Constants.Info,
                    CheckDebug = "",
                    CheckTaskName = "Fysiker|BasicPlanCheck",
                    CheckInvisibleUnlessWarningOrError = Constants.False,
                    CheckInactivated = Constants.False,
                    CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                    CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
                }); ;



            //PD generert, kun med hvis planen faktisk krever PD-plan.
            if (isPDNecessary == Constants.True)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.4",
                CheckCategory = "PD",
                CheckName = "PD: PD-plan generert",
                CheckTemplateValue = Constants.True,
                CheckVerification = "False",
                CheckType = "Info",
                CheckExplanation = "Sjekker om det finnes en PD-plan generert for denne planen.",
                CheckTrafficLight = Constants.OBS,
                CheckTaskName = "Fysiker|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
            }); ;


            //PD generert, kun med hvis planen faktisk krever PD-plan.
            if (isPDNecessary == Constants.True)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.5",
                CheckCategory = "PD",
                CheckName = "PD: PD-plan schedulerte behandlinger",
                CheckTemplateValue = "1",
                CheckVerification = "False",
                CheckType = "Info",
                CheckExplanation = "Sjekker om PD-plan er schedulert. Oppgir antall schedulerte behandlinger.",
                CheckTrafficLight = Constants.OBS,
                CheckTaskName = "Fysiker|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
            });

            // ----------------------------------
            // ---------- END PD  ---------------
            // ----------------------------------

            //VMAT sjekk Coll > 2 grader
            if ( boolVMAT_SRS_IMRT_FiF_TotB == true || hybridIMRT == true) //boolVMAT_SRS_TotB == true
            {
                checkDiscardedAtRuntime = Constants.False;
                //_PDNodvendig = Constants.True;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            checkPointList.Add(new CheckPoint()
                {
                    CheckListCategory = _sjekklisteKategori,
                    CheckNumber = "4.6",
                    CheckCategory = "Collimator",
                    CheckName = "Collimatorvinkel >= 2°",
                    CheckTemplateValue = "",
                    CheckVerification = "False",
                    CheckType = "Sjekk",
                    CheckExplanation = "Sjekker om kollimatorvinkel er > 2° for VMAT- og IMRT-teknikk. Printer brukte vinkler.",
                    CheckTrafficLight = Constants.Error,
                    CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                    CheckInvisibleUnlessWarningOrError = Constants.False,
                    CheckInactivated = Constants.False,
                    CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                    CheckSanityLevelRequired = Constants.SanityLevelPlanExist
                });


            //Jaw Tracking 
            if (boolVMAT_SRS_TotB == true && (!_match_Hal && !_match_Eth))
            {// For VMAT-teknikk. Unntak hvis Halcyon eller Ethos maskin.
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.7",
                CheckCategory = "JawTracking",
                CheckName = "JawTracking",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om jaw Tracking er satt på for VMAT-teknikk. Unntak: Halcyon og Ethos maskintype.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            //Field Size Small
            if (boolVMAT_SRS_TotB == true && (!_match_Hal && !_match_Eth))
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.8",
                CheckCategory = "Liten feltstørrelse",
                CheckName = "Liten feltstørrelse",
                CheckTemplateValue = "Toleranse:" + Environment.NewLine + " X >= " + Constants.ToleranceFieldsize_x + "cm " + Environment.NewLine + "Y >= " + Constants.ToleranceFieldsize_y + "cm " + Environment.NewLine + "X*Y >= " + Constants.ToleranceFieldsize_xy + "cm2",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om feltstørrelsen definert av kollimatorene er mindre enn toleransen for VMAT-teknikk (<" + Constants.ToleranceFieldsize_x + "cm). Dette er ofte tilfelle når man bruker Jaw Tracking på små felt. Det er ikke nødvendigvis problematisk. Sjekken gir mer informasjon om hvor stor andel av buen(e) som har liten feltstørrelse så man kan bedømme om det er et problem.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            //Avoidance    
            if (boolVMAT_SRS_TotB == true)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            checkPointList.Add(new CheckPoint()
                {
                    CheckListCategory = _sjekklisteKategori,
                    CheckNumber = "4.10",
                    CheckCategory = "Avoidance",
                    CheckName = "Avoidance",
                    CheckTemplateValue = "",
                    CheckVerification = "False",
                    CheckType = "Info",
                    CheckExplanation = "Informerer om at avoidance er satt på buene for VMAT-teknikk. Gir mer detaljert informasjon om avoidancevinkler. Hvis det ikke er satt på avoidance, fjernes dette SjekkPunkt.",
                    CheckTrafficLight = Constants.OBS,
                    CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                    CheckInvisibleUnlessWarningOrError = Constants.False,
                    CheckInactivated = Constants.False,
                    CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                    CheckSanityLevelRequired = Constants.SanityLevelPlanExist
                });


            //Elektronsjekker


            if (techniqueName == Constants.Teknikk.Electron_technique_forklaring)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            checkPointList.Add(new CheckPoint()
                {
                    CheckListCategory = _sjekklisteKategori,
                    CheckNumber = "4.11",
                    CheckCategory = "Elektroner Applikator/Tray/CustomCode:",
                    CheckName = "Elektroner Applikator/Tray/CustomCode:",
                    CheckTemplateValue = "",
                    CheckVerification = "False",
                    CheckType = "Info",
                    CheckExplanation = "Henter ut Applikator, Tray og Custom Code. Custom Code fungerer ikke i nåværende versjon av ESAPI.",
                    CheckTrafficLight = Constants.OBS,
                    CheckTaskName = "Fysiker|Doseplan",
                    CheckInvisibleUnlessWarningOrError = Constants.False,
                    CheckInactivated = Constants.False,
                    CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                    CheckSanityLevelRequired = Constants.SanityLevelPlanExist
                });
            

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.12",
                CheckCategory = "Energivalg",
                CheckName = "Energivalg",
                CheckTemplateValue = chosenEclipseTemplate.TemplateEnergyChoice,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om energivalg er standard etter templatet.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            }); ;

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.13",
                CheckCategory = "Base Plan",
                CheckName = "Base Plan",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = Constants.Info,
                CheckExplanation = "Sjekker om planen har en BasePlan. Returnerer navnet på baseplan.",
                CheckTrafficLight = Constants.Printout,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.14",
                CheckCategory = "Base Plan",
                CheckName = "Base Plan bidrag i %",
                CheckTemplateValue = chosenEclipseTemplate.TemplateBasePlanContribution,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Hvis planen har en baseplan, returnerer estimert dosebidrag i prosent fra baseplan basert på fraksjoneringen.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelFractionationExist
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.15",
                CheckCategory = "Fluence",
                CheckName = "Fluence_Max fra IMRT-felt",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Info",
                CheckExplanation = "Henter ut max fluence for alle felt og viser dem.",
                CheckTrafficLight = Constants.Printout,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
            });
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.16",
                CheckCategory = "Fluence",
                CheckName = "Minste Fluence_Max",
                CheckTemplateValue = ">" + Constants.ToleranceSmallestFluenceMaxVAlue.ToString(),
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Henter ut max fluence for alle felt, sjekker om den minste av dem er < " + Constants.ToleranceSmallestFluenceMaxVAlue + ".",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
            });
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.17",
                CheckCategory = "Couchvinkel",
                CheckName = "Couchvinkel",
                CheckTemplateValue = Constants.False,
                CheckVerification = "False",
                CheckType = "Info",
                CheckExplanation = "Sjekker om det er couchvinkel satt på (!=0). False/True. Gir vinkelen i kommentar under.",
                CheckTrafficLight = Constants.OBS,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });
            //Doseratesjekk avhengig av energi (og FFF), sjekkes alltid.
            //Fylle opp templatverdi med forventede verdier for FeltListen? Dette gjør vi når vi går igjennom sjekken.
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.18",
                CheckCategory = "Doserate",
                CheckName = "Doserate",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om doserate er satt rett for energien. Sjekkes mot en mal med standard doserate per energi, også avhengig av maskintype (feks. TB vs Halcyon)",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist
            });


            //Sjekk av Extended avhengig av lateralitet og gantryvinkel.
            //Denne må ses på. per nå kun til info.
            match = fieldList.FirstOrDefault(stringToCheck => stringToCheck.FieldExtended == Constants.True);
            if (match != null)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.19",
                CheckCategory = "Gantryvinkel Extended",
                CheckName = "Gantryvinkel er Extended",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Info",
                CheckStatus = Constants.Info,
                CheckExplanation = "Informerer om at minst en gantryvinkel er extended i denne plan.",
                CheckTrafficLight = Constants.Printout,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            }); 
            


            bool bakfrafelt_bool = PlanExtension.Does180DegreeStaticFieldExist(techniqueName, fieldList);
            // Sjekker om bakgrafelt burde ha extended eller ikke. Komplisert da den må se på gantryvektingen av øvrige felt, lateralitet og pasientorientering, blant annet. Burde kanskje også ha egens sjekk på lateralitet.
            if (((bakfrafelt_bool) || (match != null)) && (!_match_Hal && !_match_Eth)) //Ikke nødvendig sjekk hvis Halcyon og Ethos.                                                                 //vekting_gantryvinkel.VinkelWarning == Konstanter.True
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.20",
                CheckCategory = "Bakfrafelt / Gantryvinkel Extended",
                CheckName = "Bakfrafelt og Extended-status",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om 'Extended'-status på bakfrafelt er optimal med tanke på:" + Environment.NewLine + " 1) Lateralitet for plan, hvis relevant*. " + Environment.NewLine + "2) Gantryvinkel-vekting for alle øvrige felt (mer mot 90 eller 270 grader)." + Environment.NewLine + " *Lateralitet antas ut fra isosenterflytt vs UserOrigin (antatt senter av bilde) ved HeadFirstSupine, HeadFirstProne, FeetFirstSupine eller FeetFirstProne orientering.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });


            checkDiscardedAtRuntime = Constants.False; //Default 
       //SHOULD ADD: set checkDiscardedAtRuntime = True if not necessary to run check so we dont spam checklist.
       //Only run when Field-in-Field technique exists? - suggestion for code:
            bool existFiF = PlanExtension.CheckIfPlanContainsFiF(patientContext.ChosenPlan, patientContext); //Add own code here for checking if plan has an FiF fields.
            // Remove check if not necessary: 
            //if (existFiF)                                                    
            //{
            //    checkDiscardedAtRuntime = Constants.False;
            //}
            //else
            //{
            //    checkDiscardedAtRuntime = Constants.True;
            //}

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = _sjekklisteKategori,
                CheckNumber = "4.21",
                CheckCategory = "Teknikk",
                CheckName = "Field-in-field-felt slått sammen",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker at alle felt som skulle vært slått sammen field-in-field er gjort det. Detter er basert på antagelsen om at hvis to eller flere felt har samme energi, samme gantryvinkel, samme kollimatoråpning, og samme kollimatorvinkel, så skulle de vært slått sammen.",
                CheckTrafficLight = Constants.Ok,
                CheckTaskName = "Doseplan;Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });


            //-------------------------------------------
            //-------------------------------------------
            //-------------------------------------------

            return checkPointList;
        }

        public static List<CheckPoint> CreateCourseCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplate)
        {

            //List of checkpoints
            List<CheckPoint> checkPointList = new List<CheckPoint>();

            //-------------------------------------------
            //---------   Course generelt   -------------
            //-------------------------------------------
            string checkListCategory = "Course";
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "1.1",
                CheckCategory = "Intensjon",
                CheckName = "Intensjon",
                CheckTemplateValue = chosenEclipseTemplate.TemplateIntent,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om intensjonen er korrekt i henhold til templatet",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelCourseExist
            });
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "1.2",
                CheckCategory = "Diagnose",
                CheckName = "Diagnose",
                CheckTemplateValue = chosenEclipseTemplate.TemplateDiagnosis,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om diagnosen er korrekt i henhold til templatet.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelCourseExist
            });
            return checkPointList;
        }

        public static List<CheckPoint> CreateCTAndStructuresCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplate)
        {
            //List of checkpoints
            List<CheckPoint> checkPointList = new List<CheckPoint>();
            //-------------------------------------------
            //------- CT og strukturer generelt   -------
            //-------------------------------------------

            string checkListCategory = "CT og strukturer";

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "2.1",
                CheckCategory = "CT",
                CheckName = "UserOrigin:",
                CheckTemplateValue = "", //Independent of template
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om User Origin er lagt inn, og ev. avstand fra markører. Gir varsel hvis UserOrigin ikke er endret fra default. Gir varsel hvis markører ikke detekteres (krever et punkt med over " + Constants.MarkerFoundCriteriaHUValue + "HU mindre enn " + Constants.NumberOfPixelsInsideBodySearch + " pixler inn i body, eller opptil " + Constants.NumberOfPixelsOutsideBodySearch +   " pixler utenfor body). Søket strekker seg i alle kombinasjoner av +/-" + Constants.NumberOfPixelsInSearch_Y + " pixler i y-retning, og +/-" + Constants.NumberOfSlizesInSearch + " i begge Z-retning. Skript gir varsel hvis UserOrigin er satt mer enn " + Constants.ToleranceMarkerPositionDifferenceMm + "mm fra markør",
                CheckTrafficLight = Constants.Warning, //If not placed, Error, Warning if not optimal 
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist,
                CalculateLate = true
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "2.2",
                CheckCategory = "CT",
                CheckName = "CT Slice Thickness",
                CheckTemplateValue = chosenEclipseTemplate.TemplateCTSliceThickness,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om CT slice thickness (bildeoppløsning i z-retning) er som forventet. Oppgis i mm.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelImageExist
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "2.3",
                CheckCategory = "Strukturer",
                CheckName = "Bordtopp", //  "BordtoppSurface"
                CheckTemplateValue = chosenEclipseTemplate.TemplateCouchName + "!!!!" + chosenEclipseTemplate.TemplateCouchHU, //Separate couchNames and HU values with "!!!!". A bit silly, but should work. 
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om Couch er lagt inn, og med rett HU",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist
            });
            //Avhengig av det forrige punktet? Hva skjer hvis ingen bord?
            //checkPointList.Add(new CheckPoint()
            //{
            //    CheckListCategory = checkListCategory,
            //    CheckNumber = "2.4",
            //    CheckCategory = "Strukturer",
            //    CheckName = "BordtoppSurface HU",
            //    CheckTemplateValue = chosenEclipseTemplate.TemplateCouchHU,
            //    CheckVerification = "False",
            //    CheckType = "Sjekk",
            //    CheckExplanation = "Sjekker om bordtoppSurface har korrekt HU",
            //    CheckTrafficLight = Constants.Error,
            //    CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
            //    CheckInvisibleUnlessWarningOrError = Constants.False,
            //    CheckInactivated = Constants.False,
            //    CheckDiscardedAtRuntime = "",
            //    CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist
            //});

            checkPointList.Add(new CheckPoint() //Fjerne hvis det ikke er tomme?
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "2.5",
                CheckCategory = "Strukturer",
                CheckName = "Tomme strukturer",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Info",
                CheckExplanation = "Sjekker om det finnes tomme strukturer i struktursettet.",
                CheckTrafficLight = Constants.Info,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist
            });

            //checkPointList.Add(new CheckPoint() //Fjerne hvis det ikke er tomme?
            //{
            //    CheckListCategory = checkListCategory,
            //    CheckNumber = "2.6",
            //    CheckCategory = "Strukturer",
            //    CheckName = "Marginer",
            //    CheckTemplateValue = "",
            //    CheckVerification = "False",
            //    CheckType = "Info",
            //    CheckExplanation = "Sjekker marginer. Kun testing per nå.",
            //    CheckTrafficLight = Constants.Info,
            //    CheckTaskName = "Fysiker|Doseplan",
            //    CheckInvisibleUnlessWarningOrError = Constants.False,
            //    CheckInactivated = Constants.False,
            //    CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist
            //});

            checkPointList.Add(new CheckPoint() //Fjerne hvis det ikke er tomme?
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "2.6",
                CheckCategory = "Strukturer",
                CheckName = "HR strukturer",
                CheckTemplateValue = chosenEclipseTemplate.TemplateMandatoryHighResolutionStructureIDs,
                CheckVerification = "False",
                CheckType = "Info",
                CheckExplanation = "Sjekker om fornuftige strukturer i struktursettet er satt til High Resolution. Henter en liste fra templatet av Mandatory HighResolution Structures. Disse må ha HighResolution hvis de eksisterer. " + Environment.NewLine + "I tillegg sjekker den at strukturer med for stort volum (" + Constants.ShouldNotBeHighResolutionStructureIfVolumeHigherThanCm3 + "cm3) ikke har HighResolution. " + Environment.NewLine + "Det er en egen kode for STEREOTAKSI-templater: alle target strukturer skal ha HighResolution. Organ-strukturer som er < " + +Constants.HighResolutionStructureIfDistanceLessThanCm + " cm fra et målvolum kan vurderes å ha HighResolution (så lenge de er organer og 'ikke for store', definert som " + Constants.ShouldNotBeHighResolutionStructureShortDistanceFromTargetIfVolumeHigherThanCm3 + " cc)." + Environment.NewLine +  "Avstand markert i tabell kan være enda nærmere når den allerede er < " + Constants.HighResolutionStructureIfDistanceLessThanCm + "cm.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist
            });


            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "2.7",  //"7.10"
                CheckCategory = "CT",
                CheckName = "CT mangler ikke snitt",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker at det ikke mangler CT-snitt",
                CheckTrafficLight = Constants.Warning, //Constants.Ok
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelStructureSetExist //Constants.SanityLevelPlanExist
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckResultValue = "Regn ut",  //Value until calculation is done.
                CheckNumber = "2.8",
                CheckCategory = "Strukturer",
                CheckName = "HU i PTV > -850",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekken identifiserer voxler i PTV som har HU < -850 og som ikke er dekket av en struktur med tildelt HU-verdi. Hvis slike voxler finnes, varsler den om potensiell mangel på HU-korreksjon i lavdensitetsområder av PTV.",
                CheckTrafficLight = Constants.Ok, //Wrong. CHANGE TO: Warning
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist,
                CalculateLate = true, //Calculate this check last when view is loading checkpoints. Do all 'quicker' checks before this one. This is only matters for checks that are not set to 'CalculateDelayed=true'.
                CalculateDelayed = true //Only calculate after excplicitly pressing 'Regn ut' button.
            });


            return checkPointList;
        }

        public static List<CheckPoint> CreatePlanCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplate)
        {

            //List of checkpoints
            List<CheckPoint> checkPointList = new List<CheckPoint>();


            string checkDiscardedAtRuntime = Constants.False;

            //-------------------------------
            //--------- Plan ----------------
            //-------------------------------
            string checkListCategory = "Plan";
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.1",
                CheckCategory = "Fraksjonering",
                CheckName = "Fraksjonering",
                CheckTemplateValue = chosenEclipseTemplate.TemplateFractionations,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om hovedfraksjonering er standard i henhold til templatet. Denne sjekken kan ikke sammenligne med rekvisisjon. Se også refktliste for sekundær refpkt.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelFractionationExist
            }); //ColorSet = "Green"
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.2",
                CheckCategory = "Normalisering",
                CheckName = "Normalisering",
                CheckTemplateValue = chosenEclipseTemplate.TemplateNormalization,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om Normaliseringen er satt rett",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            }); //ColorSet = "Green"
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.3a",
                CheckCategory = "Kalkulering",
                CheckName = "Beregningsalgoritme",
                CheckTemplateValue = chosenEclipseTemplate.TemplateCalculationAlgorithm,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om beregningsalgoritmen er satt rett",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            }); //ColorSet = "Green"

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.3b",
                CheckCategory = "Kalkulering",
                CheckName = "Kalkuleringsoppløsning (cm)",
                CheckTemplateValue = chosenEclipseTemplate.TemplateCalculationResolution,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om kalkuleringsoppløsningen er i henhold til templatet. Hentes ut ved å sjekke kalkuleringsoppløsning i X-retning, i cm.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelCalculatedDoseExist //Checks the actual dose matrix
            }); //ColorSet = "Green"

            //Hva skjer om multiple toleransetabeller? Lag liste.
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.4a",
                CheckCategory = "Toleransetabell",
                CheckName = "Toleransetabell beh.felt",
                CheckTemplateValue = chosenEclipseTemplate.TemplateToleranceTableTreat,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om rett Toleransetabell er lagt inn rett for behandlingsfelt iht. templat.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist 
            });
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.4b",
                CheckCategory = "Toleransetabell",
                CheckName = "Toleransetabell setupfelt",
                CheckTemplateValue = chosenEclipseTemplate.TemplateToleranceTableSetup,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om rett Toleransetabell er lagt inn rett for isofelt iht. templat.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            //Hva skjer om multiple toleransetabeller? Lag liste.
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.5a",
                CheckCategory = "Setupfelt",
                CheckName = "Antall setupfelt",
                CheckTemplateValue = chosenEclipseTemplate.TemplateNumberOfSetupFields,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om rett det er lagt inn setupfelt. Vanligvis 4 stk, men noen unntak. Feks Ethos og Halcyon maskin, samt stereotaksier trenger kun 1. Total hjerne trenger kun 2. ",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.5b",
                CheckCategory = "Setupfelt",
                CheckName = "Antall bolus setupfelt",
                CheckTemplateValue = ">0",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om det er lagt inn minst ett bolus setupfelt hvis det er boluser attached til feltene." + Environment.NewLine + "Hvis det er en strukturbolus, vil ikke denne sjekken komme opp fordi bolus er ikke koblet til feltene." + Environment.NewLine + "Det er unntak for elektronfelt, da elektronfelt ikke trenger bolusfelt.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist,
                CheckDebug = "Kode ikke testet på elektronplaner."
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.6",
                CheckCategory = "PasientOrientering",
                CheckName = "PasientOrientering",
                CheckTemplateValue = chosenEclipseTemplate.TemplatePatientOrientation, //PatientOrientation.HeadFirstSupine.ToString(),
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om pasientorienteringen er som forventet iht. templat.",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist //Checked on plan level, not on Image level // Should there be a check on Image level integrated here?
            });

            checkPointList.Add(new CheckPoint()
            {
                //Leggt til dette sjekkpunkt kun hvis planen viser lateralitet??  Relevant for Mamma, Lunge, ØNH. For lunge kan det vaere ho, ve og medialt...
                CheckListCategory = checkListCategory,
                CheckNumber = "3.7",
                CheckCategory = "Lateralitet",
                CheckName = "Lateralitet",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                //CheckSettings = Constants.SjekkSettingsMedium,
                CheckExplanation = "Sjekker lateraliteten til planen ut ifra isosenterplassering." + Environment.NewLine + "Sammenligner også med lateralitet i PlanID og TargetVolume ID. Koden leter etter '_L', 'Ve', '_R' eller 'Ho' i slutten av planID, eller '_L' eller 'Ho' i PTV-struktur. ",
                CheckTrafficLight = Constants.Info,
                CheckDebug = "Antar User Origin er i senter av pasient, ikke testet utenom standard pasientorienteringer. Kan finnes '_L' etc i plannavn, uten at det gjelder lateralitet, kan referer til feks Lumbalkolumna...",
                CheckTaskName = "Fysiker|Doseplan",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist,
            }); ; //ColorSet = "Green"


            //Mobius
            if (Directory.Exists(Constants.MobiusPath))
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }


            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.8",
                CheckCategory = "Mobius",
                CheckName = "Mobius",
                CheckTemplateValue = Constants.True,
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om det finnes Mobius-fil med sekundær beregning generert på pasient. Hvis plannavnet er endret i etter at plan ble sendt til Mobius vil den ikke finne filen.",
                CheckTrafficLight = Constants.Warning,
                CheckTaskName = "Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist //Need plan name to check file name. Technically does not make sense to check before after calculation. If dose is cleared after sendt to Mobius it could be a new plan with same name. Keep as reminder: //Constants.SanityLevelCalculatedDoseExist
            }); ;
            
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.9",
                CheckCategory = "Godkjenning",
                CheckName = "Plan Uncertainties",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = Constants.Info,
                CheckExplanation = "Viser om/hvilke plan uncertainties som er lagt til i planen ",
                CheckTrafficLight = Constants.Info,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });


            //See SUS specific checkpoints further down


            return checkPointList;

        }

        public static List<CheckPoint> CreateReferencePointCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplate)
        {

            //List of checkpoints
            List<CheckPoint> checkPointList = new List<CheckPoint>();

            string PTVIDList_Template = chosenEclipseTemplate.TemplatePTVStructureIDs;
            string PlanIDList_Template = chosenEclipseTemplate.TemplatePlanIDs;
            string CTVIDList_Template = chosenEclipseTemplate.TemplateCTVStructureIDs;

            bool sekvplanExisterer;
            string sekv_planer = "";
            string felles_ref_pkt = "";
            string checkDiscardedAtRuntime = Constants.False;

            //-------------------------------------------
            //-------- -Referansepunkt ----------------
            //-------------------------------------------
            string checkListCategory = "Refpkt";
            checkPointList.Add(new CheckPoint()
            {

                CheckListCategory = checkListCategory,
                CheckNumber = "5.1",
                CheckCategory = "Referansepunkt",
                CheckName = "Primært referansepunkt lik Target Structure",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om Primært referansepunkt har en tilsvarende struktur, og at det stemmer med templatet. Sier uansett ifra om referansepunkt og struktur ikke har samme navn. Den sjekker samtidig mot templatet om navnet er som forventet.",
                CheckTrafficLight = Constants.Warning,
                CheckTemplateValue = PTVIDList_Template,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });
            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "5.2",
                CheckCategory = "Referansepunkt",
                CheckName = "Sekundære referansepunkt lik strukturnavn",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Hvis Default-templat: Sjekker om alle sekundære referansepunkt har en tilsvarende struktur. " + Environment.NewLine + "Hvis annet templat: Går igjennom liste av PTV-strukturer som eksisterer, og leter etter tilsvarende refpkt.",
                CheckTrafficLight = Constants.Warning,
                CheckTemplateValue = PTVIDList_Template,
                CheckTaskName = "Fysiker|Doseplan|BasicPlanCheck",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.False,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist,
                CheckResultValue = "",
            });



            sekvplanExisterer = PlanExtension.SequentialPlanExist(patientContext);
            // Itererer gjennom alle planer i samme course (tempplan) og sjekker for revisjon og sekvensielle planer
            

            //legger inn sjekkpunkt hvis det eksisterte sekv. planer el. revisjoner
            if (sekvplanExisterer == true)
            {
                checkDiscardedAtRuntime = Constants.False;
            }
            else
            {
                checkDiscardedAtRuntime = Constants.True;
            }

            checkListCategory = "Refpkt";
                checkPointList.Add(new CheckPoint()
                {
                    CheckListCategory = checkListCategory,
                    CheckNumber = "5.3",
                    CheckCategory = "Finnes sekvensiell plan eller planrevisjoner",
                    CheckName = "Finnes bidrag fra annen plan til felles referansepunkt",
                    CheckTemplateValue = "",
                    CheckResultValue = Constants.True,
                    CheckComment = "Andre planer som bidrar til samme referansepunkt: " + sekv_planer + Environment.NewLine + "Felles referansepunkt: " + felles_ref_pkt,
                    CheckVerification = "False",
                    CheckType = Constants.Info,
                    CheckExplanation = "Sjekker om det finnes sekviensielle planer eller planrevisjoner. Sjekker om andre planer gir bidrag til referansepunktene på denne planen. Koden bruker dette videre.",
                    CheckTrafficLight = Constants.Printout,
                    CheckStatus = Constants.Printout,
                    CheckTaskName = "Fysiker",
                    CheckInvisibleUnlessWarningOrError = Constants.False,
                    CheckInactivated = Constants.False,
                    CheckDiscardedAtRuntime = checkDiscardedAtRuntime,
                    CheckSanityLevelRequired = Constants.SanityLevelPlanExist,
                }); ; ;



            return checkPointList;
        }


        public static List<CheckPoint> CreateDVHCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplate, FieldsAnalysis fieldsAnalysis )
        {

            //List of checkpoints
            List<CheckPoint> checkPointList = new List<CheckPoint>();

            //Set variables
            string templateName = chosenEclipseTemplate.TemplateName;
            string PTVIDsList_Template = chosenEclipseTemplate.TemplatePTVStructureIDs;
            string CTVIDsList_Template = chosenEclipseTemplate.TemplateCTVStructureIDs;

            switch (templateName)
            {
                //--------------------------------------------------------------
                //--------    Just for documentation (adding a fake demand)  -------------------
                //--------------------------------------------------------------
                case "zzDocumentation":
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<", "%", _ToleranseAdv: 107)); //used to generate checkpoint for documentation
                    break;
                //--------------------------------------------------------------
                //--------    TemplatSpesifikke DVH-krav     -------------------
                //--------------------------------------------------------------

                case "Mamma":
                    //Needs update after introducing SIB! Should change to Gy and not % for each type of ptv structure, boost or chest/breast. 
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<", "%", _ToleranseAdv: 107)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "%", "BODY|Body", "<", "%", _pValue: 105, _ToleranseAdv: 2)); //rettet bug 15.11.2024 breped
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", PTVIDsList_Template, "<", "%", _ToleranseAdv: 107));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "%", PTVIDsList_Template, "<", "%", _pValue: 105, _ToleranseAdv: 2));
                    //checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", PTVIDsList_Template, ">=", "%", _pValue: 98, _ToleranseAdv: 90));
                    //checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", CTVIDsList_Template, ">=", "%", _pValue: 98, _ToleranseAdv: 95));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", "PTV_Breast_L_40|PTV_Breast_R_40|PTV_Chestw_L_40|PTV_Chestw_R_40", ">=", "Gy", _pValue: 98, _ToleranseAdv: 36.05));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", "CTV_Breast_L_40|CTV_Breast_R_40|CTV_Chestw_L_40|CTV_Chestw_R_40", ">=", "Gy", _pValue: 98, _ToleranseAdv: 38.05));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", "CTV_Tumbed_L_48|CTV_Tumbed_R_48", ">=", "Gy", _pValue: 98, _ToleranseAdv: 45.6));
                    break;

                case "Lunge_kurativ":


                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<", "%", _ToleranseAdv: 110)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "%", "BODY|Body", "<", "cc", _pValue: 110, _ToleranseAdv: 2));

                    break;

                case "Total_Hjerne":


                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "%", "CTV_Brain*|CTV*", "<=", "cc", _pValue: 95, _ToleranseAdv: 2));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", "CTV_Brain*|CTV*", ">=", "%", _pValue: 98, _ToleranseAdv: 95));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "%", PTVIDsList_Template, "<=", "cc", _pValue: 90, _ToleranseAdv: 2));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "%", PTVIDsList_Template, ">=", "%", _pValue: 98, _ToleranseAdv: 90));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<=", "%", _ToleranseAdv: 110, _ToleranseErr: 115));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "%", "BODY| Body", "<=", "cc", _pValue: 110, _ToleranseAdv: 2));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Mean", "", "LensR*|Lens_R*", "<=", "Gy", _ToleranseAdv: 5));
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Mean", "", "LensL*|Lens_L*", "<=", "Gy", _ToleranseAdv: 5));

                    break;

                    //Alle stereotaksi
                case "Stereotaksi_lunge": case "Stereotaksi_lever": case "Stereotaksi_columna":

                    int antallFr = 0;
                    Double PTV_Volume = 0;
                    string D2cm_toleranse_komm = "";
                    if (patientContext.SanityLevel > Constants.SanityLevelFractionationExist)
                    {
                        ExternalPlanSetup plan = patientContext.ChosenPlan; //sanityLevel is at SanityLevelCalculatedDoseExist, so fractionation should exist too.
                        antallFr = plan.NumberOfFractions ?? default(int);


                        //ONly set if TargetStructure Exist!!
                        if (plan.TargetVolumeID != null)
                        {
                            PTV_Volume = Math.Round(plan.StructureSet.Structures.Where(x => x.Id == plan.TargetVolumeID).FirstOrDefault().Volume, 2);
                            D2cm_toleranse_komm = "Toleranse avhengig av PTV-volum. " + plan.TargetVolumeID + " volum = " + PTV_Volume + " cc.";
                        }
                        else
                        {
                            PTV_Volume = 19;
                            D2cm_toleranse_komm = "Toleranse er avhengig av PTV-volum. Klarte ikke å finne Target Volume! Antar PTV volum " + PTV_Volume + "cc (<20cc)! Kontroller manuelt!";
                        }
                        
                        
                        
                        
                    }


                    
                    ///--------- Setter toleranser som er volumavhengige -------------
                    Double D2cm_toleranse_adv = 55;
                    Double D2cm_toleranse_abs = 60;

                    
                    if (PTV_Volume <= 20)
                    {
                        D2cm_toleranse_adv = 65;
                        D2cm_toleranse_abs = 75;
                    }
                    else if (PTV_Volume <= 40 && PTV_Volume > 20)
                    {
                        D2cm_toleranse_adv = 70;
                        D2cm_toleranse_abs = 80;
                    }
                    else
                    {
                        D2cm_toleranse_adv = 70;
                        D2cm_toleranse_abs = 80;
                    }
                    //-----------------------------------------------------------

                    //Minimumvolum
                    checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Volume", "cc", PTVIDsList_Template, ">=", "cc", _ToleranseAdv: 6));

                    if (antallFr == 3)
                    {

                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<", "%", _ToleranseAdv: 140)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "D2cm", "<", "%", _ToleranseAdv: D2cm_toleranse_adv, _ToleranseErr: D2cm_toleranse_abs, _Kommentar: D2cm_toleranse_komm)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "SpinalCanal", "<", "Gy", _pValue: 0.035, _ToleranseAdv: 20.1));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "spinalCanalPRV", "<", "Gy", _pValue: 0.035, _ToleranseAdv: 20.1, _ToleranseErr: 20.3));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Esophagus", "<", "Gy", _pValue: 0.1, _ToleranseErr: 25.2));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Esophagus", "<", "Gy", _pValue: 5, _ToleranseErr: 18));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Heart", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 26.1, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Heart", "<", "Gy", _pValue: 15, _ToleranseErr: 24));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ArterPulmonalis", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 26.1, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ArterPulmonalis", "<", "Gy", _pValue: 15, _ToleranseErr: 24));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "A_Subclavian", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 26.1, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "A_Subclavian", "<", "Gy", _pValue: 15, _ToleranseErr: 24));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Aorta", "<", "Gy", _pValue: 0.1, _ToleranseErr: 45));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Aorta", "<", "Gy", _pValue: 10, _ToleranseErr: 39));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "VenaCava", "<", "Gy", _pValue: 0.1, _ToleranseErr: 45));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "VenaCava", "<", "Gy", _pValue: 10, _ToleranseErr: 39));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Trachea", "<", "Gy", _pValue: 0.1, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ProxBronkialtre", "<", "Gy", _pValue: 0.1, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ProxBronchus_PRV", "<", "Gy", _pValue: 0.1, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Skin", "<", "Gy", _pValue: 0.1, _ToleranseErr: 33));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Skin", "<", "Gy", _pValue: 10, _ToleranseErr: 30));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "PlexusBrachialis", "<", "Gy", _pValue: 0.1, _ToleranseErr: 24));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungsSubITV|Lung", "<", "%", _pValue: 20, _ToleranseAdv: 10, _ToleranseErr: 15));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Mean", "", "LungsSubITV|Lungs", "<", "Gy", _ToleranseAdv: 8));
                        if (fieldsAnalysis.PlanLaterality == Constants.Hoyre)
                        {
                            checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungLft|Lung_L", "<", "%", _pValue: 5, _ToleranseAdv: 5, _ToleranseErr: 10));
                        }
                        if (fieldsAnalysis.PlanLaterality == Constants.Venstre)
                        {
                            checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungRgt|Lung_R", "<", "%", _pValue: 5, _ToleranseAdv: 5, _ToleranseErr: 10));
                        }
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Brystvegg/costa", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 36.9)); //Maksdose til costae, bruker brystvegg
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Brystvegg/costa", "<", "Gy", _pValue: 1, _ToleranseAdv: 28.8)); //Maksdose til costae, bruker brystvegg
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "Brystv/costaOut|Brystvegg/costa", "<", "cc", _pValue: 30, _ToleranseAdv: 30, _ToleranseErr: 100)); //Dose til et volum av brystvegg  //måtte korrigerer rEnhet til cc!

                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "Gy", "Liver|LiverSubPTV", ">=", "cc", _pValue: 15, _ToleranseAdv: 700));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "Gy", "Liver|LiverSubPTV", ">=", "cc", _pValue: 17, _ToleranseErr: 700));

                    }
                    if (antallFr == 5)
                    {

                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<", "%", _ToleranseAdv: 140)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "D2cm", "<", "%", _ToleranseAdv: D2cm_toleranse_adv, _ToleranseErr: D2cm_toleranse_abs, _Kommentar: D2cm_toleranse_komm));//TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "SpinalCanal", "<", "Gy", _pValue: 0.035, _ToleranseAdv: 25));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "spinalCanalPRV", "<", "Gy", _pValue: 0.035, _ToleranseErr: 25));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Esophagus", "<", "Gy", _pValue: 0.1, _ToleranseErr: 35));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Esophagus", "<", "Gy", _pValue: 5, _ToleranseErr: 20));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Heart", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 29, _ToleranseErr: 38));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Heart", "<", "Gy", _pValue: 15, _ToleranseErr: 32));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ArterPulmonalis", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 29, _ToleranseErr: 38));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ArterPulmonalis", "<", "Gy", _pValue: 15, _ToleranseErr: 32));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "A_Subclavian", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 29, _ToleranseErr: 38));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "A_Subclavian", "<", "Gy", _pValue: 15, _ToleranseErr: 32));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Aorta", "<", "Gy", _pValue: 0.1, _ToleranseErr: 53));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Aorta", "<", "Gy", _pValue: 10, _ToleranseErr: 47));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "VenaCava", "<", "Gy", _pValue: 0.1, _ToleranseErr: 53));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "VenaCava", "<", "Gy", _pValue: 10, _ToleranseErr: 47));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Trachea", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 35, _ToleranseErr: 38));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ProxBronkialtre", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 35, _ToleranseErr: 38));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ProxBronchus_PRV", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 35, _ToleranseErr: 38));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Skin", "<", "Gy", _pValue: 0.1, _ToleranseErr: 39.5));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Skin", "<", "Gy", _pValue: 10, _ToleranseErr: 36.5));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "PlexusBrachialis", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 30.5, _ToleranseErr: 32));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungsSubITV|Lung", "<", "%", _pValue: 20, _ToleranseAdv: 10, _ToleranseErr: 15));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Mean", "", "LungsSubITV|Lungs", "<", "Gy", _ToleranseAdv: 8));
                        if (fieldsAnalysis.PlanLaterality == Constants.Hoyre)
                        {
                            checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungLft|Lung_L", "<", "%", _pValue: 5, _ToleranseAdv: 5, _ToleranseErr: 10));
                        }
                        if (fieldsAnalysis.PlanLaterality == Constants.Venstre)
                        {
                            checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungRgt|Lung_R", "<", "%", _pValue: 5, _ToleranseAdv: 5, _ToleranseErr: 10));
                        }
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Brystvegg/costa", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 43)); //Maksdose til costae, bruker brystvegg
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Brystvegg/costa", "<", "Gy", _pValue: 1, _ToleranseAdv: 35)); //Maksdose til costae, bruker brystvegg
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "Brystv/costaOut|Brystvegg/costa", "<", "cc", _pValue: 30, _ToleranseAdv: 30, _ToleranseErr: 100)); //Dose til et volum av brystvegg  //måtte korrigerer rEnhet til cc!

                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "Gy", "LiverSubPTV|Liver", ">=", "cc", _pValue: 15, _ToleranseErr: 700, _Kommentar: "Liver lesions. "));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "Gy", "Liver|LiverSubPTV", ">=", "cc", _pValue: 21, _ToleranseErr: 700, _Kommentar: "Non-Liver lesions. "));

                    }
                    if (antallFr == 8)
                    {
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "BODY|Body", "<", "%", _ToleranseAdv: 140)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Max", "%", "D2cm", "<", "%", _ToleranseAdv: D2cm_toleranse_adv, _ToleranseErr: D2cm_toleranse_abs, _Kommentar: D2cm_toleranse_komm)); //TrafikkLys, prefix, prefix enhet, strukturID, operator, resultat enhet, opt advarselTol, opt errorTol
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "spinalCanalPRV|SpinalCanalPRV", "<", "Gy", _pValue: 0.035, _ToleranseAdv: 28, _ToleranseErr: 32));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Esophagus", "<", "Gy", _pValue: 0.1, _ToleranseErr: 40));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Heart", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 40, _ToleranseErr: 45.6));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ArterPulmonalis", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 40, _ToleranseErr: 45.6));
                        //_sjekkpunktliste.Add(PlanCheckTemplates.LeggTilDVHSjekkPunkt(Konstanter.Warning, "D", "cc", "A_Subclavian", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 40, _ToleranseErr: 45.6));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Aorta", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 60, _ToleranseErr: 64.8));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "VenaCava", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 60, _ToleranseErr: 64.8));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Trachea", "<", "Gy", _pValue: 0.1, _ToleranseErr: 40));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "ProxBronkialtre", "<", "Gy", _pValue: 0.1, _ToleranseErr: 40));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Skin", "<", "Gy", _pValue: 0.1, _ToleranseErr: 48));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Skin", "<", "Gy", _pValue: 10, _ToleranseErr: 44));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "PlexusBrachialis", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 34.4, _ToleranseErr: 38.4));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungsSubITV|Lung", "<", "%", _pValue: 20, _ToleranseAdv: 10, _ToleranseErr: 15));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "Mean", "", "LungsSubITV|Lungs", "<", "Gy", _ToleranseAdv: 8));
                        if (fieldsAnalysis.PlanLaterality == Constants.Hoyre)
                        {
                            checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungLft|Lung_L", "<", "%", _pValue: 5, _ToleranseAdv: 5, _ToleranseErr: 10));
                        }
                        if (fieldsAnalysis.PlanLaterality == Constants.Venstre)
                        {
                            checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "LungRgt|Lung_R", "<", "%", _pValue: 5, _ToleranseAdv: 5, _ToleranseErr: 10));
                        }
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Brystvegg/costa", "<", "Gy", _pValue: 0.1, _ToleranseAdv: 43)); //Maksdose til costae, bruker brystvegg
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "D", "cc", "Brystvegg/costa", "<", "Gy", _pValue: 1, _ToleranseAdv: 35)); //Maksdose til costae, bruker brystvegg
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "V", "Gy", "Brystv/costaOut|Brystvegg/costa", "<", "cc", _pValue: 30, _ToleranseAdv: 30, _ToleranseErr: 100)); //Dose til et volum av brystvegg  //måtte korrigerer rEnhet til cc!

                        //_sjekkpunktliste.Add(PlanCheckTemplates.LeggTilDVHSjekkPunkt(Konstanter.Warning, "CV", "Gy", "Liver;LiverSubPTV", ">=", "cc", _pValue: 15, _ToleranseAdv: 700));
                        checkPointList.Add(CheckPointExtension.AddDvhCheckPoint(Constants.Warning, "CV", "Gy", "Liver|LiverSubPTV", ">=", "cc", _pValue: 21.6, _ToleranseErr: 700));

                        //SpinalCord vs SpinalCanal? Cauda Equina?
                        //Chestwall, BowelSmall, BowelLargem Rektum, Bladder wall, Stomach, Kidneys, Ureter, Penile bulb, FemoralHead_L, FemoralHead_R.
                        // Ingen brystvegggrenser?  //Brystvegg/costa

                    }

                    break;

            }
   
            return checkPointList;
        }

        public static List<CheckPoint> CreateSUSCheckPointList(PatientContext patientContext, EclipseCheckTemplate chosenEclipseTemplate)
        {
            //---Moved checkPoints---:
            //"Field-in-field slått sammen" in Technique category.
            //"Plan Uncertainties" in Plan category
            //"CT mangler ikke snitt" in CTAndStructures
            //"HU i PTV er alle > -850" in CTAndStructures

            List<CheckPoint> checkPointList = new List<CheckPoint>();

            string checkListCategory = "Plan"; //These particular ones will be added to "Plan" category. Others that are more generic are added to the relevant classes.


            //--------------------
            // SUS specific checkpoints:
            //--------------------


            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.10",
                CheckCategory = "SUS",
                CheckName = "Rekvisisjon godkjent?",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om rekvisisjon er godkjent.",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist



            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.11",
                CheckCategory = "SUS",
                CheckName = "Doseplannummer",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om doseplannummer er formatert korrekt",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist


            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.12",
                CheckCategory = "SUS",
                CheckName = "Formatering plan og felt-navn",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om plannavn og feltnavn er formatert korrekt",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist

            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.13",
                CheckCategory = "SUS",
                CheckName = "Plan har portal dose plan",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om det er en tilsvarende portal dose QA plan lagt til hvis plan er VMAT/IMRT",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist

            });


            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.14",
                CheckCategory = "SUS",
                CheckName = "Plan godkjent og reviewed?",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om plan er godkjent og reviewed",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.15",
                CheckCategory = "SUS",
                CheckName = "Plan satt unapproved etter reviewed?",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om plan er satt i unapproved etter reviewed",
                CheckTrafficLight = Constants.Error,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });



            checkPointList.Add(new CheckPoint()
            {
                CheckListCategory = checkListCategory,
                CheckNumber = "3.16",
                CheckCategory = "SUS",
                CheckName = "Antall behandlinger",
                CheckTemplateValue = "",
                CheckVerification = "False",
                CheckType = "Sjekk",
                CheckExplanation = "Sjekker om antall behandlinger lagt inn plan scheduling samsvarer med antall fraksjoner",
                CheckTrafficLight = Constants.Ok,
                CheckTaskName = "Doseplan|Fysiker",
                CheckInvisibleUnlessWarningOrError = Constants.False,
                CheckInactivated = Constants.True,
                CheckDiscardedAtRuntime = "",
                CheckSanityLevelRequired = Constants.SanityLevelPlanExist
            });

            //--------------------
            // End SUS specific checkpoints
            //--------------------




            return checkPointList;

        }

        //------------------
        //------------------


        #endregion CreateCheckPoint SubMethods

        //public static List<CheckPoint> SetDefaultProgressBarValue(List<CheckPoint> checkPointList)
        //{
        //    //Remove inactivated CheckPoints:
        //    for (int i = checkPointList.Count - 1; i >= 0; i--)
        //    {
        //        //Itererate trough CheckPointList and remove inactive Checkpoints
        //        var s = checkPointList[i];
        //            s.Progress = 0;
        //    }
        //    return checkPointList; //Modified checkpointlist
        //}

        //------------------
        // Helper methods
        //-----------------

        #region HelpMethods

        //remove checkpoints at compile
        public static List<CheckPoint>  RemoveInactivatedCheckpoints(List<CheckPoint> checkPointList) 
        {
            //Remove inactivated CheckPoints:
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                //Itererate trough CheckPointList and remove inactive Checkpoints
                var s = checkPointList[i];
                if (s.CheckInactivated == Constants.True)
                {
                    //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
                    checkPointList.RemoveAt(i);
                }
            }
            return checkPointList; //Modified checkpointlist
        }
        //new, discard checkpoints at runtime:
        public static List<CheckPoint> RemoveDiscardedCheckpoints(List<CheckPoint> checkPointList)
        {
            //Remove inactivated CheckPoints:
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                //Itererate trough CheckPointList and remove inactive Checkpoints
                var s = checkPointList[i];
                if (s.CheckDiscardedAtRuntime != null)
                {
                    if (s.CheckDiscardedAtRuntime == Constants.True)
                    {
                        //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
                        checkPointList.RemoveAt(i);
                    }
                }
            }
            return checkPointList; //Modified checkpointlist
        }

        public static List<CheckPoint> GetDiscardedCheckpoints(List<CheckPoint> checkPointList)
        {
            List<CheckPoint> discardedCheckPoints = new List<CheckPoint>();
            //Remove inactivated CheckPoints:
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                //Itererate trough CheckPointList and remove inactive Checkpoints
                var s = checkPointList[i];
                if (s.CheckDiscardedAtRuntime != null)
                {
                    if (s.CheckDiscardedAtRuntime == Constants.True)
                    {
                        //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
                        discardedCheckPoints.Add(s);
                    }
                }

            }
            return discardedCheckPoints; //Modified checkpointlist
        }

        public static List<CheckPoint> GetInactivatedCheckpoints(List<CheckPoint> checkPointList)
        {
            List<CheckPoint> inactivatedCheckPoints = new List<CheckPoint>();
            //Remove inactivated CheckPoints:
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                //Itererate trough CheckPointList and remove inactive Checkpoints
                var s = checkPointList[i];
                if (s.CheckInactivated == Constants.True)
                {
                    //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
                    inactivatedCheckPoints.Add(s);
                }
            }
            return inactivatedCheckPoints; //Modified checkpointlist
        }

        public static List<CheckPoint> RemoveCheckpointsFailedSanity(List<CheckPoint> checkPointList, PatientContext patientContext)
        {
            //Remove CheckPoints that require higher Sanity Level:
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                //Itererate trough CheckPointList and remove Checkpoints
                var s = checkPointList[i];
                if (patientContext.SanityLevel < s.CheckSanityLevelRequired)
                {
                    checkPointList.RemoveAt(i);
                }
            }
            return checkPointList; //Modified checkpointlist
        }

        public static List<CheckPoint> GetCheckpointsFailedSanity(List<CheckPoint> checkPointList, PatientContext patientContext)
        {
            List<CheckPoint> failedSanityCheckPoints = new List<CheckPoint>();
            //Remove CheckPoints that require higher Sanity Level:
            for (int i = checkPointList.Count - 1; i >= 0; i--)
            {
                //Itererate trough CheckPointList and remove Checkpoints
                var s = checkPointList[i];
                if (patientContext.SanityLevel < s.CheckSanityLevelRequired)
                {
                    failedSanityCheckPoints.Add(s);
                }
            }
            return failedSanityCheckPoints; //Modified checkpointlist
        }

        //discard checkpoints at because of control type
        //public static List<CheckPoint> RemoveFailedControlTypeCheckpoints(List<CheckPoint> checkPointList, string controlType)
        //{
        //    //Remove inactivated CheckPoints:
        //    for (int i = checkPointList.Count - 1; i >= 0; i--)
        //    {
        //        //Itererate trough CheckPointList and remove inactive Checkpoints
        //        var s = checkPointList[i];
        //        if (s.CheckDiscardedAtRuntime != null)
        //        {
        //            if (!s.CheckTaskName.Contains(controlType)) //NOT YET TESTTED
        //            {
        //                //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
        //                checkPointList.RemoveAt(i);
        //            }
        //        }
        //    }
        //    return checkPointList; //Modified checkpointlist
        //}

        //public static List<CheckPoint> GetFailedControlTypeCheckpoints(List<CheckPoint> checkPointList, string controlType)
        //{
        //    List<CheckPoint> failedControlTyopeCheckPoints = new List<CheckPoint>();
        //    //Remove inactivated CheckPoints:
        //    for (int i = checkPointList.Count - 1; i >= 0; i--)
        //    {
        //        //Itererate trough CheckPointList and remove inactive Checkpoints
        //        var s = checkPointList[i];
        //        if (s.CheckDiscardedAtRuntime != null)
        //        {
        //            if (!s.CheckTaskName.Contains(controlType)) //NOT YET TESTTED
        //            {
        //                //What about: s.CheckStatus ==Constants.Ukjent, s.CheckStatus == Constants.Til_info?    or:  s.CheckType == Constants.Info
        //                failedControlTyopeCheckPoints.Add(s);
        //            }
        //        }

        //    }
        //    return failedControlTyopeCheckPoints; //Modified checkpointlist
        //}



        #endregion HelpMethods

    }


}
